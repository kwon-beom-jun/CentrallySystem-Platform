import { defineConfig } from 'vite';
import vue      from '@vitejs/plugin-vue';
import vuetify  from 'vite-plugin-vuetify';

/**
  CORS 문제를 개발 단계에서 “미리” 없애기 위해
  Vue CLI 시절에도 devServer.proxy 로 백엔드(8080) 요청을 우회하는 것이 일반적이지만,
  원본 vue.config.js 코드가 없어서 예시용으로 기본 프록시 규칙을 넣어 둔 것
  백엔드와 포트가 다르면 브라우저 CORS 에러가 나므로 ↓ 와 같은 프록시가 필요

  백엔드가 CORS 헤더를 제대로 내보내면 Vite의 server.proxy 를 써도 되고, 안 써도 됨
  단, 쿠키(JWT · 세션)처럼 withCredentials를 쓰는 경우와 로컬 테스트용 도메인(예: localhost:3000)이 
  CORS 화이트리스트에 포함되지 않은 경우는 프록시를 두는 편이 훨씬 간단
 */
export default defineConfig({
  plugins: [vue(), vuetify({ autoImport: true })],
  resolve: { alias: { '@': '/src' } },
  server : {
    port : 3000,
    proxy: {
      '/api'     : 'http://localhost:8080',
      '/auth'    : 'http://localhost:8080',
      '/hrm'     : 'http://localhost:8080',
      '/receipt' : 'http://localhost:8080'
    }
  },
  build: { outDir: 'dist' }
});
