import { hrmApi } from '@/api/apiConfig';

export default {
  // 부서(팀), 고용형태, 직책 정보 조회 (GET /metadata)
  async getMetadatas() {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("부서(팀), 직책, 고용형태 조회") + "; path=/";
    return await hrmApi.get('/metadata');
  },
};
