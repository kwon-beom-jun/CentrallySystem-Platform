import { hrmApi } from '@/api/apiConfig';

export default {
  // 전체 팀 정보 조회 (GET /teams)
  async getTeams() {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("팀 전체 조회") + "; path=/";
    return await hrmApi.get('/teams');
  },
};
