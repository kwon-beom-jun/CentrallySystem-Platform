import { hrmApi } from '@/api/apiConfig';

export default {
  // 전체 사용자 목록 조회 (GET /users)
  async getUsers(params) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("전체 사용자 조회") + "; path=/";
    return await hrmApi.get('/users', { params });
  },

  // 특정 사용자 조회 (GET /users/{id})
  async getUserById(id) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("특정 사용자 조회") + "; path=/";
    return await hrmApi.get(`/users/${id}`);
  },

  // 전체 사용자 목록 조회 Basic (GET /users)
  async getUsersBasic() {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("전체 사용자 조회") + "; path=/";
    return await hrmApi.get('/users/basic');
  },

  // 여러 사용자 ID를 받아 한 번에 조회 (POST /users/bulk-lookup)
  async getUsersByIds(ids) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("여러 사용자 조회") + "; path=/";
    const response = await hrmApi.post('/users/bulk-lookup', ids);
    return response.data;
  },

  // 특정 사용자 일부 필드 업데이트 (PATCH /users/{id})
  async patchUser(id, updates) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("사용자 정보 부분 업데이트") + "; path=/";
    return await hrmApi.patch(`/users/${id}`, updates);
  },
};
