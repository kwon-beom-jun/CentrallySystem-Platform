import { hrmApi } from '@/api/apiConfig';

export default {
  // 전체 고용 타입 정보 조회 (GET /employment-types)
  async getEmploymentTypes() {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("고용 타입 조회") + "; path=/";
    return await hrmApi.get('/employment-types');
  },
};
