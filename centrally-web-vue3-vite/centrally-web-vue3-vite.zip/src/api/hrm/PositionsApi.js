import { hrmApi } from '@/api/apiConfig';

export default {
  // 전체 직책 조회 (GET /positions)
  async getPositions() {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("직책 조회") + "; path=/";
    return await hrmApi.get('/positions');
  },
  // 유저 직책 조회 (GET /positions)
  async getPositionsByPositionId(positionId) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("유저 직책 조회") + "; path=/";
    return await hrmApi.get(`/positions/${positionId}`);
  },
};
