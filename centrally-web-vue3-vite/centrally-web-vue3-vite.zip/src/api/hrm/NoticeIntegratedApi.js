import { hrmApi } from '@/api/apiConfig';

export default {
  // 공지 전체 조회
  async getNotices(params) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("공지 전체 조회") + "; path=/";
    return await hrmApi.get('/notices', { params });
  },

  // 공지 단건 조회 (공지 ID로 조회)
  async getNotice({ noticeId }) {
    return await hrmApi.get(`/notices/${noticeId}`);
  },

  // 공지 등록 (파일 포함)
  async createNotice(formData) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("공지 등록") + "; path=/";
    // multipart/form-data 전송
    return await hrmApi.post('/notices', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  // 공지 수정 (파일 추가/삭제 포함)
  async patchNotice({ noticeId, formData }) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("공지 수정") + "; path=/";
    return await hrmApi.patch(`/notices/${noticeId}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  // 공지 삭제
  async deleteNotice(params) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("공지 삭제") + "; path=/";
    return await hrmApi.delete(`/notices/${params.id}`);
  },
};
