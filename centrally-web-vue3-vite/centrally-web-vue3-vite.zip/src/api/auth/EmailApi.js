import { authApi } from '@/api/apiConfig';

export default {
  async mailSend(params) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("메일 인증코드 발송") + "; path=/";
    return await authApi.post('/email/send', params);
  },

  async mailVerify(params) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("메일 인증코드 검증") + "; path=/";
    return await authApi.post('/email/verify', params);
  },
};
