import { authApi } from '@/api/apiConfig';

export default {
  async login(userEmail, password, encryptData) {
    // 로그인 기능 쿠키 설정
    document.cookie = "X-Func-Vue=" + encodeURIComponent("로그인") + "; path=/";
    // const password = EncryptionUtil.encryptPassword(rawPassword, loginKey);
    return await authApi.post('/login', {
      userEmail,
      password,
      encryptData
    });
  },
  
  async logout() {
    // 로그아웃 기능 쿠키 설정
    document.cookie = "X-Func-Vue=" + encodeURIComponent("로그아웃 [메뉴는 마지막 로그아웃 위치]") + "; path=/";
    return await authApi.post('/logout');
    // localStorage.removeItem('jwtToken');
  },

  async getMe() {
    // 서버에 GET /me 요청 -> JWT 쿠키 사용
    return await authApi.get('/me');
  },
};
