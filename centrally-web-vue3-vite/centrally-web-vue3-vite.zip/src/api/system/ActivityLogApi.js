import { systemApi } from '@/api/apiConfig';

export default {
  async getActivityLogs(params) {
    // 로그인 기능 쿠키 설정
    document.cookie = "X-Func-Vue=" + encodeURIComponent("이력 조회") + "; path=/";
    return await systemApi.get('/activity-log', { params });
  },
};
