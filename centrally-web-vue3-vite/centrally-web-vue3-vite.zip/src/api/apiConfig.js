// apiConfig.js
import axios from 'axios';
import router from '@/router';
import { toast } from 'vue3-toastify';

/* ────────────────────────────────────────────────
 * 공통 유틸
 * ──────────────────────────────────────────────── */
const recentToasts = new Set();
function pushToastOnce(msg, ttl = 2000) {
  if (recentToasts.has(msg)) return;          // 같은 메시지 2초 내 재표시 방지
  recentToasts.add(msg);
  setTimeout(() => recentToasts.delete(msg), ttl);
  toast.error(msg, { autoClose: ttl });
}
const delay = (ms) => new Promise((r) => setTimeout(r, ms));

/* ────────────────────────────────────────────────
 * axios 인스턴스 공통 팩토리
 * ──────────────────────────────────────────────── */
const createApi = (baseURL) =>
  axios.create({
    baseURL,
    withCredentials: true,                    // HttpOnly JWT 쿠키 전송
    headers: { 'Content-Type': 'application/json' },
  });

export const systemApi  = createApi(import.meta.env.VITE_SYSTEM_API_BASE_URL);
export const authApi    = createApi(import.meta.env.VITE_AUTH_API_BASE_URL);
export const hrmApi     = createApi(import.meta.env.VITE_HRM_API_BASE_URL);
export const receiptApi = createApi(import.meta.env.VITE_RECEIPT_API_BASE_URL);

/* ────────────────────────────────────────────────
 * 인터셉터 초기화 (main.js 등에서 1회 호출)
 * ──────────────────────────────────────────────── */
export async function initInterceptors() {
  /* Pinia 등록 시점 문제를 피하려고 require() 사용 */
  // const { useLoadingStore } = require('@/store/loading');
  // const { useAuthStore    } = require('@/store/auth');
  const { useLoadingStore } = await import('@/store/loading');
  const { useAuthStore    } = await import('@/store/auth');

  const loadingStore = useLoadingStore();
  const authStore    = useAuthStore();

  const attachInterceptors = (api) => {
    /* ▸ 1) Request */
    api.interceptors.request.use(
      (config) => {
        loadingStore.startLoading();

        const menu = router.currentRoute.value?.meta?.menu ?? '';
        document.cookie = `X-Menu-Vue=${encodeURIComponent(menu)}; path=/`;

        return config;
      },
      async (error) => {
        loadingStore.stopLoading();
        toast.error(`에러 발생 : ${error}`);
        await delay(1000);
        return Promise.reject(error.response);
      },
    );

    /* ▸ 2) Response */
    api.interceptors.response.use(
      (res) => {
        loadingStore.stopLoading();
        return res;                            // 전체 응답 객체 유지
      },
      async (error) => {
        loadingStore.stopLoading();
        await handleError(error, authStore);
        /* resolve 되지 않는 Promise 반환 → 이후 then 체인 차단 */
        return new Promise(() => {});
      },
    );
  };

  [systemApi, authApi, hrmApi, receiptApi].forEach(attachInterceptors);
}

/* ────────────────────────────────────────────────
 * 공통 에러 처리
 * ──────────────────────────────────────────────── */
async function handleError(error, authStore) {
  /* 실패 서비스 식별 */
  const url = error?.config?.baseURL ?? '';
  const service =
    url.includes('/hrm')     ? 'HRM' :
    url.includes('/auth')    ? 'AUTH' :
    url.includes('/receipt') ? 'RECEIPT' :
    'Unknown Service';

  const { status, data = {}, headers = {} } = error.response || {};
  const msg    = data.message || data.error || '알 수 없는 오류가 발생했습니다';
  const reason = headers['x-reason'];
  const here   = router.currentRoute.value.path;

  /* ▸ 401 : 권한 변경 or 토큰 만료 */
  if (status === 401) {
    if (reason === 'ROLE_CHANGED') {
      await forceLogout('권한이 변경되었습니다\n다시 로그인해주세요', authStore);
    } else if (here !== '/login') {
      await forceLogout('로그아웃 되었습니다\n다시 로그인해주세요', authStore);
    }
    return;
  }

  /* ▸ 403 : 금지 */
  if (status === 403) {
    pushToastOnce(`[${service}] ${msg}`);
    await delay(1500);
    return;
  }

  /* ▸ 네트워크 / 잘못된 요청 */
  if (
    error.code === 'ERR_NETWORK' ||
    (error.code === 'ERR_BAD_REQUEST' && !data.message)
  ) {
    pushToastOnce(`[${service}] 서비스와의 연결에 실패했습니다`);
    await delay(1500);
    return;
  }

  /* ▸ 기타 백엔드 오류 */
  pushToastOnce(`[${service}] ${msg}`);
  await delay(1500);
}

async function forceLogout(message, authStore) {
  pushToastOnce(message);
  await delay(1500);
  authStore.logout();
  router.push('/login');
}
