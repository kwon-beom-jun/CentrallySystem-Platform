import { receiptApi } from '@/api/apiConfig';

export default {

  // 영수증 신청(신청 상태로 변경)
  async requestReceipt(receiptId) {
    document.cookie = 'X-Func-Vue=' + encodeURIComponent('영수증 신청') + '; path=/';
    // REST 컨벤션: POST /request/{id}
    return await receiptApi.post(`/request/${receiptId}`);
  },

  // 사용자 영수증 상태 저장
  // POST /receipts/user/{userId}/decisions
  // body: [{ receiptId, decision, rejectReason }]
  async saveReceiptDecisions(userId, decisionList) {
    document.cookie = "X-Func-Vue=" + encodeURIComponent("사용자 영수증 상태 저장") + "; path=/";
    return await receiptApi.post(`/request/user/${userId}/decisions`, decisionList);
  },

  /**
   * 영수증 상태를 관리자 권한으로 강제 변경
   * @param {number} receiptId  영수증 PK
   * @param {'WAITING'|'REQUEST'|'REJECTED'|'APPROVED'|'CLOSED'} newStatus
   */
  async forceChangeStatus(receiptId, newStatus) {
    document.cookie = 'X-Func-Vue=' + encodeURIComponent('영수증 강제 상태변경') + '; path=/';
    return await receiptApi.put(`/request/${receiptId}/status/${newStatus}`);
  },

};
