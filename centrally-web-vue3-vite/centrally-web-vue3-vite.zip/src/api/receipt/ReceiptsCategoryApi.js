// src/api/receipt/ReceiptsCategoryApi.js
import { receiptApi } from '@/api/apiConfig';

export default {
  /* 카테고리 전체 조회(활성 목록) */
  async getCategories() {
    document.cookie = 'X-Func-Vue=' + encodeURIComponent('카테고리 전체 조회(활성 목록)') + '; path=/';
    return receiptApi.get('/categories');          // ← /active 대신 / 기본 엔드포인트로 통일
  },

  /* 카테고리 삭제(비활성화) */
  async disableCategory(id) {
    document.cookie = 'X-Func-Vue=' + encodeURIComponent('카테고리 삭제(비활성화)') + '; path=/';
    return receiptApi.patch(`/categories/${id}/delete`);
  },

  /* 신규 등록 */
  async createCategory(payload) {
    document.cookie = 'X-Func-Vue=' + encodeURIComponent('카테고리 등록') + '; path=/';
    return receiptApi.post('/categories', payload);          // POST /categories
  },

  /* 수정 */
  async updateCategory(id, payload) {
    document.cookie = 'X-Func-Vue=' + encodeURIComponent('카테고리 수정') + '; path=/';
    return receiptApi.put(`/categories/${id}`, payload);     // PUT /categories/{id}
  }
};
