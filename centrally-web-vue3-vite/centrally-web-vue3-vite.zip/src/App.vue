<template>
  <!--
    Pinia에 useLoadingStore를 만들어 요청 카운트 기반으로 isLoading 여부를 관리합
    Axios 인터셉터에 startLoading() / stopLoading()를 심어 모든 API 호출을 로딩 관리
    Router 가드(beforeEach / afterEach)에도 동일하게 로딩 관리를 추가
    메인 레이아웃 (App.vue 등) 에서 vue3-loading-overlay를 읽어 isLoading이 true면 스피너를 표시

    :active="isLoading"
      true일 때 스피너 활성화, false면 숨김
    opacity, backgroundColor
      로딩 오버레이 배경 투명도와 배경색
    loader, color
      스피너 타입(spinner, dots, 등)과 색상
    zIndex
      오버레이가 다른 요소 위에 표시되도록 설정
  -->
  <!-- 로딩 오버레이 컴포넌트 -->
  <LoadingOverlay
    :active="isLoading"
    :opacity="0.8"
    :backgroundColor="'#ffffff'"
    :loader="'spinner'"
    :color="'#375a7f'"
    :zIndex="9999"
  />

  <div>
    <!-- v-if 조건을 사용하여 로그인 페이지가 아닐 때만 렌더링 -->
    <Header v-if="showLayout" />

    <Navigation v-if="showLayout" />

    <FileTreeDrawer />

    <router-view />
    
    <Footer v-if="showLayout" />
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import Header from './components/HeaderLayout.vue';
import Footer from './components/FooterLayout.vue';
import Navigation from './components/NavigationLayout.vue';
import FileTreeDrawer     from '@/components/dms/DmsFileTreeDrawer.vue';

import LoadingOverlay from 'vue3-loading-overlay';
import { useLoadingStore } from '@/store/loading';
import 'vue3-loading-overlay/dist/vue3-loading-overlay.css';

// 로딩 스토어 사용
const loadingStore = useLoadingStore();
const isLoading = computed(() => loadingStore.isLoading);

const route = useRoute();

// 현재 경로의 메타 정보를 확인하여 로그인 페이지 여부를 판별
// ✅ 중괄호 + return
const showLayout = computed(() => {
  // console.log('route.name →', route.name);        // 디버그
  const hidden = ['userlogin', 'userjoin'];        // ❶
  return !!route.name && !hidden.includes(String(route.name).toLowerCase()); // ❷
});
</script>

<style scoped>
body {
  font-family: 'Inter', sans-serif;
  background-color: #F5F7FA;
  padding-top: 56px;
}

#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}

/* 날짜 선택 셀렉트 박스 크기 조정 */
#yearSelect {
  font-size: 0.8rem; /* 폰트 크기 줄이기 */
  padding: 0.25rem 0.5rem; /* 패딩 줄이기 */
  width: auto; /* 너비 자동 조정 */
}

/* 반응형 스타일 */
@media (min-width: 1920px) {
  .navbar-text {
    font-size: 1.5rem; /* 더 큰 텍스트 크기 */
  }
}

@media (max-width: 650px) {
  body {
    padding-top: 0px;
  }
  h2 {
    font-size: 1.25rem; /* 모바일 제목 글자 크기 조정 */
  }
  .mb-3 {
    margin-bottom: 0.25rem !important; /* 하단 여백을 0.25rem으로 설정 */
  }
  .sidebar {
    top: 0px;
    width: 100%;
    height: auto;
    position: relative;
    left: 0;
    padding: 0;
    display: flex;
    flex-direction: row;
    justify-content: space-around;
  }
  .sidebar a {
    padding: 10px 5px; /* 메뉴 항목의 상하 패딩을 줄여서 공간 절약 */
    flex: 1;
    text-align: center;
    border-right: none; /* 우측 테두리 제거 */
    font-size: 0.75rem; /* 모바일 사이드바 글자 크기 조정 */
  }
  .sidebar a:last-child {
    border-right: none;
  }
  .submenu a {
    padding: 5px 0; /* 하위 메뉴 항목의 상하 패딩을 줄여서 공간 절약 */
    font-size: 0.7rem; /* 하위 메뉴 글자 크기 줄이기 */
  }
  .content {
    margin-left: 0;
    padding: 20px;
    font-size: 0.875rem; /* 모바일 콘텐츠 글자 크기 조정 */
  }
  .content-title {
    font-size: 1.25rem; /* 모바일 컨텐츠 제목 글자 크기 조정 */
    margin-bottom: 30px;
  }
  .navbar {
    position: static;
    box-shadow: none;
  }
  .navbar-text {
    justify-content: center;
    font-size: 1rem; /* 모바일 네비게이션 텍스트 크기 조정 */
  }
  .footer {
    width: 100%;
    left: 0;
    font-size: 0.875rem; /* 모바일 푸터 글자 크기 조정 */
  }
  .table {
    font-size: 0.75rem; /* 모바일 테이블 글자 크기 조정 */
  }
}
</style>
