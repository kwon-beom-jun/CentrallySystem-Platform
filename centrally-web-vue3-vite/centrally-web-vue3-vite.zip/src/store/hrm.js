import { defineStore } from 'pinia';
import { useAuthStore } from '@/store/auth';

export const useHrmStore = defineStore('hrm', {
    // HRM 서비스 전용 상태 (필요한 경우 추가)
    state: () => ({
        // 예시: hrmData: null,
    }),
    // 게터를 통해 HRM 관리자 여부 계산
    getters: {
        // authStore의 역할(roles)을 확인하여, HRM 관리자인지 여부를 반환
        isHrmAdmin() {
            const authStore = useAuthStore();
            return authStore.getRoles.includes('ROLE_GATE_SYSTEM') ||
                   authStore.getRoles.includes('ROLE_HRM_MANAGER');
        }
    },
    // HRM 관련 액션 (필요한 경우 추가)
    actions: {
        // 예시: hrmAction() { ... }
    }
});
