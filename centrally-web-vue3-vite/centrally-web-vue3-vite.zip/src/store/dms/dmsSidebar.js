// store/dmsSidebar.js
import { defineStore } from 'pinia';

export const useDmsSidebarStore = defineStore('dmsSidebar', {
  state: () => ({
    isOpen: false,
    width  : 320,
  }),
  actions: {
    open()  { this.isOpen = true;  },
    close() { this.isOpen = false; },
    toggle(){ this.isOpen = !this.isOpen; },

    /** Drag → 폭 조절 */
    setWidth(w){
      this.width = Math.max(250, w);
    },
  },
});

