/**
 * 
  브라우저 새로고침 / 앱 전체 재실행
    - Pinia 스토어의 메모리도 초기화됩니다. → 다시 HrmUserApi.getUsersBasic() 1 회 호출

  같은 세션 안에서 다른 화면으로 이동했다가 돌아옴
    - 스토어 인스턴스·users 배열이 그대로 살아-있음 → 추가 호출 없음

  컴포넌트가 여러 개 동시에 마운트
    - 첫 번째 컴포넌트가 호출을 시작하고, 나머지는 loadingPromise 를 재사용 → 네트워크 1 회

  사용자 목록 변경(추가·퇴사) 등 서버 데이터가 바뀜
    - _자동_으로는 갱신되지 않음

  로그아웃 후 다른 계정 로그인
    - 보통 앱 전체가 새로 로드되므로 다시 호출됨 (동일 탭에서 SPA 방식으로 계정만 바꾼다면 수동 초기화 필요)

 */
import { defineStore } from 'pinia'
import HrmUserApi from '@/api/hrm/UsersApi'

export const useUserDirectoryStore = defineStore('userDirectory', {
  state: () => ({
    users        : null,     // Raw list
    loadingPromise: null     // 진행 중인 Promise
  }),

  actions: {
    /* 필요할 때 호출 ─ 이미 로딩돼 있으면 그대로 돌려줌 */
    async ensureLoaded () {
      if (this.users) return this.users            // ① 캐시 hit

      if (!this.loadingPromise) {                  // ② 최초 호출
        this.loadingPromise = HrmUserApi.getUsersBasic()
          .then(res => {
            this.users = res.data                  // 캐시에 넣기
            return this.users
          })
          .finally(() => { this.loadingPromise = null })
      }
      return this.loadingPromise                   // ③ 진행 중 Promise 재사용
    },

    /** 필요할 때 호출 → 캐시 비우고 강제 재조회 */
    async refresh () {
      this.users = null
      return this.ensureLoaded(true)
    }
  },
  
  getters: {
    /** userId → 사용자 객체 반환 (없으면 null) */
    getById: (state) => (id) =>
      state.users?.find(u => u.userId === id) ?? null,
  },
})
