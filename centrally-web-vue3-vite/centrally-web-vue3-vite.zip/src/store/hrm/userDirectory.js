// /store/hrm/userDirectory.js
import { defineStore } from 'pinia'
import AuthUserPermissionApi from '@/api/auth/UserPermissionApi'
import HrmUserApi            from '@/api/hrm/UsersApi'

export const useUserDirectoryStore = defineStore('userDirectory', {
  state: () => ({
    users        : null,   // [{ userId, name, email, …, roles:[…] }]
    allRoles     : null,   // [{ roleId, roleNameDetail, serviceName }]
    loadingPromise: null
  }),

  actions: {
    async ensureLoaded () {
      if (this.users) return this.users

      if (!this.loadingPromise) {
          this.loadingPromise = Promise.all([
            AuthUserPermissionApi.getUsersWithRoles(), // 역할·권한
            HrmUserApi.getUsersBasic()                 // 팀·부서(가벼운 버전)
          ])
          .then(([roleRes, basicRes]) => {
            /* team / department 를 userId ⇒ user 매핑으로 바꿔 두기 */
            const basicMap = Object.fromEntries(
              (basicRes.data || []).map(u => [u.userId, u])
            )
  
            /* 두 응답을 병합해 users 배열 생성 */
            this.users = (roleRes.data.userWithRolesList || []).map(u => {
              const b = basicMap[u.userId] || {}
              return {
                ...u,
                department : b.department ?? '미지정',
                team       : b.team       ?? '미지정'
              }
            })
  
            this.allRoles = roleRes.data.authRoles.allRoles
            return this.users
        })
        .finally(() => { this.loadingPromise = null })
      }
      return this.loadingPromise
    },

    async refresh () {
      this.users = null
      return this.ensureLoaded()
    }
  },

  getters: {
    /* userId → 사용자 */
    getById: state => id =>
      (state.users || []).find(u => u.userId === id) || null,

    /* 조건(service, roleDetail)으로 필터 */
    getByRole: state => (service, roleDetail) =>
      (state.users || []).filter(u =>
        u.roles.some(r =>
          (service     ? r.serviceName     === service     : true) &&
          (roleDetail  ? r.roleNameDetail  === roleDetail : true)
        )),

    /* 특정 사용자가 역할을 갖고 있는지 */
    hasRole: (state, getters) => (userId, service, roleDetail) =>
      getters.getByRole(service, roleDetail).some(u => u.userId === userId)
  }
})
