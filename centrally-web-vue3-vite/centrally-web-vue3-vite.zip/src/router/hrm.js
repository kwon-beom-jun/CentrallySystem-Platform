// src/router/hrm.js
import NoticeIntegrated from '@/views/hrm/NoticeIntegrated.vue';
import NoticeIntegratedDetail from '@/components/hrm/NoticeIntegratedDetail.vue';
import UserInformation from '@/views/hrm/UserInformation.vue';
import UserManagement from '@/views/hrm/UserManagement.vue';
import DeptTeamManager from '@/views/hrm/DeptTeamManager.vue';
import PerformanceHistory from '@/views/hrm/PerformanceHistory.vue';
import PerformanceManagement from '@/views/hrm/PerformanceManagement.vue';
import UserPermissions from '@/views/hrm/UserPermissions.vue';
import OrgDirectory from '@/views/hrm/OrgDirectory.vue';

/**
 * 권한
 *   ROLE_HRM_EMPLOYEE  : 사원
 *   ROLE_HRM_MANAGER   : 관리자
 * 
 * 로그인 확인 필요 없을 시 : meta에 requiresAuth=false 추가
 * menu는 백엔드에서 이력관리에서 사용
 * 
 */
const hrmRoutes = [
  {
    // (공통) 공지 사항
    path: 'notice-integrated',
    name: 'NoticeIntegrated',
    component: NoticeIntegrated,
    meta: { 
      requiresAuth: false, // 전 사원 사용 가능
      menu: '공지 사항'
    },
  },
  {
    // (공통) 공지 사항 세부
    path: 'notice-integrated-detail',
    name: 'NoticeIntegratedDetail',
    component: NoticeIntegratedDetail,
    meta: { 
      requiresAuth: false, // 전 사원 사용 가능
      // allowedRoles: ['ROLE_HRM_EMPLOYEE', 'ROLE_HRM_MANAGER'], // 사원 혹은 관리자 접근 가능
      menu: '공지 사항 세부'
    },
  },
  {
    // (공통) 사용자 정보
    path: 'user-information',
    name: 'UserInformation',
    component: UserInformation,
    meta: { 
      requiresAuth: false, // 전 사원 사용 가능
      /* allowedRoles: ['ROLE_HRM_EMPLOYEE', 'ROLE_HRM_MANAGER'], */
      menu: '사용자 정보'
    },
  },
  {
    // (관리자) 사용자 관리
    path: 'user-management',
    name: 'UserManagement',
    component: UserManagement,
    meta: {
      allowedRoles: ['ROLE_HRM_MANAGER'],
      menu: '사용자 관리'
    },
  },
  {
    // (관리자) 부서 및 팀 관리
    path: 'dept-team-manager',
    name: 'DeptTeamManager',
    component: DeptTeamManager,
    meta: { 
      allowedRoles: ['ROLE_HRM_MANAGER'],
      menu: '부서 및 팀 관리'
    },
  },
  {
    // (관리자) 유저 실적 확인
    path: 'performance-history',
    name: 'PerformanceHistory',
    component: PerformanceHistory,
    meta: { 
      allowedRoles: ['ROLE_HRM_MANAGER'],
      menu: '유저 실적 확인'
    },
  },
  {
    // (관리자) 실적 관리
    path: 'performance-management',
    name: 'PerformanceManagement',
    component: PerformanceManagement,
    meta: { 
      allowedRoles: ['ROLE_HRM_MANAGER'],
      menu: '실적 관리'
    },
  },
  {
    // (관리자) 권한 부여
    path: 'user-permissions',
    name: 'UserPermissions',
    component: UserPermissions,
    meta: { 
      allowedRoles: ['ROLE_HRM_MANAGER'],
      menu: '권한 부여'
    },
  },
  {
    // (관리자) 조직도
    path: 'org-directory',
    name: 'OrgDirectory',
    component: OrgDirectory,
    meta: { 
      allowedRoles: ['ROLE_HRM_MANAGER'],
      menu: '조직도'
    },
  },
];

export default hrmRoutes;
