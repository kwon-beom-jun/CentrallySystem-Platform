// src/router/ststem.js
import ActivityLog from '@/views/system/ActivityLog.vue';
import StatisticsScreen from '@/views/system/StatisticsScreen.vue';
import RoleManagement from '@/views/system/RoleManagement.vue';
import ComponentTest from '@/views/system/ComponentTest.vue';

/**
 * 권한
 *   ROLE_GATE_SYSTEM  : 모든 권한
 * 
 * 로그인 확인 필요 없을 시 : meta에 requiresAuth=false 추가
 * menu는 백엔드에서 이력관리에서 사용
 * 
 */
const systemRoutes = [
  {
    // 이력 관리
    path: 'activity-log',
    name: 'ActivityLog',
    component: ActivityLog,
    meta: { 
      allowedRoles: ['ROLE_GATE_SYSTEM'],
      menu: '이력 관리'
    },
  },
  {
    // 통계 관리
    path: 'statistics-screen',
    name: 'StatisticsScreen',
    component: StatisticsScreen,
    meta: { 
      allowedRoles: ['ROLE_GATE_SYSTEM'],
      menu: '통계 관리'
    },
  },
  {
    // 권한 관리
    path: 'role-management',
    name: 'RoleManagement',
    component: RoleManagement,
    meta: { 
      allowedRoles: ['ROLE_GATE_SYSTEM'],
      menu: '권한 관리'
    },
  },
  {
    path: 'component-test',
    name: 'ComponentTest',
    component: ComponentTest,
    meta: { 
      allowedRoles: ['ROLE_GATE_SYSTEM'], 
      menu: '컴포넌트 테스트'
    },
  },
];

export default systemRoutes;
