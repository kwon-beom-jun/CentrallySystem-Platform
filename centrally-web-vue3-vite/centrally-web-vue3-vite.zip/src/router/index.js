// src/router/index.js
// import { createRouter, createWebHistory } from 'vue-router';
import { createRouter, createWebHashHistory } from 'vue-router';
import { useAuthStore } from '@/store/auth';  // Pinia 스토어
import { useLoadingStore } from '@/store/loading'; // Pinia 스토어
import dmsRoutes from './dms';
import authRoutes from './auth';
import receiptRoutes from './receipt';
import hrmRoutes from './hrm';
import systemRoutes from './system';
import MainPage from '@/views/MainPage.vue';
import UserLogin from '@/views/UserLogin.vue';
import UserJoin from '@/views/UserJoin.vue';
import { toast } from 'vue3-toastify';
import { useSidebarStore } from '@/store/sidebar';
import { useDmsSidebarStore } from '@/store/dms/dmsSidebar';

/**
 * 로그인 확인 필요 없을 시 : meta에 requiresAuth=false 추가
 * menu는 백엔드에서 이력관리에서 사용
 */
const routes = [
  {
    path: '/',
    name: 'MainPage',
    component: MainPage,
    meta: { 
      menu: '메인'
    },
  },
  {
    path: '/login',
    name: 'UserLogin',
    component: UserLogin,
    meta: { 
      isLoginPage: true,
      requiresAuth: false,
      menu: '로그인'
    },
  },
  {
    path: '/join',
    name: 'UserJoin',
    component: UserJoin,
    meta: {
      isJoinPage: true,
      requiresAuth: false,
      menu: '회원가입'
    },
  },

  {
    path: '/dms',
    name: 'Dms',
    children: dmsRoutes,
  },
  {
    path: '/auth',
    name: 'Auth',
    children: authRoutes,
  },
  {
    path: '/receipt',
    name: 'Receipt',
    children: receiptRoutes,
  },
  {
    path: '/hrm',
    name: 'Hrm',
    children: hrmRoutes,
  },
  {
    path: '/system',
    name: 'System',
    children: systemRoutes,
  },
];

const router = createRouter({
  // history: createWebHistory(),
  history: createWebHashHistory(), // 해시모드(#) 사용
  routes,
});

// 라우트 네비게이션 전역 가드 설정
// 라우트 권한 확인
router.beforeEach(async (to, from, next) => {

  // .env에서 LOCALTEST가 true일 경우 인증 없이 통과
  if (import.meta.env.VITE_LOCALTEST === 'true') {
    return next();
  }

  const authStore = useAuthStore(); // Pinia
  if (authStore.roles.includes('ROLE_GATE_SYSTEM')) {
    return next();
  }

  // 기본: 모든 라우트는 인증 필요로 가정
  // 인증 불필요한 경우에만 requiresAuth: false가 명시되어 있음
  const requiresAuth = !to.matched.some(record => record.meta.requiresAuth === false);

  // (1) 인증이 필요한 라우트인지
  if (requiresAuth) {
    // 1-A) 로그인 여부 체크
    if (!authStore.isAuthenticated) {
      // 로그인 안 되어 있음 → 로그인 페이지로
      toast.warning('로그인이 필요합니다');
      await new Promise((resolve) => setTimeout(resolve, 1000));
      return next({ name: 'UserLogin' });
    }

    // 1-B) 권한 체크 (allowedRoles가 있는 경우만 검사)
    const routeAllowedRoles = to.meta.allowedRoles; // 예: ['ROLE_HRM_MANAGER', 'ROLE_HRM_EMPLOYEE']
    if (routeAllowedRoles && routeAllowedRoles.length > 0) {
      // 사용자 권한 배열
      const userRoles = authStore.roles; // 예: ['ROLE_HRM_EMPLOYEE', 'ROLE_HRM_MANAGER']

      // “하나라도 매칭되면 통과” 방식
      const hasRole = userRoles.some(role => routeAllowedRoles.includes(role));
      if (!hasRole) {
        // 권한 없음 → 접근 불가
        toast.warning('해당 메뉴에 접근할 권한이 없습니다');
        await new Promise((resolve) => setTimeout(resolve, 1000));
        // 그냥 이전 페이지로 (또는 다른 경로로)
        // return next(false);
        return next({ path: '/' });
      }
    }
  }
  
  // (2) 인증 불필요 or 권한 체크 통과
  return next();
});

// 라우트 이동 완료 후 (혹은 중단 포함)
// Axios 사용 중 라우터 이동 시 로딩 중단
router.afterEach(() => {
  // 라우트 이동 완료 시 로딩 종료
  const loadingStore = useLoadingStore();
  loadingStore.stopLoading();
  
  // 라우트 이동이 끝난 뒤, 사이드바 닫기
  const sidebarStore = useSidebarStore();
  sidebarStore.closeSidebar();

  const dmsSidebar = useDmsSidebarStore();
  // 문서관리 라우트를 벗어나면 Drawer 닫기
  if (!/\/dms/.test(router.currentRoute.value.path)) {
    dmsSidebar.close();
  }

  // 라우트 이동이 끝난 뒤, 스크롤 맨 위로 이동
  window.scrollTo(0, 0)
});

export default router;
