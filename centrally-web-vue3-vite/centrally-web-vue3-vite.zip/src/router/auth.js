import OAuthCallback from '@/views/auth/OAuthCallback.vue';

/**
 * 로그인 확인 필요 없을 시 : meta에 requiresAuth=false 추가
 * menu는 백엔드에서 이력관리에서 사용
 */
const authRoutes = [
  {
    // OAuth 로그인 후 콜백 페이지
    path: 'oauth-call-back',
    name: 'OAuthCallback',
    component: OAuthCallback,
    meta: { 
      requiresAuth: false,
      menu: 'OAuth 로그인 콜백'
    },
  },
];

export default authRoutes;
