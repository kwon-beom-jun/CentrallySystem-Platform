// src/router/dms.js
import DmsPage from '@/views/dms/DmsPage.vue';
import DmsCreateModifyPage from '@/components/dms/DmsCreateModifyPage.vue';

/**
 *  ※ 권한 예시
 *    ROLE_DMS_USER      : 문서 조회
 *    ROLE_DMS_MANAGER   : 문서 권한 관리
 *
 *  menu는 백엔드에서 메뉴 히스토리(접근 로그) 등에 사용합니다.
 */
const dmsRoutes = [
  /* ------------------- 공통 영역 ------------------- */
  {
    /* 문서 트리(폴더/파일) – nodeId 생략 시 루트 */
    path: ':nodeId(\\d+)?',
    name: 'DmsNode',
    component: DmsPage,
    meta: {
    //   allowedRoles: ['ROLE_DMS_USER', 'ROLE_DMS_MANAGER'],
      menu: '문서 열람',
    },
  },

  /* ------------------- 관리자 영역 ------------------- */
  {
    /* 문서 생성 및 수정  */
    path: 'dms-create-modify-page',
    name: 'DmsCreateModifyPage',
    component: DmsCreateModifyPage,
    meta: {
    //   allowedRoles: ['ROLE_DMS_MANAGER'],
      menu: '문서 수정 & 생성',
    },
  },
];

export default dmsRoutes;
