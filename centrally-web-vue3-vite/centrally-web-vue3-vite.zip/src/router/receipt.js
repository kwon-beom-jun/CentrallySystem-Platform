// src/router/receipt.js
import AnnualReceiptSummary from '@/views/receipt/AnnualReceiptSummary.vue';
import ReceiptRequestOverview from '@/views/receipt/ReceiptRequestOverview.vue';
import PersonalReceiptHistory from '@/views/receipt/PersonalReceiptHistory.vue';
import ReceiptManagement from '@/views/receipt/ReceiptManagement.vue';
import ReceiptClosure from '@/views/receipt/ReceiptClosure.vue';
import ReceiptHistory from '@/views/receipt/ReceiptHistory.vue';
import ReceiptHistoryDetail from '@/views/receipt/ReceiptHistoryDetail.vue';
import ReceiptPersonalRequestDetails from '@/views/receipt/ReceiptPersonalRequestDetails.vue';
import ReceiptSubmission from '@/views/receipt/ReceiptSubmission.vue';
import ReceiptMetaManagement from '@/views/receipt/ReceiptMetaManagement.vue';
import ReceiptAllMerge from '@/views/receipt/ReceiptAllMerge.vue';
import ReceiptAllMergeDetail from '@/views/receipt/ReceiptAllMergeDetail.vue';

const receiptRoutes = [

  
  /**
   *  권한
   *    ROLE_RECEIPT_REGISTRAR : 등록자
   *    ROLE_RECEIPT_APPROVER  : 결재자
   *    ROLE_RECEIPT_MANAGER   : 관리자
   * 
   * 등록자 : 등록, 상세 내용, 월별 정산 내역
   * 결재자 : [등록자] + 신청 내역, 개인 신청 내역, 월별 신청 상세 내역
   * 관리자 : [결재자] + 영수증 마감, 권한 부여
   * 
   * 로그인 확인 필요 없을 시 : meta에 requiresAuth=false 추가
   * menu는 백엔드에서 이력관리에서 사용
   * 
   */
  
  // --------------------- 공통 영역 ---------------------

  {
    // (공통) 영수증 등록
    path: 'receipt-submission',
    name: 'ReceiptSubmission',
    component: ReceiptSubmission,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_REGISTRAR', 'ROLE_RECEIPT_APPROVER', 'ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'], // 등록자, 결재자, 관리자
      menu: '영수증 등록'
    }, 
  },
  {
    // (공통) 영수증 신청 내역 조회
    path: 'personal-receipt-history',
    name: 'PersonalReceiptHistory',
    component: PersonalReceiptHistory,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_REGISTRAR', 'ROLE_RECEIPT_APPROVER', 'ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'], // 등록자, 결재자, 관리자
      menu: '영수증 신청 내역 조회'
    }, 
  },
  {
    // (공통) 영수증 년도별 요약(마감된것만)
    path: 'annual-receipt-summary',
    name: 'AnnualReceiptSummary',
    component: AnnualReceiptSummary,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_REGISTRAR', 'ROLE_RECEIPT_APPROVER', 'ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'], // 등록자, 결재자, 관리자
      menu: '영수증 년도별 요약'
    }, 
  },



  // --------------------- 결재자, 검수자, 관리자 영역 ---------------------

  {
    // 영수증 신청 내역 조회 현황
    path: 'receipt-request-overview',
    name: 'ReceiptRequestOverview',
    component: ReceiptRequestOverview,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_APPROVER', 'ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'], // 결재자, 관리자
      menu: '영수증 신청 내역 조회 현황'
    }, 
  },
  {
    // 영수증 신청 내역 조회 현황 상세페이지
    path: 'receipt-personal-request-details',
    name: 'ReceiptPersonalRequestDetails',
    component: ReceiptPersonalRequestDetails,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_APPROVER', 'ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'], // 결재자, 관리자
      menu: '영수증 신청 내역 조회 현황 상세페이지'
    }, 
  },
  {
    // 영수증 결재 내역 조회
    path: 'receipt-history',
    name: 'ReceiptHistory',
    component: ReceiptHistory,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_APPROVER', 'ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'], // 결재자, 관리자
      menu: '영수증 결재 내역 조회'
    }, 
  },
  {
    // 영수증 내역 상세 조회
    path: 'receipt-history-detail',
    name: 'ReceiptHistoryDetail',
    component: ReceiptHistoryDetail,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_APPROVER', 'ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'], // 결재자, 관리자
      menu: '영수증 내역 상세 조회'
    }, 
  },

// --------------------- 검수자, 관리자 영역 ---------------------

  {
    // 영수증 전체 취합
    path: 'receipt-all-merge',
    name: 'ReceiptAllMerge',
    component: ReceiptAllMerge,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'],
      menu: '영수증 전체 취합'
    }, 
  },
  {
    // 영수증 전체 취합 상세 (Excel 다운로드)
    path: 'receipt-all-merge-detail',
    name: 'ReceiptAllMergeDetail',
    component: ReceiptAllMergeDetail,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'],
      menu: '영수증 전체 취합 상세'
    }, 
  },
  {
    // 영수증 결제 마감
    path: 'receipt-closure',
    name: 'ReceiptClosure',
    component: ReceiptClosure,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_INSPECTOR', 'ROLE_RECEIPT_MANAGER'],
      menu: '영수증 결제 마감'
    }, 
  },

// --------------------- 관리자 영역 ---------------------
  {
    // 영수증 설정
    path: 'receipt-meta-management',
    name: 'ReceiptMetaManagement',
    component: ReceiptMetaManagement,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_MANAGER'],
      menu: '영수증 설정 관리'
    }, 
  },
  {
    // 영수증 마감
    path: 'receipt-management',
    name: 'ReceiptManagement',
    component: ReceiptManagement,
    meta: { 
      allowedRoles: ['ROLE_RECEIPT_MANAGER'], //관리자
      menu: '영수증 내역 관리'
    }, 
  },
  // {
  //   // 영수증 마감
  //   path: 'receipt-management',
  //   name: 'ReceiptClosure',
  //   component: ReceiptClosure,
  //   meta: { 
  //     allowedRoles: ['ROLE_RECEIPT_MANAGER'], //관리자
  //     menu: '영수증 마감'
  //   }, 
  // },
];

export default receiptRoutes;
