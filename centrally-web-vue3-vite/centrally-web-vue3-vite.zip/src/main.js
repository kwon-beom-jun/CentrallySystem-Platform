// src/main.js
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify'
import { BootstrapVue3 } from 'bootstrap-vue-3';
import { createPinia } from 'pinia';
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';
import { usePreviewModal } from './utils/preview-modal'; // Import the preview-modal composable

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-vue-3/dist/bootstrap-vue-3.css';

import './assets/styles/common.css'; // 공통 CSS 임포트
import './assets/styles/card.css'; // 공통 CSS 임포트
import './assets/styles/preview-modal.css'; // 미리보기 CSS 임포트

import { initInterceptors } from '@/api/apiConfig'; // axios 설정

import Vue3Toastify from 'vue3-toastify'; // toast
import 'vue3-toastify/dist/index.css'; // toast
import './assets/styles/toast-override.css'; // toast

import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';

// https://remixicon.com/
import 'remixicon/fonts/remixicon.css';

import clickAway from '@/utils/clickAway';

// import './assets/styles/font.css'; // 공통 Font CSS 임포트
// import axios from 'axios';

//https://apexcharts.com/
import VueApexCharts from 'vue3-apexcharts'; // ApexCharts
import "@/assets/styles/cart.css";


// 모바일 스타일 적용
// import '@/styles/mobile.css'; 

/**
  async 대신 사용시 Chrome 89·Firefox 108·Safari 15 이상의 브라우저만 이용가능
    // vite.config.js
    import { defineConfig } from 'vite'
    import vue from '@vitejs/plugin-vue'

    export default defineConfig({
      plugins: [vue()],
      build: {
        target: 'esnext'       // 또는 'es2022'
      }
    })
 */
// 다양한 브라우저(사내 IE 모드, 구형 Edge 등)도 지원
(async () => {
  const app = createApp(App);

  // toast 전역 등록 (아래 간단한 예시)
  // toast.success("성공 메시지입니다!");
  // toast.error("에러 메시지입니다!");
  // toast.info("정보 메시지입니다!");
  // toast.warning("경고 메시지입니다!");
  app.use(Vue3Toastify, {
    autoClose: 1500,        // 1000ms 후 자동 닫힘
    position: "top-center", // 토스트 표시 위치 (예: "top-right", "top-center", "top-left", "bottom-right", "bottom-left")
    pauseOnHover: true,     // 마우스 올리면 자동 닫힘 타이머 일시정지
    draggable: true,        // 드래그하여 토스트 이동 가능 여부
    hideProgressBar: true   // 타이머 바 숨김
  });

  // Register the preview modal globally
  app.config.globalProperties.$previewModal = usePreviewModal();

  const pinia = createPinia();
  pinia.use(piniaPluginPersistedstate);
  app.use(pinia);

  app.use(router);
  app.use(vuetify);
  app.use(BootstrapVue3);

  // ApexCharts
  app.use(VueApexCharts); 

  await initInterceptors();

  app.directive('click-away', clickAway);
  app.mount('#app');
})()