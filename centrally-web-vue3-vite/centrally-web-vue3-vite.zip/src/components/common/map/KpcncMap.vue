<template>
  <!-- style 인라인 바인딩으로 크기 제어 -->
  <div
    ref="mapEl"
    :style="{
      width: toUnit(width),
      height: toUnit(height),
      borderRadius: '8px',
      boxShadow: '0 4px 12px rgba(0,0,0,.15)',
    }"
  />
  </template>
  
<script setup>
import { ref, onMounted } from 'vue'

/* ---------- Props ---------- */
defineProps({
  width : { type: [Number, String], default: 600 },  // px 또는 %
  height: { type: [Number, String], default: 300 },
})

/* width=600 → '600px', width='100%' → '100%' */
const toUnit = v => typeof v === 'number' ? `${v}px` : v

/* ---------- Kakao SDK 로드 ---------- */
/* global kakao */
function loadSdk(cb) {
  if (window.kakao && window.kakao.maps) { kakao.maps.load(cb); return }

  const s = document.createElement('script');
  const appkey = import.meta.env.VITE_KAKAO_MAP_JAVASCRIPT_API_KEY.replace(/\/$/, '');
  
  s.src   = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${appkey}&autoload=false`
  s.async = true
  s.onload = () => kakao.maps.load(cb)
  document.head.appendChild(s)
}

/* ---------- 지도 초기화 ---------- */
const mapEl = ref(null)

onMounted(() => {
  loadSdk(() => {
    if (!mapEl.value) return

    const center = new kakao.maps.LatLng(37.543087866864, 127.05844935459)
    const map    = new kakao.maps.Map(mapEl.value, { center, level: 3 })

    const imgSrc  = 'https://www.kpcnc.co.kr/src/img/map_ico.png'
    const imgSize = new kakao.maps.Size(40, 43)
    const marker  = new kakao.maps.Marker({
      position: center,
      image   : new kakao.maps.MarkerImage(imgSrc, imgSize),
    })
    marker.setMap(map)
  })
})
</script>
  
<style scoped>
/* ❹ 추가: 지도 영역 */
/* .map-container {
  width: 100%;
  max-width: 600px;
  height: 300px;
  margin: 40px auto 0;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,.15);
} */
</style>