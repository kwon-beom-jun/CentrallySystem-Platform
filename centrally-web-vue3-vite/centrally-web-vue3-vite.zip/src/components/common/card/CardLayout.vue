<template>
    <div class="card-layout">
      <div class="card" v-for="item in data" :key="item.date">
        <div class="card-header">
          <p class="card-title">{{ item.date }}</p>
        </div>
        <div class="card-body">
          <p class="card-text"><strong>참여 : </strong>{{ item.people.length }}명</p>
          <p class="card-text"><strong>구분/사유 : </strong>{{ item.type }} / {{ item.reason }}</p>
          <p class="card-text"><strong>금액 : </strong>{{ item.amount }}</p>
          <p class="card-text"><strong>금액/인원수 : </strong>{{ item.amountPerPerson }}</p>
          <p>
            <strong class="card-text">영수증 사진 : </strong>
            <a class="card-text" @click.prevent="openPreviewModal(item.receipt)" style="cursor: pointer; color: blue;">
              {{ item.receiptName }}
            </a>
          </p>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { defineProps } from 'vue';
  
  // 카드 레이아웃에서 사용할 데이터 전달
  const props = defineProps({
    data: {
      type: Array,
      required: true
    },
    openPreviewModal: {
      type: Function,
      required: true
    }
  });
  </script>
  
  <style scoped>
  .card-layout {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
  }
  
  .card {
    width: 100%;
    border: 1px solid #ddd;
    padding: 10px;
    border-radius: 5px;
  }
  
  .card-header {
    font-size: 1.2rem;
    font-weight: bold;
  }
  
  .card-body {
    font-size: 1rem;
  }
  
  .card-text {
    margin-bottom: 10px;
  }
  </style>
  