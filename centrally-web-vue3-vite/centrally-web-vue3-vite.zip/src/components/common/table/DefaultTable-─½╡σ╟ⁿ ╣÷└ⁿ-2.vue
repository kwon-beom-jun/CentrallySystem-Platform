<!--

  ──────────────── 1) 필수 / 선택 프롭 ───────────────
    • columns      : 배열 [ { key, label, width, mobile? }, … ]
    • data         : 배열 [ { key: value, … }, … ]
    • footerData   : (옵션) ['합계', '…'] 
    • mobileCard   : true → 650 px 이하에서 카드 UI (기본 false)
    • selectable   : 행 체크박스 활성화
    • rowClick     : 행 클릭 콜백
    • openSidebar  : 행 클릭 → 사이드바 실행 함수
    • 기타         : bodyFontSize / fixedHeader / scroll 등


  ──────────────── 2) 컬럼 예시 (mobile 옵션) ───────────────
  <DefaultTable
    :columns="[
      { key:'id',     label:'번호',   width:50,
        mobile:{ line:1, inline:true, prefix:'',    suffix:' | '       } },
      {
        key: 'permission',
        label: '권한',
        width: 150,
        type: 'select',
        getOptions: (row) => {
          // 예시: row.projects (서비스명)에 따라 해당 서비스의 권한 옵션을 반환
          // (실제 옵션은 필요에 따라 변경)
          const rolesByService = {
            hrm: [
              { value: '사원', label: '사원' },
              { value: '관리자', label: '관리자' }
            ],
            receipt: [
              { value: '관리자', label: '관리자' },
              { value: '결재자', label: '결재자' }
            ],
            system: [
              { value: '시스템', label: '시스템' }
            ]
          };
          return rolesByService[row.projects] || [];
        },
        mobile:{ line:3, inline:false }
      }
    ]"
    :data="userData"                   // 테이블에 표시할 데이터 배열 (각 행에 { name, email, department, team, projects, permission } 등 포함)
    :footerData="footerData"           // (옵션) 테이블 푸터 데이터
    :openSidebar="openSidebar"         // 행 클릭 시 사이드바를 열기 위한 함수
    :rowClick="handleRowClick"         // 행 클릭 시 실행할 콜백 함수
    :bodyFontSize="'0.75rem'"         // 테이블 본문 폰트 사이즈
    :fixedHeader="true"                // 헤더 고정 여부
    @row-updated="handleRowUpdated"    // 셀렉트 변경 시, 해당 행(row)의 업데이트를 전달받음
  />
  ▸ line    : 카드 안에서 몇 번째 줄에 놓일지(1 부터)
  ▸ inline  : true → 같은 줄에 나란히 / false → 개별 줄
  ▸ prefix  : 값 앞에 붙일 문자열 (공백은 \u00A0 사용)
  ▸ suffix  : 값 뒤에 붙일 문자열
  ▸ bold    : true → font-weight:900


  ──────────────── 3) 컴포넌트 사용 샘플 ───────────────
    <DefaultTable
      :columns="columns"
      :data="rows"
      :mobileCard="true"
      selectable
      :rowClick="handleRow"
    />


설명:
- 만약 행의 셀렉트 박스를 클릭하면, @click.stop 처리되어 행 클릭 이벤트가 발생하지 않습니다.
- 행 전체 클릭 시에는 openSidebar와 rowClick 함수가 호출됩니다.
- 셀렉트 값 변경 시 onSelectChange()에서 row-updated 이벤트가 emit되어 상위에서 변경된 행 정보를 받을 수 있습니다.
-->
<template>
  <div
    class="table-container"
    :class="{ 'card-enabled': useCard }"
    :style="tableContainerStyles"
  >
    <table
      v-if="showTable"
      :class="['table', { 'no-header': noColumns }]"
      :style="{ '--table-body-font-size': bodyFontSize }"
    >
      <!-- thead -->
      <thead v-if="!noColumns" :class="{ 'fixed-header': fixedHeader }">
        <tr>
          <th v-if="selectable" class="checkbox-col">
            <input
              type="checkbox"
              :checked="allSelected"
              :indeterminate="someSelected"
              @click.stop="toggleSelectAll($event.target.checked)"
            />
          </th>
          <th v-for="column in columns" :key="column.key">
            {{ column.label }}
          </th>
        </tr>
      </thead>

      <!-- tbody -->
      <tbody>
        <!-- tr @click="onRowClick(item)" 
             → 행을 클릭하면 openSidebar와 rowClick을 둘 다 시도 -->
        <tr
          v-for="(item, rowIndex) in data"
          :key="rowIndex"
          @click="onRowClick(item)"
        >
          <!-- 각 행 체크박스 -->
          <td v-if="selectable" class="checkbox-col" @click.stop>
            <input
              type="checkbox"
              :checked="isRowSelected(item)"
              @change="toggleRowSelect(item, $event.target.checked)"
            />
          </td>
          <td
            v-for="column in columns"
            :key="column.key"
            :data-label="column.label"
            :data-prefix="useCard ? column.mobile?.prefix ?? '' : ''"
            :data-suffix="useCard ? column.mobile?.suffix ?? '' : ''"
            :class="[
              column.customClass ? column.customClass(item[column.key]) : '',
              'ellipsis',
              useCard ? `mobile-line-${column.mobile?.line ?? 99}` : '',
              useCard && column.mobile?.inline ? 'mobile-inline' : '',
              useCard && column.mobile?.align === 'right' ? 'mobile-align-right' : '',
            ]"
            :style="[
              columnStyles(column),
              useCard ? mobileCellStyle(column) : {},
            ]"
          >
            <!-- (A) type='select': <DefaultSelect> -->
            <!-- type='select' → DefaultSelect
                 여기서 @click.stop으로 행 클릭 이벤트 전파 중단 -->
            <template v-if="column.type === 'select'">
              <div @click.stop>
                <DefaultSelect
                  v-model="item[column.key]"
                  :options="getSelectOptions(column, item)"
                  size="full-small"
                  style="width: 100%"
                  :customHeight="selectHeight"
                  @change="(val) => onSelectChange(item, column, val)"
                />
              </div>
            </template>

            <!-- (B) type='button': '삭제' 버튼 -->
            <template v-else-if="column.type === 'button'">
              <!-- 클릭 시 이벤트 전파 중단 (@click.stop) -->
              <div @click.stop>
                <DefaultButton
                  :size="column.buttonSize || 'full-small'"
                  :color="column.buttonColor || 'gray'"
                  :customHeight="buttonHeight"
                  @click="() => onButtonClick(item, column)"
                >
                  {{ column.buttonText || "" }}
                </DefaultButton>
              </div>
            </template>

            <!-- (A) type='select': <DefaultSelect> -->
            <template v-else>
              {{
                column.customValue ? column.customValue(item) : item[column.key]
              }}
            </template>
          </td>
        </tr>

        <!-- Placeholder 행 -->
        <tr
          v-for="n in fillerRows"
          :key="'placeholder-' + n"
          class="placeholder-row"
          aria-hidden="true"
        >
          <td v-if="selectable" class="checkbox-col"></td>
          <td
            v-for="column in columns"
            :key="column.key"
            :data-label="column.label"
            :data-prefix="(useCard && column.mobile?.prefix) || ''"
            :data-suffix="(useCard && column.mobile?.suffix) || ''"
            :class="[
              'ellipsis',
              useCard ? `mobile-line-${column.mobile?.line || 99}` : '',
              useCard && column.mobile?.inline ? 'mobile-inline' : '',
              useCard && column.mobile?.align === 'right' ? 'mobile-align-right' : '',
            ]"
            :style="[
              columnStyles(column),
              useCard ? mobileCellStyle(column) : {},
            ]"
          ></td>
        </tr>
      </tbody>

      <!-- tfoot -->
      <tfoot v-if="footerData.length">
        <tr>
          <td v-if="selectable"></td>
          <td v-for="(footerItem, index) in footerData" :key="index">
            {{ footerItem }}
          </td>
        </tr>
      </tfoot>
    </table>
  </div>
</template>

<script setup>
import { defineProps, defineEmits, computed, watch, ref, nextTick, onMounted, onUnmounted } from 'vue';
import DefaultButton from "@/components/common/button/DefaultButton.vue";
import DefaultSelect from "@/components/common/select/DefaultSelect.vue";

const props = defineProps({
  columns: {
    type: Array,
    required: false,
  },
  data: {
    type: Array,
    required: true,
  },
  footerData: {
    type: Array,
    default: () => [],
  },
  // 기존 로직처럼 openSidebar와 rowClick을 모두 받을 수 있게 함
  openSidebar: {
    type: Function,
    required: false,
  },
  rowClick: {
    type: Function,
    required: false,
    default: null,
  },
  showTable: {
    type: Boolean,
    default: true,
  },
  noColumns: {
    type: Boolean,
    default: false,
  },
  bodyFontSize: {
    type: String,
    default: "0.75rem",
  },
  fixedHeader: {
    type: Boolean,
    default: false,
  },
  buttonHeight: {
    type: String,
    default: "",
  },
  selectHeight: {
    type: String,
    default: "",
  },
  // 데이터 항목별 인원당 금액을 계산하는 함수 (옵션)
  calculateAmountPerPerson: {
    type: Function,
    required: false,
    default: (item) => item.amount,
  },
  scroll: {
    type: Boolean,
    default: false,
  },
  scrollHeight: {
    type: [String, Number],
    default: 360,
  },
  // 행 선택(체크박스) 기능 on/off
  selectable: {
    type: Boolean,
    default: false,
  },
  // v-model 대상
  selectedRows: {
    type: Array,
    default: () => [],
  },
  // 데이터 없을 때 더미(Placeholder) 행을 넣을지 여부
  usePlaceholder: {
    type: Boolean,
    default: true,
  },
  // 최소 행 수(더미 포함)
  minRows: {
    type: Number,
    default: 10,
  },
  mobileCard: {
    type: Boolean,
    default: false,
  },
});

/* 뷰포트 & 프롭 둘 다 만족할 때만 카드 레이아웃 */
const useCard = ref(false);
const mq = 650;
function calcCard() {
  useCard.value = props.mobileCard && window.innerWidth < mq;
}

onMounted(() => {
  window.addEventListener("resize", calcCard);
  calcCard();
});
onUnmounted(() => window.removeEventListener("resize", calcCard));

function mobileCellStyle(column) {
  if (!useCard.value) return {};
  return {
    order: column.mobile?.line ?? 99,
    fontWeight: column.mobile?.bold ? "900" : "normal",
  };
}

/* const emit = defineEmits([
  'row-updated', 
  'delete-row',
  'update:selectedRows',
  'selection-change'
]); */
// 어떤 이벤트가 올지 모르므로 “열 때 선언된 emit”을 그대로 가격
// 타입 검사를 포기하고 eslint-plugin-vue 규칙도 통과
// (아래 주석 제거 시 에러)
// eslint-disable-next-line vue/valid-define-emits
const emit = defineEmits();

/** table-container 인라인 스타일 (스크롤 옵션) */
const tableContainerStyles = computed(() => {
  if (!props.scroll) return {};
  const h =
    typeof props.scrollHeight === "number"
      ? `${props.scrollHeight}px`
      : props.scrollHeight;
  return { maxHeight: h, overflowY: "auto" };
});

/** 컬럼 폭 지정 함수 */
function columnStyles(column) {
  const style = {};
  const fixedWidth = column.width || 150;
  style.width = fixedWidth + "px";
  style.minWidth = fixedWidth + "px";
  style.maxWidth = fixedWidth + "px";
  return style;
}

/** Select 컬럼 옵션 얻기 */
function getSelectOptions(column, row) {
  if (typeof column.getOptions === "function") {
    return column.getOptions(row);
  }
  return [];
}

/** Select 변경 시 → 상위로 알림 */
// function onSelectChange(item, column, newValue) {
function onSelectChange(item) {
  // item[column.key]가 이미 바뀌었음
  // 필요하다면 row-updated 이벤트 발생
  emit("row-updated", { ...item });
}

// 삭제 버튼 클릭 시
function onButtonClick(item, column) {
  // 열 정의에 emit이 있으면 그걸, 없으면 'button-click'
  const evt = column.emit ?? "button-click";
  emit(evt, { ...item });
}

/** 행 전체 클릭 → openSidebar & rowClick 모두 시도 */
function onRowClick(item) {
  if (props.openSidebar) {
    props.openSidebar(item);
  }
  if (props.rowClick) {
    props.rowClick(item);
  }
}

/* ───────── 테이블 더미 행 ───────── */
const fillerRows = computed(() => {
  if (!props.usePlaceholder || useCard.value) return 0;
  return Math.max(props.minRows - props.data.length, 0);
});

const rowHeight = ref(0);

/** 데이터·윈도 크기 변화 → 행 높이 재계산 */
async function syncRowHeight() {
  await nextTick(); // DOM 그려진 뒤
  const firstRow = document.querySelector(
    ".table tbody tr:not(.placeholder-row)"
  );
  rowHeight.value = firstRow ? firstRow.offsetHeight : 0;
  document.documentElement.style.setProperty("--row-h", `${rowHeight.value}px`);
}

/* 데이터 바뀔 때 */
watch(() => props.data, syncRowHeight, { deep: true });

/* 최초·리사이즈 때 */
onMounted(() => {
  syncRowHeight();
  window.addEventListener("resize", syncRowHeight);
});

/* ───────── 선택 로직 ───────── */
const internalSelected = ref(new Set(props.selectedRows));

/* 부모 → 자식 동기화 */
watch(
  () => props.selectedRows,
  (rows) => {
    internalSelected.value = new Set(rows);
  },
  { deep: true }
);

/* 행이 선택됐는지 판단 */
function isRowSelected(row) {
  return internalSelected.value.has(row);
}

/* 단일 행 토글 */
function toggleRowSelect(row, checked) {
  if (checked) internalSelected.value.add(row);
  else internalSelected.value.delete(row);
  exportSelection();
}

/* 전체 선택/해제 */
function toggleSelectAll(checked) {
  if (checked) internalSelected.value = new Set(props.data);
  else internalSelected.value.clear();
  exportSelection();
}

/* 선택 배열을 부모에 전달 */
function exportSelection() {
  const arr = Array.from(internalSelected.value);
  emit("update:selectedRows", arr); // v-model
  emit("selection-change", arr); // (옵션) 추가 이벤트
}

/* 헤더 체크박스 상태 */
const allSelected = computed(
  () =>
    internalSelected.value.size === props.data.length && props.data.length > 0
);
const someSelected = computed(
  () => internalSelected.value.size > 0 && !allSelected.value
);
</script>

<style scoped>
.table-container {
  width: 100%;
  overflow-x: auto;
  /* height: 300px;
  overflow-x: auto;
  overflow-y: auto; */
}

.table {
  /*
    기본적으로 테이블은 border-collapse: collapse;가 적용되어 인접한 셀의 경계선이 합쳐져 보임
    sticky 헤더 등의 효과를 위해 각 셀의 경계를 분리하여 개별 스타일을 적용하려면
    border-collapse: separate;를 사용해야 함
    기본값: collapse → separate로 변경
  */
  border-collapse: separate;

  /* 
    border-spacing은 separate 모드에서 셀 간의 간격을 지정하는 속성
    0으로 설정하면 셀들 사이에 추가적인 간격 없이 딱 붙어 있게 됨
    셀 간 간격 0
  */
  border-spacing: 0;
  width: 100%;
}

/* th, td 기본 패딩 및 수평 경계선 */
.table th,
.table td {
  padding: 8px;
  vertical-align: middle; /* 추가: 세로 중앙 정렬 */
  /* border-top: 1px solid #ccc; */
  /* border-bottom: 1px solid #ccc; */
}

/* 첫 번째 셀에는 왼쪽 경계선 제거, 나머지 셀에는 왼쪽 경계선 (얇은 회색) 적용 */
.table th:not(:first-child),
.table td:not(:first-child) {
  border-left: 1px solid #e0e0e0;
}

/* th는 상하 경계선을 굵게 처리 (1px solid) */
.table th {
  border-top: 1px solid #a5a5a5 !important;
  border-bottom: 1px solid #a5a5a5 !important;
}

.no-header {
  border-top: 1px solid #dee2e6;
}

/* 헤더 고정 (fixedHeader 프롭이 true인 경우 적용) */
.fixed-header th {
  position: sticky;
  top: 0;
  background-color: #f7f7f7;
  z-index: 2;
  border-top: 1px solid #a5a5a5;
  border-bottom: 1px solid #a5a5a5;
}

/* 항상 ellipsis 적용 (텍스트가 넘치면 ... 표시) */
.ellipsis {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 테이블 본문 폰트 사이즈 */
tbody {
  font-size: var(--table-body-font-size, 1rem);
}

/* 기본 텍스트 색상 (예시) */
.table-container table tbody td {
  color: rgb(27, 27, 27);
}

/* 여러가지 커스텀 텍스트 색상 예시 */
.text-red {
  color: red;
  font-weight: bold !important;
}
.text-black {
  color: black !important;
}
.text-blue {
  color: blue !important;
}
.text-green {
  color: green !important;
}

/* 행 Hover 시 배경색 */
tbody tr:hover td {
  background-color: #e7f1ff !important;
}

/* 체크박스 전용 폭 50 px */
.checkbox-col {
  width: 40px;
  min-width: 40px;
  max-width: 40px;
  text-align: center; /* 가운데 정렬(선택) */
  padding: 0; /* 필요 시 패딩 조절 */
}

/* 체크박스 확대 */
.checkbox-col input[type="checkbox"] {
  transform: scale(1.1);
  transform-origin: center; /* 가운데 기준으로 확대 */
  cursor: pointer; /* 마우스 오버 시 포인터 */
}

/* Placeholder Row 스타일 */
.placeholder-row td {
  height: var(--row-h, 40px); /* ★ 실제 행 높이와 100% 동일 */
  padding: 0; /* 데이터 행과 동일하게 – 필요하면 조정 */
  /* 데이터 행과 같은 여백·라인하이트 적용 */
  padding: 8px; /* .table td 와 동일 */
  line-height: 1.5; /* 필요 시 조정 */
  background: #fafafa; /* 은은한 구분만 유지 → 원하는 색으로 변경 */
  border-left: 1px solid #e0e0e0;
}
.placeholder-row td:first-child {
  border-left: none;
}
.placeholder-row td::after {
  content: "\00a0"; /* NBSP = non-breaking space */
}
/* ─── 650 px 이하(모바일) 카드 전용 ───────────────────────── */
@media (max-width: 650px) {
  .card-enabled .table thead {
    display: none;
  }
  .card-enabled .table,
  .card-enabled .table * {
    border-left: none !important;
    border-right: none !important;
  }

  .card-enabled .table tbody tr {
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    box-sizing: border-box;
    border-top: 1px solid #d7d7d7;
    border-bottom: 1px solid #d7d7d7;
    padding: 10px 12px;
    margin-bottom: 10px;
    background: #fff;
  }

  .card-enabled .table tbody td {
    width: 100% !important;
    min-width: 0 !important;
    max-width: 100% !important;
    padding: 2px 0 !important;
    border: none !important;
    font-size: 0.78rem;
    white-space: normal !important;
  }
  .card-enabled .table tbody td.mobile-inline {
    width: auto !important;
    display: inline-flex;
    align-items: center;
  }

  .card-enabled .table tbody td.mobile-line-1 {
    order: 1;
  }
  .card-enabled .table tbody td.mobile-line-2 {
    order: 2;
    margin-top: 2px;
  }
  .card-enabled .table tbody td.mobile-line-3 {
    order: 3;
  }

  .card-enabled .table tbody td::before {
    content: attr(data-prefix);
  }
  .card-enabled .table tbody td::after {
    content: attr(data-suffix);
  }

  .card-enabled .table tbody tr:hover {
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
  }
  .card-enabled.table-container{
    max-height:none !important;   /* 높이 제한 해제 */
    overflow-y:visible !important;/* 스크롤 막기 */
  }
  .card-enabled .mobile-align-right{
    margin-left:auto;          /* 같은 줄에서 오른쪽으로 밀기 */
    text-align:right;
  }
  /* 카드(tr) 공통 */
  .card-enabled .table tbody tr {
    border: 1px solid #e9e9e9 !important;
    border-radius: 12px !important;
    box-shadow: 0 3px 8px rgba(0,0,0,.08) !important;  /* 기본 그림자 */
    margin: 14px 0 !important;
    padding: 12px 14px !important;
    background: #ffffff !important;
    transition: transform .15s, box-shadow .15s !important;
  }
  /* 터치(눌림) 시 살짝 떠오르게 */
  .card-enabled .table tbody tr:active {
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 12px rgba(0,0,0,.12) !important;
  }

  /* 카드 내부 셀 여백·글꼴 */
  .card-enabled .table tbody td {
    padding: 8px 0 !important;
    font-size: .82rem !important;
    border: none !important;
  }
  /* 번호 컬럼 강조 */
  .card-enabled .table tbody td:first-child {
    font-weight: 600 !important;
    color: #1c64f2 !important;
  }

  /* 하단 툴바(≈75 px) 때문에 가려지는 현상 방지 → 컨테이너 패딩 추가 */
  .table-container.card-enabled {
    padding-bottom: 0px;   /* 필요 시 툴바 높이 + 여유분 조정 */
  }
  .table {
    font-size: 0.75rem !important;
  }
  .table-container table tbody td {
    font-size: 0.7rem;
  }
  .table th,
  .table td {
    padding: 6px;
  }
}

@media (max-width: 700px) {
  .table th,
  .table td {
    padding: 5px;
  }
  .table-container {
    max-height: 360px !important;
    overflow-y: auto;
  }
}
</style>
