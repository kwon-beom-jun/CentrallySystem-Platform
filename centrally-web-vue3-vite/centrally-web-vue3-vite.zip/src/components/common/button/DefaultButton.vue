<template>
  <div :class="alignmentClass" :style="marginStyle">
    <button
      :type="type"
      :class="['btn', buttonClass, customClass]"
      @click="handleClick"
      :style="buttonStyle"
    >
      <slot />
    </button>
  </div>
</template>

<script setup>
import { defineProps, defineEmits, computed } from 'vue';

const props = defineProps({
  type: {
    type: String,
    default: 'button', // 기본값은 button
    validator: (value) => ['button', 'submit', 'reset'].includes(value),
  },
  size: {
    type: String,
    default: 'medium',
    validator: (value) => [
      'xsmall', 'small', 'medium', 'large', 'full',
      'full-xsmall', 'full-small', 'full-medium', 'full-large'
    ].includes(value),
  },
  customClass: {
    type: String,
    default: '',
  },
  align: {
    type: String,
    default: 'center',
    validator: (value) => ['left', 'center', 'right'].includes(value),
  },
  color: {
    type: String,
    default: 'default', // 기본 색상
    validator: (value) => ['default', 'blue', 'red', 'green', 'yellow', 'gray'].includes(value),
  },
  // 마진 (왼쪽, 오른쪽, 위, 아래)
  marginLeft: {
    type: String,
    required: false,
    default: '0'
  },
  marginRight: {
    type: String,
    required: false,
    default: '0'
  },
  marginTop: {
    type: String,
    required: false,
    default: '0'
  },
  marginBottom: {
    type: String,
    required: false,
    default: '0'
  },
  customHeight: {
    type: String,
    default: '' // 값이 없으면 기본 스타일 유지
  },
  customWidth: {
    type: String,
    default: ''
  }
});

// margin 관련 computed 스타일 객체 생성
const marginStyle = computed(() => {
  return `
    margin-left: ${props.marginLeft} !important;
    margin-right: ${props.marginRight} !important;
    margin-top: ${props.marginTop} !important;
    margin-bottom: ${props.marginBottom} !important;
  `;
});

const emits = defineEmits(['click']);

const handleClick = (event) => {
  emits('click', event);
};

const buttonClass = computed(() => {
  let sizeClass = '';

  // 'full-'로 시작하는 조합형 사이즈 처리
  if (props.size.startsWith('full-')) {
    // 'full-' 뒤에 오는 사이즈를 파싱 (xsmall, small, medium, large)
    const normalSize = props.size.replace('full-', ''); // 예: full-small → small
    sizeClass = 'btn-full'; // 100% 너비

    // small, xsmall, large 등에 대응
    switch (normalSize) {
      case 'xsmall':
        sizeClass += ' btn-xs';
        break;
      case 'small':
        sizeClass += ' btn-sm';
        break;
      case 'large':
        sizeClass += ' btn-lg';
        break;
      case 'medium':
      default:
        // medium은 별도 클래스 없음
        break;
    }
  }
  // 기존 사이즈 처리
  else {
    switch (props.size) {
      case 'full':
        sizeClass = 'btn-full';
        break;
      case 'xsmall':
        sizeClass = 'btn-xs';
        break;
      case 'small':
        sizeClass = 'btn-sm';
        break;
      case 'large':
        sizeClass = 'btn-lg';
        break;
      // medium / default
      default:
        sizeClass = '';
        break;
    }
  }

  const colorClass = `btn-${props.color}`;
  return `${sizeClass} ${colorClass}`;
});

const buttonStyle = computed(() => {
  const style = {};
  if (props.customHeight) style.height = props.customHeight + ' !important';
  if (props.customWidth)  style.width  = props.customWidth  + ' !important';
  return style;
});

const alignmentClass = computed(() => {
  switch (props.align) {
    case 'left':
      return 'text-start';
    case 'right':
      return 'text-end';
    default:
      return 'text-center';
  }
});
</script>

<style scoped>
.btn {
  --bs-btn-color: #222;
  --bs-btn-bg: #ffffff;
  --bs-btn-border-color: #D4D4D4;
  --bs-btn-hover-color: #222;
  --bs-btn-hover-bg: #ebebeb;
  /* --bs-btn-hover-border-color: #ffffff; */
  --bs-btn-focus-shadow-rgb: 60, 153, 110;
  --bs-btn-active-color: #fff;
  --bs-btn-active-bg: #ffffff;
  --bs-btn-active-border-color: #D4D4D4;
  --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
  --bs-btn-disabled-color: #fff;
  --bs-btn-disabled-bg: #ffffff;
  --bs-btn-disabled-border-color: #ffffff;
  /* === 기본 사이즈 === */
  height:38px;
  font-size:.8rem;
  padding-left: 1rem;
  padding-right: 1rem;
  border-radius:3px;

  /* === 세로 가운데 정렬 핵심 === */
  display:inline-flex;          /* flex 컨테이너로 */
  justify-content:center;       /* 가로 가운데 */
  align-items:center;           /* 세로 가운데 */
  vertical-align:middle;        /* 표·아이콘과 함께 쓸 때 */
}

.no-pad {
  padding-left: 0 !important;
  padding-right: 0 !important;
  min-width: 0 !important;     /* 글자 길이만큼 튀어나오는 것 방지 */
  box-sizing: border-box;      /* width안에 padding 포함시키려면(optional) */
}

/* 색상별 커스텀 */
/* .btn-default {
  --bs-btn-bg: #375a7f;
  --bs-btn-border-color: #375a7f;
  --bs-btn-hover-bg: #5a7694;
  --bs-btn-hover-border-color: #5a7694;
} */

.btn-blue {
  color: #fff;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #ffffff;
  --bs-btn-bg: #007bff;
  --bs-btn-border-color: #007bff;
  --bs-btn-hover-bg: #0056b3;
  --bs-btn-hover-border-color: #0056b3;
}

.btn-red {
  color: #fff;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #ffffff;
  --bs-btn-bg: #dc3545;
  --bs-btn-border-color: #dc3545;
  --bs-btn-hover-bg: #bd2130;
  --bs-btn-hover-border-color: #bd2130;
}

.btn-green {
  color: #fff;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #ffffff;
  --bs-btn-bg: #28a745;
  --bs-btn-border-color: #28a745;
  --bs-btn-hover-bg: #218838;
  --bs-btn-hover-border-color: #218838;
}

.btn-yellow {
  color: #fff;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #ffffff;
  --bs-btn-bg: #ffc107;
  --bs-btn-border-color: #ffc107;
  --bs-btn-hover-bg: #e0a800;
  --bs-btn-hover-border-color: #e0a800;
}

.btn-gray {
  color: #fff;
  --bs-btn-hover-color: #fff;
  --bs-btn-hover-bg: #ffffff;
  --bs-btn-bg: #7c7c7c;
  --bs-btn-border-color: #7c7c7c;
  --bs-btn-hover-bg: #5f5f5f;
  --bs-btn-hover-border-color: #7c7c7c;
}

/* full 버튼: 너비 100% */
.btn, .btn-xs, .btn-sm, .btn-lg, .btn-full {
  /* padding: 0.3rem 0.6rem; */
  font-size: 0.8rem;
}

.text-start {
  text-align: left !important;
}

.text-end {
  text-align: right !important;
}

.text-center {
  text-align: center !important;
}

@media (max-width: 650px) {
  .btn ,.btn-xs ,.btn-sm ,.btn-lg {
    /* height: 33px !important; */
    font-size: 0.7rem !important;
    /* padding: 0.4rem 0.4rem !important; */
    /* height: auto !important; */
    line-height: 1.5;
  }
}

@media (max-width: 500px) {
  .btn, .btn-xs, .btn-sm, .btn-lg {
    /* height: 28px !important; */
    /* font-size: 0.55rem !important; */
    /* padding: 0.43rem 0.43rem !important; */
    /* height: auto !important; */
    padding-left: 0.8rem;
    padding-right: 0.8rem;
    line-height: 1.5;
  }
}

</style>
