<template>
  <div class="content content-wrapper" v-if="isLoaded">
    <!-- 제목 -->
    <h2 class="article-view-head">{{ notice.title }}</h2>
    <div class="article-view-head-detail">
      <DefaultLabel size="small" text="작성자 : " />
      <DefaultLabel size="small" class="author-name" :text="notice.author"/>
    </div>
    <span class="date">{{ notice.date }} </span>
    <!-- <DefaultFormRow align="left" marginTop="10px">
      <DefaultButton 
        size="small"
        color="gray"
        @click="goBack"
          customHeight="28px"
      >
        <v-icon size="20">mdi-arrow-left</v-icon>
      </DefaultButton>
    </DefaultFormRow> -->

    <DefaultFormRow marginTop="40px" align="between">
      <DefaultLabel size="small" text="본문" marginTop="10px" alignment="right"/>
      <div>
        <DefaultFormRow marginBottom="5px" align="right">
          <DefaultButton 
            size="small"
            color="gray"
            @click="goBack"
              customHeight="28px"
          >
            <v-icon size="20">mdi-arrow-left</v-icon>
          </DefaultButton>
        </DefaultFormRow>
      </div>
    </DefaultFormRow>

    <div
      class="ql-editor"
      v-html="sanitizedContent"
    />

    <DefaultFormRow marginBottom="10px">
      <div>
        <DefaultLabel
          v-if="notice.attachments && notice.attachments.length > 0 && nonImageFiles.length > 0"
          text="첨부 파일"
          size="small"
          margin-bottom="5px"
        />
        <div v-if="nonImageFiles.length > 0">
          <ul class="attachment-list">
            <li v-for="file in nonImageFiles" :key="file.attachmentId">
              <a :href="file.fileUrl" target="_blank" rel="noopener noreferrer" :download="file.fileName">
                <DefaultLabel text="[다운로드]" size="small" />
                <DefaultLabel :text="file.fileName" size="small" />
                <!-- {{ file.fileName }} -->
              </a>
            </li>
          </ul>
        </div>
      </div>
    </DefaultFormRow>

    <!-- 첨부파일 미리보기 영역 -->
    <div class="attachment-section">
      <DefaultFormRow marginBottom="5px">
        <div>
          <!-- <DefaultLabel
            v-if="notice.attachments && notice.attachments.length > 0 && imageFiles.length > 0"
            text="이미지"
            size="small"
            margin-bottom="5px"
          /> -->
          <div v-if="imageFiles.length > 0">
            <div class="preview-container">
              <div v-for="file in imageFiles" :key="file.attachmentId" class="preview-item">
                <a :href="file.fileUrl" target="_blank" rel="noopener noreferrer" :download="file.fileName">
                  <img class="image-preview" :src="file.fileUrl" :alt="file.fileName" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </DefaultFormRow>
    </div>

    <!-- </div> -->
    <hr />
    <!-- 수정/삭제 -->
    <DefaultFormRow marginBottom="5px" align="right">
      <DefaultButton 
        @click="openEditModal"
        marginRight="5px"
        v-if="isAdmin"
      >
        수정
      </DefaultButton>
      <DefaultButton 
        color="red" 
        @click="showDeleteAlert"
        v-if="isAdmin"
      >
        삭제
      </DefaultButton>
    </DefaultFormRow>
  </div>

  <!-- 삭제 확인 AlertModal -->
  <AlertModal
    :isVisible="deleteConfirmVisible"
    :disableBackgroundClose="false"
    title="삭제 확인"
    confirmText="확인"
    cancelText="취소"
    @close="deleteConfirmVisible = false"
    @confirm="deleteNotice"
  >
    <template #body>
      <p>삭제하시겠습니까?</p>
    </template>
  </AlertModal>

  <!-- 모달 컴포넌트 -->
  <NoticeIntegratedCreateModifyModal
    :isVisible="isModalVisible"
    :isAdmin="isAdmin"
    :isCreate="isCreate"
    :form="form"
    @close="onCloseModal"
    @save="onSave"
  />
</template>


<script setup>
/* ------------------------------------
   import & setup
------------------------------------ */
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useHrmStore } from '@/store/hrm'
import NoticeIntegratedApi from '@/api/hrm/NoticeIntegratedApi'

// 컴포넌트
import AlertModal from '@/components/common/modal/AlertModal.vue'
import DefaultButton from '@/components/common/button/DefaultButton.vue'
import DefaultFormRow from '@/components/common/DefaultFormRow.vue'
import DefaultLabel from '@/components/common/label/DefaultLabel.vue'
// import DefaultTextarea from '@/components/common/textarea/DefaultTextarea.vue'
// import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue'
import NoticeIntegratedCreateModifyModal from '@/components/hrm/NoticeIntegratedCreateModifyModal.vue'
import { toast } from 'vue3-toastify'
import DOMPurify from 'dompurify'

// 로딩 상태 플래그
const isLoaded = ref(false);

/* ------------------------------------
   상태
------------------------------------ */
// 관리자 여부
const isAdmin = ref(false);

// 삭제 모달 표시여부
const deleteConfirmVisible = ref(false);

// Vue Router, Pinia 스토어
const route = useRoute();
const router = useRouter();
const hrmStore = useHrmStore();

const areaRows = ref(10);

// 상세 공지 notice
const notice = ref({
  id: null,
  title: '',
  author: '',
  date: '',
  content: '',
  attachments: []
})
const author = ref('');

/* ------------------------------------
  공지 상세 조회
------------------------------------ */
async function fetchNoticeDetail(noticeId) {
  const response = await NoticeIntegratedApi.getNotice({ noticeId });
  const data = response.data;
  if (!data) {
    toast.error('공지 정보를 불러올 수 없습니다.');
    router.push('/hrm/notice-integrated');
    return
  }
  notice.value = {
    id: data.noticeId,
    title: data.title,
    author: author.value || '미확인',
    date: data.creationDate,
    content: data.content,
    attachments: data.attachments || []
  }
  areaRows.value = (notice.value.attachments && notice.value.attachments.length > 0) ? 10 : 20;
  isLoaded.value = true;
}

/* ------------------------------------
  이미지 파일 여부
------------------------------------ */
function isImageFile(fileName) {
  const lower = fileName.toLowerCase()
  return (
    lower.endsWith('.jpg') ||
    lower.endsWith('.jpeg') ||
    lower.endsWith('.png') ||
    lower.endsWith('.gif') ||
    lower.endsWith('.bmp')
  )
}

/* ---------------------------------------------------
   첨부파일 필터링 computed 프로퍼티
--------------------------------------------------- */
const imageFiles = computed(() => {
  return notice.value.attachments.filter(file => isImageFile(file.fileName))
})
const nonImageFiles = computed(() => {
  return notice.value.attachments.filter(file => !isImageFile(file.fileName))
})

/* ------------------------------------
  뒤로가기
------------------------------------ */
function goBack() {
  router.back();
}

/* ------------------------------------
  삭제 관련
------------------------------------ */
function showDeleteAlert() {
  deleteConfirmVisible.value = true;
}
async function deleteNotice() {
  deleteConfirmVisible.value = false;
  await NoticeIntegratedApi.deleteNotice({ id: notice.value.id });
  toast.success('공지 삭제 완료');
  // 목록으로
  await new Promise(res => setTimeout(res, 1000));
  router.push('/hrm/notice-integrated');
}

/* ------------------------------------
  수정 모달 열기
------------------------------------ */
const isModalVisible = ref(false); // 모달 표시 여부
const isCreate = ref(false);       // 등록(false)/수정(true)
const form = ref({});              // 모달에 전달할 데이터

function openEditModal() {
  // 수정 모드
  isCreate.value = false;
  // 상세 데이터를 복사하여 모달로 넘김
  form.value = JSON.parse(JSON.stringify(notice.value));
  // 모달 표시
  isModalVisible.value = true;
}

/* ------------------------------------
   모달 이벤트 핸들러
------------------------------------ */
function onCloseModal() {
  isModalVisible.value = false;
}

function onSave() {
  // 모달에서 등록/수정 성공 시 emit('save') → 여기서 받음
  isModalVisible.value = false;
  // 수정한 뒤 다시 상세조회 or 즉시 반영
  fetchNoticeDetail(notice.value.id);
}

// -----------------------
// onMounted
// -----------------------
onMounted(() => {
  isAdmin.value = hrmStore.isHrmAdmin;
  const noticeId = route.query.noticeId || route.params.noticeId;
  const authorParam = route.query.author || route.params.author;
  if (!noticeId || !authorParam) {
    router.push('/hrm/notice-integrated');
    // toast.error('잘못된 접근입니다.');
    return;
  }
  author.value = authorParam;
  fetchNoticeDetail(noticeId);
});


const sanitizeOptions = {
  // ① 기본 HTML 프로필 + img, a 등 대부분 태그 유지
  USE_PROFILES: { html: true },
  // ② Quill이 추가로 쓰는 태그·속성 확장
  ADD_TAGS: ['span'],
  ADD_ATTR: [
    'class', 'style',                 // 색상·정렬
    'data-list', 'data-indent',       // 목록·들여쓰기
    'data-checked',                   // 체크리스트
    'target', 'rel'                   // 링크 보안
  ],
  // ③ 위험 태그만 확실히 금지
  FORBID_TAGS: ['script', 'iframe', 'object']
}
const sanitizedContent = computed(() =>
  DOMPurify.sanitize(notice.value.content, sanitizeOptions)
)
DOMPurify.addHook('afterSanitizeAttributes', node => {
  if (node.tagName === 'A') {           // <a> 태그라면
    node.setAttribute('target', '_blank');        // 새 탭 열기
    node.setAttribute('rel', 'noopener noreferrer'); // 탭 제어·referrer 보호
  }
});
</script>

<style scoped>
hr {
  color: #cfcfcf; 
}

/* ================== 기사(공지) 상세 ================== */
.article-view-head {
  margin-top: 0px;                       /* 여백 ↑ */
  font-size: 1.5rem;                      /* 조금 키움 */
  font-weight: 700;
  line-height: 1.4;
  word-break: break-word;                 /* 긴 제목 줄바꿈 */
}

/* ─── meta 영역 ───────────────────────────── */
.article-view-head-detail {
  margin-top: 8px;
  margin-left: 3px;
  display: flex;                          /* 가로배치 */
  gap: 6px;
  font-size: 0.85rem;                     /* 작게 */
  color: #6c757d;                         /* 회색톤 */
  font-weight: 500;
}

.date {                                   /* 새 디자인 */
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 0.8rem;
  color: #818181;
  margin-left: auto;                      /* 작성자 오른쪽 끝 정렬 */
  margin-top: 20px;
}
.date::before {                           /* 시계 아이콘(유니코드) */
  content: "⏰";
  font-size: 0.8rem;
}

/* 작성자 닉에 색 포인트 */
.author-name {
  color: #37acc9;
  font-weight: 600;
}

/* ─── 본문(Quill) ─────────────────────────── */
.ql-editor {
  border-top:    1px solid #EEEEEE;          /* 굵게 */
  border-bottom: 1px solid #EEEEEE;
  padding: 50px 0 50px 0;
  line-height: 1.7;
  font-size: 0.9rem;                      /* 본문 가독성 */
}


.detail-box-body {
  border: 1px solid #616161;
  padding: 16px;
  margin-bottom: 20px;
  border-radius: 2px;
}
.detail-box-content {
  border: 1px solid #b1b1b1;
  padding: 16px;
  margin-bottom: 20px;
  border-radius: 8px;
}
.detail-box {
  border: 1px solid #ddd;
  padding: 16px;
  margin-bottom: 20px;
  border-radius: 8px;
}
.label-title {
  font-weight: bold;
  margin-bottom: 4px;
  display: inline-block;
  width: 80px;
}
.layer {
  margin-bottom: 12px;
}
.attachment-section {
  margin-bottom: 20px;
}
.preview-container {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.preview-item {
  border: 1px solid #eee;
  padding: 5px;
  border-radius: 4px;
  max-width: 220px;
}
.image-preview {
  width: 130px;
  height: 130px;
  object-fit: cover;
}
.button-group {
  margin-top: 20px;
}

/* ==== 모달 내부 스타일 ==== */
.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  line-height: 1;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}
.form-control,
.attachment-list {
  font-size: 0.8rem;
}
.attachment-list {
  margin-bottom: 0px;
}

.attachment-list a,
.attachment-list a * {
  cursor: pointer !important;
}

@media (max-width: 650px) {
  .ql-editor {
    font-size: 0.75rem;
  }
  .date {                                   /* 새 디자인 */
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 0.65rem;
    color: #818181;
    margin-left: auto;                      /* 작성자 오른쪽 끝 정렬 */
    margin-top: 10px;
  }
  .date::before {                           /* 시계 아이콘(유니코드) */
    content: "⏰";
    font-size: 0.8rem;
  }
}

@media (max-width: 500px) {
  hr {
    margin: 10px 0px 10px 0px;
  }
  .attachment-section {
    margin-bottom: 0px;
  }
  .image-preview {
    width: 70px;
    height: 70px;
    object-fit: cover;
  }
}
</style>
