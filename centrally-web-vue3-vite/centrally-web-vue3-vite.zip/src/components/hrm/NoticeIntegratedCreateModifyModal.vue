<template>
  <!-- 부트스트랩 모달 -->
  <b-modal
    ref="noticeModal"
    style="--bs-modal-width:800px"
    v-model="innerVisible"
    :title="'공지 사항'"
    :keyboard="false"
    :backdrop="'static'"
    centered
    fade
    hide-footer
    @hide="onHideModal"
  >

    <!-- 모달 본문 -->
    <form>
      <div v-show="headerVisible">
        <div class="layer">
          <DefaultLabel text="제목" forId="noticeTitle" size="small" :required="true" />
          <DefaultTextfield
            type="text"
            id="noticeTitle"
            v-model="localForm.title" 
            size="full"
            :disabled="!props.isAdmin" 
            placeholder="제목을 입력하세요"
          />
        </div>
        <DefaultFormRow marginBottom="10px" customClass="two-col">
          <div class="col-wrapper">
            <DefaultLabel text="작성자" forId="noticeAuthor" size="small" />
            <DefaultTextfield
            type="text"
            id="noticeAuthor"
            v-model="localForm.author" 
            size="full"
            disabled
            placeholder="자동 입력"
            marginRight="5px"
            />
          </div>
          <div class="col-wrapper">
            <DefaultLabel text="작성일" forId="noticeDate" size="small" />
            <DefaultTextfield
            type="text"
            id="noticeDate"
            :placeholder="localForm.date" 
            size="full"
            disabled
            />
          </div>
        </DefaultFormRow>

        <!-- (관리자) -->
        <div class="layer" v-if="props.isAdmin">
          <DefaultLabel text="[추가된 첨부 파일]" size="small" />

          <!-- 기존 첨부파일 목록 (수정 모드) -->
          <div v-if="localForm.attachments && localForm.attachments.length > 0">
            <ul class="attachment-list">
              <li
                v-for="(attachment, index) in localForm.attachments"
                :key="attachment.attachmentId"
              >
                <a :href="attachment.fileUrl" target="_blank">
                  {{ attachment.fileName }}
                </a>
                <!-- x 버튼: 삭제 -->
                <button 
                  type="button"
                  class="btn btn-danger square-btn ms-2"
                  @click="removeExistingFile(index, attachment.attachmentId)"
                >
                  x
                </button>
              </li>
            </ul>
          </div>
          <div v-else>
            <!-- 기존 첨부파일 없음 -->
          </div>

          <!-- 새로 첨부할 파일 목록 미리보기 -->
          <div v-if="newFiles.length > 0" class="mt-2">
            <ul class="attachment-list">
              <li
                v-for="(file, idx) in newFiles"
                :key="idx"
              >
                {{ file.name }}
                <button 
                  type="button"
                  class="btn btn-danger square-btn ms-2"
                  @click="removeNewFile(idx)"
                >
                  x
                </button>
              </li>
            </ul>
          </div>

          <!-- 새 파일 추가 -->
          <DefaultLabel text="새 파일 추가" size="small" marginTop="10px" />
          <input 
            type="file"
            class="form-control"
            multiple
            @change="handleFileChange"
          />
        </div>

        <!-- (관리자 아님) -->
        <div class="layer" v-else>
          <DefaultLabel text="첨부파일" size="small" />
          <div v-if="localForm.attachments && localForm.attachments.length > 0">
            <ul class="attachment-list">
              <li
                v-for="attachment in localForm.attachments"
                :key="attachment.attachmentId"
              >
                <a :href="attachment.fileUrl" target="_blank">
                  {{ attachment.fileName }}
                </a>
              </li>
            </ul>
          </div>
          <div v-else>
            <span>첨부파일 없음</span>
          </div>
        </div>
      </div>



      <!-- ───── 실선 + 중앙 버튼 ───── -->
      <div
        class="collapse-divider"
        :class="{ open: !headerVisible }"
        @click="toggleHeader"
      >
        <span class="divider-btn">
          {{ headerVisible ? '접기' : '펼치기' }}
        </span>
      </div>



      <div class="layer">
        <DefaultLabel text="내용" forId="noticeContent" size="small" />
        <!-- :readonly="!props.isAdmin" -->
        <QuillyEditor
          ref="quillRef"
          v-model="localForm.content"
          :options="editorOptions"
          class="border rounded editor-box"
          :style="{ height: editorHeight }"
        />
      </div>

      <!-- <div v-if="props.isAdmin" class="layer form-check">
        <input
          type="checkbox"
          class="form-check-input"
          id="cookieConsent"
          v-model="localForm.cookieConsent"
        >
        <label class="form-check-label" for="cookieConsent">
          해당 공지를 다시 띄우지 않음(쿠키 사용 동의)
        </label>
      </div> -->
    </form>
    
    <DefaultFormRow marginBottom="5px" align="right">
      <!-- 모달 푸터 -->
      <DefaultButton 
        @click="closeModal"
        color="gray"
        marginRight="5px"
        size="small"
      >
        닫기
      </DefaultButton>
      
      <DefaultButton
        v-if="props.isAdmin && props.isCreate"
        @click="saveNotice"
        marginRight="5px"
        size="small"
      >
        등록
      </DefaultButton>

      <DefaultButton
        v-if="props.isAdmin && !props.isCreate"
        @click="saveNotice"
        marginRight="5px"
        size="small"
      >
        수정
      </DefaultButton>
    </DefaultFormRow>
  </b-modal>
  <AlertModal
    :isVisible="closeConfirmVisible"
    :disableBackgroundClose="true"
    title="확인"
    confirmText="확인"
    cancelText="취소"
    @close="closeConfirmVisible = false"
    @confirm="reallyClose"
  >
    <template #body>
      <p>작성 중인 공지 사항을 닫으시겠습니까?</p>
    </template>
  </AlertModal>
</template>

<script setup>
import { ref, defineProps, defineEmits, watch, onMounted, onBeforeUnmount, nextTick, computed } from 'vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import AlertModal from '@/components/common/modal/AlertModal.vue'
import NoticeIntegratedApi from '@/api/hrm/NoticeIntegratedApi';
import { cloneDeep } from 'lodash';
import { toast } from 'vue3-toastify';
import Quill from 'quill'
import { QuillyEditor } from 'vue-quilly';

const props = defineProps({
  isAdmin: Boolean,
  isCreate: Boolean,
  isVisible: Boolean,
  form: Object,
});

// ────────── 뷰포트(모바일) 감지 ──────────
const isMobile = ref(window.innerWidth <= 650)
function handleResize () { isMobile.value = window.innerWidth <= 650 }
onMounted(()   => window.addEventListener('resize', handleResize))
onBeforeUnmount(() => window.removeEventListener('resize', handleResize))

// ────────────── 5 MB 상수 ──────────────
const MAX_BYTES = 5 * 1024 * 1024;   // 5 MB

const emit = defineEmits(['close', 'save']);

// 모달 상태
const innerVisible = ref(false);
const skipPopstateOnce = ref(false);

// 닫기 확인 모달 노출 여부
const closeConfirmVisible = ref(false);

// 헤더 접기/펼치기 상태
const headerVisible = ref(true);

// 로컬 상태
const localForm = ref({});
const newFiles = ref([]);
const deletedFileIds = ref([]);

// 닫기
function closeModal() {
  askBeforeClose();
}
/** 닫기 시 무조건 호출할 함수 */
function askBeforeClose () {
  // 이미 확인창이 떠 있으면 추가로 띄우지 않음
  if (!closeConfirmVisible.value) closeConfirmVisible.value = true;
}

/* AlertModal 에서 ‘확인’ 누르면 호출 */
function reallyClose() {
  closeConfirmVisible.value = false;
  // 확인 눌렀을 때 : 부모에 먼저 알리고
  emit('close');
  // v-model 만으로 모달을 닫는다 (이게 전부!)
  innerVisible.value = false;

  // 뒤로가기 히스토리 처리 필요하면 여기서만
  if (history.state?.modal) {
    skipPopstateOnce.value = true;
    history.back();
  }
}

// 파일 추가
function handleFileChange(e) {
  const files = e.target.files;
  for (let i = 0; i < files.length; i++) {
    newFiles.value.push(files[i]);
  }
  e.target.value = '';
}

// 기존 파일 삭제
function removeExistingFile(idx, attachmentId) {
  localForm.value.attachments.splice(idx, 1);
  deletedFileIds.value.push(attachmentId);
}

// 새 파일 삭제
function removeNewFile(idx) {
  newFiles.value.splice(idx, 1);
}

/* --- 모달 열 때 히스토리에 한 단계 추가 --- */
function openModal() {
  innerVisible.value = true;
  history.pushState({ modal: true }, '');   // 빈 state 하나 쌓기
}

/* --- popstate(뒤로가기) 시 모달이 열려 있으면 닫기 --- */
function handlePopState() {
  if (skipPopstateOnce.value) {
    skipPopstateOnce.value = false;
    return;                       // 아무 일도 하지 않음
  }
  if (innerVisible.value) {
    askBeforeClose();
    history.pushState({ modal: true }, '');
    // innerVisible.value = false;   // 모달 닫기
    // emit('close');
  }
}

// 저장
async function saveNotice() {
  // 제목 체크
  if (!localForm.value.title || !localForm.value.title.trim()) {
    toast.warning("제목을 입력해주세요");
    return;
  }
  // 내용 체크
  if (!localForm.value.content || !localForm.value.content.trim()) {
    toast.warning("내용을 입력해주세요");
    return;
  }

  /* ---------- 본문(HTML) 용량 체크 ---------- */
  const contentBytes =
  new TextEncoder().encode(localForm.value.content).length; // UTF-8
  if (contentBytes > MAX_BYTES) {
    toast.warning("본문은 5 MB를 초과할 수 없습니다.");
    return;
  }

  const formData = new FormData();

  const jsonString = JSON.stringify(localForm.value);
  const noticeBlob = new Blob([jsonString], { type: 'application/json' });
  formData.append('notice', noticeBlob);

  newFiles.value.forEach(f => formData.append('files', f));
  deletedFileIds.value.forEach(id => formData.append('deletedFileIds', id));

  let response;
  if (props.isCreate) {
    response = await NoticeIntegratedApi.createNotice(formData);
    toast.success("공지 등록 완료");
  } else {
    response = await NoticeIntegratedApi.patchNotice({
      noticeId: localForm.value.id,
      formData,
    });
    toast.success("공지 수정 완료");
  }
  emit('save', response.data);

  reallyClose();
}

/** 모달이 닫힐 때 호출될 함수 */
function onHideModal(bvEvent) {
  /* 모달이 hide 될 때,
    closeConfirmVisible(확인창) 이 열려 있으면 ―> 막기 */
  if (closeConfirmVisible.value) {
    bvEvent.preventDefault();
    return;
  }

  bvEvent.preventDefault();             // 그 외 모든 경우 차단
  askBeforeClose();                     // “닫으시겠습니까?”
}

const quillRef = ref(null);
/* const editorOptions = {
  theme: 'snow',
  modules: { toolbar: true },
} */
const editorOptions = {
  theme: 'snow',
  modules: {
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ color: ['#000', '#E60000', '#FF9900', '#FFFF00', '#FFFFFF',
           '#008A00', '#0066CC', '#9933FF', 'custom-color'] }, { background: [] }],   // 글자색 / 배경색 ▶ 추가
      [{ list: 'ordered' }, { list: 'bullet' }],
      [{ align: [] }],
      // Quill 이 그림 파일을 Base64 로 즉시 변환해
      // <img src="data:…"> 형태로 DOM 에 삽입 text 형식으로 DB에 들어감
      // 파일보다 33 % ↑ 추후 변경이 필요할 수 있음
      ['link', 'image', 'video'],
      ['clean']
    ]
  }
}

// ─── 접기/펼치기 상태 ───
function toggleHeader() {
  headerVisible.value = !headerVisible.value;
}
// ─── 에디터 높이 계산 ───
const editorHeight = computed(() => {
  const base      = isMobile.value ? 200 : 300   // 헤더 펼친 높이
  const collapsed = isMobile.value ? 400 : 500   // 헤더 접힌 높이
  return `${headerVisible.value ? base : collapsed}px`
})

watch(
  () => props.isVisible,
  (newVal) => {
    innerVisible.value = newVal;
    // 모달 초기화(폼 세팅 등) 필요하면 여기서 실행
    if (newVal) {
      // - 직접 참조하면 부모 객체와 연결되어 있음
      // localForm.value = props.form;
      // - 깊은 복사 후 사용하면 부모 객체와 독립적임
      // - 함수나 날짜 객체 등 복잡한 타입은 제대로 복사하지 못할 수 있으니 주의
      localForm.value = cloneDeep(props.form);
      newFiles.value = [];
      deletedFileIds.value = [];
      headerVisible.value = true;
      openModal();
    }
  },
  { immediate: true }
);

onMounted(async () => {
  await nextTick();
  quillRef.value.initialize(Quill);
  window.addEventListener('popstate', handlePopState);
})

onBeforeUnmount(() => {
  window.removeEventListener('popstate', handlePopState);
});
</script>

<style scoped>
.layer {
  margin-bottom: 10px;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}
.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  line-height: 1;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}
.form-control {
  font-size: 0.8rem;
  /* padding: 10px; */
  height: 33px;
}
.attachment-list {
  font-size: 0.8rem;
  margin-bottom: 0px;
}
.editor-box { 
  height: 300px;
}
:deep(.ql-container) { 
  min-height: 300px; 
}
/* ───── ‘작성자 / 작성일’ 전용 그리드 ───── */
.two-col {                 /* ① 행에 그리드 적용 */
  display: grid !important;
  grid-template-columns: 1fr 1fr;   /* 50 % / 50 % */
  column-gap: 8px;                  /* 칸 사이 여백 (원하는 값) */
}
/* ② 셀 안의 div 가 100% 폭을 차지하도록 */
.col-wrapper {
  width: 100%;
}
/* 필요하면 Textfield 가 label 과 같은 줄에 눌려
   좁아지는 것을 방지하려고 min-width 를 없앰 */
.col-wrapper :deep(.form-control) { 
  min-width: 0;
}

/* ───── 실선 + 버튼 ───── */
.collapse-divider {
  display: flex;               /* 좌·우 선과 버튼을 한 줄에 */
  align-items: center;
  cursor: pointer;
  margin: 12px 0;
}
.collapse-divider::before,
.collapse-divider::after {
  content: '';
  flex: 1 1 0;
  height: 0;
  border-top: 1px solid #bbb;  /* 실선 */
}
.divider-btn {
  padding: 0 10px;             /* 좌우 여백 */
  font-size: 0.75rem;
  color: #555;
  user-select: none;
}
/* 접힌 상태 강조(선택 사항) */
.collapse-divider.open::before,
.collapse-divider.open::after {
  border-color: #0d6efd;       /* 부트스트랩 파랑 */
}
.collapse-divider.open .divider-btn {
  color: #0d6efd;
}

@media (max-width: 650px) {
  .modal-header {
    font-size: 1.2rem;
  }
  .square-btn {
    width: 14px;
    height: 14px;
    padding: 0;
    font-size: 0.5rem;
  }
  .form-control, .attachment-list {
    font-size: 0.7rem;
  }
  .form-control {
    height:30px !important;
  }
}
@media (max-width: 500px) {
  .modal-header {
    font-size: 0.8rem;
  }
  .square-btn {
    width: 12px;
    height: 12px;
    padding: 0;
    font-size: 0.4rem;
  }
  .form-control, .attachment-list {
    font-size: 0.65rem;
  }
  /* .editor-box { 
    height: 150px !important;
  } */
  :deep(.ql-container),
  :deep(.ql-editor)    { 
    min-height: 200px !important; 
  }
}
</style>
