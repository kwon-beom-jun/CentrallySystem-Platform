<template>
  <!-- v-if="visible" 로 모달 표시/숨김 제어 -->
  <div v-if="visible" class="modal-overlay">
    <div class="modal-container">
      <!-- 모달 헤더 -->
      <div class="modal-header">
        <h5 class="modal-title">실적 추가</h5>
        <button type="button" class="btn-close" @click="closeModal" />
      </div>

      <!-- 모달 바디 -->
      <div class="modal-body">
        <form @submit.prevent="submitForm">
          <!-- 시작일, 종료일 -->
          <div class="d-flex">
            <div class="form-group w-50 me-2">
              <DefaultLabel for="fromDate" text="시작일" size="small" :required="true" />
              <DefaultTextfield
                type="date"
                id="fromDate"
                size="full"
                v-model="localFormData.fromDate" 
              />
            </div>
            <div class="form-group w-50">
              <DefaultLabel for="toDate" text="종료일" size="small" :required="true" />
              <DefaultTextfield
                type="date"
                id="toDate"
                size="full"
                v-model="localFormData.toDate" 
              />
            </div>
          </div>
          <div class="d-flex">
            <div class="form-group me-2">
            <!-- 유형, 상태 -->
            <DefaultLabel for="workType" text="유형" size="small" :required="true" />
            <DefaultSelect
              id="workType"
              v-model="localFormData.workType"
              :options="workTypeOptions"
              size="large"
            />
            </div>
            <div class="form-group">
              <!-- 유형, 상태 -->
              <DefaultLabel for="status" text="상태" size="small" :required="true" />
              <DefaultSelect
                id="status"
                v-model="localFormData.status"
                :options="statusOptions"
                size="large"
              />
            </div>
          </div>
          <!-- 성과 주제 -->
          <div class="form-group">
            <DefaultLabel for="performanceTitle" text="성과 주제" size="small" :required="true" />
            <DefaultTextfield
              type="text"
              id="performanceTitle"
              v-model="localFormData.performanceTitle" 
              size="full"
              placeholder="성과 주제를 입력해주세요"
            />
          </div>
          <!-- 성과 -->
          <div class="form-group">
            <DefaultLabel for="performance" text="성과" size="small" />
            <DefaultTextarea
              id="performance"
              v-model="localFormData.performance"
              size="full"
              placeholder="성과를 입력해주세요"
              :rows="4"
            />
          </div>
          <br />
          <!-- 버튼 영역 -->
          <div class="modal-footer">
            <DefaultButton 
              align="right"
              color="gray"
              margin-right="5px"
              @click="closeModal"
            >
              취소
            </DefaultButton>
            <DefaultButton 
              align="right"
              @click="submitForm"
            >
              저장
            </DefaultButton>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, defineProps, defineEmits } from 'vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultTextarea from '@/components/common/textarea/DefaultTextarea.vue';
import DefaultSelect from '@/components/common/select/DefaultSelect.vue';
import { cloneDeep } from 'lodash';
import { toast } from 'vue3-toastify';

const props = defineProps({
  visible: { type: Boolean, default: false },
  formData: {
    type: Object,
    default: () => ({
      fromDate: '',
      toDate: '',
      workType: '',
      performanceTitle: '',
      performance: '',
      status: '',
    }),
  },
});
const emits = defineEmits(['close', 'submit']);

/**
 * 모달 내부에서 쓸 지역 데이터
 * => 부모로부터 받은 formData를 로컬 복사
 */
const localFormData = ref({ ...props.formData });

/**
 * props.formData가 바뀔 때마다 localFormData를 다시 세팅
 */
watch(
  () => props.formData,
  (newVal) => {
    localFormData.value = cloneDeep(newVal);
  },
  { deep: true }
);

/** DefaultSelect에 넣을 옵션들 */
const workTypeOptions = [
  { value: '프로젝트', label: '프로젝트' },
  { value: '회의', label: '회의' },
  { value: '내부과제', label: '내부과제' },
  { value: '보고서 작성', label: '보고서 작성' },
];

const statusOptions = [
  { value: '1', label: '진행' },
  { value: '2', label: '완료' },
  { value: '3', label: '대기' },
];

/** 모달 닫기 */
function closeModal() {
  emits('close');
}

/** 폼 전송(저장) */
function submitForm() {
  if (
    !localFormData.value.fromDate ||
    !localFormData.value.toDate ||
    !localFormData.value.workType ||
    !localFormData.value.performanceTitle
  ) {
    toast.warning('시작일, 종료일, 유형, 성과 주제, 성과 내용을 모두 입력해주세요.');
    return;
  }
  emits('submit', { ...localFormData.value });
}
</script>

<style scoped>
.form-group {
  margin-bottom: 10px;
}

/* 반투명 배경 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1050;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* 모달 컨테이너 */
.modal-container {
  background: #fff;
  width: 650px;
  /* max-width: 600px; */
  border-radius: 4px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
  animation: fadeIn 0.3s;
  padding: 1rem;
}

/* 헤더 */
.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
}

/* 바디, 푸터 */
.modal-body {
  max-height: 70vh;
  overflow-y: auto;
}
.modal-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 1rem;
}

/* 기존 .d-flex, .form-control, .me-2 등 Bootstrap 스타일 일부만 mimic */
.d-flex {
  display: flex;
  gap: 0.5rem;
}
.w-50 {
  width: 50%;
}
.form-control {
  width: 100%;
  padding: 0.4rem;
  margin: 0;
}
.me-2 {
  margin-right: 0.5rem;
}

@media (max-width: 650px) {
  .modal-container {
    width: 480px;
  }
  .me-2 {
    margin-right: 0rem !important;
  }
}

@media (max-width: 500px) {
  .modal-container {
    width: 340px;
  }
}

/* 간단한 fadeIn 애니메이션 */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
</style>
