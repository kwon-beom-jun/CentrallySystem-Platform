<template>
  <div v-if="visible" class="modal-overlay">
    <div class="modal-container">
      <!-- 모달 헤더 -->
      <div class="modal-header">
        <h5 class="modal-title">실적 수정</h5>
        <button type="button" class="btn-close" @click="closeModal" />
      </div>

      <!-- 모달 바디 -->
      <div class="modal-body">
        <form @submit.prevent="submitEdit">
          <!-- 시작일, 종료일 -->
          <div class="d-flex">
            <div class="form-group  w-50 me-2">
              <DefaultLabel for="editFromDate" text="시작일" size="small" :required="true" />
              <DefaultTextfield
                type="date"
                id="editFromDate"
                size="full"
                v-model="editData.fromDate" 
              />
            </div>
            <div class="form-group w-50">
              <DefaultLabel for="editToDate" text="종료일" size="small" :required="true" />
              <DefaultTextfield
                type="date"
                id="editToDate"
                size="full"
                v-model="editData.toDate" 
              />
            </div>
          </div>
          <div class="d-flex">
            <div class="form-group me-2">
            <!-- 유형, 상태 -->
            <DefaultLabel for="editWorkType" text="유형" size="small" :required="true" />
            <DefaultSelect
              id="editWorkType"
              v-model="editData.workType"
              :options="workTypeOptions"
              size="large"
            />
            </div>
            <div class="form-group">
              <!-- 유형, 상태 -->
              <DefaultLabel for="editStatus" text="상태" size="small" :required="true" />
              <DefaultSelect
                id="editStatus"
                v-model="editData.status"
                :options="statusOptions"
                size="large"
              />
            </div>
          </div>
          <!-- 성과 주제 -->
          <div class="form-group">
            <DefaultLabel for="editPerformanceTitle" text="성과 주제" size="small" :required="true" />
            <DefaultTextfield
              type="text"
              id="editPerformanceTitle"
              v-model="editData.performanceTitle" 
              size="full"
              placeholder="성과 주제를 입력해주세요"
            />
          </div>
          <!-- 성과 -->
          <div class="form-group">
            <DefaultLabel for="editPerformance" text="성과" size="small" />
            <DefaultTextarea
              id="editPerformance"
              v-model="editData.performance"
              size="full"
              placeholder="성과를 입력해주세요"
              :rows="4"
            />
          </div>
          <br />
          <!-- 푸터 -->
          <div class="modal-footer">
            <DefaultButton 
              align="right"
              color="gray"
              margin-right="5px"
              @click="closeModal"
            >
              취소
            </DefaultButton>
            <DefaultButton 
              align="right"
              color="red"
              margin-right="5px"
              @click="showDeleteAlert"
            >
              삭제
            </DefaultButton>
            <DefaultButton 
              align="right"
              @click="submitEdit"
            >
              수정
            </DefaultButton>
          </div>
        </form>
      </div>
    </div>
    <AlertModal 
      :isVisible="deleteConfirmVisible" 
      :disableBackgroundClose="true"
      title="삭제 확인" 
      confirmText="확인" 
      cancelText="취소"
      @close="deleteConfirmVisible = false" 
      @confirm="deleteNotice">
      <template #body>
        <p>삭제하시겠습니까?</p>
      </template>
    </AlertModal>
  </div>
</template>

<script setup>
import { ref, watch, defineProps, defineEmits } from 'vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import AlertModal from '@/components/common/modal/AlertModal.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultTextarea from '@/components/common/textarea/DefaultTextarea.vue';
import DefaultSelect from '@/components/common/select/DefaultSelect.vue';
import { cloneDeep } from 'lodash';
import { toast } from 'vue3-toastify';

const props = defineProps({
  visible: { type: Boolean, default: false },
  editDataProp: {
    type: Object,
    default: () => ({
      fromDate: '',
      toDate: '',
      workType: '프로젝트',
      performanceTitle: '',
      performance: '',
      status: '',
    }),
  },
});
const emits = defineEmits(['close', 'save', 'delete']);

/**
 * 로컬 데이터
 */
const editData = ref({ ...props.editDataProp });

/**
 * 부모에서 editDataProp가 바뀌면 localEditData도 반영
 */
watch(
  () => props.editDataProp,
  (newVal) => {
    editData.value = cloneDeep(newVal);
  },
  { deep: true }
);

/** 옵션 목록: DefaultSelect에 넘길 데이터 */
const workTypeOptions = [
  { value: '프로젝트', label: '프로젝트' },
  { value: '회의', label: '회의' },
  { value: '내부과제', label: '내부과제' },
  { value: '보고서 작성', label: '보고서 작성' },
];

const statusOptions = [
  { value: '1', label: '진행' },
  { value: '2', label: '완료' },
  { value: '3', label: '대기' },
];

/** 모달 닫기 */
function closeModal() {
  emits('close');
}

/** 수정 */
function submitEdit() {
  // 필수 항목 검사: 성과는 제외 (즉, fromDate, toDate, workType, performanceTitle 필수)
  if (
    !editData.value.fromDate ||
    !editData.value.toDate ||
    !editData.value.workType ||
    !editData.value.performanceTitle
  ) {
    toast.warning('시작일, 종료일, 유형, 성과 주제, 성과 내용을 모두 입력해주세요.');
    return;
  }
  // 수정 완료 후 부모에게 알림
  emits('save', { ...editData.value });
}

const deleteConfirmVisible = ref(false);

/** 삭제 버튼 클릭 => AlertModal 열기 */
function showDeleteAlert() {
  deleteConfirmVisible.value = true;
}

/** AlertModal에서 확인 시 => 부모에 삭제 이벤트 알림 */
function deleteNotice() {
  // 현재 항목 ID를 부모에 전달
  deleteConfirmVisible.value = false;
  // (부모에서 AlertModal 등으로 재확인할 수도 있음)
  emits('delete', { ...editData.value });
}
</script>

<style scoped>
.form-group {
  margin-bottom: 10px;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1050;
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-container {
  background: #fff;
  width: 650px;
  /* max-width: 600px; */
  border-radius: 4px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
  animation: fadeIn 0.3s;
  padding: 1rem;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
}

.modal-body {
  max-height: 70vh;
  overflow-y: auto;
}
.modal-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 1rem;
}

/* 유사 부트스트랩 유틸 */
.d-flex {
  display: flex;
  gap: 0.5rem;
}
.me-2 {
  margin-right: 0.5rem;
}
.w-50 {
  width: 50%;
}
.form-control {
  width: 100%;
  padding: 0.4rem;
  margin: 0;
}

@media (max-width: 650px) {
  .modal-container {
    width: 480px;
  }
  .me-2 {
    margin-right: 0rem !important;
  }
}

@media (max-width: 500px) {
  .modal-container {
    width: 340px;
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
</style>
