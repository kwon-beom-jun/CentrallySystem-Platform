<!-- src/components/common/AppHeader.vue -->
<template>
  <header class="navbar">
    <div class="navbar-inner">
      <!-- 로고(1000px↓ 숨김) -->
      <RouterLink to="/" class="logo" @click="handleLogoClick">
        <!-- <img src="/img/common/logo/5.png" alt="logo" /> -->
        <img class="logo-desktop" src="/img/common/logo/kpcnc-logo.png" alt="logo" />
        <img class="logo-mobile"  src="/img/common/logo/kpcnc-logo2.png" alt="logo-mobile" />
      </RouterLink>

      <!-- ─────────── 메인 메뉴 + 메가메뉴 ─────────── -->
      <div
        class="menu-group"
        @mouseenter="cancelHide"
        @mouseleave="scheduleHide"
      >
        <nav class="desktop-nav">
          <div class="main-nav">
              <!-- 메뉴 박스의 click / touch 리스너 삭제 호버 기능만 사용하려 제거 -->
              <!-- @click.prevent="toggleByClick(m.key)"
                   @touchstart.prevent.stop="toggleByClick(m.key)" -->
            <div
              v-for="m in visibleMenus"
              :key="m.key"
              class="menu-box"
              @mouseenter="setHover(m.key)"
            >
              <a href="#" @click.prevent>{{ m.label }}</a>
            </div>
          </div>
        </nav>

        <!-- 메가 드롭다운 -->
        <transition name="fade">
          <div
            v-if="hovered"
            class="mega-all"
            @mouseenter="cancelHide"
            @mouseleave="scheduleHide"
          >
            <div v-for="col in visibleMenus" :key="col.key" class="mega-col">
              <p class="mega-title">{{ col.label }}</p>

              <!-- 서브 메뉴 (RouterLink / 액션별 a 태그) -->
              <template v-for="s in visibleSubs(col.sub)">
                <!-- 문서 트리 Drawer 토글 -->
                <a
                  v-if="s.action === 'dmsDrawer'"
                  :key="s.label"
                  href="#"
                  class="mega-link"
                  @click.prevent="toggleDmsDrawer(); closeMega();"
                >
                  {{ s.label }}
                </a>

                <!-- 일반 라우팅 -->
                <RouterLink v-else :key="s.to" :to="s.to" class="mega-link" @click="closeMega">
                  {{ s.label }}
                </RouterLink>
              </template>
            </div>
          </div>
        </transition>
      </div>

      <!-- ─────────── 유저 영역 ─────────── -->
      <!-- <div class="user-box">
        <RouterLink to="/hrm/user-information" class="user-name">
          {{ authStore.getUser }}
        </RouterLink>
        <span class="divider">|</span>
        <a href="#" class="user-name" @click.prevent="doLogout">로그아웃</a>
      </div> -->
      <!-- ─────────── 유저 영역 ─────────── -->
      <div class="user-box">
        <!-- 프로필 -->
        <RouterLink to="/hrm/user-information" class="icon-btn" @click="handleLogoClick">
          <svg class="icon"><use href="#icon-user" /></svg>
        </RouterLink>

        <span class="divider">|</span>

        <!-- 로그아웃 -->
        <a href="#" class="icon-btn" @click.prevent="doLogout">
          <svg class="icon"><use href="#icon-logout" /></svg>
        </a>
      </div>
      <svg style="display: none">
        <!-- user-circle -->
        <symbol
          id="icon-user"
          viewBox="0 0 24 24"
          stroke="currentColor"
          fill="none"
        >
          <circle cx="12" cy="12" r="10" stroke-width="2" />
          <circle cx="12" cy="10" r="3" stroke-width="2" />
          <path d="M6 19c1.5-3 10.5-3 12 0" stroke-width="2" />
        </symbol>

        <!-- log-out -->
        <symbol
          id="icon-logout"
          viewBox="0 0 24 24"
          stroke="currentColor"
          fill="none"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="M16 17l5-5-5-5" stroke-width="2" />
          <path d="M21 12H9" stroke-width="2" />
          <path
            d="M13 5v-2a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v18a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-2"
            stroke-width="2"
          />
        </symbol>
      </svg>
    </div>
  </header>
</template>

<script setup>
/* ─────────── imports ─────────── */
import { ref, computed, nextTick, onBeforeUnmount } from "vue";
import { useRouter, RouterLink } from "vue-router";
import { useAuthStore } from "@/store/auth";
import { useDmsSidebarStore } from "@/store/dms/dmsSidebar";
import { useMobileMenuStore } from '@/store/navigation';
import LoginApi from "@/api/auth/LoginApi";
import { toast } from "vue3-toastify";

/* ─────────── 스토어 & 라우터 ─────────── */
const authStore = useAuthStore();
const dmsDrawerStore = useDmsSidebarStore();
const router = useRouter();
const mobileMenu = useMobileMenuStore();  

/* ─────────── Role 확인 유틸 ─────────── */
const roles = computed(() => authStore.roles);
const isLocaltest = computed(() =>
  String(import.meta.env.VITE_LOCALTEST ?? import.meta.env.VITE_APP_LOCALTEST) ===
  "true"
);

/* ─────────── 로고 클릭 → 모든 모바일 레이어 닫기 ─────────── */
function handleLogoClick () {
  mobileMenu.reset();                 // 햄버거 & 시트 전부 닫기
  if (dmsDrawerStore.isOpen) {        // 문서 Drawer 열려 있으면 닫기
    dmsDrawerStore.close();
  }
}

function canShow(roleArr = []) {
  if (roleArr.length === 0) return true;
  if (isLocaltest.value) return true;
  if (roles.value.includes("ROLE_GATE_SYSTEM")) return true;
  return roleArr.some((r) => roles.value.includes(r));
}

/* ─────────── 메뉴 데이터 ─────────── */
const allMenus = [
  {
    key: "notice",
    label: "공지사항",
    roles: [],
    sub: [
      {
        to: "/hrm/notice-integrated",
        label: "공지사항",
        roles: [],
      },
    ],
  },
  /* {
    key: "dms",
    label: "문서 관리",
    roles: [], // 모든 사용자 허용
    sub: [
      // 문서 트리 Drawer 토글 전용
      { action: "dmsDrawer", label: "문서 트리", roles: [] },
      {
        to: "/dms/dms-create-modify-page",
        label: "문서 작성",
        roles: [],
      },
    ],
  }, */
  {
    key: "receipt",
    label: "영수증",
    roles: [
      "ROLE_RECEIPT_INSPECTOR",
      "ROLE_RECEIPT_REGISTRAR",
      "ROLE_RECEIPT_APPROVER",
      "ROLE_RECEIPT_MANAGER",
    ],
    sub: [
      {
        to: "/receipt/receipt-submission",
        label: "영수증 등록(개인)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR",
          "ROLE_RECEIPT_REGISTRAR",
          "ROLE_RECEIPT_APPROVER",
          "ROLE_RECEIPT_MANAGER",
        ],
      },
      {
        to: "/receipt/personal-receipt-history",
        label: "영수증 신청 내역 조회(개인)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR",
          "ROLE_RECEIPT_REGISTRAR",
          "ROLE_RECEIPT_APPROVER",
          "ROLE_RECEIPT_MANAGER",
        ],
      },
      {
        to: "/receipt/annual-receipt-summary",
        label: "영수증 년도별 요약(개인)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR",
          "ROLE_RECEIPT_REGISTRAR",
          "ROLE_RECEIPT_APPROVER",
          "ROLE_RECEIPT_MANAGER",
        ],
      },
      {
        to: "/receipt/receipt-request-overview",
        label: "영수증 결재 신청 현황(개인-결재)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_APPROVER", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-history",
        label: "영수증 결재 내역 조회(개인-결재)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_APPROVER", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-all-merge",
        label: "영수증 전체 취합(검수자)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-closure",
        label: "영수증 결재 마감(검수자)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-management",
        label: "영수증 내역 관리(관리자)",
        roles: ["ROLE_RECEIPT_MANAGER"],
      },
      {
        to: "/receipt/receipt-meta-management",
        label: "영수증 설정 관리(관리자)",
        roles: ["ROLE_RECEIPT_MANAGER"],
      },
    ],
  },
  {
    key: "management",
    label: "사원 관리",
    roles: ["ROLE_HRM_MANAGER"],
    sub: [
      {
        to: "/hrm/user-management",
        label: "사용자 관리",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/performance-management",
        label: "실적 관리",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/user-permissions",
        label: "권한 부여",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/dept-team-manager",
        label: "부서/팀 관리",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/org-directory",
        label: "조직도",
        roles: ["ROLE_HRM_MANAGER"],
      },
    ],
  },
  {
    key: "system",
    label: "시스템",
    roles: ["ROLE_GATE_SYSTEM"],
    sub: [
      {
        to: "/system/activity-log",
        label: "이력 관리",
        roles: ["ROLE_GATE_SYSTEM"],
      },
      {
        to: "/system/statistics-screen",
        label: "대시보드 관리",
        roles: ["ROLE_GATE_SYSTEM"],
      },
    ],
  },
  /* {
    key: "systemtest",
    label: "테스트",
    roles: ["ROLE_GATE_SYSTEM"],
    sub: [
      {
        to: "/system/component-test",
        label: "테스트 컴포넌트",
        roles: ["ROLE_GATE_SYSTEM"],
      },
    ],
  }, */
];

/* 보이는(필터링된) 메뉴 / 서브메뉴 */
const visibleMenus = computed(() => allMenus.filter((m) => canShow(m.roles)));
const visibleSubs = (subs) => subs.filter((s) => canShow(s.roles));

/* ─────────── 메가메뉴 호버 상태 ─────────── */
const hovered = ref(null);
let hideTimer; // 메가메뉴 지연 해제용 타이머

const setHover = (key) => {
  cancelHide(); // 타이머 취소
  hovered.value = key; // 즉시 보여주기
};

/** ms 후 숨김 예약 */
/** “메뉴 → 메가드롭다운” 사이의 마우스 이동 틈새에서 깜빡임을 막아 주는 ‘완충 지연’ 역할 */
function scheduleHide() {
  hideTimer = setTimeout(() => (hovered.value = null), 30);
}

/** 예약된 숨김 취소 */
function cancelHide() {
  clearTimeout(hideTimer);
}

function closeMega () {
  hovered.value = null                      // 메가드롭다운 닫기
  removeOutsideClickListener()              // 외부-클릭 리스너도 해제
}

/* ─────────── 터치 기기 지원 :  click 으로 열고 다시 click 하면 닫기 ─────────── */
function toggleByClick(key) {
  // 터치 시 auto-hide 타이머 제거
  cancelHide();
  // 동일 메뉴를 누르면 닫기, 다른 메뉴를 누르면 교체
  hovered.value = (hovered.value === key ? null : key);

  // 문서 전체(바깥)를 한 번 터치하면 닫히도록 리스너 등록
  addOutsideClickListener();
}

let outsideListener;                             // 한 번만 설치
function addOutsideClickListener() {
  if (outsideListener) return;                   // 이미 있음
  outsideListener = (e) => {
    if (!e.target.closest('.menu-group')) {      // 메뉴 바깥
      hovered.value = null;
      removeOutsideClickListener();
    }
  };
  document.addEventListener('click', outsideListener);
}
function removeOutsideClickListener() {
  if (!outsideListener) return;
  document.removeEventListener('click', outsideListener);
  outsideListener = null;
}
onBeforeUnmount(removeOutsideClickListener);

/* ─────────── 문서 트리 Drawer 토글 ─────────── */
async function toggleDmsDrawer() {
  dmsDrawerStore.isOpen ? dmsDrawerStore.close() : dmsDrawerStore.open();
  // 작은 화면에서 Drawer 열릴 때 메가메뉴는 접히도록 (1 프레임 대기)
  await nextTick();
  hovered.value = false;
}

/* ─────────── 로그아웃 ─────────── */
async function doLogout() {
  const res = await LoginApi.logout();
  if (res.status !== 200) toast.error("로그아웃 실패");
  authStore.logout();
  router.push("/login?logout=success");
}
</script>

<style scoped>
/* ───── 헤더 기본 ───── */
.navbar {
  height: 65px;
  background: #fff;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.06);
  position: fixed !important;
  inset: 0 0 auto 0;
  width: 100%;
  padding: 0;
  z-index: 1015;
}
.navbar-inner {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 25px;
  display: flex;
  align-items: center;
}

/* 로고 */
.logo-desktop {
  /* width: 45px; */
  width: 170px;
}
.logo-mobile {
  /* width: 45px; */
  display: none;
  width: 170px;
}

/* ───── 메인 메뉴 ───── */
.menu-group {
  flex: 1;
  display: flex;
  justify-content: center;
  position: relative;
}
.desktop-nav {
  height: 100%;
}
.main-nav {
  display: flex;
  height: 100%;
}
.menu-box {
  height: 100%;
  display: flex;
  align-items: center;
}
.menu-box > a {
  display: block;
  height: 100%;
  line-height: 65px;
  padding: 0 15px;
  color: #004497;
  font-weight: 700;
  font-size: 0.875rem;
  text-decoration: none;
}
.menu-box:hover > a {
  color: #ff9f43;
}

/* ───── 메가 드롭다운 ───── */
.mega-all {
  position: fixed;
  top: 65px;
  left: 50%;
  transform: translateX(-50%);
  width: max-content;
  max-width: calc(100% - 80px);
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 6px;
  padding: 24px 32px;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-start;
  gap: 40px;
  z-index: 999;
}
.mega-col {
  position: relative;
  padding-left: 20px;
}
.mega-col:first-child {
  padding-left: 0;
}
.mega-col::before {
  content: "";
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 1px;
  background: #e5e5e5;
}
.mega-col:first-child::before {
  display: none;
}
.mega-title {
  font-size: 0.8rem;
  margin-bottom: 10px;
  color: #004497;
  font-weight: 900;
}
.mega-link {
  display: block;
  padding: 6px 0;
  font-size: 0.75rem;
  color: #333;
  text-decoration: none;
}
.mega-link:hover {
  color: #ff9f43;
  text-decoration: none;
}
/* 메가 드롭 사라지는 시간 */
:deep(.fade-leave-active) {
  transition-duration: 0ms !important;   /* 기본 300ms → 0ms */
}

/* ───── 유저 영역 ───── */
.user-box {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0px 43px 0px 43px;
  font-size: 0.875rem;
}
.user-name {
  color: #004497;
  font-weight: 600;
  text-decoration: none;
}
.user-name:hover {
  color: #ff9f43;
}
.divider {
  color: #888;
}

/* ───── 애니메이션 ───── */

/* -------- user-box 아이콘용 -------- */
.icon {
  width: 30px;
  height: 30px;
  vertical-align: middle;
}
.icon-btn:hover {
  color: #ff9f43;
}
.icon-btn{
  /* 기본 아이콘 색 → 남색 */
  /* color:#004497; */
  color:#005dcf;
}
.user-box .icon-btn:hover{
  /* Hover 색(기존 그대로) */
  color:#ff9f43;
}

/* ───── 반응형 ───── */
@media (max-width: 1000px) {
  /* ───── 유저 영역 ───── */
  .user-box {
    padding: 0px 0px 0px 0px;
  }
  /* 로고 */
  .logo-desktop {
    display: none;
    width: 170px;
  }
  .logo-mobile {
    display: block;
    width: 80px;
  }
  /* .logo {
    display: none;
  } */
  /* .menu-group {
    justify-content: flex-start;
  } */
  .menu-box > a {
    padding: 0 10px;
  }
  .mega-all {
    padding: 24px 16px;
  }
  .mega-col {
    padding-left: 10px;
  }
  .mega-title {
    font-size: 0.75rem;
  }
  .mega-link {
    font-size: 0.7rem;
  }
}

/* 650px↓ : 메뉴 숨김, 이름/로그아웃만 */
@media (max-width: 650px) {
  .icon {
    width: 26px;
    height: 26px;
  }
  .user-btn {
    font-size: 1.55rem; /* 아이콘 크기 */
  }
  .navbar-inner {
    padding: 0 18px;
  }
  .desktop-nav {
    display: none;
  }
  .navbar {
    /* box-shadow: 0 2px 5px rgba(0, 0, 0, 0.06) !important; */
    border-bottom: 1px solid #e5e5e5;
  }
}
</style>
