<template><!-- ───────── 재직 인원 차트 ───────── -->
    <v-col cols="12" md="6">
      <v-card>
        <v-card-title class="d-flex justify-space-between align-center v-chart-title-custom">
          <DefaultLabel text="📌 재직 인원 통계" />

          <v-select
            v-model="granularity"
            :items="granularities"
            density="compact"
            hide-details
            variant="outlined"
            class="employee-select"
          >
            <template v-slot:selection="{ item }">
              <span class="select-small">{{ item.title ?? item }}</span>
            </template>
            <template v-slot:item="{ props, item }">
              <v-list-item v-bind="props" title="">
                <v-list-item-title class="select-small-option">
                  {{ item.title ?? item }}
                </v-list-item-title>
              </v-list-item>
            </template>
          </v-select>
        </v-card-title>

        <hr class="divider-with-gap" />

        <v-card-text class="v-chart-text-custom">
          <apexchart
            type="bar"
            height="300"
            :options="chartOpt"
            :series="chartSeries"
          />
        </v-card-text>
      </v-card>
    </v-col>

    <!-- ───────── 재직 인원 통계 데이터 (테이블) ───────── -->
    <v-col cols="12" md="6">
      <div class="employees-data">

        <DefaultFormRow marginTop="20px">
          <DefaultLabel text="현 재직 인원 테이블" size="large" />
        </DefaultFormRow>

        <DefaultLabel text="재직 인원에 대한 데이터를 보여줍니다" size="small" marginBottom="20px" />

        <DefaultTable
          :columns="deptColumns"
          :data="deptData"
          :bodyFontSize="'0.8rem'"
          :fixedHeader="true"
          :scrollHeight="300"
          scroll
          :minRows="7"
        />
      </div>
    </v-col>
</template>

<script setup>
import { ref, computed } from "vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";

const granularities = ["일", "월", "년"];
const granularity = ref("일");

const raw = {
  일: {
    cat: ["월", "화", "수", "목", "금", "토", "일"],
    dat: [32, 28, 30, 31, 29, 31, 29],
  },
  월: {
    cat: [
      "1월",
      "2월",
      "3월",
      "4월",
      "5월",
      "6월",
      "7월",
      "8월",
      "9월",
      "10월",
      "11월",
      "12월",
    ],
    dat: [150, 152, 98, 150, 151, 72, 148, 150, 151, 153, 154, 155],
  },
  년: {
    cat: ["2021", "2022", "2023", "2024", "2025"],
    dat: [145, 149, 150, 151, 153],
  },
};

const chartSeries = computed(() => [
  { name: "재직 인원", data: raw[granularity.value].dat },
]);
const chartOpt = computed(() => ({
  chart: { toolbar: { show: false } },
  xaxis: { categories: raw[granularity.value].cat },
  tooltip: { y: { formatter: (v) => `${v} 명` } },
  colors: ["#4e73df"],
}));


/* ▸▸ 재직 인원 테이블 컬럼 정의 */
const deptColumns = [
  { key: 'dept',      label: '부서',        width: 100 },
  { key: 'deptTotal', label: '부서 인원',   width: 80 },
  { key: 'team',      label: '팀',          width: 100 },
  { key: 'teamTotal', label: '팀 인원',     width: 100 }
];

/* ▸▸ 표시할 데이터 */
const deptData = ref([
  { dept: 'A', deptTotal: '30명', team: 'Q-1', teamTotal: '10명' },
  { dept: 'A', deptTotal: '30명', team: 'W-2', teamTotal: '10명' },
  { dept: 'A', deptTotal: '30명', team: 'E-3', teamTotal: '10명' },
  { dept: 'B', deptTotal: '20명', team: 'G-1', teamTotal: '10명' },
  { dept: 'B', deptTotal: '20명', team: 'H-2', teamTotal: '10명' },
  { dept: 'C', deptTotal: '50명', team: 'J-1', teamTotal: '10명' },
  { dept: 'C', deptTotal: '50명', team: 'J-2', teamTotal: '10명' },
  { dept: 'C', deptTotal: '50명', team: 'J-3', teamTotal: '10명' },
  { dept: 'C', deptTotal: '50명', team: 'J-4', teamTotal: '10명' },
  { dept: 'C', deptTotal: '50명', team: 'J-5', teamTotal: '10명' },
  { dept: '미지정', deptTotal: '5명', team: '-', teamTotal: '-' }
]);
</script>

<style scoped>
@media (max-width: 500px) {
  .v-chart-text-custom {
    padding: 0 10px 10px 0 !important;
  }
}
</style>