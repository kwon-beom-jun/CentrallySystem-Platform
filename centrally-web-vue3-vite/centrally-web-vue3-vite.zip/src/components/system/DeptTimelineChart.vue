<template>
  <v-card class="dept-timeline-chart">
    <v-card-title class="text-subtitle-2 d-flex justify-space-between v-chart-title-custom align-center">
      <DefaultLabel text="📌 부서별 지출 타임라인" />

      <v-select
        v-model="gran"
        :items="gItems"
        density="compact"
        hide-details
        variant="outlined"
        class="employee-select"
        style="max-width: 60px"
      >
        <!-- 선택돼 있는 값 -->
        <template #selection="{ item }">
          <span class="select-small">{{ item.title ?? item }}</span>
        </template>

        <!-- 드롭다운 항목 -->
        <template #item="{ props, item }">
          <v-list-item v-bind="props" title="">
            <v-list-item-title class="select-small-option">
              {{ item.title ?? item }}
            </v-list-item-title>
          </v-list-item>
        </template>
      </v-select>
    </v-card-title>
    
    <hr class="divider-with-gap" />

      <v-card-text class="v-chart-text-custom">
        <!-- 꺾은선 그래프 -->
        <apexchart type="line" height="350" :options="optSel" :series="serSel" />

        <DefaultFormRow align="right">
          <v-btn icon @click="zoomIn" size="x-small" class="mx-1 mb-3">
            <v-icon size="18">mdi-magnify-plus-outline</v-icon>
          </v-btn>
          <v-btn icon @click="zoomOut" size="x-small" class="mx-1 mb-3">
            <v-icon size="18">mdi-magnify-minus-outline</v-icon>
          </v-btn>
        </DefaultFormRow>
      </v-card-text>
  </v-card>
  <hr/>

  <!-- 📊 테이블 영역 -->
  <div class="mt-6">
    <DefaultFormRow marginBottom="15px">
      <DefaultLabel text="부서별 지출 데이터(단위:만)" size="large" />
    </DefaultFormRow>

    <DefaultTable
      :columns="tblColumns"
      :data="tblData"
      scroll
      :scrollHeight="300"
      :bodyFontSize="'0.8rem'"
      :fixedHeader="true"
      :minRows="3"
    />
  </div>
  <hr/>

  <!-- 📊 테이블 영역 -->
  <!-- 팀별 지출 영역 -->
  <div class="mt-6">
    <DefaultFormRow marginBottom="15px">
      <DefaultLabel text="팀별 지출 데이터(단위:만)" size="large" />
    </DefaultFormRow>

    <DefaultTable
      :columns="teamColumns"
      :data="teamTblData"
      scroll
      :scrollHeight="300"
      :bodyFontSize="'0.8rem'"
      :fixedHeader="true"
      :minRows="3"
    />
  </div>
  <hr/>
</template>

<script setup>
import "@/assets/styles/cart.css";
import { ref, computed, watch } from "vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultLabel   from "@/components/common/label/DefaultLabel.vue";
import DefaultTable   from "@/components/common/table/DefaultTable.vue";
import ApexCharts from "apexcharts";

/* ── 월·일 선택 ─────────────── */
const gItems = ["월", "일"];
const gran   = ref("월");

/* ── 축 레이블 ──────────────── */
const months = [ "1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월" ];
const days   = Array.from({ length: 31 }, (_, i) => `${i + 1}일`);

/* ── 더미 데이터 ─────────────── */
const serMon = [
  { name:"경영관리본부", data:[ 80, 75, 90, 85, 88, 95,110,105, 99,120,115,130 ] },
  { name:"SI사업본부", data:[120,130,115,140,150,155,160,158,162,168,172,180] },
  { name:"AI산업본부", data:[ 40, 38, 42, 45, 43, 41, 48, 46, 44, 49, 50, 52 ] }
];
const serDay = [
  { name:"경영관리본부", data:Array.from({length:31},()=>Math.floor(60+Math.random()*40)) },
  { name:"SI사업본부", data:Array.from({length:31},()=>Math.floor(100+Math.random()*60)) },
  { name:"AI산업본부", data:Array.from({length:31},()=>Math.floor(30+Math.random()*20)) }
];

/* ── 차트 옵션 ──────────────── */
const baseOpt = {
  chart:{
    id: "dept-line",
    toolbar:{ show:false },
    zoom:{ enabled:true },
    events:{ mounted: onChartMounted }
  },
  stroke:{ curve:"smooth", width:2 },
  markers:{ size:3 },
  yaxis:{ labels:{ formatter:v=>v.toLocaleString()+'(만)' } },
  tooltip:{ y:{ formatter:v=>v.toLocaleString()+'(만)' } },
  legend:{ position:"top" },
  colors:["#4e73df","#1cc88a","#f6c23e"]
};

const serSel = computed(() => gran.value === "월" ? serMon : serDay);
const optSel = computed(() => ({
  ...baseOpt,
  xaxis:{ categories: gran.value === "월" ? months : days }
}));

function onChartMounted(ctx) {
  xRange.value = { min: ctx.w.globals.minX, max: ctx.w.globals.maxX };
}

// 현재 보여 주는 x축 구간 기억
const xRange   = ref({ min: 0, max: months.length - 1 });
const zoomStack = [];

function zoomIn () {
  const { min, max } = xRange.value;
  if (max - min <= 1) return;             // 더 이상 못 줄이면 끝

  // 현재 범위를 기록
  zoomStack.push({ min, max });           // ★ push

  // 25 %씩 잘라내기 (한쪽 12.5 %)
  const span   = max - min + 1;
  const shrink = Math.ceil(span * 0.125);
  const newMin = min + shrink;
  const newMax = max - shrink;
  if (newMin >= newMax) return;           // 안전장치

  ApexCharts.exec("dept-line", "zoomX", newMin, newMax);
  xRange.value = { min: newMin, max: newMax };
}

function zoomOut () {
  const fullMax = (gran.value === "월" ? months : days).length - 1;

  // 직전 범위로 복귀
  if (zoomStack.length) {
    const { min, max } = zoomStack.pop();    // ★ pop
    ApexCharts.exec("dept-line", "zoomX", min, max);
    xRange.value = { min, max };
    return;
  }

  // 스택이 비었다 = 이미 최상위. 전체로 리셋
  ApexCharts.exec("dept-line", "resetZoom");
  xRange.value = { min: 0, max: fullMax };
}

/* ── 📑 테이블 컬럼 ───────────── */
const monthCols = months.map((m, i) => ({
  key: `m${i + 1}`, label: m, width: 50
}));
const tblColumns = computed(() => (
  gran.value === '월'
    ? [
        { key: 'dept', label: '부서', width: 80 },
        ...monthCols,
        { key: 'sum',  label: '합계(만)', width: 80 }
      ]
    : [
        { key: 'dept',  label: '부서', width: 80 },
        { key: 'label', label: gran.value, width: 80 },
        { key: 'value', label: '지출(만)', width: 80 }
      ]
));

/* ── 테이블 데이터 생성 ──────── */
const tblData = computed(() => {
  if (gran.value === '월') {
    // 월별 피벗 테이블
    return serMon.map(dept => {
      const row = { dept: dept.name };
      let sum = 0;
      dept.data.forEach((v, idx) => {
        row[`m${idx + 1}`] = v.toLocaleString();
        sum += v;
      });
      row.sum = sum.toLocaleString();
      return row;
    });
  }

  // '일' 모드 – 기존 방식
  const labels = days;
  const rows = [];
  serDay.forEach(dept => {
    labels.forEach((lab, idx) => {
      rows.push({
        dept : dept.name,
        label: lab,
        value: dept.data[idx].toLocaleString()
      });
    });
  });
  return rows;
});


/* ── 1) ‘팀별’용 더미 데이터 ───────────── */
const teamMon = [
  { name: '프레임워크 (SI사업본부)', data: [1800,15,20,17,19,21,25,23,20,28,26,30] },
  { name: '영업 (경영관리본부)', data: [62,60,70,68,69,74,85,82,79,92,89,100] },
  { name: 'RAP (AI사업본부)', data: [120,130,115,140,150,155,160,158,162,168,172,180] },
  { name: 'AI (AI사업본부)',  data: [40,38,42,45,43,41,48,46,44,49,50,52] }
];

/* ── 2) 팀별 테이블 컬럼(고정) ─────────── */
const teamColumns = [
  { key:'team',  label:'팀',  width:135 },
  ...monthCols,                        // 1~12월 열 재사용
  { key:'sum',  label:'합계(만)', width:80 }
];

/* ── 3) 팀별 테이블 데이터 생성 ───────── */
const teamTblData = teamMon.map(team => {
  const row = { team: team.name };
  let sum = 0;
  team.data.forEach((v, idx) => {
    row[`m${idx+1}`] = v.toLocaleString();
    sum += v;
  });
  row.sum = sum.toLocaleString();
  return row;
});

watch(gran, val => {
  const fullMax = (val === "월" ? months : days).length - 1;
  xRange.value = { min: 0, max: fullMax };
  zoomStack.length = 0;                      // ★ 스택 비우기
  ApexCharts.exec("dept-line", "resetZoom");
 });
</script>

<style scoped>
@media (max-width: 650px) {
  .v-field__input {
    max-width: 110px !important;
    padding-right: 5px !important;
    padding-left: 10px !important;
    font-size: 0.7rem !important;
  }
}
/* 필요 시 추가 커스텀 */
@media (max-width: 500px) { 
  .v-chart-text-custom {
    padding: 0 10px 10px 0 !important;
  }
}
</style>
