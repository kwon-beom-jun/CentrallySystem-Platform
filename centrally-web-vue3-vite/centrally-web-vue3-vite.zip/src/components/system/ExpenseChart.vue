<template>
  <!-- ───────── 영수증 차트 데이터 ───────── -->
  <v-col cols="12" md="6" class="chart-card-wrapper">
    <div class="expenseStats-data">
      <DefaultFormRow marginTop="10px">
        <DefaultLabel text="영수증 통계 요약" size="large" />
      </DefaultFormRow>
      <DefaultLabel text="영수증 통계에 대한 데이터를 보여줍니다" size="small" marginBottom="10px" />
      <hr class="hr-custom" />
      <DefaultFormRow marginTop="10px" marginBottom="10px" align="between">
        <DefaultLabel marginRight="30px" text="선택 기간" />
        <DefaultLabel :text="expenseStats.period" color="#777777" size="small" />
      </DefaultFormRow>
      <hr class="hr-custom" />
      <DefaultFormRow marginTop="10px" marginBottom="10px" align="between">
        <DefaultLabel marginRight="30px" text="평균(일)" />
        <DefaultLabel :text="expenseStats.avg" color="#777777" size="small" />
      </DefaultFormRow>
      <hr class="hr-custom" />
      <DefaultFormRow marginTop="10px" marginBottom="10px" align="between">
        <DefaultLabel marginRight="30px" text="최대 지출" />
        <DefaultLabel :text="expenseStats.max" color="#777777" size="small" />
      </DefaultFormRow>
      <hr class="hr-custom" />
      <DefaultFormRow marginTop="10px" marginBottom="10px" align="between">
        <DefaultLabel marginRight="30px" text="최소 지출" />
        <DefaultLabel :text="expenseStats.min" color="#777777" size="small" />
      </DefaultFormRow>
      <hr class="hr-custom" />
      <DefaultFormRow marginTop="10px" marginBottom="10px" align="between">
        <DefaultLabel marginRight="30px" text="총 지출" />
        <DefaultLabel :text="expenseStats.total" color="#777777" size="small" />
      </DefaultFormRow>
      <hr class="hr-custom" />
    </div>
  </v-col>

  <!-- ───────── 영수증 지출 차트 ───────── -->
  <v-col cols="12" md="6">
    <v-card>
      <!-- v-row · v-col 제거, spacer 사용 -->
      <v-card-title class="v-chart-title-custom d-flex align-center">
        <DefaultLabel text="📌 영수증 지출" />

        <v-spacer />

        <!-- 시작 날짜 -->
        <v-text-field
          v-model="start"
          label="시작"
          type="date"
          density="compact"
          hide-details
          variant="outlined"
          class="mini-field me-2"
          style="max-width: 140px"
          @change="validateRange"
        />

        <!-- 종료 날짜 -->
        <v-text-field
          v-model="end"
          label="종료"
          type="date"
          density="compact"
          hide-details
          variant="outlined"
          class="mini-field"
          style="max-width: 140px"
          @change="validateRange"
        />
      </v-card-title>

      <hr class="divider-with-gap" />

      <v-card-text class="v-chart-text-custom">
        <apexchart type="area" height="300" :options="opt" :series="ser" />
      </v-card-text>
    </v-card>
  </v-col>
</template>

<script setup>
import { ref, computed, watch } from "vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import { toast } from 'vue3-toastify'

const toISO = (d) => d.toISOString().substring(0, 10);
const today = new Date();
const start = ref(toISO(new Date(today.getTime() - 6 * 24 * 60 * 60 * 1000)));
const end = ref(toISO(today));

/* 통계 객체 */
const expenseStats = ref({
  period: "-",
  total: "-",
  avg: "-",
  max: "-",
  min: "-",
});

/* 더미 데이터(최근 30일) */
const raw = Array.from({ length: 30 }).map((_, i) => {
  const d = new Date(today.getTime() - (29 - i) * 24 * 60 * 60 * 1000);
  return [toISO(d), Math.floor(80_000 + Math.random() * 80_000)];
});

/* 필터링 및 차트 시리즈 */
const filtered = computed(() =>
  raw.filter(([d]) => d >= start.value && d <= end.value)
);
const ser = computed(() => [{ name: "지출 합계(₩)", data: filtered.value }]);

const opt = {
  chart: { type: "area", toolbar: { show: false }, zoom: { enabled: false } },
  stroke: { curve: "smooth" },
  xaxis: { type: "datetime" },
  tooltip: {
    x: { format: "yyyy-MM-dd" },
    y: { formatter: (v) => v.toLocaleString() + "₩" },
  },
  colors: ["#1cc88a"],
};

function validateRange () {
  if (start.value > end.value) {
    toast.warning('시작일이 종료일보다 클 수 없습니다.')
    // 가장 최근 값으로 되돌리기
    const tmp = start.value;
    start.value = end.value;
    end.value   = tmp;
  }
}

/* 통계 계산 → expenseStats 갱신 */
watch(
  filtered,
  () => {
    const nums = filtered.value.map(([, v]) => v);
    const total = nums.reduce((a, b) => a + b, 0);
    const avg = Math.round(total / (nums.length || 1));
    const max = Math.max(...nums);
    const min = Math.min(...nums);

    expenseStats.value = {
      period: `${start.value} ~ ${end.value}`,
      total: total.toLocaleString() + "₩",
      avg: avg.toLocaleString() + "₩",
      max: max.toLocaleString() + "₩",
      min: min.toLocaleString() + "₩",
    };
  },
  { immediate: true }
);
</script>

<style scoped>
@media (max-width: 500px) {
  .hr-custom {
    margin: 10px 0 10px 0 !important;
  }
  .v-chart-text-custom {
    padding: 0 10px 10px 0 !important;
  }
}
</style>