<template>
  <!-- 모달 -->
  <!--
    배경 클릭 및 ESC 키 입력시 모달이 닫히는 기능
      data-bs-backdrop="static"
      data-bs-keyboard="false"
   -->
  <div 
    class="modal fade"
    id="activityLogDetailModal"
    tabindex="-1"
    aria-labelledby="activityLogDetailModalLabel"
    aria-hidden="true"
  >
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <!-- 모달 헤더 -->
        <div class="modal-header">
          <h5 class="modal-title" id="activityLogDetailModalLabel">
            로그 상세
          </h5>
          <button 
            type="button" 
            class="btn-close" 
            data-bs-dismiss="modal" 
            aria-label="Close"
            @click="closeModal"
          ></button>
        </div>

        <!-- 모달 본문 -->
        <div class="modal-body">
          <!-- (1) 이름 + 발생 시간 -->
          <div class="row mb-2">
            <div class="col-6">
              <DefaultLabel text="이름" size="small" />
              <DefaultTextfield
                type="text"
                v-model="localLogData.username"
                size="full"
                disabled
              />
            </div>
            <div class="col-6">
              <DefaultLabel text="발생 시간" size="small" />
              <DefaultTextfield
                type="text"
                v-model="localLogData.timestamp"
                size="full"
                disabled
              />
            </div>
          </div>

          <!-- (2) 이메일 (단독 줄) -->
          <div class="row mb-2">
            <div class="col-12">
              <DefaultLabel text="이메일" size="small" />
              <DefaultTextfield
                type="text"
                v-model="localLogData.userEmail"
                size="full"
                disabled
              />
            </div>
          </div>

          <!-- (3) 메뉴 + 기능 -->
          <div class="row mb-2">
            <div class="col-4">
              <DefaultLabel text="메뉴" size="small" />
              <DefaultTextfield
                type="text"
                v-model="localLogData.menu"
                size="full"
                disabled
              />
            </div>
            <div class="col-8">
              <DefaultLabel text="기능" size="small" />
              <DefaultTextfield
                type="text"
                v-model="localLogData.function"
                size="full"
                disabled
              />
            </div>
          </div>

          <!-- (4) IP + HTTP Method -->
          <div class="row mb-2">
            <div class="col-4">
              <DefaultLabel text="Method" size="small" />
              <DefaultTextfield
                type="text"
                v-model="localLogData.httpMethod"
                size="full"
                disabled
              />
            </div>
            <div class="col-8">
              <DefaultLabel text="IP" size="small" />
              <DefaultTextfield
                type="text"
                v-model="localLogData.ip"
                size="full"
                disabled
              />
            </div>
          </div>

          <!-- (5) HTTP Body (단독 줄, 여러 줄 표시) -->
          <div class="row mb-2">
            <div class="col-12">
              <DefaultLabel text="Body" size="small" />
              <DefaultTextarea
                v-model="localLogData.httpBody"
                size="full"
                disabled
                rows="8"
              />
            </div>
          </div>

        </div>

        <!-- 모달 푸터 -->
        <div class="modal-footer">
          <DefaultButton 
            @click="closeModal"
            color="gray"
            size="small">
            닫기
          </DefaultButton>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, defineProps, defineEmits, onMounted, watch } from 'vue';
import * as bootstrap from 'bootstrap';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultTextarea from '@/components/common/textarea/DefaultTextarea.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import { cloneDeep } from 'lodash';

/**
 * 부모로부터 받은 로그 데이터
 * prop: logData
 */
const props = defineProps({
  logData: {
    type: Object,
    default: null
  }
});

/**
 * 모달 닫기 이벤트
 */
const emit = defineEmits(['close']);

/**
 * 모달 인스턴스
 */
const modalInstance = ref(null);

/**
 * 모달에서 직접 조작할 로컬 데이터
 */
const localLogData = ref({});

/**
 * 전달받은 logData가 변경될 때마다 localLogData 갱신
 */
watch(
  () => props.logData,
  (newData) => {
    if (newData) {
      localLogData.value = cloneDeep(newData);
    }
  },
  { deep: true, immediate: true }
);

onMounted(() => {
  const modalEl = document.getElementById('activityLogDetailModal');
  modalInstance.value = new bootstrap.Modal(modalEl, {});
  // 모달이 ESC나 배경 클릭 등으로 닫힐 때 발생하는 hidden.bs.modal 이벤트 처리
  modalEl.addEventListener('hidden.bs.modal', () => {
    emit('close'); // 부모에게 모달이 닫혔음을 알림
  });
  // 모달 표시
  modalInstance.value.show();
});

/**
 * 모달 닫기
 */
function closeModal() {
  modalInstance.value.hide();
  emit('close');
}
</script>

<style scoped>
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.2rem;
}
</style>
