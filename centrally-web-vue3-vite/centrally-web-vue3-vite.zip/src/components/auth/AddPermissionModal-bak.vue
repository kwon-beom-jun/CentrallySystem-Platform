<template>
  <div class="modal-overlay">
    <div class="modal-container">
      <!-- 모달 헤더 -->
      <div class="modal-header">
        <h5 class="modal-title">권한 부여</h5>
        <button type="button" class="btn-close" @click="closeModal" />
      </div>

      <!-- 모달 바디 -->
      <div class="modal-body">

        <!-- 사용자 검색 -->
        <DefaultFormRow marginBottom="5px">
          <DefaultLabel text="사용자 검색" forId="userSearch" size="small" />
        </DefaultFormRow>
        <DefaultFormRow>
          <UserSearchDropdown
            inputId="userSearch"
            inputSize="full"
            style="width: 100%"
            :includeCurrentUser="true"
            :keepSearchValue="false"
            placeholder="이름(이메일)을 입력하여 검색"
            @userSelected="onUserSelected"
          />
        </DefaultFormRow>

        <!-- 선택된 사용자 (읽기 전용 텍스트필드) -->
        <DefaultFormRow marginBottom="5px" marginTop="15px">
          <DefaultLabel text="선택된 사용자" forId="selectedUser" size="small" />
        </DefaultFormRow>
        <DefaultFormRow marginBottom="15px">
          <DefaultTextfield
            type="text"
            id="selectedUser"
            v-model="selectedUserLabel"
            size="full"
            style="width: 100%"
            disabled="true"
          />
        </DefaultFormRow>

        <!-- 서비스 선택 -->
        <DefaultFormRow marginBottom="5px">
          <DefaultLabel text="서비스" forId="serviceSearch" size="small" />
        </DefaultFormRow>
        <DefaultFormRow marginBottom="15px">
          <DefaultSelect
            id="serviceSearch"
            v-model="selectedService"
            :options="serviceOptions"
            size="full"
            style="width: 100%"
            :placeholder="serviceOptions.length === 0 
              ? '모든 서비스 권한이 추가되어있습니다' 
              : '서비스 선택'"
            :disabled="!selectedUserId || serviceOptions.length === 0"
          />
        </DefaultFormRow>

        <!-- 권한 선택 -->
        <DefaultFormRow marginBottom="5px">
          <DefaultLabel text="권한" forId="permissionSearch" size="small" />
        </DefaultFormRow>
        <DefaultFormRow marginBottom="20px">
          <DefaultSelect
            id="permissionSearch"
            v-model="selectedRoleDetail"
            :options="roleOptionsForSelectedService"
            size="full"
            style="width: 100%"
            placeholder="권한 선택"
            :disabled="!selectedService"
          />
        </DefaultFormRow>

        <!-- 버튼 영역 -->
        <DefaultFormRow marginBottom="5px" align="right">
          <DefaultButton
            size="small"
            @click="closeModal"
            margin-right="5px"
            color="gray"
          >
            취소
          </DefaultButton>
          <DefaultButton
            size="small"
            type="primary"
            @click="addPermission"
          >
            추가
          </DefaultButton>
        </DefaultFormRow>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import DefaultSelect from '@/components/common/select/DefaultSelect.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import UserSearchDropdown from '@/components/auth/UserSearchDropdown.vue';
import AuthUserPermissionApi from '@/api/auth/UserPermissionApi';
import { toast } from 'vue3-toastify';

// 모달 이벤트 정의
defineProps({});
const emit = defineEmits(['close', 'permissionAdded']);

// 선택값
const selectedUserId = ref('');
const selectedUserLabel = ref('');  // 새로 추가: 화면에 표시할 사용자 이름(이메일)
const selectedUserEmail = ref('');
const selectedService = ref('');
const selectedRoleDetail = ref('');

// 사용자 옵션, 서비스 옵션, 권한 옵션
const userOptions = ref([]);     // 전체 사용자 목록
// const serviceOptions = ref([]);  // 전체 서비스 목록
const allRoles = ref([]);        // 모든 권한 목록

// 모달 닫기
function closeModal() {
  emit('close');
}

// 서비스가 선택되면 해당 서비스의 권한 목록만 필터링
const roleOptionsForSelectedService = computed(() => {
  if (!selectedService.value) return [];
  // 전체 roles 중에서, 현재 선택된 서비스만 추출
  let filtered = allRoles.value.filter(
    role => role.serviceName === selectedService.value
  );

  // "현재 선택된 유저"가 이미 가지고 있는 (serviceName, roleNameDetail) 찾기
  const user = userOptions.value.find(u => u.value === selectedUserId.value);
  if (user) {
    // 이 유저가 가진 권한 중 '현재 선택된 서비스'인 것만 뽑아오기
    const userHasForThisService = user.roles
      .filter(r => r.serviceName === selectedService.value)
      .map(r => r.roleNameDetail);

    // 이미 가진 권한은 목록에서 제외
    filtered = filtered.filter(
      r => !userHasForThisService.includes(r.roleNameDetail)
    );
  }

  return filtered.map(r => ({
    value: r.roleNameDetail, // "사원", "관리자" 등
    label: r.roleNameDetail
  }));
});

// 서비스 선택이 변경되면 권한 선택값 초기화
watch(selectedService, () => {
  // 새 서비스 선택 시, 이전에 선택한 권한은 초기화합니다.
  selectedRoleDetail.value = '';
});

watch(selectedUserId, () => {
  // 유저가 바뀌면 서비스, 권한을 초기화
  selectedService.value = '';
  selectedRoleDetail.value = '';
});

function onUserSelected(option) {
  if (!option) return;
  selectedUserId.value = option.value;
  selectedUserLabel.value = option.label;
  selectedUserEmail.value = option.email;
}

// 권한 추가
async function addPermission() {
  // userId, serviceName, roleNameDetail가 모두 있어야 함
  if (!selectedUserId.value || !selectedService.value || !selectedRoleDetail.value) {
    toast.error('모든 항목을 선택하세요.');
    return;
  }

  const params = {
    userId: selectedUserId.value,
    email:        selectedUserEmail.value,
    serviceName: selectedService.value,
    roleNameDetail: selectedRoleDetail.value
  };

  await AuthUserPermissionApi.createUserWithRole(params);
  toast.success('권한이 추가되었습니다.');
  emit('permissionAdded');
}

/**
 * (수정) serviceOptions를 computed로 선언
 * - selectedUserId가 없으면 전체를 그대로 보여주거나, 빈 배열로 처리
 * - user가 이미 가진 serviceName은 제외
 */
const serviceOptions = computed(() => {
  // (1) 아직 유저를 선택 안 했다면 전체 목록 그대로 or 빈 배열
  if (!selectedUserId.value) {
    const uniqueService = [...new Set(allRoles.value.map(r => r.serviceName))];
    return uniqueService.map(s => ({ value: s, label: s }));
  }

  // (2) 현재 선택된 유저를 찾는다
  const user = userOptions.value.find(u => u.value === selectedUserId.value);
  if (!user) {
    // 혹은 전체를 보여주고 싶다면, 여기서도 위와 동일한 로직
    return [];
  }

  // (3) 유저가 이미 가진 serviceName 목록
  const userHasServices = user.roles.map(r => r.serviceName);

  // (4) 전체 서비스 목록
  let uniqueSrv = [...new Set(allRoles.value.map(r => r.serviceName))];

  // (5) 이미 가진 서비스는 제외
  uniqueSrv = uniqueSrv.filter(s => !userHasServices.includes(s));

  // (6) 최종 결과
  return uniqueSrv.map(s => ({ value: s, label: s }));
});

// (3) 모달 오픈 시점에 사용자 목록, 전체 권한 목록 가져오기
onMounted(async () => {
  // 사용자 목록
  const response = await AuthUserPermissionApi.getUsersWithRoles();
  const userList = response.data.userWithRolesList || [];
  userOptions.value = userList.map(u => ({
    value: u.userId,
    label: `${u.name} (${u.email})`,
    email: u.email,
    roles: u.roles
  }));

  // 전체 권한 목록
  allRoles.value = response.data.authRoles.allRoles || [];

  // 서비스 옵션
  // const uniqueService = [...new Set(allRoles.value.map(r => r.serviceName))];
  // serviceOptions.value = uniqueService.map(svc => ({
  //   value: svc,
  //   label: svc
  // }));
});
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1050;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* 모달 컨테이너 */
.modal-container {
  background: #fff;
  width: 400px;
  border-radius: 4px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
  animation: fadeIn 0.3s;
  padding: 1rem;
}

/* 헤더 */
.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
}

.modal-body {
  max-height: 70vh;
  overflow-y: auto;
}

/* 검색 결과 목록 스타일 */
.search-result {
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 4px;
  max-height: 150px;
  overflow-y: auto;
  margin: 0 0 15px 0;
  list-style: none;
  padding: 0;
}

.search-result li {
  padding: 8px 10px;
  cursor: pointer;
  font-size: 0.7rem;
}

.search-result li:hover {
  background-color: #f2f2f2;
}

/* 간단한 fadeIn 애니메이션 */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@media (max-width: 500px) {
  .modal-container {
    width: 300px;
  }

  .search-result li {
    padding: 8px 10px;
    cursor: pointer;
    font-size: 0.45rem;
  }
}
</style>
