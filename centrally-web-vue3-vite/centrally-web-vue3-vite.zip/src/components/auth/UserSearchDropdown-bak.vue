<template>
  <div class="search-wrapper">
    <!-- 검색어 입력 -->
    <DefaultTextfield
      :id="inputId"
      type="text"
      v-model="searchTerm"
      :size="inputSize"
      :placeholder="computedPlaceholder"
      @keydown="handleKeydown"
    />

    <!-- 검색 결과 목록 (dropdown) -->
    <ul ref="dropdownList" v-if="showList" class="search-result list-group">
      <li
        v-for="(option, index) in filteredOptions"
        :key="option.value"
        :class="['list-group-item', { active: index === activeIndex }]"
        @click="onSelectUser(option)"
      >
        {{ option.label }}
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, defineExpose, defineProps, defineEmits, watch } from 'vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import { useAuthStore } from '@/store/auth'
import { useUserDirectoryStore } from '@/store/hrm/userDirectory'

// ====================== Props ======================
const props = defineProps({
  labelText: {
    type: String,
    default: '사용자 검색'
  },
  inputId: {
    type: String,
    default: 'userSearch'
  },
  placeholder: {
    type: String,
    default: '이름(이메일)을 입력하여 검색'
  },
  inputSize: {
    type: String,
    default: 'medium'
  },
  // 선택 후 입력값 유지 여부
  keepSearchValue: {
    type: Boolean,
    default: true
  },
  // 자기 자신도 검색에 포함할지 여부 (기본: false = 자기 자신 제외)
  includeCurrentUser: {
    type: Boolean,
    default: false
  }
});

// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

// ====================== Emits ======================
const emit = defineEmits(['userSelected']);

// ====================== State ======================
const authStore = useAuthStore();
const searchTerm = ref('');
const userOptions = ref([]); // 최종 사용자 목록(옵션)
const activeIndex = ref(-1);
const dropdownOpen = ref(true);

// ====================== Computed ======================
/** 검색어가 있을 때만 필터링 */
const filteredOptions = computed(() => {
  if (!searchTerm.value) return [];
  const lowerTerm = searchTerm.value.toLowerCase();
  return userOptions.value.filter(option =>
    option.label.toLowerCase().includes(lowerTerm)
  );
});

/** 드롭다운 표시 여부 */
const showList = computed(() => {
  return dropdownOpen.value && searchTerm.value && filteredOptions.value.length > 0;
});

/** 검색어가 ''가 되면 userSelected에 '' emit (keepSearchValue=true일 경우) */
watch(searchTerm, (newVal) => {
  if (props.keepSearchValue && newVal === '') {
    emit('userSelected', '');
  }
});

// ====================== onMounted ======================
onMounted(async () => {
  try {
    const raw = await userDirStore.ensureLoaded()   // 호출은 한 번만!
    userOptions.value = raw
      .filter(u => props.includeCurrentUser || u.userId !== authStore.getUserId)
      .map(mapUser)
  } catch (e) {
    console.error('사용자 목록 조회 실패', e)
  }
})

// ====================== mapUser 함수 ======================
/**
 * HrmUser 데이터 -> 드롭다운 표시용 option
 * 기존: '이름 (이메일)' 만 표시하던 방식
 * 필요 시 '/ 부서 / 팀' 등 추가 가능
 */
function mapUser(user) {
  // team / department 정보가 있을 수 있음
  let deptName = '미지정';
  let teamName = '미지정';
  if (user.team) {
    teamName = user.team || '미지정';
    if (user.department) {
      deptName = user.department || '미지정';
    }
  }

  // 기본: '이름 (이메일)' 
  // 필요 시: ` - ${deptName} / ${teamName}` 같은 식으로 확장
  const labelStr = `${user.name} (${user.email})`;

  return {
    value: user.userId,
    label: labelStr,   // 표시 텍스트
    userId: user.userId,
    name: user.name,
    email: user.email,
    department: deptName,
    team: teamName
    // etc...
  };
}

// ====================== Dropdown & Keyboard ======================
const dropdownList = ref(null);

function scrollActiveItemInView() {
  if (!dropdownList.value) return;
  const listItems = dropdownList.value.querySelectorAll('li');
  if (activeIndex.value >= 0 && activeIndex.value < listItems.length) {
    listItems[activeIndex.value].scrollIntoView({
      behavior: 'smooth',
      block: 'nearest'
    });
  }
}

function handleKeydown(e) {
  dropdownOpen.value = true;
  if (!showList.value) return;
  if (e.key === 'ArrowDown') {
    if (activeIndex.value < filteredOptions.value.length - 1) {
      activeIndex.value++;
      scrollActiveItemInView();
    }
    e.preventDefault();
  } else if (e.key === 'ArrowUp') {
    if (activeIndex.value > 0) {
      activeIndex.value--;
      scrollActiveItemInView();
    }
    e.preventDefault();
  } else if (e.key === 'Enter') {
    selectActiveOption();
    e.preventDefault();
  } else if (e.key === 'Escape') {
    searchTerm.value = '';
    activeIndex.value = -1;
    emit('userSelected', '');
    e.preventDefault();
  } else if (e.key === 'Tab') {
    // Tab 키를 누르면 드롭다운을 숨김
    dropdownOpen.value = false;
    activeIndex.value = -1;
  }
}

function selectActiveOption() {
  if (
    activeIndex.value >= 0 &&
    activeIndex.value < filteredOptions.value.length
  ) {
    onSelectUser(filteredOptions.value[activeIndex.value]);
  }
}

function onSelectUser(option) {
  // 부모 컴포넌트로 선택된 항목 전달
  emit('userSelected', option);

  activeIndex.value = -1;
  
  if (!props.keepSearchValue) {
    searchTerm.value = '';
  } else {
    // 기존 로직: '검색어가 이메일 or 이름이면 그대로 남기고, 아니면 label 사용'
    const lowerSearch = searchTerm.value.toLowerCase();
    if (option.email.toLowerCase().includes(lowerSearch)) {
      searchTerm.value = option.email;
    } else if (option.name.toLowerCase().includes(lowerSearch)) {
      searchTerm.value = option.name;
    } else {
      searchTerm.value = option.label;
    }
  }
  
  dropdownOpen.value = false;
}

// ====================== 외부 노출 ======================
defineExpose({
  resetSearch: () => {
    searchTerm.value = '';
    activeIndex.value = -1;
  }
});

const computedPlaceholder = computed(() =>
  props.includeCurrentUser
    ? props.placeholder               // 본인도 포함할 때
    : `${props.placeholder} | 본인 제외` // 기본(본인 제외) → 안내 문구 추가
);

</script>

<style scoped>
.search-wrapper {
  position: relative;
}
.search-result {
  position: absolute;
  top: 100%;
  left: 50%;
  transform: translateX(-50%);
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 0 0 4px 4px;
  max-height: 150px;
  overflow-y: auto;
  margin: 0;
  padding: 0;
  z-index: 1000;
  list-style: none;
  width: auto;
  min-width: 100%;
}
.search-result li {
  padding: 8px 10px;
  cursor: pointer;
  font-size: 0.7rem;
}
.search-result li:hover,
.search-result li.active {
  background-color: #f2f2f2;
  color: black;
}

@media (max-width: 650px) {
  .list-group-item,
  .list-group {
    font-size: 0.6rem !important;
  }
  .search-result li {
    font-size: 0.6rem !important;
  }
}

@media (max-width: 500px) {
  .list-group-item,
  .list-group {
    font-size: 0.6rem !important;
  }
  .search-result li {
    font-size: 0.6rem !important;
  }
}
</style>
