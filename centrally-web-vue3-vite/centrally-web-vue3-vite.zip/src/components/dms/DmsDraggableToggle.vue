<template>
  <!-- 드래그 핸들(📂) -->
  <button
    class="dms-toggle"
    :style="{ left: pos.x + 'px', top: pos.y + 'px' }"
    @pointerdown.stop="startDrag"
    @click.stop="handleClick"
    title="문서 트리 열기"
  >
    📂
  </button>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useDmsSidebarStore } from '@/store/dms/dmsSidebar'

/* ───── 상수 ───── */
const BTN  = 42      // 버튼 지름
const HEAD = 60      // 헤더 높이
const TH   = 5       // 드래그로 간주할 최소 이동(px)

/* ───── 상태 ───── */
const drawer = useDmsSidebarStore()
const pos = ref({ x: window.innerWidth - BTN - 18, y: HEAD + 5 })

/* 위치 제한 함수 */
function clamp ({ x, y }) {
  return {
    x: Math.min(Math.max(0, x), window.innerWidth  - BTN),
    y: Math.min(Math.max(HEAD, y), window.innerHeight - BTN)
  }
}

/* 초기 위치 복원 + 리사이즈 대응 */
function onResize () {
  pos.value = clamp(pos.value)
}
onMounted(() => {
  const saved = localStorage.getItem('dmsTogglePos')
  if (saved) pos.value = clamp(JSON.parse(saved))
  window.addEventListener('resize', onResize)
})
onUnmounted(() => window.removeEventListener('resize', onResize))

/* ───── 드래그 로직 ───── */
let dragging = false
let moved    = false
let sx = 0, sy = 0, dx = 0, dy = 0

function startDrag (e) {
  e.currentTarget.setPointerCapture(e.pointerId) // 포인터 캡처
  dragging = true
  moved    = false
  sx = e.clientX
  sy = e.clientY
  dx = sx - pos.value.x
  dy = sy - pos.value.y

  window.addEventListener('pointermove', onMove)
  window.addEventListener('pointerup',   stopDrag)
  window.addEventListener('pointercancel', stopDrag)
}

function onMove (e) {
  if (!dragging) return

  const deltaX = e.clientX - sx
  const deltaY = e.clientY - sy

  /* 5 px 이상 움직였을 때만 드래그로 간주 */
  if (!moved && (Math.abs(deltaX) > TH || Math.abs(deltaY) > TH)) moved = true

  if (moved) {
    pos.value = clamp({ x: e.clientX - dx, y: e.clientY - dy })
  }
}

function stopDrag () {
  dragging = false
  localStorage.setItem('dmsTogglePos', JSON.stringify(pos.value))

  window.removeEventListener('pointermove', onMove)
  window.removeEventListener('pointerup',   stopDrag)
  window.removeEventListener('pointercancel', stopDrag)
}

/* 짧게 탭(클릭) → 드래그가 없었을 때만 사이드바 열기 */
function handleClick () {
  if (!moved) drawer.open()
}
</script>

<style scoped>
.dms-toggle{
  position: fixed;
  z-index: 1012;
  width: 42px; height: 42px;
  border: none; border-radius: 50%;
  background:#8f8f8f; color:#fff;
  font-size: 1.2rem; cursor: grab;
  opacity: .9;
  transition: box-shadow .2s;
  touch-action: none;   /* 모바일 드래그 안정화 */
  user-select: none;
}
.dms-toggle:hover  {
  box-shadow: 0 2px 8px rgba(0,0,0,.25);
}
.dms-toggle:active {
  cursor: grabbing;
}
</style>
