<template>
  <div class="content content-wrapper">
    <h2 class="content-title">
      <DefaultFormRow marginBottom="5px" align="left">
        <DefaultLabel text="제목 수정 : " /> 
        <DefaultTextfield
          type="text"
          v-model="title"
          :placeholder="placeholder"
          size="large"
        />
        </DefaultFormRow>
    </h2>
    <p class="content-sub-title">
      <DefaultFormRow marginBottom="5px" align="left">
        <DefaultLabel text="경로 수정 : " />
        <DefaultTextfield
          type="text"
          :placeholder="subTitle == '' ? placeholderSubTitle : subTitle"
          disabled="false"
          size="large"
        />
        <DefaultButton 
          size="small"
          color="gray"
          marginLeft="10px"
          @click="openPathPicker"
        >
          경로
        </DefaultButton>
      </DefaultFormRow>
    </p>

    <!-- 뒤로가기 -->
    <div class="button-group"></div>

    <!-- 작성자 / 날짜 -->
    <DefaultFormRow marginBottom="5px" align="between">
      <div>
        <DefaultLabel text="작성자 : " />
        <DefaultLabel text="관리자" margin-right="0px"/>
      </div>
      <div>
        <DefaultFormRow>
          <DefaultButton 
            marginRight="5px"
            @click="showPermissionModal = true"
          >
            권한 부여
          </DefaultButton>
          <DefaultButton 
            @click="fileInput.click()"
          >
            첨부파일 등록
          </DefaultButton>
          <input
            ref="fileInput"
            type="file"
            multiple
            style="display:none"
            @change="handleFileChange"
          />
        </DefaultFormRow>
      </div>
    </DefaultFormRow>

    <!-- WYSIWYG 편집기 -->
    <QuillyEditor
      ref="quillRef"
      v-model="body"
      :options="editorOptions"
      style="height:300px"
      class="border rounded quill-box"
    />

    <DefaultFormRow marginBottom="10px" marginTop="20px">
      <div>
        <DefaultLabel
          text="첨부 파일"
          size="small"
          margin-bottom="5px"
        />
        <!-- 첨부 파일 영역 : 기존 + 새 파일 목록 + X 버튼 -->
        <ul class="attachment-list">
          <!-- 기존 첨부파일 -->
          <li v-for="(file, idx) in nonImageFiles" :key="file.id">
            <a :href="file.url" target="_blank" rel="noopener noreferrer">
              <DefaultLabel text="[다운로드]" size="small" />
              {{ file.name }}
            </a>
            <!-- 삭제 버튼 -->
            <button
              type="button"
              class="btn btn-danger square-btn ms-2"
              @click="removeExistingFile(idx, file.id)"
            >x</button>
          </li>

          <!-- 새로 선택한 파일 목록 -->
          <li v-for="(file, idx) in newFiles" :key="'new-'+idx">
            {{ file.name }}
            <button
              type="button"
              class="btn btn-danger square-btn ms-2"
              @click="removeNewFile(idx)"
            >x</button>
          </li>
        </ul>
      </div>
    </DefaultFormRow>

    <!-- </div> -->
    <hr />
    <!-- 완료 -->
    <DefaultFormRow marginBottom="5px" align="right">
      <DefaultButton
        @click="submit"
      >
        완료
      </DefaultButton>
    </DefaultFormRow>

    <!-- 권한 부여 모달 컴포넌트 -->
    <DmsUsersPermissionModal
      v-model="showPermissionModal"
      @confirm="handlePermissionConfirm"
    />

  </div>
</template>

<script setup>
/* ------------ import ------------ */
import { ref, onMounted, nextTick } from 'vue'
import Quill       from 'quill'
import { QuillyEditor } from 'vue-quilly'
import DefaultButton from '@/components/common/button/DefaultButton.vue'
import DefaultFormRow from '@/components/common/DefaultFormRow.vue'
import DefaultLabel from '@/components/common/label/DefaultLabel.vue'
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue'
import DmsUsersPermissionModal from '@/components/dms/DmsUsersPermissionModal.vue'

/* ------------ 상태 ------------ */
const title               = ref('');
const subTitle            = ref('');
const body                = ref('');
const placeholder = '제목을 입력해 주세요'
const placeholderSubTitle = '경로를 지정해 주세요'
const showPermissionModal = ref(false);

/* 예시 더미 파일 1개 추가 */
const nonImageFiles = ref([
  { id: 1, name: 'sample.pdf', url: '/files/sample.pdf' }
]);
const fileInput      = ref(null);   // input 엘리먼트 참조
const newFiles       = ref([]);     // 새로 선택한 파일
const deletedFileIds = ref([]);     // 기존 파일 중 삭제된 id 저장

/* 파일 선택 */
function handleFileChange(e) {
  newFiles.value.push(...e.target.files);
  e.target.value = '';              // 같은 파일 재선택 가능하도록 리셋
}

/* 기존 첨부파일 삭제 */
function removeExistingFile(idx, id) {
  nonImageFiles.value.splice(idx, 1);
  deletedFileIds.value.push(id);
}

/* 새 첨부파일 삭제 */
function removeNewFile(idx) {
  newFiles.value.splice(idx, 1);
}

/* ------------ 메서드 ------------ */
function openPathPicker() {
  // TODO: 경로(트리) 선택 모달 오픈
}

function handlePermissionConfirm (selectedUsers) {
  // TODO: 권한 저장 API 호출
  console.log('선택된 사용자', selectedUsers)
}

function submit() {
  // TODO: 저장 로직
  console.log('저장 완료')
}

/* Quill 옵션 (원하면 툴바 배열로 커스터마이즈) */
const quillRef   = ref(null)
const editorOptions = {
  theme  : 'snow',
  modules: { toolbar: true }
}
/* ----------- onMounted ----------- */
onMounted(async () => {
  await nextTick()
  quillRef.value?.initialize(Quill)  // vue-quilly → 실제 Quill 인스턴스 주입
})
</script>

<style scoped>
.content-sub-title {
  padding-left: 0px;
}
.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  line-height: 1;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}
.attachment-list {
  font-size: 0.8rem;
}
.attachment-list {
  margin-bottom: 0px;
}
@media (max-width: 650px) {
  .square-btn {
    width: 14px;
    height: 14px;
    padding: 0;
    font-size: 0.5rem;
  }
  .attachment-list {
    font-size: 0.7rem;
  }
}
@media (max-width: 500px) {
  .square-btn {
    width: 12px;
    height: 12px;
  }
}
</style>
