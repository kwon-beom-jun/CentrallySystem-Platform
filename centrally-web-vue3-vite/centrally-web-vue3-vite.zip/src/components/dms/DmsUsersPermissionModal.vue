<template>
  <b-modal
    v-model="innerVisible"
    size="sm"
    no-close-on-backdrop
    centered
    fade
    hide-footer
  >
    <template #title>
      <div class="permission-title">유저 권한 관리</div>
    </template>
    <form @submit.prevent="submit" @keydown.enter.prevent>
      <!-- ── 사용자 검색 ─────────────────────────── -->
      <div class="form-group search-wrapper">
        <DefaultLabel text="참여자 검색" forId="userSearch" size="small" marginBottom="5px" />
        <UserSearchDropdown
          ref="userSearchDropdownRef"
          inputId="userSearch"
          inputSize="full"
          :keepSearchValue="false"
          placeholder="이름(이메일)을 입력하여 검색"
          @userSelected="onUserSelected"
        />
      </div>

      <!-- ── 추가 인원 목록 ──────────────────────── -->
      <div v-if="addedPeople.length" class="form-group">
        <DefaultLabel text="추가 인원 목록" size="small" marginBottom="5px" />
        <ul class="list-group">
          <li v-for="p in addedPeople" :key="p.userId" class="list-group-item">
            {{ p.name }} / {{ p.department }} / {{ p.team }}
          </li>
        </ul>
      </div>

      <!-- ── 현재 권한 목록 ──────────────────────── -->
      <div v-if="currentPermissions.length" class="form-group">
        <DefaultLabel text="현재 권한 목록" size="small" marginBottom="5px" />
        <ul class="list-group">
          <li v-for="p in currentPermissions" :key="p.userId" class="list-group-item">
            {{ p.name }} / {{ p.department }} / {{ p.team }}
          </li>
        </ul>
      </div>

      <!-- ── Footer ─────────────────────────────── -->
      <div class="modal-footer">
        <DefaultButton color="gray" marginRight="5px" @click="closeModal">취소</DefaultButton>
        <DefaultButton type="submit">등록</DefaultButton>
      </div>
    </form>
  </b-modal>
</template>

<script setup>
import { ref, defineProps, defineEmits, watch } from 'vue'
import { BModal } from 'bootstrap-vue-3'
import DefaultButton from '@/components/common/button/DefaultButton.vue'
import DefaultLabel from '@/components/common/label/DefaultLabel.vue'
import UserSearchDropdown from '@/components/auth/UserSearchDropdown.vue'
import { toast } from 'vue3-toastify'

/* ---------- props / emits ---------- */
const props = defineProps({ isVisible: Boolean });
const emit  = defineEmits(['close', 'confirm']);

/* ---------- 모달 표시 제어 ---------- */
const innerVisible = ref(props.isVisible)
watch(() => props.isVisible, v => (innerVisible.value = v));
watch(innerVisible, v => { if (!v) emit('close') });

/* ---------------- 데이터 ---------------- */
/* ※ 실제 데이터는 API 호출 결과로 대체 */
const currentPermissions = ref([
  { userId: 99, name: '홍길동', department: '총무부', team: 'A팀' },
  { userId: 98, name: '임꺽정', department: '개발부', team: 'B팀' },
])

const addedPeople = ref([]);
const userSearchDropdownRef = ref(null);

/* ---------------- 행동 ---------------- */
function onUserSelected(user) {
  // 이미 권한 보유 or 추가 대기 중인지 체크
  if (
    currentPermissions.value.some(p => p.userId === user.userId) ||
    addedPeople.value.some(p => p.userId === user.userId)
  ) {
    toast.warning('이미 권한이 있거나 추가된 사용자입니다.')
    return
  }
  addedPeople.value.push(user)
}

function resetForm() {
  addedPeople.value = []
  userSearchDropdownRef.value?.resetSearch?.()
}

function closeModal() {
  innerVisible.value = false
}

function submit() {
  if (!addedPeople.value.length) {
    toast.warning('추가된 사용자가 없습니다.')
    return
  }
  /* emit 으로 부모에 전달하거나, 여기서 바로 API 호출 */
  emit('confirm', addedPeople.value)

  /* 성공 시 현재 권한 목록에 반영 */
  currentPermissions.value.push(...addedPeople.value)
  resetForm()
  innerVisible.value = false
}
</script>


<style scoped>
.permission-title {
  font-size: 1.2rem;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}
.reason {
  margin-top: 10px;
}
.form-group {
  margin-bottom: 20px;
}
.form-row {
  display: flex;
  gap: 10px;
}
.list-group {
  font-size: 0.7rem;
}
.form-control, .attachment-list {
  font-size: 0.8rem;
}
.attachment-list {
  margin-bottom: 0px;
}
.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  line-height: 1;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

@media (max-width: 650px) {
  .permission-title {
    font-size: 1rem;
  }
  .list-group-item, .list-group {
    font-size: 0.65rem !important;
  }
  .form-group {
    margin-bottom: 10px;
  }
  .align-items-center {
    margin-bottom: 0px !important;
  }
  .form-control, .attachment-list {
    font-size: 0.7rem;
  }
}

@media (max-width: 500px) {
  /* .list-group-item, .list-group {
    font-size: 0.7rem !important;
  }
  .form-control, .attachment-list {
    font-size: 0.55rem;
  } */
}
</style>
