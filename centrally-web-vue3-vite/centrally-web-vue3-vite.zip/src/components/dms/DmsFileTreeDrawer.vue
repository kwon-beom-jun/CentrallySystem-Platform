<template>
  
  <DmsDraggableToggle v-if="showDmsToggle && !drawer.isOpen" />

  <v-layout style="display: contents" class="file-tree-sidebar">
    <!-- inset : MainNav 옆에 붙음 -->
    <!-- 데스크톱: 항상 보이기 -->
    <!-- lg 이하(≤650px): 오버레이 전환 -->
    <v-navigation-drawer
      v-model="drawer.isOpen"
      temporary
      scrim
      elevation="2"
      class="dms-drawer d-flex flex-column"
      :style="{ '--dms-drawer-width': effectiveWidth + 'px' }"
      :width="effectiveWidth"
    >
      <v-toolbar density="comfortable" color="primary">
        <v-toolbar-title class="text-body-1 font-weight-bold dms-toolbar-title">
          문서 트리
        </v-toolbar-title>
        <v-btn
          icon="mdi-chevron-left"
          variant="text"
          class="me-1"
          @click="drawer.close()"
        />
      </v-toolbar>

      <v-treeview
        :items="tree"
        item-title="title"
        item-value="id"
        open-on-click
        density="compact"
        selectable
        selection-type="leaf"
        v-model:selected="selected"
        @update:selected="onSelect"
        class="flex-grow-1 overflow-y-auto"
      />
      
      <!-- <v-divider class="mb-1" /> -->
      
      <v-toolbar density="comfortable" color="surface" class="page-add-toolbar">
        <v-toolbar-title class="text-body-1 font-weight-bold dms-toolbar-title">
          페이지 추가
        </v-toolbar-title>
        <v-btn
          icon="mdi-plus"
          variant="text"
          class="me-1"
          @click="goAddPage"
        />
      </v-toolbar>

      <!-- 우측 드래그 핸들 -->
      <div class="resize-handle" @pointerdown="startResize" />
    </v-navigation-drawer>
  </v-layout>
</template>

<script setup>
import { ref, watch, computed, onMounted, onUnmounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { useDmsSidebarStore } from '@/store/dms/dmsSidebar';
import DmsDraggableToggle from '@/components/dms/DmsDraggableToggle.vue';
import { useSidebarStore } from '@/store/sidebar';

const router = useRouter();
const route  = useRoute()
const drawer = useDmsSidebarStore();

const sidebarStore = useSidebarStore();

/* ───────── 페이지 추가 라우팅 ───────── */
function goAddPage() {
  drawer.close();                    // 모바일일 때 트리 닫기
  router.push('/dms/dms-create-modify-page');
}

/* 화면 너비 반응형 ----------------------- */
const windowWidth = ref(window.innerWidth)
function handleResize() {
  windowWidth.value = window.innerWidth
}
onMounted(() => window.addEventListener('resize', handleResize))
onUnmounted(() => window.removeEventListener('resize', handleResize))

/* ───────── 폭 드래그 로직 ───────── */
const dragging    = ref(false);
const startX      = ref(0);
const startWidth  = ref(0);
const maxWidth    = ref(0)
const MIN_WIDTH   = 180

const effectiveWidth = computed(() => {
  const offset = isMobile.value ? 80 : 260
  const limit  = windowWidth.value - offset
  return Math.min(drawer.width, limit)
})

function startResize (e){
  // 텍스트 블록 방지
  e.preventDefault();
  dragging.value  = true;
  startX.value    = e.clientX;
  startWidth.value= drawer.width;

  /* ── 화면 경계 기준 최대 폭 계산 ── */
  const offsetLeft = isMobile.value ? 80 : 260 // 메인 네비 폭 + 여유(스크롤바·패딩)
  maxWidth.value   = windowWidth.value         // 전체 화면
                    - offsetLeft

  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup'  , stopResize);

}

function onMove (e) {
  if(!dragging.value) return;
  const delta = e.clientX - startX.value;
  let next    = startWidth.value + delta
  /* ── 최대‧최소 폭 제한 ── */
  next = Math.min(Math.max(MIN_WIDTH, next), maxWidth.value)
  drawer.setWidth(next)
}

function stopResize () {
  dragging.value = false;
  window.removeEventListener('pointermove', onMove);
  window.removeEventListener('pointerup', stopResize)
}

// ────────────────────── 더미 트리 데이터 ──────────────────────
const tree = ref([
  {
    id: 1, title: '회사 규정집', children: [
      { id: 3, title: '인사 규정', children: [
        { id: 5, title: '채용 프로세스 테스트 어디까지 길어지나 확인', leaf: true },
        { id: 6, title: '휴가 정책',      leaf: true },
      ]},
      { id: 4, title: '보안 규정', leaf: true },
    ],
  },
  { id: 2, title: '템플릿', children: [
      { id: 7, title: '회의록 양식', leaf: true },
    ],
  },
]);

/* 선택 <-> 라우터 파라미터 동기화 */
const selected = ref([ +(route.params.nodeId ?? 0) ])

watch(() => route.params.nodeId, id => {
  selected.value = [ +(id ?? 0) ]
})

function onSelect (ids){
  if(!ids.length) return
  const id = +ids[0]
  router.push({ name: 'DmsNode', params: { nodeId:id } })
  drawer.close()
}

// 모바일 판별
const isMobile = ref(window.innerWidth <= 650);
function onResize() {
  isMobile.value = window.innerWidth <= 650;
}
/** 모바일 첫 진입 → 문서 Drawer 닫힘 */
onMounted(() => {
  if (window.innerWidth <= 650) drawer.close();
});
onMounted(() => 
  window.addEventListener('resize', onResize)
);
onUnmounted(() => 
  window.removeEventListener('resize', onResize)
);

const showDmsToggle = computed(() =>
  isMobile.value &&
  route.path.startsWith('/dms') &&   // 현재 문서관리 라우트
  !drawer.isOpen &&                  // 트리가 닫혀 있을 때만
  !sidebarStore.isSidebarOpen
);
</script>

<style scoped>
.dms-drawer {
  position: fixed;        /* ← Vuetify 기본값이지만 명시해두면 충돌 방지  */
  top: 65px !important;   /* 헤더 높이 */
  /* width: 100% !important;
  margin-right: 10px; */
  bottom: 0 !important;
  height: auto !important;
  border-right: 1px solid #e0e0e0;
  min-width: var(--dms-drawer-width,100px);
  border-right: 1px solid rgba(var(--v-theme-on-surface),.12);
  background   : rgba(var(--v-theme-surface),.96);
  backdrop-filter: blur(4px);
  box-shadow: 2px 0 8px rgba(0,0,0,.06);
  transition: transform var(--sidebar-slide),
              opacity   var(--sidebar-slide);
}
.v-navigation-drawer {
  z-index: 1009 !important;
}
.v-navigation-drawer__scrim {
  position: fixed !important;   /* 뷰포트 기준 */
  inset: 0 !important;          /* top/right/bottom/left = 0 */
}
.dms-drawer:not(.v-navigation-drawer--active) {
  transform: translateX(-100%) !important;
  width: 0 !important;           /* 실제 폭 0 */
  border: 0;                     /* 남아 있던 1px 라인 제거 */
  pointer-events: none;          /* 이미 있었지만 명시해 둡니다 */
  opacity  : 0;
}

/* 드래그 핸들 */
.resize-handle {
  position: absolute;
  top: 0;
  right: -12px;
  width: 24px;
  height: 100%;
  cursor: ew-resize;
  background: transparent;
}
.resize-handle:hover {
  background: rgba(var(--v-theme-primary),.12);
}

/* ───────── 트리뷰 ───────── */
.v-treeview{ padding:8px 0 12px; overflow-y:auto; }

/* 글꼴 크기 */
/* .v-treeview-node__root{ font-size:0.8rem; line-height:1.4; }
.v-toolbar-title       { font-size:0.8rem; } */

/* Hover / Active 하이라이트 */
.v-treeview-node__root:hover{
  background: rgba(var(--v-theme-primary),.08);
}
.v-treeview-node--active > .v-treeview-node__root{
  background: rgba(var(--v-theme-primary),.14);
  color: rgb(var(--v-theme-primary));
}

/* 스크롤바(리눅스·크롬 계열) */
.v-treeview::-webkit-scrollbar{ width:6px; }
.v-treeview::-webkit-scrollbar-thumb{
  background: rgba(var(--v-theme-primary),.45);
  border-radius:3px;
}

/* 체크박스 래퍼 통째로 숨기기 ── (scoped → v-deep 필수) */
:deep(.v-selection-control) {
  display: none !important;    /* ← 체크박스, ripple 통째로 제거 */
}

.page-add-toolbar {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
}

/* 모바일(<=650px) : overlay 로 쓰기 */
@media (max-width: 650px) {
  .dms-drawer {
    left:0 !important;
    /* width:33% !important; */
    width: var(--dms-drawer-width, 60vw) !important;
    transform: translateX(-100%);
    background: rgba(var(--v-theme-surface),.94);
    box-shadow:4px 0 14px rgba(0,0,0,.18);
  }

  /* ─── 트리 노드 글꼴 크기 ─── */
  :deep(.v-list-item-title) {
    font-size: 0.8rem !important;
  }

  .v-list-item--density-compact.v-list-item--one-line {
    min-height: 30px;
  }

  :deep(.v-list-item) {
    line-height: 0.5 !important;
    height: 30px !important;
  }

  /* ─── 툴바 제목 글꼴 크기 ─── */
  .dms-toolbar-title {
    font-size: 1rem !important;
  }
  :deep(.v-toolbar__content) {
    height: 54px !important;
  }
}

@media (max-width: 500px) {
  /* ─── 트리 노드 글꼴 크기 ─── */
  :deep(.v-list-item-title) {
    font-size: 0.7rem !important;
  }
  /* ─── 툴바 제목 글꼴 크기 ─── */
  .dms-toolbar-title {
    font-size: 0.8rem !important;
  }
}
</style>

