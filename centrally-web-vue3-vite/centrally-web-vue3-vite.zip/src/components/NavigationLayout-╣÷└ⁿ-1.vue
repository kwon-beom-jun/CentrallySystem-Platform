<!-- MobileLayer.vue ─ 650px 이하에서만 나타나는 하단-바 + 플로팅 시트 + 풀메뉴 -->
<template>
  <!-- ❶ 전체를 650px 이하에서만 렌더 -->
  <div v-if="isMobile">
    <!-- ───────── 하단 고정 바 ───────── -->
    <nav class="bottom-bar">
      <button @click="go('/hrm/notice-integrated')" aria-label="공지사항">
        <i class="ri-team-line"></i><span>공지</span>
      </button>

      <!-- 영수증 내역(개인)으로 이동 -->
      <button
        @click="go('/receipt/personal-receipt-history')"
        aria-label="영수증 내역"
      >
        <i class="ri-file-list-3-line"></i><span>영수증 내역</span>
      </button>

      <!-- <button @click="go('/receipt/receipt-request-overview')" aria-label="신청내역 현황">
        <i class="ri-code-s-slash-line"></i><span>신청내역</span>
      </button> -->

      <!-- 가운데 파란 + -->
      <button class="fab" @click="openSheet" aria-label="글쓰기">
        <i class="ri-add-line"></i>
      </button>

      <!-- <button @click="go('/receipt/annual-receipt-summary')" aria-label="년도별 요약">
        <i class="ri-calendar-2-line"></i><span>년도별 요약</span>
      </button> -->

      <button @click="toggleDmsDrawer" aria-label="문서 트리">
        <i class="ri-box-3-line"></i><span>문서 트리</span>
      </button>

      <button @click="toggleMenu" aria-label="더보기">
        <i class="ri-menu-line"></i><span>더보기</span>
      </button>
    </nav>

    <!-- ───────── 퀵메뉴(＋) ───────── -->
    <transition name="fade">
      <div v-if="sheet" class="quick-backdrop" @click.self="sheet = false">
        <div class="quick-menu">
          <!-- <router-link
            to="/receipt/receipt-submission"
            class="quick-item"
            @click="sheet = false"
          >
            <i class="ri-file-add-line"></i><span>영수증 등록</span>
          </router-link> --><!-- ✔ 버튼으로 교체 : 클릭 시 모달 오픈 -->
          <button
            class="quick-item"
            @click="openReceiptModal"
            :disabled="!CAN_RECEIPT_WRITE"
            v-if="CAN_RECEIPT_WRITE"
          >
            <i class="ri-file-add-line"></i><span>영수증 등록</span>
          </button>

          <!-- <router-link
            to="/hrm/notice-integrated?write"
            class="quick-item"
            @click="sheet = false"
          >
            <i class="ri-megaphone-line"></i><span>공지사항 작성</span>
          </router-link> -->
          <button
            class="quick-item"
            @click="openNoticeModal"
            :disabled="!CAN_NOTICE_WRITE"
            v-if="CAN_NOTICE_WRITE"
          >
            <i class="ri-megaphone-line"></i><span>공지사항 작성</span>
          </button>

          <button class="quick-item" @click="openDocCreate">
            <i class="ri-file-edit-line"></i><span>문서 작성</span>
          </button>
        </div>
      </div>
    </transition>

    <!-- ───────── 풀 메뉴(≡) ───────── -->
    <aside class="drawer" @click.self="menu = false" :class="{ open: menu }">
      <div class="drawer-panel" :class="{ open: menu }">
        <!-- 왼쪽 카테고리 -->
        <ul class="cat">
          <li
            v-for="c in cats"
            :key="c.key"
            :class="{ sel: c.key === cat }"
            @click="cat = c.key"
          >
            {{ c.label }}
          </li>
        </ul>

        <!-- 오른쪽 항목 -->
        <transition-group
          name="submenu"
          tag="div"
          class="items"
          style="position:relative" 
          :style="itemsOffsetStyle"
        >
          <template v-for="i in current" :key="i.label">
            <!-- 문서 트리 Drawer 전용 -->
            <a
              v-if="i.action === 'dmsDrawer'"
              href="#"
              class="item"
              @click.prevent="toggleDmsDrawer"
            >
              {{ i.label }}
            </a>
            <!-- 일반 라우팅 -->
            <router-link v-else :to="i.to" class="item" @click="menu = false">
              {{ i.label }}
            </router-link>
          </template>
          <div v-if="!current.length" class="empty">메뉴 없음</div>
        </transition-group>
      </div>
    </aside>
  </div>

  <ReceiptSubmissionCreateModal
    v-if="CAN_RECEIPT_WRITE"
    :isVisible="receiptModalVisible"
    @close="receiptModalVisible = false"
    @confirm="
      () => {
        receiptModalVisible = false; /* 필요 시 새로고침 등 */
      }
    "
  />

  <NoticeIntegratedCreateModifyModal
    :isVisible="noticeModalVisible"
    :isAdmin="true"
    :isCreate="true"
    :form="noticeInitForm"
    @close="noticeModalVisible = false"
    @save="noticeModalVisible = false"
  />
</template>

<script setup>
import { ref, computed } from "vue";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/store/auth";
import { useHrmStore } from "@/store/hrm";
import { useMobileMenuStore } from '@/store/navigation';
import { useDmsSidebarStore } from "@/store/dms/dmsSidebar";
import ReceiptSubmissionCreateModal from "@/components/receipt/ReceiptSubmissionCreateModal.vue";
import NoticeIntegratedCreateModifyModal from "@/components/hrm/NoticeIntegratedCreateModifyModal.vue";
import { toast } from "vue3-toastify";

/* ---------- 650px 이하 여부 ---------- */
const mq = window.matchMedia("(max-width:650px)");
const isMobile = ref(mq.matches);
mq.addEventListener("change", (e) => (isMobile.value = e.matches));

/* ---------- 라우터 ---------- */
const dmsDrawer = useDmsSidebarStore();
const router = useRouter();
function go(p) {
  /* ✔ 안전하게 한 번 받은 router 사용 */
  router.push(p);
  // Sheet + Drawer 모두 닫기
  mobileMenu.reset();
}

/* ---------- 문서 트리 Drawer 토글 ---------- */
function toggleDmsDrawer() {
  dmsDrawer.isOpen ? dmsDrawer.close() : dmsDrawer.open(); // 열⇄닫 토글
  // 이동 후 두 레이어 닫기
  mobileMenu.reset();
}

/* ---------- HRM 관리자 여부 ---------- */
const hrmStore = useHrmStore();
const isAdmin = computed(() => hrmStore.isHrmAdmin);

/* ---------- 상태 ---------- */
const mobileMenu = useMobileMenuStore();
const sheet = computed({
  get: () => mobileMenu.sheetOpen,
  set: v  => (v ? mobileMenu.openSheet() : mobileMenu.closeSheet()),
});
const menu = computed({
  get: () => mobileMenu.menuOpen,
  set: v  => (v ? mobileMenu.openMenu() : mobileMenu.closeMenu()),
});

/* ----------------- 영수증 등록/공지 작성 모달 열기 ----------------- */
const receiptModalVisible = ref(false);
const noticeModalVisible = ref(false);

function openReceiptModal() {
  if (!CAN_RECEIPT_WRITE.value) {
    toast.warning("영수증 등록 권한이 없습니다");
    return;
  }
  receiptModalVisible.value = true;
  sheet.value = false;
}

function openNoticeModal() {
  if (!CAN_NOTICE_WRITE.value) {
    toast.warning("공지 작성 권한이 없습니다");
    return;
  }
  noticeModalVisible.value = true;
  sheet.value = false;
}

// ‘공지 작성’ 기본 폼 (제목·내용 비워둠)
const today = new Date();
today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
const noticeInitForm = {
  id: null,
  title: "",
  author: "", // 모달 내부에서 자동으로 작성자 이름 채워짐
  date: today.toISOString().split("T")[0],
  content: "",
  attachments: [],
};

// 퀵메뉴 권한 플래그
function hasRole(allowed) {
  if (isLocal) return true; // 로컬 테스트 전부 허용
  if (roles.value.includes("ROLE_GATE_SYSTEM")) return true;
  return allowed.some((r) => roles.value.includes(r));
}

/* 필요한 권한 */
// HRM 관리자
const CAN_NOTICE_WRITE = computed(() => isAdmin.value);
// 영수증 권한 확인
const CAN_RECEIPT_WRITE = computed(() =>
  hasRole([
    "ROLE_RECEIPT_REGISTRAR",
    "ROLE_RECEIPT_APPROVER",
    "ROLE_RECEIPT_MANAGER",
  ])
);
/* ----------------- 영수증 등록/공지 작성 모달 END ----------------- */

/* ---------- 문서 작성 화면으로 이동 ---------- */
function openDocCreate() {
  /** 1) 퀵메뉴 닫기 */
  sheet.value = false;
  /** 2) 혹시 열려있을지 모를 Drawer 도 닫기 */
  if (dmsDrawer.isOpen) dmsDrawer.close();
  /** 3) 라우터 이동 */
  router.push({ name: "DmsCreateModifyPage", query: { mode: "create" } });
}

/* ---------- 더보기 토글 ---------- */
function toggleMenu() {
  /* 열려 있던 Sheet(+) 는 무조건 닫기 */
  mobileMenu.closeSheet();
  /* '지금' 열려고 하는 상태인지 미리 계산 */
  mobileMenu.toggleMenu();

  /* ① 네비게이션을 **열려고** 하는 순간 → 문서 트리 닫기 */
  /* if (willOpen && dmsDrawer.isOpen) { */
  if (dmsDrawer.isOpen) {
    dmsDrawer.close();
  }

  /* ② 토글 적용 */
  // menu.value = willOpen;
}

/* ─── 플로팅 시트(+) 열기 ─── */
function openSheet () {
  mobileMenu.openSheet();    // Sheet 열기
  mobileMenu.closeMenu();    // Drawer는 닫기
  if (dmsDrawer.isOpen) {  // 문서트리 Drawer 열려있으면 닫기
    dmsDrawer.close();
  }
}

/* ---------- 메뉴 & 권한 ---------- */
const rawMenus = [
  {
    key: "notice",
    label: "공지사항",
    sub: [
      {
        to: "/hrm/notice-integrated",
        label: "공지사항",
        roles: [],
      },
    ],
  },
  /* {
    key: "dms",
    label: "문서 관리",
    sub: [
      { action: "dmsDrawer", label: "문서 트리", roles: [] },
      {
        to: "/dms/dms-create-modify-page",
        label: "문서 작성",
        roles: [],
      },],
  }, */
  {
    key: "receipt",
    label: "영수증",
    roles: [
      "ROLE_RECEIPT_INSPECTOR",
      "ROLE_RECEIPT_REGISTRAR",
      "ROLE_RECEIPT_APPROVER",
      "ROLE_RECEIPT_MANAGER",
    ],
    sub: [
      {
        to: "/receipt/receipt-submission",
        label: "영수증 등록(개인)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR",
          "ROLE_RECEIPT_REGISTRAR",
          "ROLE_RECEIPT_APPROVER",
          "ROLE_RECEIPT_MANAGER",
        ],
      },
      {
        to: "/receipt/personal-receipt-history",
        label: "영수증 신청 내역 조회(개인)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR",
          "ROLE_RECEIPT_REGISTRAR",
          "ROLE_RECEIPT_APPROVER",
          "ROLE_RECEIPT_MANAGER",
        ],
      },
      {
        to: "/receipt/annual-receipt-summary",
        label: "영수증 년도별 요약(개인)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR",
          "ROLE_RECEIPT_REGISTRAR",
          "ROLE_RECEIPT_APPROVER",
          "ROLE_RECEIPT_MANAGER",
        ],
      },
      {
        to: "/receipt/receipt-request-overview",
        label: "영수증 결재 신청 현황(개인-결재)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_APPROVER", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-history",
        label: "영수증 결재 내역 조회(개인-결재)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_APPROVER", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-all-merge",
        label: "영수증 전체 취합(검수자)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-closure",
        label: "영수증 결재 마감(검수자)",
        roles: [
          "ROLE_RECEIPT_INSPECTOR", 
          "ROLE_RECEIPT_MANAGER"
        ],
      },
      {
        to: "/receipt/receipt-management",
        label: "영수증 내역 관리(관리자)",
        roles: ["ROLE_RECEIPT_MANAGER"],
      },
      {
        to: "/receipt/receipt-meta-management",
        label: "영수증 설정 관리(관리자)",
        roles: ["ROLE_RECEIPT_MANAGER"],
      },
    ],
  },
  {
    key: "management",
    label: "사원 관리",
    sub: [
      {
        to: "/hrm/user-management",
        label: "사용자 관리",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/performance-management",
        label: "실적 관리",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/user-permissions",
        label: "권한 부여",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/dept-team-manager",
        label: "부서/팀 관리",
        roles: ["ROLE_HRM_MANAGER"],
      },
      {
        to: "/hrm/org-directory",
        label: "조직도",
        roles: ["ROLE_HRM_MANAGER"],
      },
    ],
  },
  {
    key: "user",
    label: "개인정보",
    sub: [
      {
        to: "/hrm/user-information",
        label: "사용자 정보",
        roles: ["ROLE_HRM_EMPLOYEE", "ROLE_HRM_MANAGER"],
      },
    ],
  },
  {
    key: "system",
    label: "시스템",
    sub: [
      {
        to: "/system/activity-log",
        label: "이력 관리",
        roles: ["ROLE_GATE_SYSTEM"],
      },
      {
        to: "/system/statistics-screen",
        label: "대시보드 관리",
        roles: ["ROLE_GATE_SYSTEM"],
      },
    ],
  },
  /* {
    key: "systemtest",
    label: "테스트",
    sub: [
      {
        to: "/system/component-test",
        label: "테스트 컴포넌트",
        roles: ["ROLE_GATE_SYSTEM"],
      },
    ],
  }, */
];

const auth = useAuthStore();
const roles = computed(() => auth.roles);
const isLocal = String(
  import.meta.env.VITE_LOCALTEST ?? import.meta.env.VITE_APP_LOCALTEST
) === "true";

function canShow(r) {
  if (isLocal) return true;
  if (roles.value.includes("ROLE_GATE_SYSTEM")) return true;
  if (!r || r.length === 0) return true;
  return !r.length || r.some((x) => roles.value.includes(x));
}
const cats = rawMenus
  .map((c) => ({ ...c, sub: c.sub.filter((s) => canShow(s.roles || [])) }))
  .filter((c) => c.sub.length);

const cat = ref(cats[0]?.key);
const current = computed(
  () => cats.find((c) => c.key === cat.value)?.sub || []
);
/* ---------- 하위-메뉴 Y 오프셋 ---------- */
/* ① 카테고리 한 줄 높이를 고정값(48px)으로 둘 경우 */
const ROW_H = 48;
const itemsOffsetStyle = computed(() => ({
  marginTop: `${cats.findIndex((c) => c.key === cat.value) * ROW_H}px`,
}));
/* ② 만약 줄 높이가 바뀔 수 있다면(글자 줄바꿈 등)
     → 아래 주석코드처럼 offsetTop을 계산하는 방법도 가능
const catEls = ref([]);
onMounted(() => catEls.value = document.querySelectorAll('.cat li'));
watch(cat, () => nextTick(() => {
  const el = Array.from(catEls.value)
                  .find(li => li.classList.contains('sel'));
  itemsOffset.value = el ? el.offsetTop : 0;
}));
*/
</script>

<style scoped>
/* ───── 하단 바 ───── */
.bottom-bar {
  position: fixed;
  inset-block-end: 0;
  inset-inline: 0;
  height: 70px;
  background: #fff;
  border-top: 1px solid #e5e5e5;
  z-index: 1014;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 0px 15px 0px 15px;
}
button {
  all: unset;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 0.68rem;
  color: #222;
  cursor: pointer;
}
i {
  font-size: 22px;
}
.fab {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  margin-top: -30px;
  background: #008cff;
  color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.25);
}

/* ───── 퀵메뉴 드롭다운 ───── */
.quick-backdrop {
  position: fixed;
  inset: 0;
  z-index: 1015;
}
.quick-menu {
  position: fixed;
  left: 50%;
  bottom: 72px; /* 툴바(56) + 여백 16 */
  transform: translateX(-50%);
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 8px;
  padding: 16px 24px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.quick-item {
  all: unset;
  display: flex;
  align-items: center;
  /* justify-content: center; */
  gap: 5px; /* ← 중앙정렬 + 5px 간격 */
  font-size: 0.9rem; /* 필요 시 조정 */
  cursor: pointer;
  font-size: 0.75rem;
  padding: 6px 0;
  color: #222;
}
.quick-item:hover {
  color: #008cff;
}
.quick-item i {
  font-size: 1.1rem;
}
/* ───── 말풍선 꼬리 (테두리) ───── */
.quick-menu::before {
  content: "";
  position: absolute;
  left: 50%; /* 가운데 정렬 */
  top: 100%; /* 상자 아래에 붙이기 */
  transform: translateX(-50%) translateY(1px); /* 1px 만큼 아래로 내려 테두리 겹침 방지 */
  width: 0;
  height: 0;
  border: 9px solid transparent; /* 꼬리 크기 = 9px */
  border-top-color: #e5e5e5; /* 테두리색과 동일 */
}
/* ───── 말풍선 꼬리 (흰색 내부) ───── */
.quick-menu::after {
  content: "";
  position: absolute;
  left: 50%;
  top: 100%;
  transform: translateX(-50%);
  width: 0;
  height: 0;
  border: 8px solid transparent; /* 1px 작게 → 테두리 안쪽 */
  border-top-color: #ffffff; /* 상자 배경과 동일 */
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.15s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* ───── 풀 메뉴 ───── */
.drawer {
  position: fixed;
  inset: 0;
  padding-bottom: 70px;
  background: rgba(0, 0, 0, 0.3); /* 닫힐 때 투명 */
  z-index: 1013;
  top: 65px;
  display: flex;
  justify-content: flex-end;
  opacity: 0; /* 닫힐 때 안 보이도록 */
  pointer-events: none; /* 클릭 막기 */
  transition: transform var(--sidebar-slide),
              opacity   var(--sidebar-slide);
}
.drawer.open {
  /* ⭐ 열릴 때 상태 */
  background: rgba(0, 0, 0, 0.3);
  opacity: 1;
  pointer-events: auto;
}

.drawer-panel {
  width: 100%;
  max-width: 330px;
  background: #fff;
  display: flex;
  height: 100%;
  transform: translateX(100%); /* 처음엔 화면 밖 */
  transition: transform 0.22s ease;
}
.drawer-panel.open {
  /* ⭐ 열릴 때 슬라이드 인 */
  transform: translateX(0);
}

/* ─── 하위 메뉴 전환(잔상 제거) ─── */
.submenu-enter-active,
.submenu-leave-active {
  transition: opacity 0s ease;
  position: absolute;   /* ② 떠있는 상태로! */
  inset: 0;             /* 같은 좌표에 겹치도록 */
}
.submenu-enter-from,
.submenu-leave-to   { opacity: 0; }

.cat {
  list-style: none;
  margin: 0;
  padding: 0;
  width: 35%;
  border-right: 1px solid #eee;
}
.cat li {
  padding: 14px 18px;
  height: 48px;
  font-size: 0.685rem;
  cursor: pointer;
}
.cat li.sel,
.cat li:hover {
  background: #f5f5f5;
  color: #0061ff;
  font-weight: 600;
}
.items {
  flex: 1;
  overflow-y: auto;
  transition: margin-top 0.4s cubic-bezier(0.25, 0.8, 0.25, 1); /* 상단 offset 부드럽게 */
}
.item {
  /* 패딩 영역은 그대로 유지 */
  display: flex; /* 세로 가운데 + padding 전부 적용 */
  align-items: center;
  height: 48px;
  padding: 0 20px 0 20px; /* ← 20 │ → 34(화살표 공간) */
  box-sizing: border-box;
  position: relative;
  font-size: 0.685rem;
  color: #222;
  text-decoration: none;
}

/* 아래 실선 */
.item::before {
  content: "";
  position: absolute;
  left: 20px; /* 글자 시작점 = 좌측 패딩 */
  right: 20px; /* 화살표 앞까지 */
  bottom: 0;
  height: 1px;
  background: #cfcfcf;
}

/* 화살표(>) */
.item::after {
  content: "›";
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 1.3rem;
  font-weight: 200;
  line-height: 1;
}
.item:hover {
  background: #f0f0f0;
}
.empty {
  padding: 20px;
  color: #888;
  text-align: center;
  font-size: 0.85rem;
}

.slide-enter-active {
  transition: transform 0.2s ease;
}
.slide-leave-active {
  transition: transform 0.15s ease;
}
.slide-enter-from,
.slide-leave-to {
  transform: translateX(100%);
}
</style>
