<!-- src/components/receipt/ReceiptsCategoryCreateModal.vue -->
<template>
  <b-modal
    ref="categoryModal"
    style="--bs-modal-width: 350px"
    v-model="innerVisible"
    :title="modalTitle"
    :keyboard="false"
    :backdrop="'static'"
    centered
    hide-footer
  >
    <form @submit.prevent="saveCategory">
      <!-- 카테고리 이름 -->
        <DefaultLabel
          text="카테고리 이름"
          forId="catName"
          size="small"
          required
        />
        <DefaultTextfield
          id="catName"
          v-model="localForm.category"
          placeholder="예) 식비"
          style="width: 100%"
          size="full"
          reserveErrorSpace
        />

      <!-- 최대 금액 -->
      <DefaultLabel
        text="최대 금액(원)"
        forId="catLimit"
        size="small"
        required
      />
      <DefaultTextfield
        id="catLimit"
        type="number"
        v-model="localForm.maxAmount"
        placeholder="예) 30000"
        style="width: 100%"
        size="full"
        validationType="number"
        reserveErrorSpace
      />

      <!-- 버튼 -->
      <DefaultFormRow align="right">
        <DefaultButton
          color="gray"
          size="small"
          marginRight="5px"
          @click="closeModal"
        >
          취소
        </DefaultButton>
        <DefaultButton size="small" @click="saveCategory">
          {{ isCreate ? "등록" : "수정" }}
        </DefaultButton>
      </DefaultFormRow>
    </form>
  </b-modal>
</template>

<script setup>
import { ref, watch, computed, defineProps, defineEmits } from 'vue';
import { cloneDeep } from 'lodash';
import { toast } from 'vue3-toastify';

import DefaultLabel     from '@/components/common/label/DefaultLabel.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultButton    from '@/components/common/button/DefaultButton.vue';
import DefaultFormRow   from '@/components/common/DefaultFormRow.vue';

import ReceiptsCategoryApi from '@/api/receipt/ReceiptsCategoryApi';

/* ─── Props / Emits ─── */
const props = defineProps({
  isVisible: {
    type   : Boolean,
    default: false
  },
  isCreate : { type: Boolean, default: true },
  form     : { type: Object,  default: () => ({ id:null, category:'', maxAmount:0 }) }
});
const emit = defineEmits(['update:isVisible', 'save']);

/* ─── 로컬 상태 ─── */
const innerVisible = ref(false);
const localForm    = ref(cloneDeep(props.form));

/* 모달 제목 */
const modalTitle = computed(() => (props.isCreate ? '카테고리 등록' : '카테고리 수정'));

/* 모달 닫기 */
function closeModal () {
  innerVisible.value = false
  emit('update:isVisible', false)
}

/* ─── 저장(등록·수정) ─── */
async function saveCategory () {
  /* ① 검증 */
  if (!localForm.value.category.trim()) {
    toast.warning('카테고리 이름을 입력하세요');
    return;
  }
  if (!localForm.value.maxAmount || localForm.value.maxAmount <= 0) {
    toast.warning('최대 금액을 0보다 크게 입력하세요');
    return;
  }

  /* ② 서버 호출용 Payload */
  const payload = {
    categoryName: localForm.value.category.trim(),
    limitPrice  : Number(localForm.value.maxAmount)
  };

  try {
    let res;
    if (props.isCreate) {
      res = await ReceiptsCategoryApi.createCategory(payload);
      toast.success('카테고리가 등록되었습니다');
    } else {
      res = await ReceiptsCategoryApi.updateCategory(localForm.value.id, payload);
      toast.success('카테고리가 수정되었습니다');
    }

    /* ③ 부모에게 저장 완료 알림 */
    emit('save', res.data);      // → 부모에서 목록 재조회
    closeModal();
  } catch (e) {
    toast.error('저장 중 오류가 발생했습니다');
  }
}

/* 표시 상태 동기화 */
watch(
  () => props.isVisible,
  v => {
    innerVisible.value = v
    if (v) localForm.value = cloneDeep(props.form)
  },
  { immediate: true }
)

watch(innerVisible, v => emit('update:isVisible', v))
</script>

<style scoped>
:deep(.form-control) {
  height: 28px;
  font-size: 0.8rem;
}
</style>
