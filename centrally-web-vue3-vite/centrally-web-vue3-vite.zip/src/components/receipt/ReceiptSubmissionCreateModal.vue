<template>
  <!-- BootstrapVue 의 b-modal 사용 -->
  <b-modal
    v-model="innerVisible"
    title="영수증 등록"
    no-close-on-backdrop
    centered
    fade
    hide-footer
    scrollable
  >
    <div class="modal-body">
      <!-- 모달 내부 컨텐츠 -->
      <form @submit.prevent="openConfirmationModal" @keydown.enter.prevent>
        <!-- 이미지 등록 -->
        <div class="form-group">
          <DefaultLabel
            text="영수증 사진"
            forId="receiptImage"
            size="small"
            marginBottom="5px"
            :required="true"
          />
          <DefaultTextfield
            type="file"
            id="receiptImage"
            size="full"
            style="width: 100%"
            @change="handleFileChange"
          />
          <!-- 선택된 파일 이름 표시 및 삭제 버튼 -->
          <div v-if="receiptFile" class="mt-2">
            <ul class="list-group">
              <li class="list-group-item">
                {{ receiptFile.name }}
                <button
                  type="button"
                  class="btn btn-danger square-btn ms-2"
                  @click="removeFile"
                >
                  x
                </button>
              </li>
            </ul>
          </div>
        </div>

        <!-- 영수증 발행일 -->
        <div class="form-group">
          <DefaultFormRow marginBottom="5px">
            <DefaultLabel
              text="영수증 발행일"
              forId="date"
              size="small"
              :required="true"
            />
            <DefaultLabel
              text="[NOW]"
              size="small"
              class="now-label"
              @click="setToday"
            />
          </DefaultFormRow>
          <DefaultTextfield
            type="date"
            id="date"
            v-model="formData.date"
            size="full"
            :required="true"
          />
        </div>

        <hr />
        <!-- 참여자 검색 필드 -->
        <div class="search-wrapper">
          <DefaultLabel
            text="참여자 검색"
            forId="participantSearch"
            size="small"
            marginBottom="5px"
          />
          <UserSearchDropdown
            ref="participantSearchRef"
            labelText="사용자 검색"
            inputId="participantSearch"
            inputSize="full"
            :keepSearchValue="false"
            placeholder="이름(이메일)을 입력하여 검색"
            @userSelected="onParticipantSelected"
          />
        </div>

        <!-- 추가된 참여자 목록 -->
        <div v-if="formData.participants.length > 0">
          <DefaultLabel
            text="참여자 목록"
            marginBottom="5px"
            marginTop="5px"
            size="small"
          />
          <ul class="list-group">
            <li
              v-for="(person, idx) in formData.participants"
              :key="idx"
              class="list-group-item d-flex align-items-center justify-content-between"
            >
              <span>
                {{ person.name }} / {{ person.department }} / {{ person.team }}
              </span>
              <!-- 삭제 버튼 -->
              <button
                type="button"
                class="btn btn-sm btn-outline-danger square-btn"
                @click="removeParticipant(idx)"
              >
                ×
              </button>
            </li>
          </ul>
        </div>
        <hr class="search-wrapper-hr-2" />

        <!--카테고리 | 금액 -->
        <div class="form-row align-items-center">
          <div class="col">
            <DefaultLabel
              class="category-label"
              text="카테고리"
              forId="categorySelect"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultSelect
              v-model="formData.categoryId"
              :options="categoryOptions"
              placeholder="카테고리 선택"
              size="full"
              style="width: 100%"
              :reserveErrorSpace="true"
              marginBottom="22px"
            />
          </div>
          <div class="col">
            <DefaultLabel
              class="amount-label"
              :text="amountLabel"
              forId="amount"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultTextfield
              type="text"
              id="amount"
              v-model="formData.amount"
              size="full"
              style="width: 100%"
              validationType="number"
              :disabled="!selectedCategory"
              :externalInvalid="!!amountError"
              :externalError="amountError"
              :reserveErrorSpace="true"
              placeholder="카테고리 → 금액(원) 입력해주세요"
            />
          </div>
        </div>
        <hr class="search-wrapper-hr-1" />

        <!-- 결재자 검색 필드 -->
        <div class="search-wrapper">
          <DefaultLabel
            text="결재(합의)자 검색 [ 결재자 권한 이상 조회 ]"
            forId="approverSearch"
            size="small"
            marginBottom="5px"
          />
          <UserSearchDropdown
            ref="approverSearchRef"
            labelText="결재(합의)자 검색"
            inputId="approverSearch"
            inputSize="full"
            :keepSearchValue="false"
            :filterBy="{ service: 'receipt',
              roleDetails: [
                'ROLE_RECEIPT_APPROVER',
                'ROLE_RECEIPT_INSPECTOR',
                'ROLE_RECEIPT_MANAGER',
                'ROLE_GATE_SYSTEM'] 
            }"
            placeholder="이름(이메일)을 입력하여 검색"
            @userSelected="onApproverSelected"
          />
        </div>

        <!-- 결재자 목록 -->
        <div v-if="normalApprovers.length > 0">
          <DefaultLabel
            text="결재자 목록 (순서 변경 가능)"
            marginBottom="5px"
            marginTop="10px"
            size="small"
          />

          <!-- vuedraggable 적용 -->
          <draggable
            v-model="normalApprovers"
            @end="onDragEnd"
            item-key="userId"
            tag="ul"
            class="list-group"
            handle=".drag-handle"
          >
            <template #item="{ element, index }">
              <li
                class="list-group-item d-flex align-items-center justify-content-between"
              >
                <span class="d-flex align-items-center flex-wrap">
                  <!-- 드래그 핸들 -->
                  <span class="drag-handle me-2" title="드래그하여 순서 변경">≡</span>

                  <span
                    v-if="element.isDefault"
                    class="badge text-bg-primary me-1"
                    title="고정 합의자"
                  >
                    고정
                  </span>

                  <!-- [ 결재 | 합의 ] 글자 버튼 -->
                  <span
                    class="approval-option approval-decision"
                    :class="{
                            active  : element.approvalType === '결재',
                            disabled: element.isDefault
                          }"
                    @click="!element.isDefault && setApprovalType(element, '결재')"
                  >
                    결재
                  </span>
                  <span
                    class="approval-option approval-agree approval-option-right"
                    :class="{
                      active  : element.approvalType === '합의',
                      disabled: element.isDefault                /* 고정이면 무조건 회색 */
                            || isSameDepartment(element)        /* 같은 부서면 회색     */
                    }"
                    @click="!element.isDefault                  /* 고정은 못 바꿈        */
                          && !isSameDepartment(element)         /* 같은 부서 금지       */
                          && setApprovalType(element,'합의')"
                  >
                    합의
                  </span>

                  <!-- 기존 이름/부서/팀 -->
                  {{ element.name }} / {{ element.department }} /
                  {{ element.team }}
                </span>

                <!-- 삭제 버튼 -->
                <button
                  v-if="!element.isDefault"
                  type="button"
                  class="btn btn-sm btn-outline-danger square-btn"
                  @click.stop="removeApprover(index)"
                >
                  ×
                </button>
              </li>
            </template>
          </draggable>
        </div>
        <!-- 일반 결재자가 없을 때 → 더미 안내만 출력 -->
        <ul v-else class="list-group list-no-group mb-2">
          <li class="list-group-item text-center text-muted bg-light">
            일반 결재자를 추가해주세요
          </li>
        </ul>


        <DefaultLabel text="고정 결재자" size="small" />
        <!-- ── 고정 합의자(드래그·삭제 불가) ───────────────────────── -->
        <ul v-if="fixedApprovers.length" class="list-group mt-2">
          <li v-for="a in fixedApprovers" :key="a.userId"
              class="list-group-item d-flex align-items-center">
            <span class="d-flex align-items-center flex-wrap">
              <span class="badge bg-primary text-white me-1">고정</span>
        
              <span :class="['approval-option','approval-decision',{active:a.approvalType==='결재',disabled:true}]">결재</span>
              <span :class="['approval-option','approval-agree','approval-option-right',{active:a.approvalType==='합의',disabled:true}]">합의</span>
        
              {{ a.name }} / {{ a.department }} / {{ a.team }}
            </span>
          </li>
        </ul>

        <hr class="search-wrapper-hr-2" />

        <!-- 사유 -->
        <div class="form-group reason">
          <DefaultLabel
            text="사유"
            forId="reason"
            size="small"
            :required="true"
          />
          <DefaultTextfield
            type="text"
            id="reason"
            size="full"
            v-model="formData.reason"
            placeholder="내용을 입력해주세요"
          />
        </div>

        <!-- footer 영역 직접 구현 -->
        <div class="modal-footer">
          <DefaultButton
            align="right"
            color="gray"
            marginRight="5px"
            @click="closeModal"
          >
            취소
          </DefaultButton>
          <DefaultButton type="submit" align="right"> 등록 </DefaultButton>
        </div>
      </form>
    </div>
  </b-modal>

  <!-- AlertModal (확인 모달) -->
  <AlertModal
    :isVisible="confirmationModalVisible"
    :disableBackgroundClose="true"
    title="저장 확인"
    confirmText="확인"
    cancelText="취소"
    @close="confirmationModalVisible = false"
    @confirm="submitReceipt"
  >
    <template #body>
      <p>등록하시겠습니까?</p>
    </template>
  </AlertModal>
</template>

<script setup>
/* -------------------------------------------------------------------
 *  Imports
 * ------------------------------------------------------------------*/
import { ref, computed, watch, onMounted, onBeforeUnmount, defineProps, defineEmits } from 'vue'
import draggable                from 'vuedraggable'
import AlertModal               from '@/components/common/modal/AlertModal.vue'
import DefaultButton            from '@/components/common/button/DefaultButton.vue'
import DefaultTextfield         from '@/components/common/textfield/DefaultTextfield.vue'
import DefaultFormRow           from '@/components/common/DefaultFormRow.vue'
import DefaultLabel             from '@/components/common/label/DefaultLabel.vue'
import DefaultSelect            from '@/components/common/select/DefaultSelect.vue'
import UserSearchDropdown       from '@/components/auth/UserSearchDropdown.vue'
import { useAuthStore }         from '@/store/auth'
import { useUserDirectoryStore } from '@/store/hrm/userDirectory'
import { toast }                from 'vue3-toastify'
import ReceiptApi               from '@/api/receipt/ReceiptsApi.js'
import CategoryApi              from '@/api/receipt/ReceiptsCategoryApi.js'
import DefaultApproverApi       from '@/api/receipt/ReceiptsDefaultApproverApi'

/* -------------------------------------------------------------------
 *  Basic setup
 * ------------------------------------------------------------------*/
const props = defineProps({ isVisible: Boolean })
const emit  = defineEmits(['close', 'confirm'])
const authStore      = useAuthStore()
const myUserId       = authStore.getUserId
const userDirStore   = useUserDirectoryStore()
const innerVisible   = ref(props.isVisible)
const confirmationModalVisible = ref(false)

/* -------------------------------------------------------------------
 *  Reactive form state
 * ------------------------------------------------------------------*/
const formData = ref({
  date        : '',
  categoryId  : '',
  amount      : '',
  reason      : '',
  participants: [],
  approvers   : []
})
const receiptFile = ref(null)

/* -------------------------------------------------------------------
 *  Categories (카테고리)
 * ------------------------------------------------------------------*/
const categories = ref([])
const categoryOptions = computed(() =>
  categories.value
    .filter(c => c.enable)
    .map(c => ({ value: c.categoryId, label: c.categoryName }))
)
async function loadCategories () {
  if (categories.value.length) return
  const { data } = await CategoryApi.getCategories()
  categories.value = data
}

/* -------------------------------------------------------------------
 *  Participants & approvers helpers
 * ------------------------------------------------------------------*/
function keepDefaultAtBottom () {
  const nonDef = formData.value.approvers.filter(a => !a.isDefault)
  const def    = formData.value.approvers.filter(a =>  a.isDefault)
  formData.value.approvers = [...nonDef, ...def]
}
const participantSearchRef = ref(null)
const approverSearchRef    = ref(null)

/* -------------------------------------------------------------------
 *  File handling
 * ------------------------------------------------------------------*/
function handleFileChange (e) {
  const f = e.target.files[0]
  receiptFile.value = f || null
  e.target.value = ''
}
const removeFile = () => { receiptFile.value = null }

/* -------------------------------------------------------------------
 *  Select-box / validation helpers
 * ------------------------------------------------------------------*/
const selectedCategory = computed(() => {
  const id = Number(formData.value.categoryId || NaN)
  return categories.value.find(c => c.categoryId === id)
})
const maxAllowed = computed(() => {
  if (!selectedCategory.value) return Infinity
  const persons = formData.value.participants.length + 1
  return Math.floor(selectedCategory.value.limitPrice * persons)
})
const amountError = computed(() => {
  const entered = Number(String(formData.value.amount).replace(/\D/g, '')) || 0
  return entered > maxAllowed.value
    ? `1인당 한도 초과 (최대 ${maxAllowed.value.toLocaleString()}원)`
    : null
})
const amountLabel = computed(() => {
  if (!selectedCategory.value) return '금액'
  const persons = formData.value.participants.length + 1
  const total   = selectedCategory.value.limitPrice * persons
  return `금액 (한도 ${total.toLocaleString()}원)`
})

/* -------------------------------------------------------------------
 *  User / role helpers
 * ------------------------------------------------------------------*/
const currentDept = computed(() => {
  const me = userDirStore.getById(authStore.getUserId)
  return me?.department?.trim().toUpperCase() ?? ''
})
const isSameDepartment = target => {
  const theirs = (target?.department ?? '').trim().toUpperCase()
  return theirs && theirs === currentDept.value
}
function setApprovalType (user, type) {
  if (user.isDefault && type === '결재') return
  if (type === '합의' && isSameDepartment(user)) return
  if (type === '결재') {
    /* 자신을 제외하고 결재자 수 계산 */
    const otherCnt = formData.value.approvers
      .filter(a => a.approvalType === '결재' && a !== user).length
    if (otherCnt >= 3)
      return toast.warning('결재자는 최대 3명까지 지정할 수 있습니다.')
  }
  user.approvalType = type
}

/* ------------ 고정 / 일반 결재자 분리 ------------------------------ */
const fixedApprovers  = computed(()=> formData.value.approvers.filter(a=>a.isDefault))
const normalApprovers = computed({
  get : ()   => formData.value.approvers.filter(a=>!a.isDefault),
  set : list => {              // 드래그 후 setter 로 다시 병합
    formData.value.approvers = [...list, ...fixedApprovers.value]
  }
})

/* -------------------------------------------------------------------
 *  Participant / approver UI actions
 * ------------------------------------------------------------------*/
function onParticipantSelected (user) {
  if (formData.value.participants.some(p => p.userId === user.userId))
    return toast.warning('이미 추가된 참여자입니다.')
  formData.value.participants.push({
    userId: user.userId, name: user.name,
    department: user.department, team: user.team
  })
}
function onApproverSelected (user) {
  const dup = formData.value.approvers.some(a =>
    (a.userId && a.userId === user.userId) ||
    (!a.userId && a.email === user.email)
  )
  if (dup) return toast.warning('이미 추가된 결재자입니다.')
  /* 현재 결재자(approvalType === '결재') 수 확인 */
  const decisionCnt = formData.value.approvers
    .filter(a => a.approvalType === '결재').length
  if (decisionCnt >= 3) {
    return toast.warning('결재자는 최대 3명까지 추가할 수 있습니다.')
  }
  formData.value.approvers.push({
    userId: user.userId, name: user.name,
    department: user.department, team: user.team,
    approvalType: '결재'
  })
  keepDefaultAtBottom()
}
function removeParticipant (idx) { formData.value.participants.splice(idx, 1) }
function removeApprover (idx) {
  const target = normalApprovers.value[idx]
  if (!target) return
  const realIdx = formData.value.approvers.indexOf(target)
  if (realIdx !== -1) formData.value.approvers.splice(realIdx, 1)
}

/* -------------------------------------------------------------------
 *  Fetch default approvers
 * ------------------------------------------------------------------*/
async function fetchDefaultApprovers () {
  try {
    const { data } = await DefaultApproverApi.getDefaultApprovers({ size: 1000 });
      // 본인 + 같은 부서 전부 제외
      (data.content ?? data)
      .filter(d =>
        // 본인 제외
        d.userId !== myUserId &&
        // 같은 부서 전부 제외
        (d.department ?? '').trim().toUpperCase() !== currentDept.value
      )
      .forEach(d => {
        formData.value.approvers.push({
          userId: d.userId, name: d.userName,
          email: d.email, department: d.department, team: d.team,
          approvalType: '합의', isDefault: true
        })
      })
    keepDefaultAtBottom()
  } catch {
    toast.error('고정 합의자 목록을 불러오지 못했습니다.')
  }
}

/* -------------------------------------------------------------------
 *  Form submit & reset
 * ------------------------------------------------------------------*/
function resetFormData () {
  formData.value = {
    date: '', type: '', amount: '', reason: '',
    participants: [], approvers: formData.value.approvers.filter(a => a.isDefault)
  }
  receiptFile.value = null
  participantSearchRef.value?.resetSearch?.()
  approverSearchRef.value?.resetSearch?.()
}
function openConfirmationModal () {
 const approverCnt = formData.value.approvers
   .filter(a => a.approvalType === '결재').length

  if (approverCnt === 0)
    return toast.warning('결재자를 최소 1명 지정해야 합니다.')
  if (approverCnt > 3)
    return toast.warning('결재자는 최대 3명까지만 지정할 수 있습니다.')
  if (!formData.value.date || !formData.value.categoryId ||
      !formData.value.amount || !formData.value.reason)
    return toast.warning('필수 입력값을 모두 입력해주세요.')
  if (!receiptFile.value)
    return toast.warning('첨부 파일을 등록해주세요.')
  if (!receiptFile.value.type.startsWith('image/'))
    return toast.warning('이미지 파일만 첨부할 수 있습니다.')
  if (amountError.value)
    return toast.warning('금액 한도를 확인해주세요.')
  confirmationModalVisible.value = true
}
async function submitReceipt () {
  confirmationModalVisible.value = false
  const payload = new FormData()
  payload.append('date'       , formData.value.date)
  payload.append('categoryId' , formData.value.categoryId)
  payload.append('amount'     , formData.value.amount)
  payload.append('reason'     , formData.value.reason)
  payload.append('participants', JSON.stringify(formData.value.participants))
  payload.append('approvers'   , JSON.stringify(formData.value.approvers))
  payload.append('receiptFile' , receiptFile.value)
  await ReceiptApi.createReceipt(myUserId, payload)
  resetFormData()
  innerVisible.value = false
  emit('confirm')
}

/* -------------------------------------------------------------------
 *  Misc helpers
 * ------------------------------------------------------------------*/
const setToday = () => {
  const t = new Date()
  formData.value.date = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`
}
const openModal = () => { history.pushState({ modal: true }, '') }
function closeModal () {
  innerVisible.value = false
  if (history.state?.modal) history.back()
}
function handlePopState () {
  if (innerVisible.value) {
    innerVisible.value = false
    emit('close')
  }
}
const showModalWatcher = watch(() => props.isVisible, v => {
  innerVisible.value = v
  if (v) { resetFormData(); openModal() }
})
watch(innerVisible, v => { if (!v) emit('close') })
watch([() => formData.value.amount, maxAllowed], ([raw, max]) => {
  if (max === Infinity) return
  const entered = Number(String(raw).replace(/\D/g, '')) || 0
  if (entered > max) {
    formData.value.amount = String(max)
    toast.info(`금액이 한도를 넘어 ${max.toLocaleString()}원으로 조정됐습니다.`)
  }
})

/* -------------------------------------------------------------------
 *  Lifecycle
 * ------------------------------------------------------------------*/
onMounted(() => {
  userDirStore.refresh()
  window.addEventListener('popstate', handlePopState)
  loadCategories()
  fetchDefaultApprovers()
})
onBeforeUnmount(() => {
  window.removeEventListener('popstate', handlePopState)
  showModalWatcher() // stop
})
</script>


<style scoped>
hr {
  margin: 0 0 7px;
  border: none; /* ← 기본 border 제거 */
  height: 2px; /* 실제 두께 */
  background: #000000;
}
.search-wrapper-hr-1 {
  margin: 0px 0 10px 0;
}
.search-wrapper-hr-2 {
  margin: 15px 0 10px 0;
}
.form-row .col {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.modal-body {
  padding: 5px 5px 5px 5px;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}

.reason {
  margin-top: 10px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 10px;
}

.list-group-item,
.list-group {
  font-size: 0.875em !important;
}

.list-no-group {
  margin-top: 2px;
}


.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

.now-label {
  cursor: pointer;
  color: #0d6efd;
}

.now-label:hover {
  text-decoration: underline;
}

.drag-handle {
  cursor: grab;
  user-select: none;
}

.drag-handle:active {
  cursor: grabbing;
}

.align-items-center {
  margin-bottom: 0px !important;
}

/* 선택 토글용 글자 버튼 */
.approval-option {
  cursor: pointer;
  padding: 2px 6px;
  /* border-radius: 4px; */
  color: #39393a; /* 기본 회색 */
  border: 1px solid #8e8e8f; /* 기본 얇은 회색 테두리 */
  user-select: none;
  margin: 0;
}

.approval-option + .approval-option {
  margin-left: -1px; /* 경계선 겹침 처리 */
}

.approval-option-right {
  margin-right: 7px;
}
/* 결재 (active) : 빨강 */
.approval-decision.active {
  color: #dc3545 !important;
  background: #dc354510 !important;
  font-weight: 900;
}

/* 합의 (active) : 초록 */
.approval-agree.active {
  color: #198754 !important;
  background: #1987542b !important;
  font-weight: 900;
}

.approval-option.disabled {
  pointer-events: none; /* 클릭 차단 */
  opacity: 0.4; /* 흐리게 표시 */
}

@media (max-width: 650px) {
  hr {
    margin: 0 0 5px 0;
  }

  .search-wrapper-hr {
    margin: 10px 0 5px 0;
  }

  .list-group-item,
  .list-group {
    font-size: 0.8em !important;
  }

  .form-group {
    margin-bottom: 10px;
  }
}
</style>
