<template>
  <b-modal
    v-model="innerVisible"
    title="영수증 수정"
    no-close-on-backdrop
    size="xl"
    custom-class="receipt-modal"
    centered
    fade
    hide-footer
    body-class="p-0" 
  >
    <div class="modal-body d-flex gap-4">
      <!-- ① 이미지 영역 -->
      <div
        class="preview-pane"
        :class="{ zoomed: isPaneZoomed  }"
        @dblclick="openZoom"
      >
        <img
          v-if="previewUrl"
          :src="previewUrl"
          class="preview-img"
          :class="{ zoomed: isPaneZoomed  }"
          :style="zoomStyle"
          draggable="false"
          @dragstart.prevent
          @mousedown="startDrag"
          @touchstart.passive="startDrag"
        />
        <div v-else class="preview-placeholder">
          영수증 이미지를 선택하면<br />여기에 미리보기가 표시됩니다
        </div>
      </div>

      <form
        class="form-pane"
        @submit.prevent="openConfirmationModal"
        @keydown.enter.prevent
      >
        <!-- 이미지 등록 -->
        <div class="form-group">
          <DefaultLabel
            text="영수증 사진"
            forId="receiptImage"
            size="small"
            marginBottom="5px"
            :required="true"
          />
          <DefaultTextfield
            type="file"
            id="receiptImage"
            size="full"
            style="width: 100%"
            @change="handleFileChange"
          />
          <!-- 기존 파일 표시 (새 파일을 아직 선택하지 않았을 때만) -->
          <div v-if="originalFile.name && !receiptFile" class="mt-2">
            <ul class="list-group">
              <li class="list-group-item">
                <a :href="originalFile.url" @click.prevent="openPreviewModal(originalFile.url)"
                  >[기존 파일] {{ originalFile.name }}</a
                >
              </li>
            </ul>
          </div>

          <!-- 새 파일을 선택하면 기존 영역은 사라지고, 아래 v-if="receiptFile" 가 뜸 -->
          <div v-if="receiptFile" class="mt-2">
            <ul class="list-group">
              <li class="list-group-item">
                [새로 적용] {{ receiptFile.name }}
                <button
                  type="button"
                  class="btn btn-danger square-btn ms-2"
                  @click="removeFile"
                >
                  x
                </button>
              </li>
            </ul>
          </div>
        </div>

        <!-- 영수증 발행일 -->
        <div class="form-group">
          <DefaultFormRow marginBottom="5px">
            <DefaultLabel
              text="영수증 발행일"
              forId="date"
              size="small"
              :required="true"
            />
            <DefaultLabel
              text="[NOW]"
              size="small"
              class="now-label"
              @click="setToday"
            />
          </DefaultFormRow>
          <DefaultTextfield
            type="date"
            id="date"
            v-model="formData.date"
            size="full"
            :required="true"
          />
        </div>

        <hr />
        <!-- 참여자 검색 필드 -->
        <div class="search-wrapper">
          <DefaultLabel
            text="참여자 검색"
            forId="participantSearch"
            size="small"
            marginBottom="5px"
          />
          <UserSearchDropdown
            ref="participantSearchRef"
            labelText="사용자 검색"
            inputId="participantSearch"
            inputSize="full"
            :keepSearchValue="false"
            placeholder="이름(이메일)을 입력하여 검색"
            @userSelected="onParticipantSelected"
          />
        </div>

        <!-- 추가된 참여자 목록 -->
        <div v-if="formData.participants.length > 0">
          <DefaultLabel
            text="참여자 목록"
            marginBottom="5px"
            marginTop="5px"
            size="small"
          />
          <ul class="list-group">
            <li
              v-for="(person, idx) in formData.participants"
              :key="idx"
              class="list-group-item d-flex align-items-center justify-content-between"
            >
              <span>
                {{ person.name }} / {{ person.department }} / {{ person.team }}
              </span>
              <!-- 삭제 버튼 -->
              <button
                type="button"
                class="btn btn-sm btn-outline-danger square-btn"
                @click="removeParticipant(idx)"
              >
                ×
              </button>
            </li>
          </ul>
        </div>
        <hr class="search-wrapper-hr-2" />

        <!-- 카테고리 | 금액 (한도 적용) -->
        <div class="form-row align-items-center">
          <div class="col">
            <DefaultLabel
              class="category-label"
              text="카테고리"
              forId="categorySelect"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultSelect
              v-model="formData.categoryId"
              :options="categoryOptions"
              placeholder="카테고리 선택"
              size="full"
              style="width: 100%"
              :reserveErrorSpace="true"
              marginBottom="22px"
            />
          </div>
          <div class="col">
            <DefaultLabel
              :text="amountLabel"
              forId="amount"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultTextfield
              type="text"
              id="amount"
              v-model="formData.amount"
              size="full"
              style="width: 100%"
              validationType="number"
              :disabled="!selectedCategory"
              :externalInvalid="!!amountError"
              :externalError="amountError"
              :reserveErrorSpace="true"
              placeholder="카테고리 → 금액(원) 입력해주세요"
            />
          </div>
        </div>
        <hr class="search-wrapper-hr-1" />

        <div v-if="isRejected && props.receipt.rejectedReason" class="form-group">
          <DefaultLabel text="반려 사유" size="small" />
          <DefaultTextfield
            type="text"
            :modelValue="props.receipt.rejectedReason"
            size="full"
            bg-color="#ffe6e6"
            :disabled="true"
          />
        </div>

        <!-- 결재자 검색 필드 -->
        <div class="form-group search-wrapper">
          <DefaultLabel
            text="결재(합의)자 검색 [ 결재자 권한 이상 조회 ]"
            forId="approverSearch"
            size="small"
            marginBottom="5px"
          />
          <UserSearchDropdown
            ref="approverSearchRef"
            labelText="결재(합의)자 검색"
            inputId="approverSearch"
            inputSize="full"
            :keepSearchValue="false"
            :filterBy="{ service: 'receipt',
              roleDetails: [
                'ROLE_RECEIPT_APPROVER',
                'ROLE_RECEIPT_INSPECTOR',
                'ROLE_RECEIPT_MANAGER',
                'ROLE_GATE_SYSTEM'] 
            }"
            placeholder="이름(이메일)을 입력하여 검색"
            @userSelected="onApproverSelected"
          />
        </div>

        <!-- 결재자 목록 -->
        <div v-if="formData.approvers.length > 0">
          <DefaultLabel
            text="결재자 목록 (순서 변경 가능)"
            marginBottom="5px"
            size="small"
          />

          <!-- vuedraggable 적용 -->
          <draggable
            v-model="normalApprovers"
            item-key="userId"
            tag="ul"
            class="list-group"
            handle=".drag-handle"
          >
            <template #item="{ element, index }">
              <li
                class="list-group-item d-flex align-items-center justify-content-between"
              >
                <span class="d-flex align-items-center flex-wrap">
                  <!-- 드래그 핸들 -->
                  <span class="drag-handle me-2" title="드래그하여 순서 변경"
                    >≡</span
                  >

                  <span v-if="element.isDefault"
                        class="badge bg-primary text-white me-1"
                        title="고정 합의자">
                    고정
                  </span>

                  <!-- [ 결재 | 합의 ] 글자 버튼 -->
                  <span
                    :class="[
                      'approval-option',
                      'approval-decision',
                      { active: element.approvalType === '결재', disabled: element.isDefault }
                    ]"
                    @click="!element.isDefault && setApprovalType(element, '결재')"
                  >
                    결재
                  </span>
                  <span
                    :class="[
                      'approval-option',
                      'approval-agree',
                      'approval-option-right',
                      {
                        active  : element.approvalType === '합의',
                        disabled: element.isDefault || isSameDepartment(element),
                      }
                    ]"
                    @click="!element.isDefault && onAgreeClick(element)"
                  >
                    합의
                  </span>

                  <!-- 기존 이름/부서/팀 -->
                  {{ element.name }} / {{ element.department }} /
                  {{ element.team }}
                </span>

                <!-- 삭제 버튼 -->
                <button
                  v-if="!element.isDefault"
                  type="button"
                  class="btn btn-sm btn-outline-danger square-btn"
                  @click.stop="removeApprover(index)"
                >
                  ×
                </button>
              </li>
            </template>
          </draggable>

          <!-- ── 2) 고정 합의자(맨 끝·드래그 X) ───────────────── -->
          <ul v-if="fixedApprovers.length" class="list-group mt-2">
            <li
              v-for="a in fixedApprovers"
              :key="a.userId"
              class="list-group-item d-flex align-items-center justify-content-between"
            >
              <span class="d-flex align-items-center flex-wrap">
                <span class="badge bg-primary text-white me-1">고정</span>

                <!-- ✅ “결재 / 합의” 표시(비활성) -->
                <span
                  :class="[
                    'approval-option',
                    'approval-decision',
                    { active: a.approvalType === '결재', disabled: true }
                  ]"
                >
                  결재
                </span>
                <span
                  :class="[
                    'approval-option',
                    'approval-agree',
                    'approval-option-right',
                    { active: a.approvalType === '합의', disabled: true }
                  ]"
                >
                  합의
                </span>

                <!-- 이름 / 부서 / 팀 -->
                {{ a.name }} / {{ a.department }} / {{ a.team }}
              </span>
              <!-- 삭제‧타입 변경 버튼 없음 -->
            </li>
          </ul>
        </div>
        <hr class="search-wrapper-hr-2" />

        <!-- 사유 -->
        <div class="form-group reason">
          <DefaultLabel
            text="사유"
            forId="reason"
            size="small"
            :required="true"
          />
          <DefaultTextfield
            type="text"
            id="reason"
            size="full"
            v-model="formData.reason"
            placeholder="내용을 입력해주세요"
          />
        </div>

        <!-- footer 영역 직접 구현 -->
        <div class="modal-footer">
          <DefaultButton
            align="right"
            color="gray"
            marginRight="5px"
            @click="closeModal"
          >
            취소
          </DefaultButton>
          <DefaultButton type="submit" align="right"> 수정 </DefaultButton>
        </div>
      </form>
    </div>

    <!-- 이미지 미리보기 모달 -->
    <div
      v-if="isPreviewVisible"
      class="modal preview-modal"
      @click="closePreviewModalOnOutsideClick"
    >
      <div
        class="preview-modal-content"
        @mousedown="startDragPreview"   @mousemove="onDragPreview"
        @mouseup="endDragPreview"       @mouseleave="endDragPreview"
        @touchstart="startDragPreview"  @touchmove="onDragPreview"
        @touchend="endDragPreview"
      >
        <img
          :src="previewImage"
          class="preview-modal-image"
          :class="{ zoomed: isZoomed }"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
          }"
          @dblclick="toggleZoomPreview"
          @touchstart="toggleZoomPreview"
        />
      </div>
    </div>
  </b-modal>
  
  <!-- 확인 모달 -->
  <AlertModal
    :isVisible="confirmationModalVisible"
    title="저장 확인"
    @close="confirmationModalVisible = false"
    @confirm="updateReceipt"
    cancelText="취소"
    confirmText="확인"
  >
    <template #body><p>수정하시겠습니까?</p></template>
  </AlertModal>
</template>

<script setup>
/* ────────────────────────────── ①  Imports ───────────────────────────── */
import { ref, reactive, computed, watch, onMounted, defineProps, defineEmits } from 'vue';
import { BModal }          from 'bootstrap-vue-3';
import draggable           from 'vuedraggable';

import DefaultLabel        from '@/components/common/label/DefaultLabel.vue';
import DefaultTextfield    from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultFormRow      from '@/components/common/DefaultFormRow.vue';
import DefaultButton       from '@/components/common/button/DefaultButton.vue';
import DefaultSelect       from '@/components/common/select/DefaultSelect.vue';
import UserSearchDropdown  from '@/components/auth/UserSearchDropdown.vue';
import AlertModal          from '@/components/common/modal/AlertModal.vue';

import CategoryApi         from '@/api/receipt/ReceiptsCategoryApi.js';
import ReceiptApi          from '@/api/receipt/ReceiptsApi.js';

import { useAuthStore }        from '@/store/auth';
import { useUserDirectoryStore } from '@/store/hrm/userDirectory';
import { usePreviewModal }     from '@/utils/preview-modal';
import { toast }               from 'vue3-toastify';

/* ────────────────────────────── ②  Props & Emits ─────────────────────── */
const props = defineProps({ isVisible: Boolean, receipt: Object });
const emit  = defineEmits(['close', 'confirm']);

/* ────────────────────────────── ③  Stores ────────────────────────────── */
const authStore     = useAuthStore();
const userDirStore  = useUserDirectoryStore();

/* ────────────────────────────── ④  모달 on/off ───────────────────────── */
const innerVisible            = ref(props.isVisible);
const confirmationModalVisible = ref(false);

/* ────────────────────────────── ⑤  미리보기 모달 ──────────────────────── */
const {
  isPreviewVisible, previewImage, zoomedPosition, zoomOrigin,
  openPreviewModal, isZoomed,
  toggleZoom: toggleZoomPreview,
  startDrag : startDragPreview, onDrag : onDragPreview, endDrag : endDragPreview
} = usePreviewModal();

function closePreviewModalOnOutsideClick (e) {
  if (!e.target.classList.contains('preview-modal-image')) isPreviewVisible.value = false;
}

/* ────────────────────────────── ⑥  Form 데이터 ───────────────────────── */
const formData = ref({
  date: '', type: '', amount: '', reason: '',
  participants: [], approvers: [],
});

/* ---------- 파일 ---------- */
const receiptFile  = ref(null);
const previewUrl   = ref(null);
const originalFile = ref({ name: '', url: '' });

function handleFileChange (e) {
  const file = e.target.files[0] || null;
  receiptFile.value = file;
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value);
  previewUrl.value = file ? URL.createObjectURL(file) : originalFile.value.url || null;
  resetZoomAndPos();
  e.target.value = '';
}
function removeFile () {
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value);
  receiptFile.value = null;
  previewUrl.value  = originalFile.value.url || null;
  resetZoomAndPos();
}

/* ---------- 오늘 날짜 ---------- */
function setToday () {
  const d = new Date();
  formData.value.date = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

/* ---------- 참여자 / 결재자 ---------- */
function onParticipantSelected (u) {
  if (formData.value.participants.some(p => p.userId === u.userId))
    return toast.warning('이미 추가된 참여자입니다.');
  formData.value.participants.push({ userId:u.userId, name:u.name, department:u.department, team:u.team });
}

function onApproverSelected (u) {
  if (formData.value.approvers.some(a => a.userId === u.userId))
    return toast.warning('이미 추가된 결재자입니다.');
  /* ── 현재 ‘결재’(approvalType === "결재") 인원 수 검사 ── */
  const decisionCnt = formData.value.approvers
    .filter(a => a.approvalType === '결재').length
  if (decisionCnt >= 3)
    return toast.warning('결재자는 최대 3명까지 지정할 수 있습니다.')
  const obj = { userId:u.userId, name:u.name, department:u.department, team:u.team,
                approvalType:'결재', isDefault:false, approvalRole:1 };
  formData.value.approvers.splice(normalApprovers.value.length, 0, obj);
}

function removeParticipant (idx) { formData.value.participants.splice(idx,1); }
function removeApprover    (idx) { 
  if (formData.value.approvers[idx].isDefault) return toast.info('고정 합의자는 삭제할 수 없습니다.');
  formData.value.approvers.splice(idx,1); 
}

/* ────────────────────────────── ⑦  Drag / Zoom ──────────────────────── */
const isPaneZoomed = ref(false);
const pos          = reactive({ x:0, y:0 });
let   start        = { x:0, y:0 };
let   dragging     = false;

const zoomStyle = computed(() =>
  isPaneZoomed.value
    ? { transform:`translate(${pos.x}px,${pos.y}px) scale(1.5)`,
        cursor: dragging?'grabbing':'zoom-out' }
    : { cursor:'zoom-in' });

function openZoom () {
  if (!previewUrl.value) return;
  isPaneZoomed.value = !isPaneZoomed.value;
  if (!isPaneZoomed.value) pos.x = pos.y = 0;
}
function startDrag (e) {
  if (!isPaneZoomed.value) return;
  e.preventDefault();
  dragging = true;
  const p  = e.touches?.[0] ?? e;
  start    = { x:p.clientX-pos.x, y:p.clientY-pos.y };
  addDragListeners();
}
function onMove (e) {
  if (!dragging) return;
  const p  = e.touches?.[0] ?? e;
  pos.x    = p.clientX - start.x;
  pos.y    = p.clientY - start.y;
  e.preventDefault();
}
function endDrag () { dragging=false; removeDragListeners(); }

function addDragListeners () {
  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup',   endDrag);
  window.addEventListener('touchmove', onMove, { passive:false });
  window.addEventListener('touchend',  endDrag);
}
function removeDragListeners () {
  window.removeEventListener('mousemove', onMove);
  window.removeEventListener('mouseup',   endDrag);
  window.removeEventListener('touchmove', onMove);
  window.removeEventListener('touchend',  endDrag);
}
function resetZoomAndPos () { isPaneZoomed.value=false; dragging=false; pos.x=pos.y=0; }

/* ────────────────────────────── ⑧  한도 / 카테고리 ──────────────────── */
const categories      = ref([]);
const categoryOptions = computed(() =>
  categories.value.filter(c=>c.enable).map(c=>({ value:c.categoryId, label:c.categoryName }))
);
async function loadCategories () { if (!categories.value.length) categories.value = (await CategoryApi.getCategories()).data; }

const selectedCategory = computed(()=>{
  const id = Number(formData.value.categoryId || NaN);
  return categories.value.find(c=>c.categoryId===id);
});
const maxAllowed = computed(()=>{
  if (!selectedCategory.value) return Infinity;
  return Math.floor(selectedCategory.value.limitPrice * (formData.value.participants.length+1));
});
const amountError = computed(()=>{
  const entered = Number(String(formData.value.amount).replace(/\D/g,''))||0;
  return entered > maxAllowed.value ? `1인당 한도 초과 (최대 ${maxAllowed.value.toLocaleString()}원)` : null;
});
const amountLabel = computed(()=>{
  if (!selectedCategory.value) return '금액';
  const tot = selectedCategory.value.limitPrice*(formData.value.participants.length+1);
  return `금액 (한도 ${tot.toLocaleString()}원)`;
});
watch([()=>formData.value.amount, maxAllowed], ([raw,max])=>{
  if (!selectedCategory.value) return;
  const entered = Number(String(raw).replace(/\D/g,''))||0;
  if (entered > max) { formData.value.amount=String(max); toast.info(`금액이 한도를 넘어 최대값 ${max.toLocaleString()}원으로 자동 조정됐습니다.`);}
});

/* ────────────────────────────── ⑨  부서 / 승인타입 ─────────────────── */
const currentDept = computed(()=>{
  const me = userDirStore.getById(authStore.getUserId);
  return me?.department?.trim().toUpperCase() ?? '';
});
function isSameDepartment (u) {
  return (u?.department ?? '').trim().toUpperCase() === currentDept.value;
}
function setApprovalType (u, type) {
  if (u.isDefault || (type==='합의' && isSameDepartment(u))) return;
  /* 3 명 제한: 합의 → 결재 전환 시에도 검사 */
  if (type === '결재') {
    const decisionCnt = formData.value.approvers
        .filter(a => a.approvalType === '결재').length
    /* 이미 3명인데, 본인도 결재로 바꾸려 하면 차단 */
    if (decisionCnt >= 3 && u.approvalType !== '결재')
      return toast.warning('결재자는 최대 3명까지만 지정할 수 있습니다.')
  }
  u.approvalType = type;
  u.approvalRole = u.isDefault ? 3 : (type==='합의'?2:1);
}
function onAgreeClick (u) {
  if (u.isDefault || isSameDepartment(u)) {
    if (isSameDepartment(u)) toast.info('같은 부서 사용자는 ‘합의’로 지정할 수 없습니다.');
    return;
  }
  setApprovalType(u,'합의');
}

/* ---------- 고정 / 일반 결재자 ---------- */
const fixedApprovers   = computed(()=> formData.value.approvers.filter(a=>a.isDefault));
const normalApprovers  = computed({
  get:()=>formData.value.approvers.filter(a=>!a.isDefault),
  set:list=>{ formData.value.approvers=[...list,...fixedApprovers.value]; }
});

/* ────────────────────────────── ⑩  PATCH 용 FormData ────────────────── */
function buildDiffFD () {
  const fd = new FormData(), cur=formData.value, orig=props.receipt;

  /* Primitive */
  if (cur.date       && cur.date       !== orig.date)       fd.append('date',cur.date);
  if (cur.categoryId && cur.categoryId !== orig.categoryId) fd.append('categoryId',cur.categoryId);
  if (cur.amount     && cur.amount     !== orig.amount)     fd.append('amount',cur.amount);
  if (cur.reason     && cur.reason     !== orig.reason)     fd.append('reason',cur.reason);

  /* Participants */
  const stripP = p=>({ userId:p.userId,name:p.name,department:p.department,team:p.team });
  const newP   = JSON.stringify(cur.participants.map(stripP));
  const oldP   = JSON.stringify((orig.participants??[]).map(stripP));
  if (newP!==oldP) fd.append('participants',newP);

  /* Approvers */
  const stripA = a=>({
    userId:a.userId, approvalType:a.approvalType,
    approvalRole: a.isDefault ? 3 : (a.approvalType==='합의'?2:1),
    isDefault:a.isDefault, name:a.name, department:a.department, team:a.team
  });
  const newA = JSON.stringify(cur.approvers.map(stripA));
  const oldA = JSON.stringify((orig.approvers??[]).map(stripA));
  if (newA!==oldA) fd.append('approvers',newA);

  /* File */
  if (receiptFile.value)              fd.append('receiptFile',receiptFile.value);
  else if (!previewUrl.value && orig.receipt) fd.append('deleteFile',true);

  return fd;
}

/* ────────────────────────────── ⑪  저장 / 취소 ──────────────────────── */
const diffForPatch = ref(null);

function openConfirmationModal () {
  const diffFD = buildDiffFD();
  if (![...diffFD.keys()].length) return toast.info('변경된 내용이 없습니다.');

  const approverCnt = formData.value.approvers
    .filter(a => a.approvalType === '결재').length
  if (approverCnt === 0)
    return toast.warning('결재자를 최소 1명 지정해야 합니다.')
  if (approverCnt > 3)
    return toast.warning('결재자는 최대 3명까지만 지정할 수 있습니다.')

  if (diffFD.has('date')       && !formData.value.date)       return toast.warning('발행일을 입력하세요');
  if (diffFD.has('categoryId') && !formData.value.categoryId) return toast.warning('카테고리를 선택하세요');
  if (diffFD.has('amount')     && !formData.value.amount)     return toast.warning('금액을 입력하세요');
  if (diffFD.has('reason')     && !formData.value.reason)     return toast.warning('사유를 입력하세요');
  if (diffFD.has('receiptFile') &&
      !(receiptFile.value.type||'').startsWith('image/'))     return toast.warning('첨부 파일은 이미지만 가능합니다.');
  if (diffFD.has('amount') && amountError.value)              return toast.warning('금액 한도를 확인해주세요.');

  diffForPatch.value = diffFD;
  confirmationModalVisible.value = true;
}

async function updateReceipt () {
  confirmationModalVisible.value=false;
  if (!diffForPatch.value) { innerVisible.value=false; return; }

  try {
    await ReceiptApi.patchReceipt(authStore.getUserId, props.receipt.id, diffForPatch.value);
    toast.success('수정 완료'); emit('confirm');
  } catch (e) {
    console.error(e); toast.error('수정에 실패했습니다.');
  } finally {
    diffForPatch.value=null; innerVisible.value=false;
  }
}
function closeModal () { innerVisible.value=false; if (history.state?.modal) history.back(); }

/* ────────────────────────────── ⑫  Lifecycle & Watch ────────────────── */
onMounted(()=> loadCategories());

watch(()=>props.isVisible, v=> innerVisible.value=v);
watch(innerVisible, v=>{ if (!v) emit('close'); });
watch(()=>props.receipt, r=>{
  if (!r) return;
  formData.value={
    date:r.date, categoryId:r.categoryId, type:r.type,
    amount:r.amount?.replace(/[^0-9]/g,''), reason:r.reason,
    participants:(r.participants??[]).map(p=>({...p})),
    approvers   :(r.approvers??[]).map(a=>({...a,isDefault:a.approvalRole===3}))
  };
  originalFile.value = { name:r.receiptName??'', url:r.receipt??'' };
  previewUrl.value   = originalFile.value.url || null;
  receiptFile.value  = null;
}, { immediate:true });

/* ────────────────────────────── ⑬  기타 Helpers ─────────────────────── */
const isRejected = computed(()=> props.receipt?.statusText === '반려');
</script>

<style scoped>
hr {
  margin: 0 0 7px;
  border: none; /* ← 기본 border 제거 */
  height: 2px; /* 실제 두께 */
  background: #000000;
}
.search-wrapper-hr-1 {
  margin: 0px 0 10px 0;
}
.search-wrapper-hr-2 {
  margin: 15px 0 10px 0;
}
.form-row .col {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.modal-body {
  padding: 10px 0px 10px 20px !important;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}

.reason {
  margin-top: 10px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 10px;
}

.list-group-item,
.list-group {
  font-size: 0.875em !important;
}

.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

.now-label {
  cursor: pointer;
  color: #0d6efd;
}

.now-label:hover {
  text-decoration: underline;
}

.drag-handle {
  cursor: grab;
  user-select: none;
}

.drag-handle:active {
  cursor: grabbing;
}

.align-items-center {
  margin-bottom: 0px !important;
}

/* 선택 토글용 글자 버튼 */
.approval-option {
  cursor: pointer;
  padding: 2px 6px;
  /* border-radius: 4px; */
  color: #39393a; /* 기본 회색 */
  border: 1px solid #8e8e8f; /* 기본 얇은 회색 테두리 */
  user-select: none;
  margin: 0;
}

.approval-option + .approval-option {
  margin-left: -1px; /* 경계선 겹침 처리 */
}

.approval-option-right {
  margin-right: 7px;
}
/* 결재 (active) : 빨강 */
.approval-decision.active {
  color: #dc3545 !important;
  background: #dc354510 !important;
  font-weight: 900;
}

/* 합의 (active) : 초록 */
.approval-agree.active {
  color: #198754 !important;
  background: #1987542b !important;
  font-weight: 900;
}

.approval-option.disabled {
  pointer-events: none; /* 클릭 차단 */
  opacity: 0.4; /* 흐리게 표시 */
}
/* 컨테이너는 이미 .modal-body d-flex 가 있음 -------------- */
.form-pane {
  flex: 0 0 60%;
  max-width: 50%;
  max-height: 80vh; /* preview-pane 과 동일한 세로 제한 */
  padding-right: 20px;
  padding-top: 20px;
  margin: 0 auto;
  margin-bottom: 10px;
  overflow-y: auto; /* 넘치는 부분만 내부 스크롤 */
}

/* 미리보기 박스 세부 */
.preview-pane {
  margin-top: 25px;
  flex: 0 0 40%; /* 4  */
  max-width: 40%;
  display: flex;
  align-items: center;
  justify-content: center;
  max-height: 75vh; /* 모달 높이에 맞춰서 */
  overflow: hidden; /* 너무 큰 이미지는 잘라냄 */
  /* border-right: 1px solid #dee2e6; */
}
.preview-img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain; /* 비율 유지하며 내부에 맞춤 */
  border: 2px solid #dee2e6;
  border-radius: 4px;
  user-select: none; /* 글자 선택 방지 */
  -webkit-user-drag: none; /* Safari, Chrome */
}
.preview-placeholder {
  font-size: 0.8rem;
  color: #777;
  text-align: center;
}
/* 기본(축소) */
.preview-pane {
  flex: 0 0 40%;
  max-width: 40%;
  display: flex;
  align-items: center;
  justify-content: center;
  max-height: 75vh;
  overflow: hidden;
  cursor: zoom-in; /* 확대 가능하다는 힌트 */
}
.preview-img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  transition: transform 0.2s ease;
}

/* 확대 상태 */
.preview-pane.zoomed {
  cursor: zoom-out;
  /* overflow: auto; */ /* 스크롤 가능 */
  overflow: hidden;
}

/* ── 미리보기 모달 ─────────────────────── */
.preview-modal{
  position: fixed; inset: 0;
  background: rgba(0,0,0,.7);
  display: flex; justify-content: center; align-items: center;
  z-index: 9999;
}
.preview-modal-content{ position: relative; }
.preview-modal-image{
  max-width: 80vw; max-height: 80vh;
  transition: transform .2s ease;
}

@media (max-width: 991px) {
  .modal-body {
    padding: 10px 0px 10px 20px !important;
  }
  .preview-pane {          /* 왼쪽 이미지 영역 숨김 */
    display: none;
  }
  .form-pane {
    padding-top: 0;
  }
  .v-divider {             /* 가운데 세로선 제거 */
    display: none;
  }
  .form-pane {             /* 오른쪽(폼) 영역을 100%로 확장 */
    flex: 1 1 100%;
    max-width: 100%;
  }
}

@media (max-width: 650px) {
  .modal-body {
    flex-direction: column;
  }
  .preview-pane,
  .form-pane {
    max-width: 100%;
    flex: 0 0 auto;
  }
  .form-pane {
    margin: 0;
  }
  .v-divider {
    display: none;
  }
  .preview-pane {
    height: 240px;
    margin-bottom: 1rem;
  }
  hr {
    margin: 0 0 5px 0;
  }

  .search-wrapper-hr {
    margin: 10px 0 5px 0;
  }

  .list-group-item,
  .list-group {
    font-size: 0.8em !important;
  }

  .form-group {
    margin-bottom: 10px;
  }
}
</style>
