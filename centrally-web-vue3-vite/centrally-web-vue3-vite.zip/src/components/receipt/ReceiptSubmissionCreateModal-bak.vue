<template>
  <!-- BootstrapVue 의 b-modal 사용 -->
  <b-modal
    v-model="innerVisible"
    title="영수증 등록"
    no-close-on-backdrop
    centered
    fade
    hide-footer
    scrollable
  >
    <div class="modal-body">
      <!-- 모달 내부 컨텐츠 -->
      <form @submit.prevent="openConfirmationModal" @keydown.enter.prevent>
        <!-- 이미지 등록 -->
        <div class="form-group">
          <DefaultLabel
            text="영수증 사진"
            forId="receiptImage"
            size="small"
            marginBottom="5px"
            :required="true"
          />
          <DefaultTextfield
            type="file"
            id="receiptImage"
            size="full"
            style="width: 100%"
            @change="handleFileChange"
          />
          <!-- 선택된 파일 이름 표시 및 삭제 버튼 -->
          <div v-if="receiptFile" class="mt-2">
            <ul class="list-group">
              <li class="list-group-item">
                {{ receiptFile.name }}
                <button
                  type="button"
                  class="btn btn-danger square-btn ms-2"
                  @click="removeFile"
                >
                  x
                </button>
              </li>
            </ul>
          </div>
        </div>

        <!-- 영수증 발행일 -->
        <div class="form-group">
          <DefaultFormRow marginBottom="5px">
            <DefaultLabel
              text="영수증 발행일"
              forId="date"
              size="small"
              :required="true"
            />
            <DefaultLabel
              text="[NOW]"
              size="small"
              class="now-label"
              @click="setToday"
            />
          </DefaultFormRow>
          <DefaultTextfield
            type="date"
            id="date"
            v-model="formData.date"
            size="full"
            :required="true"
          />
        </div>

        <!--카테고리 | 금액 -->
        <div class="form-row align-items-center">
          <div class="col">
            <DefaultLabel
              class="category-label"
              text="카테고리"
              forId="categorySelect"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultSelect
              v-model="formData.categoryId"
              :options="categoryOptions"
              placeholder="카테고리 선택"
              size="full"
              style="width: 100%"
              :reserveErrorSpace="true"
              marginBottom="22px"
            />
          </div>
          <div class="col">
            <DefaultLabel
              class="amount-label"
              :text="amountLabel"
              forId="amount"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultTextfield
              type="text"
              id="amount"
              v-model="formData.amount"
              size="full"
              style="width: 100%"
              validationType="number"
              :disabled="!selectedCategory"
              :externalInvalid="!!amountError"
              :externalError="amountError"
              :reserveErrorSpace="true"
              placeholder="카테고리 → 금액(원) 입력해주세요"
            />
          </div>
        </div>

        <hr />
        <!-- 참여자 검색 필드 -->
        <div class="search-wrapper">
          <DefaultLabel
            text="참여자 검색"
            forId="participantSearch"
            size="small"
            marginBottom="5px"
          />
          <UserSearchDropdown
            ref="participantSearchRef"
            labelText="사용자 검색"
            inputId="participantSearch"
            inputSize="full"
            :keepSearchValue="false"
            placeholder="이름(이메일)을 입력하여 검색"
            @userSelected="onParticipantSelected"
          />
        </div>

        <!-- 추가된 참여자 목록 -->
        <div v-if="formData.participants.length > 0">
          <DefaultLabel
            text="참여자 목록"
            marginBottom="5px"
            marginTop="5px"
            size="small"
          />
          <ul class="list-group">
            <li
              v-for="(person, idx) in formData.participants"
              :key="idx"
              class="list-group-item d-flex align-items-center justify-content-between"
            >
              <span>
                {{ person.name }} / {{ person.department }} / {{ person.team }}
              </span>
              <!-- 삭제 버튼 -->
              <button
                type="button"
                class="btn btn-sm btn-outline-danger square-btn"
                @click="removeParticipant(idx)"
              >
                ×
              </button>
            </li>
          </ul>
        </div>
        <hr class="search-wrapper-hr" />

        <!-- 결재자 검색 필드 -->
        <div class="search-wrapper">
          <DefaultLabel
            text="결재(합의)자 검색"
            forId="approverSearch"
            size="small"
            marginBottom="5px"
          />
          <UserSearchDropdown
            ref="approverSearchRef"
            labelText="결재(합의)자 검색"
            inputId="approverSearch"
            inputSize="full"
            :keepSearchValue="false"
            :filterBy="{ service: 'receipt',
              roleDetails: [
                'ROLE_RECEIPT_APPROVER',
                'ROLE_RECEIPT_INSPECTOR',
                'ROLE_RECEIPT_MANAGER',
                'ROLE_GATE_SYSTEM'] 
            }"
            placeholder="이름(이메일)을 입력하여 검색"
            @userSelected="onApproverSelected"
          />
        </div>

        <!-- 결재자 목록 -->
        <div v-if="formData.approvers.length > 0">
          <DefaultLabel
            text="결재자 목록 (순서 변경 가능)"
            marginBottom="5px"
            marginTop="10px"
            size="small"
          />

          <!-- vuedraggable 적용 -->
          <draggable
            v-model="formData.approvers"
            item-key="userId"
            tag="ul"
            class="list-group"
            handle=".drag-handle"
          >
            <template #item="{ element, index }">
              <li
                class="list-group-item d-flex align-items-center justify-content-between"
              >
                <span class="d-flex align-items-center flex-wrap">
                  <!-- 드래그 핸들 -->
                  <span class="drag-handle me-2" title="드래그하여 순서 변경"
                    >≡</span
                  >

                  <!-- [ 결재 | 합의 ] 글자 버튼 -->
                  <span
                    class="approval-option approval-decision"
                    :class="{ active: element.approvalType === '결재' }"
                    @click="setApprovalType(element, '결재')"
                  >
                    결재
                  </span>
                  <span
                    class="approval-option approval-agree approval-option-right"
                    :class="{
                      active: element.approvalType === '합의',
                      disabled: isSameDepartment(element),
                    }"
                    @click="onAgreeClick(element, '합의')"
                  >
                    합의
                  </span>

                  <!-- 기존 이름/부서/팀 -->
                  {{ element.name }} / {{ element.department }} /
                  {{ element.team }}
                </span>

                <!-- 삭제 버튼 -->
                <button
                  type="button"
                  class="btn btn-sm btn-outline-danger square-btn"
                  @click.stop="removeApprover(index)"
                >
                  ×
                </button>
              </li>
            </template>
          </draggable>
        </div>
        <hr class="search-wrapper-hr" />

        <!-- 사유 -->
        <div class="form-group reason">
          <DefaultLabel
            text="사유"
            forId="reason"
            size="small"
            :required="true"
          />
          <DefaultTextfield
            type="text"
            id="reason"
            size="full"
            v-model="formData.reason"
            placeholder="내용을 입력해주세요"
          />
        </div>

        <!-- footer 영역 직접 구현 -->
        <div class="modal-footer">
          <DefaultButton
            align="right"
            color="gray"
            marginRight="5px"
            @click="closeModal"
          >
            취소
          </DefaultButton>
          <DefaultButton type="submit" align="right"> 등록 </DefaultButton>
        </div>
      </form>
    </div>
  </b-modal>

  <!-- AlertModal (확인 모달) -->
  <AlertModal
    :isVisible="confirmationModalVisible"
    :disableBackgroundClose="true"
    title="저장 확인"
    confirmText="확인"
    cancelText="취소"
    @close="confirmationModalVisible = false"
    @confirm="submitReceipt"
  >
    <template #body>
      <p>등록하시겠습니까?</p>
    </template>
  </AlertModal>
</template>

<script setup>
import {
  ref,
  computed,
  defineProps,
  defineEmits,
  watch,
  onMounted,
  onBeforeUnmount,
} from "vue";
import { BModal } from "bootstrap-vue-3";
import draggable from "vuedraggable";
import AlertModal from "@/components/common/modal/AlertModal.vue";
import DefaultButton from "@/components/common/button/DefaultButton.vue";
import DefaultTextfield from "@/components/common/textfield/DefaultTextfield.vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import DefaultSelect from "@/components/common/select/DefaultSelect.vue";
import UserSearchDropdown from "@/components/auth/UserSearchDropdown.vue";
import { useAuthStore } from "@/store/auth";
import { toast } from "vue3-toastify";
import ReceiptApi from "@/api/receipt/ReceiptsApi.js";
import CategoryApi from "@/api/receipt/ReceiptsCategoryApi.js";
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";

const authStore = useAuthStore();
const emit = defineEmits(["close", "confirm"]);

/** 폼 데이터 */
const formData = ref({
  date: "",
  categoryId: "",
  amount: "",
  reason: "",
  participants: [],
  approvers: [],
});

/** 파일 변수 */
const receiptFile = ref(null);

function handleFileChange(e) {
  const file = e.target.files[0];
  receiptFile.value = file || null;
  e.target.value = "";
}
function removeFile() {
  receiptFile.value = null;
}

function openModal() {
  history.pushState({ modal: true }, "");
}

/** 참여자 선택 */
function onParticipantSelected(user) {
  const exists = formData.value.participants.some(
    (p) => p.userId === user.userId
  );
  if (exists) {
    toast.warning("이미 추가된 참여자입니다.");
    return;
  }
  formData.value.participants.push({
    userId: user.userId,
    name: user.name,
    department: user.department,
    team: user.team,
  });
}
/** 결재자 선택 */
function onApproverSelected(user) {
  const exists = formData.value.approvers.some((a) => a.userId === user.userId);
  if (exists) {
    toast.warning("이미 추가된 결재자입니다.");
    return;
  }
  formData.value.approvers.push({
    userId: user.userId,
    name: user.name,
    department: user.department,
    team: user.team,
    approvalType: "결재",
  });
}
/* 참여자 삭제 */
function removeParticipant(idx) {
  formData.value.participants.splice(idx, 1);
}
/* 결재자 삭제 */
function removeApprover(idx) {
  formData.value.approvers.splice(idx, 1);
}

// 카테고리(구분) 셀렉트 박스용
const categories = ref([]); // 전체 카테고리
const categoryOptions = computed(() => [
  ...categories.value
    .filter((c) => c.enable) // enable==true 만
    .map((c) => ({ value: c.categoryId, label: c.categoryName })),
]);

// 모달 열릴 때마다 카테고리 최초 1회 조회
async function loadCategories() {
  if (categories.value.length) return;
  const res = await CategoryApi.getCategories();
  categories.value = res.data; // -- [{categoryId, categoryName, ...}]
}

/** 검색 컴포넌트 Ref */
const participantSearchRef = ref(null);
const approverSearchRef = ref(null);

const confirmationModalVisible = ref(false);

function resetFormData() {
  formData.value = {
    date: "",
    type: "",
    amount: "",
    reason: "",
    participants: [],
    approvers: [],
  };
  receiptFile.value = null;

  if (participantSearchRef.value?.resetSearch) {
    participantSearchRef.value.resetSearch();
  }
  if (approverSearchRef.value?.resetSearch) {
    approverSearchRef.value.resetSearch();
  }
}

function openConfirmationModal() {
  if (
    !formData.value.date ||
    !formData.value.categoryId ||
    !formData.value.amount ||
    !formData.value.reason
  ) {
    toast.warning("필수 입력값(발행일, 카테고리, 금액, 사유)을 입력해주세요.");
    return;
  }
  if (!receiptFile.value) {
    toast.warning("첨부 파일을 등록해주세요.");
    return;
  }
  if (!receiptFile.value.type.startsWith("image/")) {
    toast.warning("첨부 파일은 이미지 파일만 등록할 수 있습니다.");
    return;
  }
  if (amountError.value) {
    toast.warning("금액을 한도를 확인해주세요.");
    return;
  }
  confirmationModalVisible.value = true;
}

async function submitReceipt() {
  confirmationModalVisible.value = false;

  const payload = new FormData();
  payload.append("date", formData.value.date);
  payload.append("categoryId", formData.value.categoryId);
  payload.append("amount", formData.value.amount);
  payload.append("reason", formData.value.reason);
  payload.append("participants", JSON.stringify(formData.value.participants));
  payload.append("approvers", JSON.stringify(formData.value.approvers));
  payload.append("receiptFile", receiptFile.value);

  const userId = authStore.getUserId;

  await ReceiptApi.createReceipt(userId, payload);

  resetFormData();
  innerVisible.value = false;
  emit("confirm");
}

function closeModal() {
  innerVisible.value = false;
  if (history.state?.modal) history.back();
}

const props = defineProps({ isVisible: Boolean });
const innerVisible = ref(props.isVisible);

function handlePopState() {
  if (innerVisible.value) {
    innerVisible.value = false;
    emit("close");
  }
}
function setToday() {
  const today = new Date();
  const y = today.getFullYear();
  const m = String(today.getMonth() + 1).padStart(2, "0");
  const d = String(today.getDate()).padStart(2, "0");
  formData.value.date = `${y}-${m}-${d}`;
}

/* ---------------- 한도 계산 ---------------- */
/* ② selectedCategory : 선택 전에는 null 이 아니라 undefined 로 돌려놓습니다
      (null → 한도 Infinity 로 계산하도록 분기하기 위함)                */
const selectedCategory = computed(() => {
  const id = Number(formData.value.categoryId || NaN);
  return categories.value.find((c) => c.categoryId === id);
});

/* ③ 한도 계산 – 선택 안 했으면 Infinity 로 반환                       */
const maxAllowed = computed(() => {
  if (!selectedCategory.value) return Infinity; // ← 포인트
  const persons = formData.value.participants.length + 1;
  return Math.floor(selectedCategory.value.limitPrice * persons);
});

/* ④ 오류 문자열 – 넘어가면 메시지, 아니면 null                       */
const amountError = computed(() => {
  const entered = Number(String(formData.value.amount).replace(/\D/g, "")) || 0;
  return entered > maxAllowed.value
    ? `1인당 한도 초과 (최대 ${maxAllowed.value.toLocaleString()}원)`
    : null; // ← null 전달
});

const amountLabel = computed(() => {
  // ▸ 카테고리 미선택 시
  if (!selectedCategory.value) return "금액";
  // ▸ ‘현재 인원(참여자 + 신청자 1명)’에 맞춘 총 한도
  const persons = formData.value.participants.length + 1;
  const total = selectedCategory.value.limitPrice * persons;
  return `금액 (한도 ${total.toLocaleString()}원)`; // 예)  한도 60,000원
});

// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

/** ① 내 부서 */
const currentDept = computed(() => {
  const me = userDirStore.getById(authStore.getUserId); // ← userId로 조회
  return me?.department?.trim().toUpperCase() ?? "";
});

/** ② 같은 부서 여부 */
function isSameDepartment(targetUser) {
  const theirs = (targetUser?.department ?? "").trim().toUpperCase();
  return theirs && theirs === currentDept.value;
}
// 버튼 클릭 처리
function setApprovalType(user, type) {
  if (type === "합의" && isSameDepartment(user)) return;
  user.approvalType = type;
}
function onAgreeClick(user) {
  if (isSameDepartment(user)) {
    toast.info("같은 부서 사용자는 ‘합의’로 지정할 수 없습니다.");
    return; // 🚫 아예 처리 중단
  }
  setApprovalType(user, "합의");
}

onMounted(() => {
  userDirStore.refresh();
  window.addEventListener("popstate", handlePopState);
  loadCategories();
});
onBeforeUnmount(() => {
  window.removeEventListener("popstate", handlePopState);
});

watch(
  [() => formData.value.amount, maxAllowed], // 감시 대상
  ([raw, max]) => {
    if (!max || max === Infinity) return; // 카테고리 미선택
    const entered = Number(String(raw).replace(/\D/g, "") || 0);
    if (entered > max) {
      formData.value.amount = String(max); // ❷ 강제 보정
      toast.info(
        `금액이 한도를 넘어 최대값 ${max.toLocaleString()}원으로 자동 조정됐습니다.`
      );
    }
  }
);

watch(
  () => props.isVisible,
  (newVal) => {
    innerVisible.value = newVal;
    if (newVal) {
      resetFormData();
      openModal();
    }
  }
);

watch(
  () => innerVisible.value,
  (val) => {
    if (!val) emit("close");
  }
);
</script>

<style scoped>
hr {
  margin: 0 0 7px;
  border: none; /* ← 기본 border 제거 */
  height: 2px; /* 실제 두께 */
  background: #000000;
}
.search-wrapper-hr {
  margin: 15px 0 10px 0;
}
.form-row .col {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.modal-body {
  padding: 5px 5px 5px 5px;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}

.reason {
  margin-top: 10px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 10px;
}

.list-group-item,
.list-group {
  font-size: 0.875em !important;
}

.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

.now-label {
  cursor: pointer;
  color: #0d6efd;
}

.now-label:hover {
  text-decoration: underline;
}

.drag-handle {
  cursor: grab;
  user-select: none;
}

.drag-handle:active {
  cursor: grabbing;
}

.align-items-center {
  margin-bottom: 0px !important;
}

/* 선택 토글용 글자 버튼 */
.approval-option {
  cursor: pointer;
  padding: 2px 6px;
  /* border-radius: 4px; */
  color: #39393a; /* 기본 회색 */
  border: 1px solid #8e8e8f; /* 기본 얇은 회색 테두리 */
  user-select: none;
  margin: 0;
}

.approval-option + .approval-option {
  margin-left: -1px; /* 경계선 겹침 처리 */
}

.approval-option-right {
  margin-right: 7px;
}
/* 결재 (active) : 빨강 */
.approval-decision.active {
  color: #dc3545 !important;
  background: #dc354510 !important;
  font-weight: 900;
}

/* 합의 (active) : 초록 */
.approval-agree.active {
  color: #198754 !important;
  background: #1987542b !important;
  font-weight: 900;
}

/* .approval-option.active {
  color: #0d6efd;
  font-weight: 900;
  background: #0d6dfd25;
} */

.approval-option.disabled {
  pointer-events: none; /* 클릭 차단 */
  opacity: 0.4; /* 흐리게 표시 */
}

@media (max-width: 650px) {
  hr {
    margin: 0 0 5px 0;
  }

  .search-wrapper-hr {
    margin: 10px 0 5px 0;
  }

  .list-group-item,
  .list-group {
    font-size: 0.8em !important;
  }

  .form-group {
    margin-bottom: 10px;
  }
}
</style>
