<template>
  <b-modal
    v-model="innerVisible"
    title="영수증 상세"
    no-close-on-backdrop
    size="xl"
    custom-class="receipt-modal"
    centered
    fade
    hide-footer
    body-class="p-0"
    @show="resetPane"
  >
    <div class="modal-body d-flex gap-4">
      <!-- ① 이미지 영역 -->
      <div
        class="preview-pane"
        :class="{ zoomed: isPaneZoomed }"
        @dblclick="openZoom"
      >
        <img
          v-if="previewUrl"
          :src="previewUrl"
          class="preview-img"
          :class="{ zoomed: isPaneZoomed }"
          :style="zoomStyle"
          draggable="false"
          @mousedown="startDrag"
          @touchstart.passive="startDrag"
        />
        <div v-else class="preview-placeholder">영수증 이미지가 없습니다</div>
      </div>

      <!-- ② 상세 정보 (전체 읽기 전용) -->
      <div class="form-pane">
        <!-- 이미지 등록 -->
        <div class="form-group">
          <DefaultLabel
            text="영수증 사진"
            forId="receiptImage"
            size="small"
            :required="true"
            marginBottom="5px"
          />
          <!-- 기존 파일 표시 (새 파일을 아직 선택하지 않았을 때만) -->
          <div v-if="originalFile.name">
            <ul class="list-group">
              <li class="list-group-item">
                <a
                  :href="originalFile.url"
                  @click.prevent="openPreviewModal(originalFile.url)"
                  >[기존 파일] {{ originalFile.name }}</a
                >
              </li>
            </ul>
          </div>
        </div>

        <!-- 영수증 발행일 -->
        <div class="form-group">
          <DefaultFormRow marginBottom="5px">
            <DefaultLabel
              text="영수증 발행일"
              forId="date"
              size="small"
              :required="true"
            />
          </DefaultFormRow>
          <DefaultTextfield
            type="date"
            id="date"
            v-model="formData.date"
            size="full"
            :required="true"
            :disabled="true"
          />
        </div>

        <!-- 구분 | 금액 -->
        <!-- 카테고리 | 금액 (한도 적용) -->
        <div class="form-row align-items-center">
          <div class="col">
            <DefaultLabel
              class="category-label"
              text="카테고리"
              forId="categorySelect"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultSelect
              v-model="formData.categoryId"
              :options="categoryOptions"
              placeholder="카테고리 선택"
              :disabled="true"
              size="full"
              style="width: 100%"
              marginBottom="10px"
            />
          </div>
          <div class="col">
            <DefaultLabel
              text="금액(원)"
              forId="amount"
              size="small"
              marginBottom="5px"
              :required="true"
            />
            <DefaultTextfield
              type="text"
              id="amount"
              v-model="formData.amount"
              size="full"
              style="width: 100%"
              validationType="number"
              :disabled="true"
              marginBottom="10px"
            />
          </div>
        </div>

        <!-- 사유 -->
        <div class="mb-3">
          <DefaultLabel text="사유" size="small" marginBottom="5px" />
          <DefaultTextfield
            type="text"
            v-model="formData.reason"
            size="full"
            :disabled="true"
            :required="true"
          />
        </div>

        <!-- 참여자 목록 -->
        <div v-if="formData.participants.length">
          <DefaultLabel text="참여자 목록" size="small" marginBottom="5px" />
          <ul class="list-group">
            <li
              v-for="(p, idx) in formData.participants"
              :key="idx"
              class="list-group-item"
            >
              {{ p.name }} / {{ p.department }} / {{ p.team }}
            </li>
          </ul>
        </div>

        <div v-if="rejectReason" class="mt-3">
          <DefaultLabel text="반려 사유" size="small" />
          <DefaultTextfield
            type="text"
            v-model="rejectReason"
            size="full"
            :disabled="true"
            bg-color="#ffe6e6"
          />
        </div>

        <!-- 결재자 목록 -->
        <div v-if="formData.approvers.length" class="mt-3">
          <DefaultLabel text="결재자 목록" size="small" marginBottom="5px" />
          <ul class="list-group">
            <li
              v-for="a in formData.approvers"
              :key="a.userId"
              :class="[
                'list-group-item d-flex align-items-center flex-wrap',
                { 'done-approver': a.stateText !== '대기' }   // ✅ 대기가 아니면 회색
              ]"
            >
              <!-- ── 왼쪽 영역 ───────────────────────────── -->
              <div class="d-flex align-items-center flex-wrap">

                <span
                  v-if="a.isDefault"
                  class="badge text-bg-primary me-1"
                  title="고정 합의자"
                >
                  고정
                </span>

                <span
                  class="approval-option approval-decision disabled"
                  :class="{ active: a.approvalType === '결재' }"
                >
                  결재
                </span>
                <span
                  class="approval-option approval-agree approval-option-right disabled"
                  :class="{ active: a.approvalType === '합의' }"
                >
                  합의
                </span>
                {{ a.name }} / {{ a.department }} / {{ a.team }}
              </div>

              <!-- ── 상태 표시(오른쪽) ────────────────────── -->
              <span
                class="state-badge ms-auto text-end"
                :class="{
                  'text-success': a.stateText === '승인',
                  'text-danger': a.stateText === '반려',
                  'text-secondary': a.stateText === '대기',
                }"
              >
                {{ a.stateText }}
              </span>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div
      v-if="isPreviewVisible"
      class="modal preview-modal"
      @click.self="isPreviewVisible = false"
    >
      <div
        class="preview-modal-content"
        @mousedown="startDragPreview"   @mousemove="onDragPreview"
        @mouseup="endDragPreview"       @mouseleave="endDragPreview"
        @touchstart="startDragPreview"  @touchmove="onDragPreview"
        @touchend="endDragPreview"
      >
        <img
          :src="previewImage"
          class="preview-modal-image"
          :class="{ zoomed: isZoomed }"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
          }"
          @dblclick="toggleZoomPreview"
          @touchstart="toggleZoomPreview"
        />
      </div>
    </div>
  </b-modal>
</template>

<script setup>
import { ref, computed, watch, defineProps, defineEmits } from "vue";
import { BModal } from "bootstrap-vue-3";

import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import DefaultTextfield from "@/components/common/textfield/DefaultTextfield.vue";
import DefaultSelect from "@/components/common/select/DefaultSelect.vue";
import DefaultFormRow from '@/components/common/DefaultFormRow.vue'

import CategoryApi from "@/api/receipt/ReceiptsCategoryApi.js";
import { usePreviewModal } from "@/utils/preview-modal";

/* ────── props / emit ────── */
const props = defineProps({
  isVisible: Boolean,
  receipt: Object,
});
const emit = defineEmits(["close"]);

/* ────── 모달 on/off ────── */
const innerVisible = ref(props.isVisible);
watch(
  () => props.isVisible,
  (v) => (innerVisible.value = v)
);
watch(innerVisible, (v) => {
  if (!v) emit("close");
});

/* ────── 미리보기 모달 ────── */
const {
  isPreviewVisible,
  previewImage,
  zoomedPosition,
  zoomOrigin,
  isZoomed,
  toggleZoom: toggleZoomPreview,
  startDrag: startDragPreview,
  onDrag: onDragPreview,
  endDrag: endDragPreview,
  openPreviewModal
} = usePreviewModal();


/* ────── 좌측 패널 상태 초기화용 함수 ────── */
const isPaneZoomed = ref(false);
const pos = ref({ x:0, y:0 });
function resetPane() {            // ← 새로 추가
  isPaneZoomed.value = false;
  pos.value = { x:0, y:0 };
}

/* ────── 이미지 확대/드래그 (좌측 pane) ────── */
let start = { x: 0, y: 0 };
let dragging = false;

const zoomStyle = computed(() =>
  isPaneZoomed.value
    ? {
        transform: `translate(${pos.value.x}px, ${pos.value.y}px) scale(1.5)`,
        cursor: dragging ? "grabbing" : "zoom-out",
      }
    : { cursor: "zoom-in" }
);

function openZoom() {
  if (!previewUrl.value) return;
  isPaneZoomed.value = !isPaneZoomed.value;
  if (!isPaneZoomed.value) pos.value = { x: 0, y: 0 };
}
function startDrag(e) {
  if (!isPaneZoomed.value) return;
  dragging = true;
  const p = e.touches?.[0] ?? e;
  start = { x: p.clientX - pos.value.x, y: p.clientY - pos.value.y };
  window.addEventListener("mousemove", onMove);
  window.addEventListener("mouseup", endDrag);
  window.addEventListener("touchmove", onMove, { passive: false });
  window.addEventListener("touchend", endDrag);
}
function onMove(e) {
  if (!dragging) return;
  const p = e.touches?.[0] ?? e;
  pos.value = { x: p.clientX - start.x, y: p.clientY - start.y };
  e.preventDefault();
}
function endDrag() {
  dragging = false;
  window.removeEventListener("mousemove", onMove);
  window.removeEventListener("mouseup", endDrag);
  window.removeEventListener("touchmove", onMove);
  window.removeEventListener("touchend", endDrag);
}

/* ────── 카테고리 옵션 (읽기 전용이라도 표시용으로 필요) ────── */
const rejectReason = ref(""); // 반려사유·좌측 초기화용 상태
const categories = ref([]);
const categoryOptions = computed(() =>
  categories.value.map((c) => ({ value: c.categoryId, label: c.categoryName }))
);
async function loadCategories() {
  if (categories.value.length) return;
  const res = await CategoryApi.getCategories();
  categories.value = res.data;
}
loadCategories();

/* ────── 표시용 데이터 ────── */
const formData = ref({
  date: "",
  categoryId: null,
  amount: "",
  reason: "",
  participants: [],
  approvers: [],
});
const originalFile = ref({ name: "", url: "" });
const previewUrl = ref(null);

/* props.receipt → formData 세팅 */
watch(
  () => props.receipt,
  (r) => {
    if (!r) return;
    formData.value = {
      date: r.date,
      categoryId: r.categoryId,
      amount: r.amount,
      reason: r.reason,
      participants: r.participants ?? [],
      // 고정 합의자(approvalRole === 3) → isDefault 플래그 주입
      approvers: (r.approvers ?? []).map(a => ({
        ...a,
        isDefault: a.isDefault ?? a.approvalRole === 3
      })),
    };
    rejectReason.value =
      (r.approvers ?? []).find(a => a.rejectedReason)?.rejectedReason || "";
    originalFile.value = { name: r.receiptName ?? "", url: r.receipt ?? "" };
    previewUrl.value = originalFile.value.url || null;

    resetPane();
  },
  { immediate: true }
);
</script>

<style scoped>
hr {
  margin: 0 0 7px;
  border: none; /* ← 기본 border 제거 */
  height: 2px; /* 실제 두께 */
  background: #000000;
}
.search-wrapper-hr {
  margin: 15px 0 10px 0;
}
.form-row .col {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.modal-body {
  padding: 10px 0px 10px 20px !important;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}

.reason {
  margin-top: 10px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 10px;
}

.list-group-item,
.list-group {
  font-size: 0.875em !important;
}

.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

.now-label {
  cursor: pointer;
  color: #0d6efd;
}

.now-label:hover {
  text-decoration: underline;
}

.drag-handle {
  cursor: grab;
  user-select: none;
}

.drag-handle:active {
  cursor: grabbing;
}

.align-items-center {
  margin-bottom: 0px !important;
}

/* 선택 토글용 글자 버튼 */
.approval-option {
  cursor: pointer;
  padding: 2px 6px;
  /* border-radius: 4px; */
  color: #39393a; /* 기본 회색 */
  border: 1px solid #8e8e8f; /* 기본 얇은 회색 테두리 */
  user-select: none;
  margin: 0;
}

.approval-option + .approval-option {
  margin-left: -1px; /* 경계선 겹침 처리 */
}

.approval-option-right {
  margin-right: 7px;
}
/* 결재 (active) : 빨강 */
.approval-decision.active {
  color: #ff0019 !important;
  background: #dc35466c !important;
  font-weight: 900;
}

/* 합의 (active) : 초록 */
.approval-agree.active {
  color: #00914d !important;
  background: #19875469 !important;
  font-weight: 900;
}

.approval-option.disabled {
  pointer-events: none; /* 클릭 차단 */
  opacity: 0.4; /* 흐리게 표시 */
}
/* 컨테이너는 이미 .modal-body d-flex 가 있음 -------------- */
.form-pane {
  flex: 0 0 60%;
  max-width: 50%;
  max-height: 80vh; /* preview-pane 과 동일한 세로 제한 */
  padding-right: 20px;
  padding-top: 20px;
  margin: 0 auto;
  margin-bottom: 10px;
  overflow-y: auto; /* 넘치는 부분만 내부 스크롤 */
}

/* 미리보기 박스 세부 */
.preview-pane {
  margin-top: 25px;
  margin-bottom: 25px;
  flex: 0 0 40%; /* 4  */
  max-width: 40%;
  display: flex;
  align-items: center;
  justify-content: center;
  max-height: 75vh; /* 모달 높이에 맞춰서 */
  overflow: hidden; /* 너무 큰 이미지는 잘라냄 */
  /* border-right: 1px solid #dee2e6; */
}
.preview-img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain; /* 비율 유지하며 내부에 맞춤 */
  border: 2px solid #dee2e6;
  border-radius: 4px;
  user-select: none; /* 글자 선택 방지 */
  -webkit-user-drag: none; /* Safari, Chrome */
}
.preview-placeholder {
  font-size: 0.8rem;
  color: #777;
  text-align: center;
}
/* 기본(축소) */
.preview-pane {
  flex: 0 0 40%;
  max-width: 40%;
  display: flex;
  align-items: center;
  justify-content: center;
  max-height: 75vh;
  overflow: hidden;
  cursor: zoom-in; /* 확대 가능하다는 힌트 */
}
.preview-img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  transition: transform 0.2s ease;
}

/* 확대 상태 */
.preview-pane.zoomed {
  cursor: zoom-out;
  /* overflow: auto; */ /* 스크롤 가능 */
  overflow: hidden;
}

/* ── 미리보기 모달 ─────────────────────── */
.preview-modal {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.preview-modal-content {
  position: relative;
}

.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}

/* scoped style 맨 아래에 추가 */
.state-badge {
  font-weight: 900;
  min-width: 48px; /* 넓이 통일 */
  text-align: right;
}

/* 승인·반려 완료된 결재자 행 */
.done-approver {
  background: #f1f1f1 !important;   /* 원하는 회색 계열로 조정 */
}
@media (max-width: 991px) {
  .modal-body {
    padding: 15px 15px 45px 15px !important;
  }
  .preview-pane {
    /* 왼쪽 이미지 영역 숨김 */
    display: none;
  }
  .v-divider {
    /* 가운데 세로선 제거 */
    display: none;
  }
  .form-pane {
    /* 오른쪽(폼) 영역을 100%로 확장 */
    flex: 1 1 100%;
    max-width: 100%;
    padding: 0px;
  }
}

@media (max-width: 650px) {
  .modal-body {
    flex-direction: column;
  }
  .preview-pane,
  .form-pane {
    max-width: 100%;
    flex: 0 0 auto;
  }
  .form-pane {
    margin: 0;
  }
  .v-divider {
    display: none;
  }
  .preview-pane {
    height: 240px;
    margin-bottom: 1rem;
  }
  hr {
    margin: 0 0 5px 0;
  }

  .search-wrapper-hr {
    margin: 10px 0 5px 0;
  }

  .list-group-item,
  .list-group {
    font-size: 0.8em !important;
  }

  .form-group {
    margin-bottom: 10px;
  }
}
</style>
