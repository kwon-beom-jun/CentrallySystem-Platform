<template>
  <div />
</template>

<script setup>
import { onBeforeMount } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useAuthStore } from '@/store/auth'
import LoginApi from '@/api/auth/LoginApi'

const router = useRouter();
const route = useRoute();
const authStore = useAuthStore();

// 페이지 뜨기전 로딩
onBeforeMount(async () => {
  
  // 피니아 로그인 정보 제거
  authStore.logout()

  // 쿼리 파라미터(error) 확인
  // 기존 기본 로그인이 Auth 서버 시큐리티에 저장되어있어서 중복로그인으로 판정 재로그인 해야함
  // 일반 로그인은 RestAPI로 아이디, 비번을 보내줘서 시큐리티에 넣어주기에 문제없음
  const errorParam = route.query.error;
  if (errorParam) {
    // 만약 error=alreadyLoggedIn 이면 사용자에게 메시지
    // 이후 로그인 페이지로 이동
    if (errorParam === 'alreadyLoggedIn') {
      router.push('/login?error=중복 로그인이 되어서 문제가 발생하였습니다.\n다시 재로그인 부탁드립니다')
    } else {
      router.push(`/login?error=[소셜 로그인 실패]\n${errorParam}`)
    }
    return // 아래 로직은 더 이상 진행 X
  }

  // (1) 소셜 로그인 성공 후, 서버에서 JWT 쿠키가 이미 발급되었을 것
  // (2) /me 호출하여 사용자 정보 가져오기
  const response = await LoginApi.getMe();

  authStore.login({
    userId: response.data.userId,
    username: response.data.username,
    userEmail: response.data.userEmail,
    userProfileImgUrl: response.data.userProfileImgUrl,
    roles: response.data.roles,
  });
  
  // (3) 메인 페이지로 이동
  router.push('/');
});
</script>

<style scoped>
</style>
