<template>
  <!-- 좌측 이미지 + 우측 로그인 레이아웃 -->
  <div class="login-layout">
    <!-- 왼쪽 : 이미지 영역 -->
    <div class="left-section">
      <v-img src="/img/common/login/003.png" alt="login image" cover class="side-image" />
    </div>

    <!-- 오른쪽 : 로그인 영역 -->
    <div class="right-section">
      <div class="form-container">
        <h1 class="title-login">LOGIN</h1>

        <!-- 타이틀 -->
        <h2 class="title">Centrally System</h2>

        <div class="system-header">
          <p class="system-subtitle">CENTRALLY SYSTEM은 회사 관련 시스템입니다</p>
        </div>

        <!-- ───── 이메일 ───── -->
        <DefaultLabel text="Account" forId="email" size="small" marginBottom="5px" />
        <v-text-field
          v-model="userEmail"
          density="compact"
          placeholder="이메일 입력"
          prepend-inner-icon="mdi-email-outline"
          variant="outlined"
          rounded="10"
          class="email"
          hide-details
        />

        <!-- ───── 패스워드 ───── -->
        <DefaultFormRow align="between" marginBottom="5px">
          <DefaultLabel text="Password" size="small" forId="Password" />
          <a
            class="text-caption text-decoration-none text-blue"
            href="#"
            rel="noopener noreferrer"
            target="_blank"
          >
            Forgot login password?
          </a>
        </DefaultFormRow>
        <v-text-field
          v-model="password"
          :append-inner-icon="visible ? 'mdi-eye-off' : 'mdi-eye'"
          :type="visible ? 'text' : 'password'"
          density="compact"
          placeholder="패스워드 입력"
          prepend-inner-icon="mdi-lock-outline"
          variant="outlined"
          rounded="10"
          @click:append-inner="visible = !visible"
          @keyup.enter="login"
        />

        <!-- 주의 문구 -->
        <DefaultLabel
          alignment="left"
          text="해당 서비스는 로그인부터 IP 정보가 기록되니 원치 않으신 분들은 이용하지 말아 주시길 바랍니다"
          size="small"
          marginTop="10px"
          marginBottom="30px"
        />

        <!-- ───── 액션 버튼 ───── -->
        <button class="action-btn login-btn" @click="login">로그인</button>
        <button class="action-btn join-btn" @click="join">회원가입</button>

        <!-- ───── 소셜 로그인(원형) ───── -->
        <div class="social-row">
          <button class="social-circle google-circle" @click="oauth('google')">
            <img class="social-icon-circle" src="/img/logo/google/google_icon.svg" alt="Google" />
          </button>
          <button class="social-circle kakao-circle" @click="oauth('kakao')">
            <img class="social-icon-circle" src="/img/logo/kakao/kakao_icon.svg" alt="Kakao" />
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- 알림 모달 -->
  <AlertModal
    :isVisible="confirmationDepartmentModalVisible"
    :disableBackgroundClose="true"
    confirmText="확인"
    @confirm="confirmationDepartmentModalVisible = false"
  >
    <template #body>
      <p style="color: red">※ 소셜 로그인 ※</p>
      <p style="color: red">
        소셜 인증이 완료되었습니다.<br />
        현재 소셜 계정과 연동된 계정이 없습니다.<br />
        소셜과 연동을 완료하기 위해 로그인을 부탁드립니다<br />
        (만료 시간 5분)
      </p>
    </template>
  </AlertModal>
</template>

<script setup>
/* ───────── 기존 스크립트 그대로 ───────── */
import { ref, onBeforeMount } from "vue";
import { useRouter, useRoute } from "vue-router";
import LoginApi from "@/api/auth/LoginApi";
import { useAuthStore } from "@/store/auth";
import { toast } from "vue3-toastify";
import AlertModal from "@/components/common/modal/AlertModal.vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";

const visible = ref(false);
const confirmationDepartmentModalVisible = ref(false);
const router = useRouter();
const route = useRoute();
const userEmail = ref("");
const password = ref("");
const authStore = useAuthStore();

const fetchUserInfo = async () => {
  const res = await LoginApi.getMe();
  authStore.login({
    userId: res.data.userId,
    username: res.data.username,
    userEmail: res.data.userEmail,
    roles: res.data.roles,
  });
  router.push("/");
};

const login = async () => {
  if (!userEmail.value || !password.value) {
    toast.error("아이디와 비밀번호를 입력해주세요");
    return;
  }
  const enc = route.query.encrypt ? encodeURIComponent(route.query.encrypt) : undefined;
  await LoginApi.login(userEmail.value, password.value, enc);
  await fetchUserInfo();
};

const oauth = (social) => {
  const base = import.meta.env.VITE_SYSTEM_API_BASE_URL.replace(/\/$/, "");
  if (social === "google") window.location.href = `${base}/auth/oauth2/authorization/google`;
  else if (social === "kakao") window.location.href = `${base}/auth/oauth2/authorization/kakao`;
  else toast.error("알 수 없는 소셜 로그인 방식입니다.");
};

const join = () => router.push("/join");

onBeforeMount(async () => {
  if (authStore.isAuthenticated) router.push("/");
  if (route.query?.encrypt) {
    confirmationDepartmentModalVisible.value = true;
    return;
  }
  if (route.query?.error) {
    toast.error(route.query.error);
    await LoginApi.logout();
    await new Promise((r) => setTimeout(r, 1500));
    router.push("/login");
    return;
  }
  if (route.query?.logout) toast.success("로그아웃 성공");
});
</script>

<style scoped>
/* ───────────────── 레이아웃 ───────────────── */
.login-layout {
  display: flex;
  min-height: 100vh;
}

.left-section {
  flex: 5;
}

.side-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.right-section {
  flex: 2;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background: #fff;
}

.form-container {
  width: 100%;
  max-width: 420px;
  transform: scale(0.83);
  transform-origin: center;
}

.title {
  text-align: left;
  font-size: 1.5rem;
  font-weight: 800;
  margin-bottom: 10px;
}

.title-login {
  text-align: left;
  font-weight: 900;
  margin-bottom: 40px;
}

/* ───────── 기본 버튼 스타일 ───────── */
.action-btn {
  width: 100%;
  height: 42px;
  margin-bottom: 10px;
  border: none;
  border-radius: 4px;
  font-size: 0.8rem;
  cursor: pointer;
  font-weight: 100;
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-btn,
.join-btn {
  font-size: 0.875rem;
  background: #f8f8f8;
  border: 1px solid #dadce0;
  color: #555;
}

.login-btn:hover,
.join-btn:hover {
  /* background: #f7f7f7; */
  background: #ececec;
}

.join-btn {
  /* background: #a6c2ff; */
  margin-bottom: 30px;
}

/* ───────── 원형 소셜 버튼 ───────── */
.social-row {
  display: flex;
  gap: 20px;
  justify-content: right;
  margin-top: 10px;
}

.social-circle {
  width: 58px;
  height: 58px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  cursor: pointer;
}

.google-circle {
  background: #fff;
  border: 1px solid #dadce0;
}

.kakao-circle {
  background: #fee500;
}

.social-icon-circle {
  width: 30px;
  height: 30px;
}

/* ───────── 기타 텍스트 및 요소 ───────── */
.system-header {
  text-align: left;
  margin-bottom: 30px;
}

.system-subtitle {
  font-size: 0.9rem;
  color: #6c757d;
}

.email {
  margin-bottom: 20px;
}

.text-caption {
  font-size: 0.7rem !important;
}

::v-deep .v-field__input {
  font-size: 0.95rem;
  display: block !important;
  gap: 0 !important;
  padding: 10px 10px 10px 25px !important;
}

/* ─── 모바일(≤768px) : 이미지 숨김 + 중앙 정렬 ─── */
@media (max-width: 768px) {
  .left-section {
    display: none !important;
  }

  .login-layout {
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .action-btn {
    height: 38px;
    font-size: 0.7rem;
  }

  .login-btn,
  .join-btn {
    font-size: 0.7rem;
    background: #f8f8f8;
    border: 1px solid #dadce0;
    color: #555;
  }

  .social-row {
    gap: 20px;
  }

  .right-section {
    width: 100%;
    padding: 1.5rem 2rem;
  }

  .form-container {
    transform: scale(0.875);
  }

  /* .social-circle {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    cursor: pointer;
    border: 1px solid #dadce0;
  }

  .social-icon-circle {
    width: 20px;
    height: 20px;
  } */

  .title {
    font-size: 1.3rem;
  }

  .system-header {
    margin-bottom: 25px;
  }

  .system-subtitle {
    font-size: 0.75rem;
  }

  ::v-deep .v-field__input {
    font-size: 0.8rem;
    display: block !important;
    gap: 0 !important;
    padding: 8px 8px 8px 20px !important;
  }
}
</style>
