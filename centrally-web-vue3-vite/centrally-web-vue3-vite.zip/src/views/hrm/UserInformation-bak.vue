<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">사용자 정보</h2>
      <p class="content-sub-title">사용자 정보 상세 페이지</p>

      <div v-if="!mobile">

        <form @submit.prevent="handleSubmit" class="form-content">
          <!-- 이름과 핸드폰 번호를 한 줄에 표시 -->
          <div class="form-group-name-phone d-flex justify-content-between">
            <div class="w-50 pr-2">
              <DefaultLabel text="이름" forId="userName" alignment="left" size="small"/>
              <DefaultTextfield
                type="text"
                id="userName"
                v-model="userName"
                size="full"
                :disabled="true"
              />
            </div>
            <div class="w-50 pl-2">
              <DefaultLabel text="핸드폰 번호" forId="phone" alignment="left" size="small"/>
              <DefaultTextfield
                type="text"
                id="phone"
                v-model="phone"
                validationType="number"
                placeholder="'-' 없이 입력하세요"
                size="full"
              />
            </div>
          </div>

          <hr v-if="socialLogins.length > 0" />

          <!-- 소셜 로그인 정보 반복 렌더링 -->
          <div v-if="socialLogins.length > 0">
            <DefaultFormRow 
              v-for="(social, index) in socialLogins" 
              :key="index"
              margin-bottom="10px"
              size="small"
            >
              <div class="social-label">
                <DefaultLabel 
                  :text="`소셜 (${social.socialName})`" 
                  :forId="`social-${index}`" 
                  alignment="left" 
                  marginBottom="0px"
                  size="small"
                />
              </div>
              <!-- 소셜 이메일 표시 -->
              <DefaultTextfield
                type="text"
                :id="`social-${index}`"
                v-model="socialLogins[index].socialEmail"
                size="full"
                style="width: 100%"
                customHeight="33px"
                :disabled="true"
              />
              <!-- 소셜 삭제 버튼 (X) -->
              <DefaultButton
                color="red"
                size="small"
                marginLeft="5px"
                customHeight="33px"
                @click="deleteSocialLogin(index, social)"
              >
                X
              </DefaultButton>
            </DefaultFormRow>
          </div>

          <hr v-if="socialLogins.length > 0" />

          <div class="form-group form-group-password d-flex justify-content-between">
          <div class="w-50 pr-2">
            <DefaultLabel 
              text="새 비밀번호" 
              forId="newPassword" 
              alignment="left" 
              size="small"
            />
            <DefaultTextfield
              type="password"
              id="newPassword"
              v-model="newPassword"
              size="full"
              placeholder="비밀번호를 변경하려면 입력"
            />
          </div>

          <div class="w-50 pl-2">
              <DefaultLabel 
                text="비밀번호 확인" 
                forId="confirmPassword" 
                alignment="left" 
                size="small"
              />
              <DefaultTextfield
                type="password"
                id="confirmPassword"
                v-model="confirmPassword"
                size="full"
                placeholder="비밀번호 재입력"
              />
              <!-- 비밀번호 불일치 경고 메시지 -->
              <div v-if="passwordMismatch" class="text-danger" style="font-size: 0.8rem;">
                비밀번호가 일치하지 않습니다.
              </div>
            </div>
          </div>

          <!-- 생년월일과 입사일을 한 줄에 표시 -->
          <div class="form-group d-flex justify-content-between">
            <div class="w-50 pr-2">
              <DefaultLabel text="생년-월-일" forId="dob" alignment="left" size="small"/>
              <DefaultTextfield
                type="date"
                id="dob"
                v-model="dob"
                size="full"
              />
            </div>
            <div class="w-50 pl-2">
              <DefaultLabel text="입사일" forId="joinDate" alignment="left" size="small"/>
              <DefaultTextfield
                type="date"
                id="joinDate"
                v-model="joinDate"
                size="full"
              />
            </div>
          </div>

          <!-- 부서, 팀, 직급을 한 줄에 표시 -->
          <div class="form-group d-flex justify-content-between">
            <div class="w-33 pr-2">
              <DefaultLabel text="부서" forId="department" alignment="left" size="small"/>
              <DefaultTextfield
                type="text"
                id="department"
                v-model="department"
                size="full"
                :disabled="true"
              />
            </div>
            <div class="w-33 px-2">
              <DefaultLabel text="팀" forId="team" alignment="left" size="small"/>
              <DefaultTextfield
                type="text"
                id="team"
                v-model="team"
                size="full"
                :disabled="true"
              />
            </div>
            <div class="w-33 pl-2">
              <DefaultLabel text="직급" forId="position" alignment="left" size="small"/>
              <DefaultTextfield
                type="text"
                id="position"
                v-model="position"
                size="full"
                :disabled="true"
              />
            </div>
          </div>

          <!-- 우편번호와 주소 -->
          <div class="form-group">
            <DefaultLabel text="우편번호" forId="zonecode" alignment="left" size="small"/>
            <div class="input-group">
              <DefaultTextfield
                type="text"
                id="zonecode"
                size="small"
                v-model="zonecode"
                placeholder="우편번호"
                :disabled="true"
              />
              <div class="input-group-append">
                <DefaultButton
                  @click="openModal"
                >
                  주소 검색
                </DefaultButton>
              </div>
            </div>
          </div>
          <div class="form-group">
            <DefaultLabel text="주소" forId="address" alignment="left" size="small"/>
            <DefaultTextfield
              type="text"
              id="address"
              v-model="address"
              size="full"
              placeholder="주소를 검색하세요"
              :disabled="true"
            />
          </div>

          <!-- 상세주소 입력 -->
          <div class="form-group">
            <DefaultLabel text="상세 주소" forId="detailAddress" alignment="left" size="small"/>
            <DefaultTextfield
              type="text"
              id="detailAddress"
              v-model="detailAddress"
              size="full"
              placeholder="상세 주소를 입력하세요"
            />
          </div>

          <!-- 저장 버튼 -->
          <DefaultButton 
            type="submit"
            align="right"
            @click="saveUser">
            저장
          </DefaultButton>
        </form>
      </div>



      <!-- 모바일 화면일 때 -->
      <div v-else>
        <form @submit.prevent="handleSubmit" class="form-content">

          <div class="card-layout">
            <div class="card">
              <div class="card-header">
                <p class="card-title">기본 정보</p>
              </div>
              <div class="card-body">
                <p class="card-text">
                  <i class="ri-user-line mobile-icon"></i>
                  {{position}} &nbsp; {{userName}}
                </p>
                <p class="card-text">
                  <i class="ri-building-line mobile-icon"></i>
                  {{department}} &nbsp; > &nbsp; {{team}}
                </p>
                <!-- 생년월일 -->
                <p class="card-text">
                  <i class="ri-calendar-2-line mobile-icon"></i>
                  생년월일&nbsp;&nbsp;:&nbsp;&nbsp;
                  <span v-if="!editingDob">{{ dob || '미등록' }}</span>
                  <input v-else type="date" v-model="dob"
                        @change="onDobChange" class="date-input" />
                  <button type="button" class="edit-btn"
                          @click="editingDob = !editingDob; editingJoin = false">✏️</button>
                </p>

                <!-- 입사일 -->
                <p class="card-text">
                  <i class="ri-run-line mobile-icon"></i>
                  입사일&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;
                  <span v-if="!editingJoin">{{ joinDate || '미등록' }}</span>
                  <input v-else type="date" v-model="joinDate"
                        @change="onJoinDateChange" class="date-input" />
                  <button type="button" class="edit-btn"
                          @click="editingJoin = !editingJoin; editingDob = false">✏️</button>
                </p>
              </div>
            </div>
          </div>

          <!-- 소셜 로그인 정보 반복 렌더링 -->
          <div v-if="socialLogins.length > 0">
            <hr />
            <DefaultFormRow 
              v-for="(social, index) in socialLogins" 
              :key="index"
              margin-bottom="10px"
              size="small"
            >
              <div class="social-label">
                <DefaultLabel 
                  :text="`소셜 (${social.socialName})`" 
                  :forId="`social-${index}`" 
                  alignment="left" 
                  marginBottom="0px"
                  size="small"
                />
              </div>
              <!-- 소셜 이메일 표시 -->
              <DefaultTextfield
                type="text"
                :id="`social-${index}`"
                v-model="socialLogins[index].socialEmail"
                size="full"
                style="width: 100%"
                customHeight="33px"
                :disabled="true"
              />
              <!-- 소셜 삭제 버튼 (X) -->
              <DefaultButton
                color="red"
                size="small"
                marginLeft="5px"
                customHeight="33px"
                @click="deleteSocialLogin(index, social)"
              >
                X
              </DefaultButton>
            </DefaultFormRow>
          </div>

          <hr />

          <DefaultLabel text="핸드폰 번호" forId="phone" alignment="left" size="small"/>
          <DefaultTextfield
            type="text"
            id="phone"
            v-model="phone"
            validationType="number"
            placeholder="'-' 없이 입력하세요"
            size="full"
            marginBottom="15px"
          />

          <hr />

          <DefaultLabel 
            text="새 비밀번호" 
            forId="newPassword" 
            alignment="left" 
            size="small"
          />
          <DefaultTextfield
            type="password"
            id="newPassword"
            v-model="newPassword"
            size="full"
            placeholder="비밀번호를 변경하려면 입력"
            marginBottom="10px"
          />

          <DefaultLabel 
            text="비밀번호 확인" 
            forId="confirmPassword" 
            alignment="left" 
            size="small"
          />
          <DefaultTextfield
            type="password"
            id="confirmPassword"
            v-model="confirmPassword"
            size="full"
            placeholder="비밀번호 재입력"
            marginBottom="15px"
          />

          <hr />
          
          <!-- 우편번호와 주소 -->
          <div class="form-group">
            <DefaultLabel text="우편번호" forId="zonecode" alignment="left" size="small"/>
            <div class="input-group">
              <DefaultTextfield
                type="text"
                id="zonecode"
                size="small"
                v-model="zonecode"
                placeholder="우편번호"
                :disabled="true"
              />
              <div class="input-group-append">
                <DefaultButton
                  @click="openModal"
                >
                  주소 검색
                </DefaultButton>
              </div>
            </div>
          </div>
          <div class="form-group">
            <DefaultLabel text="주소" forId="address" alignment="left" size="small"/>
            <DefaultTextfield
              type="text"
              id="address"
              v-model="address"
              size="full"
              placeholder="주소를 검색하세요"
              :disabled="true"
            />
          </div>

          <!-- 상세주소 입력 -->
          <div class="form-group">
            <DefaultLabel text="상세 주소" forId="detailAddress" alignment="left" size="small"/>
            <DefaultTextfield
              type="text"
              id="detailAddress"
              v-model="detailAddress"
              size="full"
              placeholder="상세 주소를 입력하세요"
            />
          </div>

          <hr />

          <!-- 저장 버튼 -->
          <DefaultButton 
            type="submit"
            align="right"
            @click="saveUser"
            marginTop="20px"
          >
            저장
          </DefaultButton>
        </form>
      </div>

    </div>

    <!-- 카카오 주소 모달 -->
    <KakaoAddressModal
      :visible="isModalOpen"
      @close="closeModal"
      @selectAddress="handleSelectAddress"
    />
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import KakaoAddressModal from '@/components/common/kakao/address/KakaoAddressModal.vue';

import { toast } from 'vue3-toastify';
import { useAuthStore } from '@/store/auth'

// API
import AuthUserApi from '@/api/auth/UsersApi';
import HrmUserApi from '@/api/hrm/UsersApi';

// Vuex/Pinia
const authStore = useAuthStore();

// ===== 상태 정의 =====
const userId = ref(null);
const userName = ref('');
const department = ref('');
const team = ref('');
const position = ref('');
const phone = ref('');
const dob = ref('');
const joinDate = ref('');
const socialLogins = ref([]);
const editingDob      = ref(false);   // ← 달력 열림 여부
const editingJoin     = ref(false);

const originalUserData = ref({});

/* 달력 닫기 헬퍼 */
function closePickers() {
  editingDob.value   = false;
  editingJoin.value  = false;
}
function onDobChange() {
  closePickers();
  saveUser();           // 날짜 고르자마자 PATCH
}
function onJoinDateChange() {
  closePickers();
  saveUser();
}

/* ---------- 650px 이하 여부 ---------- */
const mq = window.matchMedia("(max-width:650px)");
const mobile = ref(mq.matches);
mq.addEventListener("change", (e) => (mobile.value = e.matches));

// 주소 관련
const zonecode = ref('');
const address = ref('');
const detailAddress = ref('');
const isModalOpen = ref(false);


// 비밀번호 변경용 변수
const newPassword = ref('');       // 새 비번 입력
const confirmPassword = ref('');   // 새 비번 확인

// “비번 불일치” 여부 계산
const passwordMismatch = computed(() => {
  // 둘 중 하나만 입력했거나, 둘 다 입력했으나 값이 다르면 true
  return newPassword.value !== '' 
    && confirmPassword.value !== '' 
    && newPassword.value !== confirmPassword.value;
});

// 모달 열기/닫기
function openModal() {
  isModalOpen.value = true;
}
function closeModal() {
  isModalOpen.value = false;
}
function handleSelectAddress(payload) {
  address.value = payload.address;
  zonecode.value = payload.zipCode;
}

// 폼 제출
const handleSubmit = () => {
  console.log('Form submitted');
};

// 소셜 로그인 삭제
async function deleteSocialLogin(index, socialItem) {
  if (userId.value && socialItem.socialName) {
    await AuthUserApi.deleteUserSocial(userId.value, socialItem.socialName);
    toast.success(`소셜(${socialItem.socialName}) 삭제 완료`);
  }
  fetchMetadata();
}

// 사용자 정보 저장
function saveUser() {
  // 숫자만 입력되는지 확인
  const numberRegex = /^[0-9]+$/;
  if (phone.value && !numberRegex.test(phone.value)) {
    toast.error("핸드폰 번호는 숫자만 입력해 주세요.");
    return;
  }
  if (zonecode.value && !numberRegex.test(zonecode.value)) {
    toast.error("우편번호는 숫자만 입력해 주세요.");
    return;
  }
  // 비밀번호 불일치 체크
  let typedPassword = (newPassword.value || confirmPassword.value); 
  if (typedPassword) {
    // 하나만 입력
    if (!newPassword.value || !confirmPassword.value) {
      toast.error("'새 비밀번호'와 '비밀번호 확인'을 둘 다 입력해주세요.");
      return;
    }
    // 값이 다르면
    if (newPassword.value !== confirmPassword.value) {
      toast.error("비밀번호가 일치하지 않습니다.");
      return;
    }
  }

  // 변경된 필드만 모아서 업데이트
  const updates = {};

  if (phone.value !== originalUserData.value.phone) {
    updates.phoneNumber = phone.value;
  }
  if (dob.value !== originalUserData.value.dob) {
    updates.birth = dob.value;
  }
  if (joinDate.value !== originalUserData.value.joinDate) {
    updates.joiningDate = joinDate.value;
  }
  if (detailAddress.value !== originalUserData.value.detailAddress) {
    updates.addressDetail = detailAddress.value;
  }
  if (address.value !== originalUserData.value.address) {
    updates.address = address.value;
  }
  if (zonecode.value !== originalUserData.value.zonecode) {
    updates.zipCode = zonecode.value;
  }

  // “새 비밀번호”가 입력된 경우만 업데이트 (빈 값이면 변경 없음)
  if (newPassword.value) {
    updates.password = newPassword.value;
  }

  if (Object.keys(updates).length > 0) {
    HrmUserApi.patchUser(userId.value, updates)
      .then(() => {
        toast.success("저장되었습니다.");
        // 원본 데이터 업데이트
        originalUserData.value = {
          ...originalUserData.value,
          dob: dob.value,
          phone: phone.value,
          joinDate: joinDate.value,
          detailAddress: detailAddress.value,
          address: address.value,
          zonecode: zonecode.value
        };
        fetchMetadata();
      });
  } else {
    toast.info("변경된 데이터가 없습니다.");
  }
}

// ========== 데이터 로딩 ==========
// 1) HrmUserApi.getUserById(userId) → 유저 기본정보 + team + department + position
// 2) AuthUserApi.getUserSocialByEmail(userEmail) → 소셜 로그인 목록
const fetchMetadata = async () => {
  try {
    // (1) HRM 유저 정보
    const hrmRes = await HrmUserApi.getUserById(authStore.getUserId);
    if (hrmRes && hrmRes.data) {
      const user = hrmRes.data;
      // user에 team, position이 이미 들어 있음

      userId.value = user.userId;
      userName.value = `${user.name} (${user.email})`;
      // newPassword.value = user.password;
      // confirmPassword.value = user.password;
      phone.value = user.phoneNumber || '';
      dob.value = user.birth || '';
      joinDate.value = user.joiningDate || '';

      // 부서/팀/직급 값이 없으면 "미지정"으로 설정
      department.value = user.team?.department?.departmentName || '미지정';
      team.value = user.team?.teamName || '미지정';
      position.value = user.position?.positionName || '미지정';

      zonecode.value = user.zipCode ? String(user.zipCode) : '';
      address.value = user.address || '';
      detailAddress.value = user.addressDetail || '';

      // 원본 데이터 저장
      originalUserData.value = {
        newPassword:newPassword.value,
        confirmPassword: confirmPassword.value,
        phone: phone.value,
        joinDate: joinDate.value,
        dob: dob.value,
        zonecode: zonecode.value,
        address: address.value,
        detailAddress: detailAddress.value,
        department: department.value,
        team: team.value,
        position: position.value,
        userName: userName.value
      };
    }

    // (2) 소셜 로그인 정보
    const socialRes = await AuthUserApi.getUserSocialByEmail(authStore.getUserEmail);
    if (socialRes && socialRes.data) {
      socialLogins.value = socialRes.data.socialLogins || [];
    }
  } catch (error) {
    console.error("사용자 정보 로딩 실패", error);
    toast.error("사용자 정보를 가져오는 데 실패했습니다.");
  }
};

onMounted(() => {
  fetchMetadata();
});
</script>

<style scoped>
hr {
  margin: 10px 0 10px 0;
}

.content {
  width:100%;
  max-width:1000px;
  margin:0 auto;
  padding: 130px 100px 80px 100px;
  box-sizing:border-box;
}

.social-label {
  width: 150px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

label {
  margin-bottom: 10px;
}

.content-sub-title {
  margin-bottom: 50px;
}

/* 우편번호 인풋 크기 작게 */
#zonecode {
  max-width: 160px;
}

.form-group, .form-group-name-phone {
  margin-bottom: 12px;
}

.w-50 {
  width: 50%;
}
.w-33 {
  width: 33%;
}
.pr-2 {
  padding-right: 10px;
}
.pl-2 {
  padding-left: 10px;
}
.px-2 {
  padding: 0 10px;
}

@media (max-width: 650px) {
  hr {
    margin: 15px 0px 15px 0px !important;
  }
  .form-group {
    margin-bottom: 5px !important;
  }
  .form-group-name-phone {
    margin-bottom: 10px !important;
  }
  .form-group-password {
    margin-top: 25px;
  }
  label {
    font-size: 0.8rem !important;
  }
  .content {
    width: 100%;
  }
  .mobile-icon {
    font-size: 1rem;
    margin-right: 5px;
    /* color: #999; */
  }
  /* .card-header {
    background-color: #004497;
    color: #ffffff;
  } */
  .card-title {
    font-weight: 700 !important;
  }
  .edit-btn {
    border:none;
    background:transparent;
    font-size:0.8rem;
    margin-left:6px;
    cursor:pointer;
  }
  .date-input {
    font-size:0.675rem;
    padding: 4px 4px;
    width: 100px;
  }
}
</style>
