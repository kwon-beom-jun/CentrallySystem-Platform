<template>
  <div>
    <!-- Main Content Area -->
    <div class="content content-wrapper">
      <h2 class="content-title">실적 현황</h2>
      <p class="content-sub-title">개인 실적 현황 페이지</p>

      <!-- Table View (Visible on larger screens) -->
      <table class="table mt-3" id="dataTable" v-if="!isMobile">
        <thead>
          <tr>
            <th>실적</th>
            <th>시작일</th>
            <th>종료일</th>
            <th>내용</th>
            <th>성과</th>
            <th>상태</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in paginatedData" :key="item.date">
            <td>{{ item.performanceName }}</td>
            <td>{{ item.beforeDate }}</td>
            <td>{{ item.afterDate }}</td>
            <td>{{ item.content }}</td>
            <td>{{ item.performance }}</td>
            <td :class="getStatusClass(item.status)">{{ item.status }}</td>
          </tr>
        </tbody>
      </table>

      <!-- Card Layout View (Visible on smaller screens) -->
      <div class="card-layout" v-if="isMobile">
        <div class="card" v-for="item in paginatedData" :key="item.date">
          <div class="card-header">
            <p class="card-title">{{ item.performanceName }}</p>
          </div>
          <div class="card-body">
            <p class="card-text"><strong>시작일 : </strong> {{ item.beforeDate }} ~ <strong> 종료일 : </strong>{{
        item.afterDate }}</p>
            <p class="card-text"><strong>내용:</strong> {{ item.content }}</p>
            <p class="card-text"><strong>성과:</strong> {{ item.performance }}</p>
            <p class="card-text">
              <strong>상태:</strong> <span :class="getStatusClass(item.status)">{{ item.status }}</span>
            </p>
          </div>
        </div>
      </div>

      <!-- Pagination Buttons -->
      <nav>
        <ul class="pagination justify-content-center" id="pagination">
          <li class="page-item" :class="{ active: page === currentPage }" v-for="page in totalPages" :key="page">
            <a class="page-link" href="#" @click.prevent="goToPage(page)">{{ page }}</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';

const data = ref([
  { beforeDate: '2024-10-03', afterDate: '2024-11-01', performanceName: 'CENTRALLY 포탈 개발', content: '분기 보고서 작성', performance: '대기 중', status: '대기 중' },
  { beforeDate: '2024-08-01', afterDate: '2024-09-01', performanceName: '○○카드 프로젝트', content: '프로젝트 A 진행', performance: '완료', status: '완료' },
  { beforeDate: '2024-09-02', afterDate: '2024-10-01', performanceName: '○○은행 프로젝트 계약', content: '팀 미팅', performance: '진행 중', status: '진행 중' },
  // Additional data...
]);

const currentPage = ref(1);
const itemsPerPage = ref(5);
const isMobile = ref(window.innerWidth <= 650);

const totalPages = computed(() => Math.ceil(data.value.length / itemsPerPage.value));

const paginatedData = computed(() => {
  const startIndex = (currentPage.value - 1) * itemsPerPage.value;
  return data.value.slice(startIndex, startIndex + itemsPerPage.value);
});

const goToPage = (page) => {
  currentPage.value = page;
};

const updateIsMobile = () => {
  isMobile.value = window.innerWidth <= 650;
};

const getStatusClass = (status) => {
  if (status === '진행 중') return 'text-primary'; // Blue
  if (status === '완료') return 'text-success'; // Green
  if (status === '대기 중') return 'text-warning'; // Orange
  return '';
};

onMounted(() => {
  window.addEventListener('resize', updateIsMobile);
});
</script>

<style scoped>
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}

.text-muted {
  margin-bottom: 10px;
}
</style>
