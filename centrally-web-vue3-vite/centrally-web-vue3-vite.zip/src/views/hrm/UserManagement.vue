<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">사용자 관리</h2>
      <p class="content-sub-title">
        사용자의 정보를 관리하는 페이지<br />
        ( 사용자 데이터 갱신은 새로고침을 해야합니다 )
      </p>

      <div class="search-controls">
        <!-- 부서, 팀 선택 그룹 -->
        <div class="d-flex align-items-center department-group">
          <DefaultLabel text="부서 :" forId="department" size="small" />
          <DefaultSelect
            id="department"
            v-model="selectedDepartment"
            :options="deptFilterOptions"
            placeholder="부서 선택"
            size="small"
            marginRight="10px"
          />
          <DefaultLabel text="팀 :" forId="team" size="small" />
          <DefaultSelect
            id="team"
            v-model="selectedTeam"
            :options="teamsOptions"
            placeholder="팀 선택"
            size="small"
            :disabled="isTeamDisabled"
          />
        </div>
        <!-- 이름 검색 그룹 -->
        <div class="d-flex align-items-center name-group">
          <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
          <DefaultTextfield
            type="text"
            id="nameSearch"
            v-model="nameSearch"
            placeholder="이름(이메일)"
          />
        </div>
      </div>

      <!-- 테이블 보기 -->
      <DefaultTable
        :columns="columns"
        :data="filteredData"
        :rowClick="(item) => showModal(item)"
        :fixedHeader="true"
      />

      <!-- 사용자 세부 정보 모달 -->
      <UserManagementModifyModal
        :visible="modalVisible"
        :isAdmin="isAdmin"
        :user="selectedUser"
        :departmentsOptions="deptModalOptions"
        :teamsOptions="teamsOptions"
        :positionsOptions="positionsOptions"
        :departmentsData="departments"
        @close="modalVisible = false"
        @confirmSave="handleSaveClick"
        @confirmDelete="handleDeleteClick"
      />

      <!-- 저장 확인 모달 -->
      <AlertModal
        :isVisible="confirmationModalVisible"
        :disableBackgroundClose="true"
        title="저장 확인"
        cancelText="취소"
        confirmText="확인"
        @close="confirmationModalVisible = false"
        @confirm="saveUserDetails"
      >
        <template #body>
          <p>변경 사항을 저장하시겠습니까?</p>
          <p v-if="statusChanged" style="color: red;">입사/퇴사 처리가 포함되어 있습니다.</p>
        </template>
      </AlertModal>

      <!-- “삭제 확인” 전용 모달 -->
      <AlertModal
        :isVisible="deleteConfirmVisible"
        :disableBackgroundClose="true"
        title="삭제 확인"
        cancelText="취소"
        confirmText="삭제"
        @close="deleteConfirmVisible = false"
        @confirm="deleteUserConfirmed"
      >
        <template #body>
          <p style="color:red;">정말로 삭제하시겠습니까? 복구할 수 없습니다.</p>
        </template>
      </AlertModal>

      <!-- 변경된 데이터가 없을 때 모달 -->
      <AlertModal
        :isVisible="noChangesModalVisible"
        title="알림"
        confirmText="확인"
        @close="closeNoChangesModal"
        @confirm="closeNoChangesModal"
      >
        <template #body>
          <p>변경된 데이터가 없습니다.</p>
        </template>
      </AlertModal>

      <!-- 저장 완료 모달 -->
      <AlertModal
        :isVisible="saveCompleteModalVisible"
        :title="saveCompleteMessageTitle"
        confirmText="확인"
        @close="closeSaveCompleteModal"
        @confirm="closeSaveCompleteModal"
      >
        <template #body>
          <p>{{ saveCompleteMessage }}</p>
        </template>
      </AlertModal>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';

import HrmUserApi from '@/api/hrm/UsersApi';
import AuthUserApi from '@/api/auth/UsersApi';
import MetadataApi from '@/api/hrm/UserManagementMetadataApi';

import AlertModal from '@/components/common/modal/AlertModal.vue';
import UserManagementModifyModal from '@/components/hrm/UserManagementModifyModal.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultSelect from '@/components/common/select/DefaultSelect.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";

// 관리자 여부
const isAdmin = ref(true);

// 모달 관련 상태
const modalVisible = ref(false);
const confirmationModalVisible = ref(false);
const saveCompleteModalVisible = ref(false);
const noChangesModalVisible = ref(false);
const saveCompleteMessageTitle = ref('저장 완료');
const saveCompleteMessage = ref('저장되었습니다.');
const deleteConfirmVisible = ref(false);   // 삭제 확인 모달
const deletingUserId        = ref(null);   // 삭제 대상 ID

// 테이블 컬럼 설정
const columns = [
  { key: 'name',          label: '이름',         width: 50 },
  { key: 'email',         label: '이메일',       width: 120 },
  { key: 'department',    label: '부서',         width: 70 },
  { key: 'team',          label: '팀',           width: 70 },
  { key: 'positionName',  label: '직급',         width: 60 },
  { key: 'employmentType',label: '고용 형태',     width: 50 },
  { key: 'status',        label: '상태',         width: 30,   align: 'center' },
];

// 사용자 관련 상태
const selectedUser = ref({});
const originalUser = ref({});
const statusChanged = ref(false);

// 부서, 팀 선택 상태 (선택된 값은 각각의 id, 숫자 타입)
const selectedDepartment = ref('');
const selectedTeam = ref('');

// 부서 데이터 (MetadataApi에서 가져옴, 각 부서에 teams 배열 포함)
const departments = ref([]);
// 고용 타입
const employmentTypes = ref([]);
// 직급 데이터
const positions = ref([]);
// 사용자 데이터 (HrmUserApi)
const data = ref([]);
// 이름 검색어
const nameSearch = ref('');
// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

/** (A) 부모-화면 드롭다운용 – “전체” 포함 */
const deptFilterOptions = computed(() => [
  { value: '',  label: '전체보기'   },   // 리스트 필터 전용
  { value: 0,   label: '미지정' },
  ...departments.value.map(d => ({
    value: d.departmentId,
    label: d.departmentName
  }))
]);

/** (B) 자식 모달용 – “전체” 제외  */
const deptModalOptions = computed(() => [
  { value: 0, label: '미지정' },
  ...departments.value.map(d => ({
    value: d.departmentId,
    label: d.departmentName
  }))
]);

const positionsOptions = computed(() => {
  return positions.value.map(pos => ({
    value: pos.positionId,
    label: pos.positionName
  }));
});

// 팀 select 옵션
const teamsOptions = computed(() => {
  if (selectedDepartment.value) {
    const dept = departments.value.find(dep => dep.departmentId === Number(selectedDepartment.value));
    return dept && dept.teams
      ? [
          // { value: '', label: '팀 선택' },
          /* { value: 0, label: '미지정' }, */
          ...dept.teams.map(team => ({
            value: team.teamId,
            label: team.teamName
          }))
        ]
      : [
        // { value: '', label: '팀 선택' }, 
        /* { value: 0, label: '미지정' } */
      ];
  }
  return [
      // { value: '', label: '팀 선택' }, 
      /* { value: 0, label: '미지정' } */
    ];
});

// (팀 선택 → 부서 자동 연동)
watch(selectedTeam, (newTeamId) => {
  if (newTeamId) {
    for (const dep of departments.value) {
      const foundTeam = dep.teams?.find(t => t.teamId === Number(newTeamId));
      if (foundTeam) {
        if (dep.departmentId !== Number(selectedDepartment.value)) {
          selectedDepartment.value = dep.departmentId;
        }
        break;
      }
    }
  }
});

// (부서 선택이 바뀌면 팀 초기화)
watch(selectedDepartment, () => {
  selectedTeam.value = '';
});

// 테이블에 표시할 데이터: 필터
const filteredData = computed(() => {
  return data.value
    .filter(user => {
      let filterPass = true;

      // (A) 부서만 선택
      if (selectedDepartment.value && !selectedTeam.value) {
        const deptVal = Number(selectedDepartment.value);
        filterPass = user.departmentId === deptVal;
      }

      // (B) 팀만 선택
      if (!selectedDepartment.value && selectedTeam.value) {
        if (Number(selectedTeam.value) === 0) {
          filterPass = !user.teamId || user.teamId === 0;
        } else {
          filterPass = user.teamId === Number(selectedTeam.value);
        }
      }

      // (C) 부서+팀 모두 선택
      if (selectedDepartment.value && selectedTeam.value) {
        filterPass = (
          user.departmentId === Number(selectedDepartment.value) &&
          user.teamId === Number(selectedTeam.value)
        );
      }

      // (D) 이름 검색 (이메일 포함)
      const nameMatch = nameSearch.value
        ? (user.name && user.name.includes(nameSearch.value)) ||
          (user.email && user.email.includes(nameSearch.value))
        : true;

      return filterPass && nameMatch;
    })
    .map(user => {
      // 부서, 팀 이름
      let departmentName = '미지정';
      let teamName = '미지정';
      const dept = departments.value.find(dep => dep.departmentId === user.departmentId);
      if (dept) {
        departmentName = dept.departmentName || '미지정';
        const t = dept.teams.find(tt => tt.teamId === user.teamId);
        if (t) {
          teamName = t.teamName || '미지정';
        }
      }
      // 고용형태
      const empType = employmentTypes.value.find(et => et.employmentTypeId === Number(user.employmentTypeId));
      const employmentTypeLabel = empType ? empType.employmentTypeName : '미지정';
      // 직급
      const pos = positions.value.find(p => p.positionId === Number(user.position?.positionId));
      const foundPosition = pos 
        ? { positionId: pos.positionId, positionName: pos.positionName }
        : { positionId: 0, positionName: '미지정' };
      
      return {
        ...user,
        department: departmentName,
        team: teamName,
        // position에 객체 통째로 넣기
        // position: foundPosition,
        positionId: foundPosition.positionId, // 자식 컴포넌트에서 사용
        positionName: foundPosition.positionName,
        employmentType: employmentTypeLabel,
        status: user.leavingDate ? '퇴사' : '입사'
      };
    })
    .sort((a, b) => {
      // 이름 오름차순 정렬 (한글/영어 모두)
      const nameA = a.name || "";
      const nameB = b.name || "";
      return nameA.localeCompare(nameB, 'ko-KR');
    });
});

// 사용자 클릭 시 모달 열기
function showModal(user) {
  selectedUser.value = { ...user };
  originalUser.value = { ...user };
  statusChanged.value = false;
  modalVisible.value = true;
}

// 임시 저장할 patchData
const pendingPatchData = ref(null);

// 모달에서 "저장" 클릭 시
function handleSaveClick({ isMismatch, isChanged, userData, statusChangedFlag }) {
  if (isMismatch) {
    saveCompleteMessageTitle.value = '비밀번호 불일치';
    saveCompleteMessage.value = '비밀번호와 재확인의 값이 일치하지 않습니다.';
    saveCompleteModalVisible.value = true;
    return;
  }
  if (!isChanged) {
    noChangesModalVisible.value = true;
    return;
  }
  // selectedUser.value = { ...userData };
  // statusChanged.value = statusChangedFlag;
  // confirmationModalVisible.value = true;

  // 바뀐 데이터(userData)를 'selectedUser'에 즉시 넣지 않고, 
  // pendingPatchData에만 저장(기존 : 모달 창에 데이터가 날라감)
  pendingPatchData.value = userData;
  statusChanged.value = statusChangedFlag;

  // "저장 확인" 모달 열기
  confirmationModalVisible.value = true;
}

// 실제 저장 API (PUT)
async function saveUserDetails() {
  // 메인 모달 닫기
  modalVisible.value = false;
  // "저장 확인" 모달 닫기
  confirmationModalVisible.value = false;

  console.log(pendingPatchData.value);

  // ✅ HrmUserApi로 수정
  await HrmUserApi.patchUser(pendingPatchData.value.userId, pendingPatchData.value);

  saveCompleteMessageTitle.value = '저장 완료';
  saveCompleteMessage.value = '저장되었습니다.';
  saveCompleteModalVisible.value = true;
  
  await fetchMetadata();
}

// '변경된 데이터가 없습니다' 모달 닫기
function closeNoChangesModal() {
  noChangesModalVisible.value = false;
}

// 저장 완료 모달 닫기
function closeSaveCompleteModal() {
  saveCompleteModalVisible.value = false;
}

/**
 * fetchMetadata:
 *  - (A) 메타데이터(부서/직급/고용형태) → MetadataApi.getMetadatas()
 *  - (B) 사용자 목록(HrmUserApi.getUsers()) 
 *    → team?.department => departmentId/teamId 추출
 */
async function fetchMetadata() {
  const responseMeta = await MetadataApi.getMetadatas();
  const responseUser = await HrmUserApi.getUsers();

  // 🟡 부서/직급/고용형태
  departments.value = responseMeta.data.departments || [];
  positions.value = responseMeta.data.positions || [];
  employmentTypes.value = responseMeta.data.employmentTypes || [];

  // 🟡 사용자 목록
  data.value = (responseUser.data || []).map(u => mapHrmUser(u));
}

/**
 * HRM 사용자 -> 기존 로직에서 사용하던 departmentId/teamId 삽입
 */
function mapHrmUser(u) {
  let deptId = 0;
  let tId = 0;
  if (u.team) {
    tId = u.team.teamId || 0;
    if (u.team.department) {
      deptId = u.team.department.departmentId || 0;
    }
  }
  return {
    ...u,
    departmentId: deptId, // 추가
    teamId: tId           // 추가
  };
}

/** 자식 모달에서 “삭제” 클릭 시 호출 */
function handleDeleteClick(userId) {
  deletingUserId.value    = userId;      // 대상 저장
  deleteConfirmVisible.value = true;     // 확인 모달 오픈
}
/** 삭제 확인 모달에서 ‘삭제’ 버튼 눌렀을 때 */
async function deleteUserConfirmed() {
  deleteConfirmVisible.value = false;
  modalVisible.value         = false;      // 편집 모달도 함께 닫기

  // 🔥 실제 삭제 API 호출 (Soft-Delete)
  await AuthUserApi.deleteUser(deletingUserId.value);

  // 로컬 목록에서 제거
  data.value = data.value.filter(u => u.userId !== deletingUserId.value);

  // 완료 메시지
  saveCompleteMessageTitle.value = '삭제 완료';
  saveCompleteMessage.value      = '사용자가 삭제되었습니다.';
  saveCompleteModalVisible.value = true;
}

// 팀 셀렉트 박스를 비활성화할지 여부
const isTeamDisabled = computed(() => {
  if (selectedDepartment.value === '') return true;
  const dept = departments.value.find(
    d => d.departmentId === Number(selectedDepartment.value)
  );
  return !dept || !dept.teams || dept.teams.length === 0; // 팀이 0개면 true
});

// 컴포넌트 마운트 시 데이터 로드
onMounted(() => {
  fetchMetadata();
  userDirStore.refresh();
});
</script>

<style scoped>
hr {
  margin-bottom: 0px;
}

/* 테이블 스타일 */
.table {
  width: 100%;
  margin: 0;
}

/* 테이블 컨테이너: 스크롤 추가하여 10개 행 정도 보이도록 */
.table-container {
  max-height: 400px;
  overflow-y: auto;
  margin-bottom: 60px;
}

/* 검색 영역 반응형 */
.label-team {
  margin-left: 10px;
}

.search-controls {
  margin-bottom: 10px;
}

@media (min-width: 651px) {
  .search-controls {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
  }
  .search-controls > div {
    margin-right: 1rem;
    margin-bottom: 0;
  }
  #nameSearch {
    font-size: 1rem;
  }
}

@media (max-width: 650px) {
  .search-controls {
    margin-bottom: 0px;
  }
  .name-group {
    margin-bottom: 10px;
  }
  .department-group {
    margin-bottom: 0px;
  }
  .search-controls {
    display: flex;
    flex-direction: column-reverse;
    align-items: flex-end;
  }
  .search-controls > div {
    width: 100%;
    display: flex;
    justify-content: flex-end;
  }
}
</style>
