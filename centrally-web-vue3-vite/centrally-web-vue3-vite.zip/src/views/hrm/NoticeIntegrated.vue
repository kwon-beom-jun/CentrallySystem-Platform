<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">공지 사항</h2>
      <p class="content-sub-title">Notice Management</p>

      <div class="create-notice">
        <!-- "공지등록" 버튼 (isAdmin 일 때만 표시) -->
        <DefaultButton
          v-if="isAdmin"
          align="right"
          @click="showModal()"
        >
          공지등록
        </DefaultButton>
        <DefaultLabel v-else />
      </div>

      <!-- 테이블 보기 -->
      <DefaultTable
        :columns="columns"
        :data="data"
        :mobileCard="true"
        :rowClick="(item) => goToDetail(item)"
      />

      <!-- 페이지네이션 (공통 컴포넌트) -->
      <DefaultPagination
        :currentPage="currentPage"
        :totalPages="totalPages"
        :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange"
      />
    </div>

    <!-- 모달 컴포넌트 -->
    <!-- v-show="isModalVisible" -->
    <NoticeIntegratedCreateModifyModal
      :isVisible="isModalVisible"
      :isAdmin="isAdmin"
      :isCreate="isCreate"
      :form="form"
      @close="isModalVisible = false"
      @save="handleSave"
    />
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import { useHrmStore } from '@/store/hrm'
import NoticeIntegratedCreateModifyModal from '@/components/hrm/NoticeIntegratedCreateModifyModal.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue'
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import NoticeIntegratedApi from '@/api/hrm/NoticeIntegratedApi';
import HrmUserApi from "@/api/hrm/UsersApi";
import { toast } from 'vue3-toastify';

// Vue Router, Pinia 스토어
const router = useRouter();
const hrmStore = useHrmStore();

// =====================
// 관리자 여부
// =====================
const isAdmin = ref(false);

// =====================
// 모바일 상태 확인
// =====================
// **showPage 초기값**을 뷰포트에 따라 결정
const BREAK_POINT = 650
const isMobile = ref(window.innerWidth < BREAK_POINT)
/* 마지막 화면 타입을 기억 */
let prevIsMobile = isMobile.value
// 반응형 핸들러
/* resize 핸들러 */
function handleResize() {
  const nowMobile = window.innerWidth < BREAK_POINT
  /* 경계가 바뀐 경우에만 값 갱신 + 재조회 */
  if (nowMobile !== prevIsMobile) {
    isMobile.value = nowMobile
    showPage.value = nowMobile ? 5 : 10
    fetchDataFromServer(currentPage.value)      // ★ 여기서만 API 호출
    prevIsMobile = nowMobile                    // 상태 기록
  }
}

// =====================
// 모달 표시/숨김 & 등록/수정 구분
// =====================
const isModalVisible = ref(false);
const isCreate = ref(true);

// =====================
// 페이지네이션 상태
// =====================
const currentPage = ref(1);
const showPage  = ref(isMobile.value ? 5 : 10);
const totalPages = ref(1);          // 서버에서 받아온 총 페이지 수
const visiblePageCount = ref(5);    // 페이지네이션에서 보여줄 최대 페이지 버튼 수

// =====================
// 폼 데이터
// =====================
const form = ref({
  id: null,
  title: '',
  author: '',
  date: '',
  content: '',
  cookieConsent: false,
});

// =====================
// 실제 서버에서 받아올 데이터
// =====================
const data = ref([]);

// =====================
// 컬럼 정의
// =====================
const columns = [
  {
    key   : 'id',
    label : '번호',
    width : 40,
    align: 'center',
    mobile: { line   : 1, inline : true, prefix : '📝\u00a0글번호\u00a0:\u00a0', suffix : '', bold : false }
  },
  {
    key   : 'title',
    label : '제목',
    width : 200,
    mobile: { line: 2, inline: false, prefix: '', suffix: '', bold:true }
  },
  {
    key   : 'author',
    label : '작성자',
    width : 60,
    mobile: { 
      line: 1,          // 몇 번째 줄?
      inline: true,     // 같은 줄에 나란히?
      prefix: '', // 앞 붙일 문자
      suffix: '',       // 뒤 붙일 문자
      bold:false, 
      align:'right' }
  },
  {
    key   : 'editor',
    label : '수정자',
    width : 60,
    mobile: { line: 1, inline: true, prefix: '\u00a0[', suffix: ']', bold:false }
  },
  {
    key   : 'date',
    label : '작성일',
    width : 80,
    align: 'center',
    mobile: { line: 3, inline: false, prefix: '', suffix: '', bold:false }
  }
];

/**
 * 페이지 변경 시 호출
 * -> 서버(또는 mock)에서 해당 페이지 데이터, totalPages 등을 받아옴
 */
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

/**
 * 백엔드에서 데이터 가져오는 함수
 */
async function fetchDataFromServer(page = 1) {
  const responseNoices = await NoticeIntegratedApi.getNotices({
      page: page - 1,
      size: showPage.value
  });

  if (!responseNoices.data.content) {
    toast.error('공지 사항이 없습니다');
    return;
  }

  // Notice 데이터에서 authorId, editorId들을 추출하고 중복 제거
  const authorIds = [...new Set(responseNoices.data.content.map(item => item.authorId))];
  const editorIds = [...new Set(responseNoices.data.content.map(item => item.editorId))];

  // 작성자와 수정자 ID를 합쳐서 중복 제거
  const combinedIds = [...new Set([...authorIds, ...editorIds])];

  if (!combinedIds || combinedIds === "") {
    toast.error('작성자를 확인하지 못하였습니다');
    return;
  }

  const responseUsers = await HrmUserApi.getUsersByIds(combinedIds);
  const userList = responseUsers;

  // 사용자 정보를 Map으로 생성: key = userId, value = 사용자 이름
  const userMap = new Map();
  userList.forEach(user => {
    userMap.set(user.userId, user.name);
  });

  const { content, totalPages: totalPagesFromResponse } = responseNoices.data;

  // content 목록 순회 → attachmentId가 있으면 attachmentsMap에서 찾아서 매핑
  data.value = content.map(item => ({
    id: item.noticeId,
    title: item.title,
    author: userMap.get(item.authorId) || '미확인',
    editor: userMap.get(item.editorId) || '미확인',
    date: item.creationDate,
    content: item.content,
    attachments: item.attachments || []
  }));

  currentPage.value = page;   // Vue에서 쓰는 페이지 (1부터 시작)
  totalPages.value = totalPagesFromResponse;
}

// =====================
// 모달 등록
// =====================
function showModal() {
  // 등록 모드 (새로운 데이터)
  form.value = {
    id: null,
    title: '',
    author: '',
    date: getLocalDate(),
    content: '',
    cookieConsent: false,
  };
  isModalVisible.value = true;
}

function getLocalDate() {
  const today = new Date();
  today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
  return today.toISOString().split('T')[0];
}

/**
 * 저장(등록/수정)
 * - 실제로는 백엔드에 POST/PUT 요청 후, 다시 fetchDataFromServer()로 목록 재조회하는 식
 */
function handleSave() {
  // 모달 닫기
  isModalVisible.value = false;
  fetchDataFromServer();
}

/**
 * 테이블 행 클릭 시 상세 페이지로 이동
 */
function goToDetail(item) {
  router.push({
    path: '/hrm/notice-integrated-detail',
    // notice 데이터를 JSON 문자열로 변환하여 query로 전달
    query: { noticeId: item.id, author: item.author }
  });
}

/**
 * onMounted 시 1페이지 데이터를 불러옴
 */
onMounted(() => {
  isAdmin.value = hrmStore.isHrmAdmin;
  fetchDataFromServer(currentPage.value);
  window.addEventListener('resize', handleResize);
});

onUnmounted(() => window.removeEventListener('resize', handleResize));
</script>

<style scoped>
/* 테이블 행 hover 색상 */
#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}

.create-notice {
  margin-bottom: 10px;
}

@media (max-width: 650px) {
  .create-notice {
    margin-bottom: 0px;
  }
}

</style>
