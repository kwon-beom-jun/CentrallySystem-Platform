<template>
  <div>
    <!-- 메인 콘텐츠 -->
    <div class="content content-wrapper">
      <h2 class="content-title">
        <!-- selectedUserLabel 있으면 "OOO님의 실적 관리", 없으면 안내 문구 -->
        실적 관리
      </h2>
      <p class="content-sub-title">
        {{ selectedUserLabel
          ? `${selectedUserLabel}님의 실적 관리`
          : '이름을 입력하여 실적을 검색하세요'
        }}<br/>
        ( 유저 변동 시 새로고침 )
      </p>

      <div class="d-flex justify-content-between align-items-start">
        <!-- 실적 추가 버튼 (관리자 + 사용자 선택 시) -->
        <DefaultButton 
          v-if="isAdmin && selectedUserLabel"
          align="left"
          @click="openCreateModal"
        >
          실적 추가
        </DefaultButton>

        <p></p>
        <!-- (1) 검색 영역: UserSearchDropdown 컴포넌트 사용 -->
        <UserSearchDropdown
          class="mb-3"
          :keepSearchValue="false"
          :includeCurrentUser="true"
          @userSelected="onUserSelected"
        />
      </div>

      <hr v-if="!selectedUserLabel" />

      <!-- 검색을 하지 않았을 때(사용자 선택 X) 이미지 표시 -->
      <div v-if="!selectedUserLabel" class="d-flex justify-content-center mt-5">
        <img
          src="/img/hrm/PerformanceManagement/004.png"
          alt="검색을 하지 않았을 때 표시할 이미지"
          class="placeholder-image"
        />
      </div>

      <!-- (2) 실적 목록: 사용자가 선택되었을 때만 -->
      <DefaultTable
        v-if="selectedUserLabel"
        :columns="columns"
        :data="data"
        :rowClick="(item) => openEditModal(item)"
        :bodyFontSize="'0.7rem'"
        :fixedHeader="true"
      />

      <!-- 실적 추가 모달 -->
      <PerformanceManagementCreateModal
        :visible="createModalVisible"
        :formData="formData"
        @close="createModalVisible = false"
        @submit="submitPerformance"
      />

      <!-- 실적 수정/삭제 모달 -->
      <PerformanceManagementDeleteModifyModal
        :visible="editModalVisible"
        :editDataProp="editData"
        @close="editModalVisible = false"
        @save="submitEdit"
        @delete="removeItem"
      />

      <!-- 검색 실패 AlertModal -->
      <AlertModal
        :isVisible="resultModalVisible"
        :disableBackgroundClose="true"
        title="검색 실패"
        confirmText="확인"
        @confirm="resultModalVisible = false"
      >
        <template #body>
          <p>데이터를 가져오는 데 실패했습니다.</p>
        </template>
      </AlertModal>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';

// 모달 컴포넌트들
import PerformanceManagementCreateModal from '@/components/hrm/PerformanceManagementCreateModal.vue';
import PerformanceManagementDeleteModifyModal from '@/components/hrm/PerformanceManagementDeleteModifyModal.vue';
import AlertModal from '@/components/common/modal/AlertModal.vue';
// 버튼/테이블
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
// 새로운 검색 컴포넌트
import UserSearchDropdown from '@/components/auth/UserSearchDropdown.vue';
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";

// API
import PerformanceApi from "@/api/hrm/PerformanceApi";
import { toast } from 'vue3-toastify';

// 상태 변수
const resultModalVisible = ref(false);

// 사용자 선택 결과 (UserSearchDropdown에서 넘어옴)
const selectedUserId = ref('');
const selectedUserLabel = ref('');  // "홍길동 (hong@...)" 등

// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

// 관리자 여부
const userRole = ref('admin');
const isAdmin = computed(() => userRole.value === 'admin');

// 실적 목록
const data = ref([]);
const editData = ref({});

// 실적 추가 모달
const createModalVisible = ref(false);
const formData = ref({
  fromDate: '',
  toDate: '',
  workType: '프로젝트',
  performanceTitle: '',
  performance: '',
  status: '',
});

// 실적 수정/삭제 모달
const editModalVisible = ref(false);

// (테이블 컬럼 정의)
const columns = [
  { key: 'fromDate',        label: '시작일',  width: 60,  align: 'center' },
  { key: 'toDate',          label: '종료일',  width: 60,  align: 'center' },
  { key: 'workType',        label: '유형',    width: 80  },
  { key: 'performanceTitle',label: '성과주제', width: 100 },
  { key: 'performance',     label: '성과',    width: 100 },
  {
    key: 'statusTableLabel',
    label: '상태',
    width: 30,
    align: 'center',
    customClass: (value) => {
      if (value === '진행') return 'text-red';
      if (value === '완료') return 'text-green';
      if (value === '대기') return 'text-blue';
      return '';
    }
  },
];

// 상태값 매핑
const statusMapping = {
  '1': '진행',
  '2': '완료',
  '3': '대기'
};

// ====================== (1) UserSearchDropdown => 사용자 선택 콜백 ======================
function onUserSelected(option) {
  // option이 없거나 빈 문자열이면 => 선택 해제된 상황
  if (!option || !option.value) {
    selectedUserId.value = '';
    selectedUserLabel.value = '';
    data.value = [];
    return;
  }

  // 선택된 사용자 설정
  selectedUserId.value = option.value;
  selectedUserLabel.value = option.label;

  // 실적 목록 조회
  filterData();
}

// ====================== (2) 실적 목록 조회 ======================
async function filterData() {
  try {
    if (!selectedUserId.value) {
      data.value = [];
      return;
    }
    const response = await PerformanceApi.getPerformancesByUserId(selectedUserId.value);
    // 서버에러 처리
    if (response.data.error) {
      toast.error(response.data.error);
      return;
    }
    // 상태값 매핑
    data.value = response.data.map(item => ({
      ...item,
      statusTableLabel: statusMapping[item.status.toString()] || ''
    }));
  } catch (error) {
    toast.error('데이터를 가져오는 데 실패했습니다.');
    console.error(error);
  }
}

// ====================== (3) 실적 추가 모달 열기 / 저장 ======================
function openCreateModal() {
  formData.value = {
    fromDate: '',
    toDate: '',
    workType: '',
    performanceTitle: '',
    performance: '',
    status: '',
  };
  createModalVisible.value = true;
}

async function submitPerformance(newForm) {
  createModalVisible.value = false;
  if (!selectedUserId.value) return;

  try {
    await PerformanceApi.createPerformance(selectedUserId.value, newForm);
    toast.success('실적 추가 완료');
    await filterData();
  } catch (err) {
    toast.error('실적 추가 중 오류가 발생했습니다.');
    console.error(err);
  }
}

// ====================== (4) 실적 수정/삭제 모달 열기 / 저장 / 삭제 ======================
function openEditModal(item) {
  editData.value = { ...item };
  editModalVisible.value = true;
}

async function submitEdit(updatedItem) {
  editModalVisible.value = false;
  if (!selectedUserId.value) return;

  try {
    await PerformanceApi.patchPerformance(selectedUserId.value, updatedItem.performanceId, updatedItem);
    toast.success('실적 수정 완료');
    await filterData();
  } catch (err) {
    toast.error('실적 수정 중 오류가 발생했습니다.');
    console.error(err);
  }
}

async function removeItem(deletedItem) {
  editModalVisible.value = false;
  if (!selectedUserId.value) return;

  try {
    await PerformanceApi.deletePerformance(selectedUserId.value, deletedItem.performanceId);
    toast.success('실적 삭제 완료');
    await filterData();
  } catch (err) {
    toast.error('실적 삭제 중 오류가 발생했습니다.');
    console.error(err);
  }
}

// 컴포넌트 마운트 시 데이터 로드
onMounted(() => {
  userDirStore.refresh();
});
</script>

<style scoped>
hr {
  margin: 0px
}

/** ---------------- 사용자 검색 관련 css START ---------------- */
.search-wrapper {
  position: relative;
}

.search-result {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background: #fff;
  border: 1px solid #ccc;
  border-top: none;
  border-radius: 0 0 4px 4px;
  max-height: 150px;
  overflow-y: auto;
  list-style: none;
  margin: 0;
  padding: 0;
  z-index: 1000;
}

/* 검색 결과 목록 항목 스타일 */
.search-result li {
  padding: 8px 10px;
  cursor: pointer;
  font-size: 0.7rem;
}

.search-result li:hover,
.search-result li.active {
  background-color: #f2f2f2;
  color: black;
}
/** ---------------- 사용자 검색 관련 css END ---------------- */

/* 테이블에 스크롤 추가 */
.table-container {
  max-height: 400px;
  overflow-y: auto;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.close {
  font-size: 1.5rem;
  width: 2rem;
  height: 2rem;
  display: flex;
  align-items: center;
  justify-content: center;
}
.performance-save-button {
  background-color: #375a7f;
  font-size: 0.875rem;
  padding: 0.4rem 0.75rem;
}
.bnt-search-name {
  background-color: #375a7f;
}
#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}
.placeholder-image {
  max-width: 700px;
  margin-top: 30px;
  width: 100%;
  height: auto;
  opacity: 0.8;
}
@media (max-width: 650px) {
  .close {
    font-size: 1rem !important;
  }
  label {
    font-size: 0.85rem;
  }
  .performance-save-button {
    margin-bottom: 0;
    font-size: 0.63rem;
    padding: 0.3rem 0.6rem;
  }
  .align-items-center {
    margin-bottom: 10px;
  }
  .text-muted {
    font-size: 0.75rem;
    margin-bottom: 7px;
  }
  .input-search-name {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
    width: 150px !important;
  }
  .search-result li {
    padding: 5px 7px;
    cursor: pointer;
    font-size: 0.5rem;
  }
}

@media (max-width: 500px) {
  .placeholder-image {
    margin-top: 10px;
  }
}
</style>
