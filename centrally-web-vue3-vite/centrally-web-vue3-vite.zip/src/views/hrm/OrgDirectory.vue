<template>
  <div class="content content-wrapper">
    <h2 class="content-title">조직도(업데이트 예정)</h2>
    <p class="content-sub-title">조직도를 구성한 페이지</p>


  </div>
</template>

<script setup>
</script>


<style scoped>
</style>
