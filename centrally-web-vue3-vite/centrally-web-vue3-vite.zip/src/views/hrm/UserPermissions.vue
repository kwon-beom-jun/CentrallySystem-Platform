<template>
  <div class="content content-wrapper">
    <h2 class="content-title">프로젝트별 권한 부여</h2>
    <p class="content-sub-title">각 프로젝트별 사용자 권한을 관리하세요.</p>

    <!-- 필터 섹션 -->
    <div class="grid-container">
      <div class="grid-item">
        <DefaultLabel text="부서 선택" size="small" forId="departmentSelect" alignment="left" />
        <DefaultSelect
          id="departmentSelect"
          v-model="selectedDepartment"
          :options="departmentsOptions"
          placeholder="부서 선택"
          margin-top="5px"
          size="full"
        />
      </div>

      <div class="grid-item">
        <DefaultLabel text="팀 선택" size="small" forId="teamSelect" alignment="left" />
        <DefaultSelect
          id="teamSelect"
          v-model="selectedTeam"
          :options="teamsOptions"
          placeholder="팀 선택"
          margin-top="5px"
          size="full"
        />
      </div>

      <div class="grid-item">
        <DefaultLabel text="서비스 선택" size="small" forId="serviceNameelect" alignment="left" />
        <DefaultSelect
          id="serviceNameelect"
          v-model="selectedServiceName"
          :options="serviceNameOptions"
          placeholder="서비스 선택"
          margin-top="5px"
          size="full"
        />
      </div>

      <div class="grid-item">
        <DefaultLabel text="사용자 검색" size="small" forId="userSearch" alignment="left" />
        <DefaultTextfield
          type="text"
          id="userSearch"
          v-model="searchTerm"
          placeholder="이름(이메일) 입력"
          margin-top="5px"
          size="full"
        />
      </div>
    </div>
    
    <DefaultFormRow align="right" margin-bottom="5px">
      <!-- 권한 추가 버튼 -->
      <DefaultButton
        class="mt-2"
        size="small"
        color="gray"
        @click="openAddPermissionModal"
      >
        권한 추가
      </DefaultButton>
    </DefaultFormRow>

    <!-- 권한 테이블 -->
    <div v-if="filteredUsers.length" class="table-section">
      <DefaultTable
        :columns="columns"
        :data="sortedUsers"
        :rowClick="onRowClick"
        :fixedHeader="true"
        :selectHeight="'30px'"
        :buttonHeight="'30px'"
        @row-updated="handleRowUpdated"
        @delete-row="deletePermission"
        :minRows="7"
      />
    </div>

    <!-- 권한 추가 모달 -->
    <AddPermissionModal
      v-if="showAddPermissionModal"
      @close="showAddPermissionModal = false"
      @permissionAdded="onPermissionAdded"
    />
  </div>
</template>

<script setup>
import { ref, watch, computed, onMounted } from "vue";
import DefaultSelect from "@/components/common/select/DefaultSelect.vue";
import DefaultTextfield from "@/components/common/textfield/DefaultTextfield.vue";
import DefaultTable from "@/components/common/table/DefaultTable.vue";
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import AddPermissionModal from '@/components/auth/AddPermissionModal.vue';

import HrmUserApi from "@/api/hrm/UsersApi";
import AuthUserPermissionApi from "@/api/auth/UserPermissionApi";
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";

import { toast } from 'vue3-toastify';

// ========== 상태 변수 ==========
const departments = ref([]);    // 부서+팀 정보
const tableRows = ref([]);      // 테이블에 표시할 (유저×서비스) 행들
const allRoles = ref([]);       // 전체 권한(roles) 목록

// 필터 상태
const selectedDepartment = ref("");
const selectedTeam = ref("");
const selectedServiceName = ref("");
const searchTerm = ref("");
// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

// 권한 변경사항 저장 (예: { [userId]: '권한내용' })
const changes = ref({});

// ========== 테이블 컬럼 ==========
const columns = [
  { key: "name",        label: "이름",      width: 50 },
  { key: "email",       label: "이메일",    width: 120 },
  { key: "serviceName", label: "서비스",    width: 50 },
  { key: "department",  label: "부서",      width: 60 },
  { key: "team",        label: "팀",        width: 60 },
  {
    key: 'roleNameDetail',
    label: '권한',
    width: 85,
    type: 'select',
    getOptions: (row) => {
      // row.serviceName = 서비스명
      // allRoles.value = 전체 권한 [{roleId, roleNameDetail, serviceName}, ...]
      const filtered = allRoles.value.filter(r => r.serviceName === row.serviceName);
      // DefaultSelect가 사용하는 { value, label } 형태
      return filtered.map(r => ({
        value: r.roleNameDetail, 
        label: r.roleNameDetail
      }));
    },
  },
  {
    key: "delete",
    label: "",
    width: 80,
    type: "button",
    buttonText: "삭제",
    buttonColor: "red",
    buttonSize: "full-small",
    emit: 'delete-row' 
  }
];

/** row-updated 이벤트 → PATCH 호출 */
async function handleRowUpdated(updatedRow) {
  changes.value[updatedRow.userId] = updatedRow.roleNameDetail;
  await AuthUserPermissionApi.patchUserWithRole(updatedRow);
  toast.success('권한이 수정되었습니다.');
}

/** 권한 추가 모달 */
const showAddPermissionModal = ref(false);
function openAddPermissionModal() {
  showAddPermissionModal.value = true;
}
function onPermissionAdded() {
  showAddPermissionModal.value = false;
  fetchMetadata();
}

/** 권한 삭제 */
async function deletePermission(row) {
  const params = {
    userId: row.userId,
    email: row.email,
    serviceName: row.serviceName,
    roleNameDetail: row.roleNameDetail
  };
  const response = await AuthUserPermissionApi.deleteUserWithRole(params);
  if (response.status === 200) {
    toast.success('권한이 삭제되었습니다');
    fetchMetadata();
  }
}

// -------------------------------------------------------
//   부서/팀/서비스 SelectBox 옵션
// -------------------------------------------------------
const departmentsOptions = computed(() => [
  { value: "", label: "부서 선택" },
  ...departments.value.map(dep => ({
    value: dep.departmentId,
    label: dep.departmentName,
  }))
]);

const teamsOptions = computed(() => {
  if (!selectedDepartment.value) {
    return [{ value: "", label: "팀 선택" }];
  }
  const foundDept = departments.value.find(
    d => d.departmentId === Number(selectedDepartment.value)
  );
  if (!foundDept || !foundDept.teams) {
    return [{ value: "", label: "팀 선택" }];
  }
  return [
    { value: "", label: "팀 선택" },
    ...foundDept.teams.map(team => ({
      value: team.teamId,
      label: team.teamName,
    }))
  ];
});

const serviceNameOptions = computed(() => {
  const uniqueSrv = [...new Set(allRoles.value.map(r => r.serviceName))];
  return [
    { value: "", label: "서비스 선택" },
    ...uniqueSrv.map(s => ({ value: s, label: s }))
  ];
});

// -------------------------------------------------------
//   부서/팀 SelectBox 연동 로직
// -------------------------------------------------------
watch(selectedDepartment, () => {
  selectedTeam.value = "";
});
watch(selectedTeam, (newTeamId) => {
  if (!newTeamId) return;
  for (const dep of departments.value) {
    const foundTeam = dep.teams?.find(t => t.teamId === Number(newTeamId));
    if (foundTeam) {
      if (dep.departmentId !== Number(selectedDepartment.value)) {
        selectedDepartment.value = dep.departmentId.toString();
      }
      break;
    }
  }
});

// -------------------------------------------------------
//   테이블 필터링 / 정렬
// -------------------------------------------------------
const filteredUsers = computed(() => {
  return tableRows.value.filter(row => {
    let isMatch = true;

    // (1) 부서 필터
    if (selectedDepartment.value) {
      const chosenDept = departments.value.find(
        dep => dep.departmentId == selectedDepartment.value
      );
      if (chosenDept) {
        isMatch = isMatch && (row.department === chosenDept.departmentName);
      }
    }

    // (2) 팀 필터
    if (selectedTeam.value) {
      const chosenTeam = departments.value
        .flatMap(dep => dep.teams || [])
        .find(t => t.teamId == selectedTeam.value);
      if (chosenTeam) {
        isMatch = isMatch && (row.team === chosenTeam.teamName);
      }
    }

    // (3) 서비스
    if (selectedServiceName.value) {
      isMatch = isMatch && (row.serviceName === selectedServiceName.value);
    }

    // (4) 검색어
    if (searchTerm.value) {
      const lower = searchTerm.value.toLowerCase();
      const nameMatch = row.name.toLowerCase().includes(lower);
      const emailMatch = row.email.toLowerCase().includes(lower);
      isMatch = isMatch && (nameMatch || emailMatch);
    }

    return isMatch;
  });
});

const sortedUsers = computed(() => {
  return [...filteredUsers.value].sort((a, b) =>
    a.name.localeCompare(b.name, "ko-KR")
  );
});

// -------------------------------------------------------
//   테이블 행 클릭(선택) - 필요 시만 사용
// -------------------------------------------------------
function onRowClick(row) {
  changes.value[row.userId] = row.roleNameDetail;
}

// -------------------------------------------------------
//   🔥 [수정됨]: fetchMetadata에서 HrmUserApi + AuthUserPermissionApi 결합
// -------------------------------------------------------
async function fetchMetadata() {
  // 1) HrmUserApi → 부서/팀/사용자 목록 (userId, team, department 등)
  const hrmRes = await HrmUserApi.getUsers();
  const hrmUsers = hrmRes.data || [];

  // 2) AuthUserPermissionApi → 권한 정보
  const permRes = await AuthUserPermissionApi.getUsersWithRoles();
  allRoles.value = permRes.data.authRoles.allRoles || [];

  const userWithRolesList = permRes.data.userWithRolesList || [];

  // (A) 1) 부서 목록 만들기
  //  HrmUserApi.getUsers()에서 user.team?.department?.departmentId 등이 온다고 가정
  //  Map(deptId -> { departmentId, departmentName, teams: [{teamId, teamName}...] })
  const deptMap = new Map();

  hrmUsers.forEach(u => {
    if (u.team && u.team.department) {
      const d = u.team.department;
      if (!deptMap.has(d.departmentId)) {
        deptMap.set(d.departmentId, {
          departmentId: d.departmentId,
          departmentName: d.departmentName,
          teams: []
        });
      }
      const deptObj = deptMap.get(d.departmentId);
      // 중복 팀 체크
      const already = deptObj.teams.some(t => t.teamId === u.team.teamId);
      if (!already) {
        deptObj.teams.push({
          teamId: u.team.teamId,
          teamName: u.team.teamName
        });
      }
    }
  });
  departments.value = Array.from(deptMap.values());

  // (B) 2) userId -> { departmentName, teamName } 매핑
  //    HrmUserApi 결과를 userId 기준으로 접근할 수 있게끔
  const userDeptMap = new Map();
  hrmUsers.forEach(u => {
    let deptName = '미지정';
    let teamName = '미지정';
    if (u.team && u.team.department) {
      deptName = u.team.department.departmentName;
      teamName = u.team.teamName;
    }
    userDeptMap.set(u.userId, { deptName, teamName });
  });

  // (C) userWithRolesList → (유저×서비스) 테이블 행 구성
  const rowData = [];
  userWithRolesList.forEach(u => {
    const { deptName, teamName } = userDeptMap.get(u.userId) || { deptName: '미지정', teamName: '미지정' };

    // 한 사용자가 여러 serviceName / roleNameDetail 가능
    // serviceMap = { 'receipt': [roleNameDetail1, roleNameDetail2], 'hrm': [...] }
    const serviceMap = {};
    u.roles.forEach(role => {
      const srv = role.serviceName;
      if (!serviceMap[srv]) {
        serviceMap[srv] = [];
      }
      serviceMap[srv].push(role.roleNameDetail);
    });

    // 최종: serviceMap을 풀어서 rowData에 push
    Object.keys(serviceMap).forEach(serviceName => {
      const combined = serviceMap[serviceName].join(", ");
      rowData.push({
        userId: u.userId,
        name: u.name,
        email: u.email,
        department: deptName,
        team: teamName,
        serviceName,
        roleNameDetail: combined
      });
    });
  });

  tableRows.value = rowData;
}

// 컴포넌트 마운트 시 데이터 로드
onMounted(() => {
  fetchMetadata();
  userDirStore.refresh();
});
</script>

<style scoped>
.content-sub-title {
  margin-bottom: 30px;
}

/* 테이블 스타일 */
.table {
  width: 100%;
  margin: 0;
}

/* 테이블 컨테이너: 스크롤 추가하여 10개 행 정도 보이도록 */
.table-container {
  max-height: 400px;
  overflow-y: auto;
  margin-bottom: 60px;
}

.grid-container {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  margin-bottom: 15px;
}

.grid-item {
  display: flex;
  flex-direction: column;
}

.search-item {
  display: flex;
  align-items: center;
}

.search-item input {
  flex: 1; /* 입력 필드가 남은 공간을 모두 차지하도록 설정 */
}

.search-item button {
  white-space: nowrap; /* 버튼 텍스트가 줄바꿈되지 않도록 설정 */
}

.search-item-search {
  display: flex;
  align-items: center;
}

.search-item-search > .default-textfield {
  flex: 1;
  min-width: 0;
}

.form-control, .form-select {
  width: 100%;
}

.text-end {
  text-align: right;
}

.save-button {
  margin-top: 0px !important;
  margin-bottom: 50px;
}

@media (max-width: 650px) {
  .form-select {
    font-size: 0.75rem !important;
  }
  .permission-select {
    font-size: 0.6rem !important;
  }
  .grid-container {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
