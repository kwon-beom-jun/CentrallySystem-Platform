<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <!-- <h2 class="content-title">메인</h2>
      <div class="content-sub-title">
        <p>메인 페이지 입니다</p>
      </div> -->
      <div class="navbar-text">
        <video autoplay loop muted playsinline class="main-video">
          <source src="/img/common/main-logo-2100-1000.mp4" type="video/mp4" />
          이 브라우저는 비디오 태그를 지원하지 않습니다
        </video>
      </div>

      <!-- 여기서부터 650px 이하일 때만 나타날 “모바일 사이드 메뉴” -->
      <!-- <div v-if="isMobile"  -->
      <div v-if="false" class="mobile-nav-grid" :style="dynamicGridStyle">
        <div
          class="nav-item"
          v-for="(menu, idx) in mobileMenuItems"
          :key="idx"
          @click="goToMenu(menu.link)"
        >
          <!-- 메뉴 아이콘 및 레이블 사용 안함 -->
          <img :src="menu.icon" class="nav-icon" alt="메뉴 아이콘" />
          <div class="nav-label">{{ menu.label }}</div>
        </div>
      </div>

      <DefaultLabel
        class="font-weight-900"
        text="📋 최신 공지 사항"
        size="medium"
        marginBottom="5px"
        marginTop="30px"
      />
      <!-- 테이블 보기 -->
      <div v-if="noticeData.length > 0">
        <DefaultTable
          :columns="noticeColumns"
          :data="noticeData"
          :rowClick="(item) => goToNoticeDetail(item)"
          :minRows="3"
        />
      </div>
      <div v-else>
        <hr />
        <DefaultFormRow align="center" marginTop="45px" marginBottom="45px">
          <DefaultLabel
            class="font-weight-900"
            text="등록된 공지 사항이 없습니다."
            size="medium"
          />
        </DefaultFormRow>
        <hr />
      </div>

      <div v-if="canViewReceipt">
        <DefaultLabel
          class="font-weight-900"
          text="📌 최신 영수증 등록 상태"
          size="medium"
          marginBottom="5px"
          marginTop="20px"
        />
        <!-- 테이블 보기 -->
        <div v-if="receiptData.length > 0">
          <DefaultTable
            :columns="receiptColumns"
            :data="receiptData"
            :rowClick="(item) => goToReceipts(item)"
            :minRows="3"
          />
        </div>
        <div v-else>
          <hr />
          <DefaultFormRow align="center" marginTop="45px" marginBottom="45px">
            <DefaultLabel
              class="font-weight-900"
              text="등록된 영수증이 없습니다."
              size="medium"
            />
          </DefaultFormRow>
          <hr />
        </div>
      </div>

      <!-- KPCNC 지도 -->
      <DefaultLabel
        class="font-weight-900"
        text="🏢 CONTACT US"
        size="medium"
        marginTop="30px"
      />
      <hr />
      <KpcncMap :width="'100%'" :height="isMobile ? 200 : 500" />

      <!-- 주소/전화/팩스 정보 -->
      <div class="contact-info">
        <div class="info-item">
          <img
            class="info-icon"
            src="https://www.kpcnc.co.kr/src/img/loc1.png"
          />
          <div class="info-body">
            <div class="info-title">Address</div>
            <div class="info-text">
              서울시 성동구 성수이로20길 16 (성수동2가, 제이케이타워) 6층<br />
              성수역 3번 출구에서&nbsp;220&nbsp;m&nbsp;(JK타워&nbsp;6층)
            </div>
          </div>
        </div>
        <hr />

        <div class="info-item">
          <img
            class="info-icon"
            src="https://www.kpcnc.co.kr/src/img/loc2.png"
          />
          <div class="info-body">
            <div class="info-title">Tel</div>
            <div class="info-text">02&nbsp;-&nbsp;336&nbsp;-&nbsp;8100</div>
          </div>
        </div>
        <hr />

        <div class="info-item">
          <img
            class="info-icon"
            src="https://www.kpcnc.co.kr/src/img/loc3.png"
          />
          <div class="info-body">
            <div class="info-title">FAX</div>
            <div class="info-text">02&nbsp;-&nbsp;337&nbsp;-&nbsp;8668</div>
          </div>
        </div>
      </div>
      <hr />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import { useRouter } from "vue-router";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import DefaultTable from "@/components/common/table/DefaultTable.vue";
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import KpcncMap from "@/components/common/map/KpcncMap.vue";
import LoginApi from "@/api/auth/LoginApi";
import NoticeIntegratedApi from "@/api/hrm/NoticeIntegratedApi";
import HrmUserApi from "@/api/hrm/UsersApi";
import ReceiptsApi from "@/api/receipt/ReceiptsApi";
import { useAuthStore } from "@/store/auth";
import { toast } from "vue3-toastify";

/* ================= 권한 체크 ================= */
const authStore = useAuthStore();
const receiptRoles = [
  "ROLE_GATE_SYSTEM",
  "ROLE_RECEIPT_REGISTRAR",
  "ROLE_RECEIPT_APPROVER",
  "ROLE_RECEIPT_MANAGER",
];
const roles = computed(() => authStore.roles);
const canViewReceipt = computed(() =>
  roles.value.some((r) => receiptRoles.includes(r))
);

// =========== 영수증 메인 데이터 / 컬럼 정의 ===========
const receiptData = ref([]);
const receiptColumns = [
  { key: "reason", label: "사유", width: 150 },
  /* { key: 'amount', label: '금액', width: 60 }, */
  {
    key: "status",
    label: "결제 상황",
    width: 70,
    customClass: (value) => {
      if (value === "신청") return "text-blue";
      if (value === "승인") return "text-green";
      if (value === "반려") return "text-red";
      return "";
    },
  },
  { key: "date", label: "발행일", width: 100 },
  /* { key: 'approverName', label: '결재자', width: 60 }, */
];
/* ---------- 최신 영수증 3건 조회 ---------- */
async function fetchLatestReceipts() {
  try {
    const userId = authStore.getUserId;
    const res = await ReceiptsApi.getReceiptsByUserId(userId, {
      page: 0,
      size: 3,
    });

    const contents = res.data.content ?? [];

    receiptData.value = contents.map((r) => ({
      reason: r.reason,
      status: r.status?.description || "신청",
      date: r.submissionDate,
    }));
  } catch (e) {
    console.error(e);
    toast.error("영수증 정보를 불러오지 못했습니다."); // ★
  }
}
/* ---------- 최신 공지 사항 행 클릭 ---------- */
function goToReceipts() {
  router.push({
    path: '/receipt/personal-receipt-history',
  });
}

// =========== 공지 사항 메인 데이터 / 컬럼 정의 ===========
const noticeData = ref([]);
const noticeColumns = [
  /* { key: 'id',     label: '번호'  , width: 40 }, */
  { key: "title", label: "제목", width: 150 },
  { key: "author", label: "작성자", width: 70 },
  { key: "date", label: "작성일", width: 100 },
];
/* ---------- 최신 공지 사항 3건 조회 ---------- */
async function fetchLatestNotices() {
  try {
    const res = await NoticeIntegratedApi.getNotices({
      page: 0,
      size: 3,
      sort: "creationDate,desc",
    });

    const contents = res.data.content ?? [];

    // 작성자 ID 수집 → 사용자 이름 조회
    const authorIds = [...new Set(contents.map((c) => c.authorId))];
    const usersRes = authorIds.length
      ? await HrmUserApi.getUsersByIds(authorIds)
      : [];

    const userMap = new Map();
    usersRes.forEach((u) => userMap.set(u.userId, u.name));

    // 테이블 바인딩용 가공
    noticeData.value = contents.map((item) => ({
      id: item.noticeId,
      title: item.title,
      author: userMap.get(item.authorId) || "미확인",
      /* 시·분·초 제거 → 'YYYY-MM-DD' 만 표시 */
      date: item.creationDate.split(" ")[0],
    }));
  } catch (e) {
    console.error(e);
    toast.error("공지 사항을 불러오지 못했습니다.");
  }
}
/* ---------- 최신 공지 사항 행 클릭 ---------- */
function goToNoticeDetail(item) {
  router.push({
    path: '/hrm/notice-integrated-detail',
    // notice 데이터를 JSON 문자열로 변환하여 query로 전달
    query: { noticeId: item.id, author: item.author }
  });
}

// ------------------------------------------------------
// 기존 로직 (isMobile 등) 그대로
// ------------------------------------------------------
const router = useRouter();
const isMobile = ref(window.innerWidth <= 650);
function updateIsMobile() {
  isMobile.value = window.innerWidth <= 650;
}
window.addEventListener("resize", updateIsMobile);

const mobileMenuItems = [
  {
    icon: "/img/common/main/main-notice-1.png",
    label: "공지사항",
    link: "/hrm/notice-integrated",
  },
  {
    icon: "/img/common/main/main-receipt-5.png",
    label: "영수증 등록",
    link: "/receipt/receipt-submission",
  },
  {
    icon: "/img/common/main/main-hrm-5.png",
    label: "인사관리",
    link: "/hrm/user-management",
  },
  {
    icon: "/img/common/main/main-person-5.png",
    label: "개인정보",
    link: "/hrm/user-information",
  },
  {
    icon: "/img/common/main/main-system-5.png",
    label: "시스템",
    link: "/system/activity-log",
  },
];

function goToMenu(routePath) {
  router.push(routePath);
}

// ------------------------------------------------------
// (수정 부분) 동적으로 grid-template-columns, gap 설정
// ------------------------------------------------------
const windowWidth = ref(window.innerWidth);

// 창 크기가 바뀔 때마다 windowWidth 갱신
function handleResize() {
  windowWidth.value = window.innerWidth;
}
window.addEventListener("resize", handleResize);

// mount 시 한 번 실행
onMounted(() => {
  LoginApi.getMe();
  handleResize();
  fetchLatestNotices();
  if (canViewReceipt.value) fetchLatestReceipts();
});

// dynamicGridStyle: windowWidth에 따라 열 개수와 간격 결정
const dynamicGridStyle = computed(() => {
  let columns = 6;
  let gapPx = 70;
  let topMargin = 30; // 기본값
  const w = windowWidth.value;
  const itemCount = mobileMenuItems.length;

  // 기존 @media 로직을 JS로 옮김 (원하는 기준은 자유롭게 바꿔도 됨)
  if (w <= 400) {
    // topMargin = 15;
    columns = 4;
    gapPx = 30;
  } else if (w <= 500) {
    // topMargin = 25;
    columns = 4;
    gapPx = 40;
  } else if (w <= 600) {
    columns = 5;
    gapPx = 50;
  } else if (w <= 700) {
    columns = 5;
    gapPx = 60;
  } else {
    columns = 6;
    gapPx = 70;
  }

  // 실제 아이템보다 많은 열을 만들지 않는다
  // columns = Math.min(columns, itemCount);
  columns = Math.max(1, Math.min(columns, itemCount));

  return {
    // 그리드 기본 스타일
    display: "grid",
    width: "fit-content",
    margin: `${topMargin}px auto 0`,
    justifyItems: "center",

    // 동적으로 열 / 간격 세팅
    gridTemplateColumns: `repeat(${columns}, auto)`,
    gap: `${gapPx}px`,
  };
});
</script>

<style scoped>
p {
  margin-bottom: 0px !important;
}

/* 이미지 크기 조정 */
.main-video {
  width: 100% !important;
  height: auto !important;
  object-fit: cover;
}

/* 네비게이션 텍스트 및 아이콘 */
.navbar-text {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  width: 100%;
  height: 100%;
}

.content-sub-title {
  margin-bottom: 10px !important;
}
.content-sub-title {
  margin-bottom: 10px !important;
}
.navbar-text {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  width: 100%;
  height: 100%;
}

/* Contact info 스타일 */
.font-weight-900 {
  font-weight: 900;
}
.contact-info {
  max-width: 100%;
  margin: 25px auto 0;
  font-size: 0.9rem;
  line-height: 1.5;
  color: #333;
}
.info-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 12px 0;
}
.info-icon {
  width: 32px;
  height: 32px;
}
.info-body {
  flex: 1;
}
.info-title {
  font-weight: 900;
  margin-bottom: 4px;
}
.info-text {
  white-space: pre-line;
}
.contact-info hr {
  border: none;
  border-top: 1px solid #e1e1e1;
  margin: 0;
}

@media (min-width: 1000px) {
  .contact-info {
    display: flex; /* 한 줄로 */
    align-items: flex-start;
    justify-content: center;
  }
  .info-item {
    flex: 1 1 0;
    padding: 0 20px; /* 좌·우 여백 */
  }

  /* 가운데 세로선: 마지막 아이템 제외하고 우측 보더 */
  .info-item:not(:last-child) {
    border-right: 1px solid #e1e1e1;
  }

  /* 가로 hr 은 데스크톱에서 숨김 */
  .contact-info hr {
    display: none;
  }
}

/* 
  기존에 @media로 grid-template-columns, gap 지정했던 부분
  → 전부 제거함.
  나머지 margin, display, width, justify-items 등은 그대로 유지 
*/
@media (max-width: 650px) {
  .content {
    margin-left: 0;
    padding: 20px;
  }
  .navbar-text {
    gap: 10px;
    width: 100%;
    height: 100%;
  }
  .nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    cursor: pointer;
  }
  .nav-icon {
    width: 65px;
    height: 65px;
    object-fit: cover;
  }
  .nav-label {
    margin-top: 5px;
    font-size: 0.85rem;
  }
  /* .mobile-nav-grid {
    display: none !important;
  } */
  .info-title {
    font-size: 0.8rem !important;
  }
  .info-text {
    font-size: 0.7rem !important;
  }
}

@media (max-width: 900px) {
  .nav-icon {
    width: 50px;
    height: 50px;
    object-fit: cover;
  }
}

@media (max-width: 700px) {
  .nav-icon {
    width: 45px;
    height: 45px;
  }
  .nav-label {
    margin-top: 5px;
    font-size: 0.75rem;
  }
}

@media (max-width: 600px) {
  .nav-icon {
    width: 38px;
    height: 38px;
  }
  .nav-label {
    margin-top: 5px;
    font-size: 0.7rem;
  }
}

@media (max-width: 400px) {
  .nav-icon {
    width: 30px;
    height: 30px;
  }
  .nav-label {
    font-size: 0.65rem;
  }
}
</style>
