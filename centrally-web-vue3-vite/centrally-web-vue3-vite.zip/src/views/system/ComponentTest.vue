<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">컴포넌트 테스트</h2>
      <p class="content-sub-title">
        컴포넌트 테스트 화면입니다<br/>
        텍스트필드 + 버튼 + 셀렉트 높이 정렬 비교용
      </p>

      <hr/>

      <div v-for="size in sizes" :key="size" class="test-row">
        <p class="test-title">▶ Size: <strong>{{ size }}</strong></p>
        <div class="test-box">
          <DefaultTextfield
            v-model="dummy"
            :size="size"
            placeholder="텍스트필드"
          />
          <DefaultButton :size="size">
            버튼
          </DefaultButton>
          <DefaultSelect
            v-model="selected"
            :size="size"
            :options="options"
            placeholder="선택 옵션 테스트 글자"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultSelect from '@/components/common/select/DefaultSelect.vue';

const sizes = [
  'xsmall',
  'small',
  'medium',
  'large',
  'full',
  'full-xsmall',
  'full-small',
  'full-medium',
  'full-large'
];

const dummy = ref('');
const selected = ref('');
const options = [
  { value: '', label: '선택' },
  { value: '1', label: '옵션 1' },
  { value: '2', label: '옵션 2' }
];
</script>

<style scoped>
.content-sub-title {
  font-size: 0.9rem !important;
  margin-bottom: 30px !important;
}

.test-title {
  font-size: 0.8rem;
  margin-bottom: 4px;
  color: #333;
}

.test-box {
  display: flex;
  gap: 12px;
  align-items: center;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.test-box > * {
  /* 박스 안 아이템 높이 비교를 위해 border 넣기 */
  border: 1px dashed #ccc;
  padding: 2px;
}

@media (max-width: 700px) {
  .content-sub-title {
    font-size: 0.8rem !important;
    margin-bottom: 20px !important;
  }
}
</style>
