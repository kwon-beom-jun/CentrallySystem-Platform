<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">권한 관리</h2>
      <div class="content-sub-title">
        <p>사용자 권한을 관리하는 페이지 입니다</p>
      </div>
    </div>
  </div>
</template>

<script setup>
</script>

<style scoped>
</style>
