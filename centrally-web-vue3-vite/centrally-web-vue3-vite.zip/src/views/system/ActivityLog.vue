<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">이력 관리</h2>
      <div class="content-sub-title">
        <p>사용자 이력을 관리 페이지 입니다</p>
      </div>

      <div class="search-controls">
        <!-- 시작, 종료일 그룹 -->
        <DefaultFormRow align="right">
          <DefaultLabel text="시작 :" forId="startDate" size="small" />
          <DefaultTextfield
            type="date"
            id="startDate"
            v-model="startDate"
            size="xsmall"
          />
          <DefaultLabel text="종료 :" forId="endDate" size="small" marginLeft="10px" />
          <DefaultTextfield
            type="date"
            id="endDate"
            v-model="endDate"
            size="xsmall"
          />
        </DefaultFormRow>
        <!-- 이름 검색 그룹 -->
        <DefaultFormRow align="right" marginTop="7px">
          <!-- <DefaultLabel text="이름(이메일) :" forId="searchData" size="small" /> -->
          <DefaultTextfield
            type="text"
            id="searchData"
            size="large"
            v-model="searchData"
            placeholder="이름(이메일) 입력"
          />
          <DefaultButton 
            @click="search"
            color="gray"
            size="small">
            조회
          </DefaultButton>
        </DefaultFormRow>
      </div>

      <!-- 조회 결과 없을 때 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="data.length">
        <div class="activity-log-table">
          <!-- DefaultTable 컴포넌트 (큰 화면) -->
          <DefaultTable
            :columns="columns"
            :data="data"
            :showTable="viewMode"
            :bodyFontSize="'0.7rem'"
            :rowClick="(item) => openDetailModal(item)"
            @rowClick="openDetailModal" 
          />
        </div>
        
        <!-- 페이지네이션 (공통 컴포넌트) -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>

      <!-- 테이블 클릭시 상세 모달 -->
      <ActivityLogDetail
        v-if="isDetailModalVisible"
        :logData="selectedLog"
        @close="isDetailModalVisible = false"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import ActivityLogApi from '@/api/system/ActivityLogApi';
import ActivityLogDetail from '@/components/system/ActivityLogDetail.vue';
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";

// import axios from 'axios'; // 실제 백엔드 호출 시 사용

// ================ 상태 정의 ================
const noData = ref(false);
const today = new Date().toISOString().slice(0, 7);
const startDate = ref(today);
const endDate = ref(today);
const searchData = ref('');

// 모달 표시/숨김 제어
const isDetailModalVisible = ref(false);
const selectedLog = ref(null);

// 실제 서버에서 받아온 데이터
const data = ref([]);

// 페이지네이션
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);  // 페이지네이션에서 보여줄 최대 페이지 버튼 수
// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

// 컬럼 정의
const columns = ref([
  { key: 'username', label: '이름', width: 50 },
  { key: 'userEmail', label: '이메일', width: 120 },
  { key: 'menu', label: '메뉴', width: 60 },
  { key: 'function', label: '기능', width: 100 },
  { key: 'ip', label: 'URI (법적문제)', width: 110 },
  { key: 'httpMethod', label: 'METHOD', width: 40 },
  { key: 'httpBody', label: '본문', width: 120 },
  { key: 'timestamp', label: '시간', width: 120 },
]);

function openDetailModal(rowData) {
  selectedLog.value = rowData; // 클릭한 행의 데이터 보관
  isDetailModalVisible.value = true; // 모달 열기
}

/**
 * 서버에서 데이터 가져오기
 * 실제로는 axios 등을 사용하여 파라미터(startDate, endDate, searchData, currentPage 등)를 전송 후,
 * 응답에서 data, totalPages 등을 받아 세팅하시면 됩니다.
 */
async function fetchDataFromServer() {
  const response = await ActivityLogApi.getActivityLogs(
    {
      startDate: startDate.value,
      endDate: endDate.value,
      searchData: searchData.value,
      currentPage: currentPage.value,
    }, 
  );

  data.value = response.data.content;
  noData.value = data.value.length ? false : true;
  totalPages.value = response.data.totalPages;
}

/**
 * 검색 버튼 클릭 시 실행
 * - 검색 파라미터를 포함하여 페이지 1번으로 재조회
 */
function search() {
  currentPage.value = 1;
  fetchDataFromServer(currentPage.value);
}

/**
 * 페이지 변경 시 (DefaultPagination에서 방출)
 * - 새 페이지를 받아서 currentPage를 갱신
 * - 백엔드 재조회
 */
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(currentPage.value);
}

// 사용자가 시작일을 수정했을 때, 종료일보다 큰 경우 → 종료일을 시작일과 동일하게 맞춤
watch(startDate, (newStart) => {
  if (newStart > endDate.value) {
    endDate.value = newStart;
  }
});
// 사용자가 종료일을 수정했을 때, 시작일보다 작은 경우 → 시작일을 종료일과 동일하게 맞춤
watch(endDate, (newEnd) => {
  if (newEnd < startDate.value) {
    startDate.value = newEnd;
  }
});

onMounted(() => {
  // 컴포넌트 초기 로드시 첫 페이지 조회
  fetchDataFromServer(currentPage.value);
  userDirStore.refresh();
});
</script>

<style scoped>
#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}

.activity-log-table {
  margin-bottom: 10px;
}

/* 상태별 색상 설정 */
.status-complete {
  color: blue; /* 완료 상태는 파란색 */
}
.status-in-progress {
  color: red; /* 진행중 상태는 빨간색 */
}
.align-items-center {
  margin-bottom: 0px !important;
}
.start-end-date-group label {
  margin-left: 10px !important;
}
.bnt-search {
  margin: 0 !important;
}

.search-controls {
  margin-bottom: 10px;
}

@media (min-width: 1151px) {
}

@media (min-width: 1920px) {
}

@media (max-width: 650px) {
}
</style>
