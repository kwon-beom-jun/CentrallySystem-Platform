<template>

  <!-- 문서관리 전용 테마 래퍼 -->
  <v-theme-provider :theme="dms">

    <!-- Layout 컨텍스트 제공 -->
    <v-layout full-height>
      
      <!-- 본문 -->
      <v-main>
        <router-view />
      </v-main>
      
    </v-layout>

  </v-theme-provider>
</template>

<script setup>
import { watch } from 'vue'
import { useRoute } from 'vue-router'
import { useDmsSidebarStore } from '@/store/dms/dmsSidebar'

const route  = useRoute()
const drawer = useDmsSidebarStore()

/* 이전 경로 기억용 */
let prevPath = route.path

watch(
  () => route.path,
  (newPath) => {
    /* ① /dms → 비-/dms 로 이동 ⇒ 닫기 */
    if (!newPath.startsWith('/dms')) {
      drawer.close()
    }
    /* ② 비-/dms → /dms 로 ‘처음’ 진입할 때만 열기 */
    else if (!prevPath.startsWith('/dms')) {
      drawer.open()
    }

    prevPath = newPath        // 직전 경로 갱신
  },
  { immediate: true }
)
</script>

<style scoped>
</style>
