<template>
  <div class="content content-wrapper">
    <h2 class="content-title">{{ title }} (#{{ route.params.nodeId ?? 'root' }})</h2>
    <p class="content-sub-title">{{ subTitle }}</p>

    <!-- 뒤로가기 -->
    <div class="button-group"></div>

    <!-- 작성자 / 날짜 -->
    <DefaultFormRow marginBottom="5px" align="between">
      <div>
        <DefaultLabel text="작성자 : " />
        <DefaultLabel text="관리자" margin-right="0px"/>
        <!-- <DefaultLabel :text="notice.date" size="small" /> -->
      </div>
      <div>
        <DefaultFormRow align="right">
          <DefaultButton 
            size="small"
            @click="add"
          >
            권한 부여
          </DefaultButton>
        </DefaultFormRow>
      </div>
    </DefaultFormRow>

    <div class="ql-editor" v-html="sanitizedContent" />

    <DefaultFormRow marginBottom="10px">
      <div>
        <DefaultLabel
          text="첨부 파일"
          size="small"
          margin-bottom="5px"
          margin-top="20px"
        />
        <!-- <div v-if="nonImageFiles.length > 0"> -->
          <ul class="attachment-list">
            <li v-for="file in nonImageFiles" :key="file.attachmentId">
              <!-- <a :href="file.fileUrl" target="_blank" rel="noopener noreferrer"> -->
              <a href="/#" target="_blank" rel="noopener noreferrer">
                <DefaultLabel text="[다운로드]" size="small" />
                <!-- <DefaultLabel :text="file.fileName" size="small" /> -->
                <DefaultLabel text="테스트" size="small" />
                <!-- {{ file.fileName }} -->
              </a>
            </li>
          </ul>
        <!-- </div> -->
      </div>
    </DefaultFormRow>

    <!-- </div> -->
    <hr />
    <!-- 수정/삭제 -->
    <DefaultFormRow marginBottom="5px" align="right">
      <DefaultButton 
        marginRight="5px"
        @click="goToPermissionModify"
      >
        수정
      </DefaultButton>
        <!-- @click="showDeleteAlert" -->
      <DefaultButton 
        color="red" 
      >
        삭제
      </DefaultButton>
    </DefaultFormRow>

  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router'
import DefaultButton from '@/components/common/button/DefaultButton.vue'
import DefaultFormRow from '@/components/common/DefaultFormRow.vue'
import DefaultLabel from '@/components/common/label/DefaultLabel.vue'
import DOMPurify from 'dompurify'
// import { toast } from 'vue3-toastify'

const route = useRoute();
const router = useRouter();

const title = ref('문서 관리 메인 페이지');
const subTitle = ref('경로 예시 : OOO > TT > 문서 관리 메인 페이지');
/* 📄 실제 본문(HTML 문자열) – 나중엔 API 결과로 바뀜 */
const body = ref('<p><strong>Hello</strong> DMS World!</p>')

/* ---------- XSS 방어 & Quill 호환 옵션 ---------- */
const sanitizeOptions = {
  USE_PROFILES: { html: true },
  ADD_TAGS:  ['span'],
  ADD_ATTR: ['class','style','data-indent','data-list','target','rel'],
  FORBID_TAGS: ['script','iframe','object']
}
const sanitizedContent = computed(() =>
  DOMPurify.sanitize(body.value, sanitizeOptions)
)
DOMPurify.addHook('afterSanitizeAttributes', node => {
  if (node.tagName === 'A') {
    node.setAttribute('target', '_blank')
    node.setAttribute('rel', 'noopener noreferrer')
  }
})

/* ---------- 수정 버튼 → 권한 관리 페이지 ---------- */
function goToPermissionModify () {
  router.push({ name: 'DmsCreateModifyPage' })
}
</script>

<style scoped>
/* Quill 기본 보기용 스타일 그대로 사용 */
.ql-editor{
  border:1px solid #d0d0d0;
  border-radius:4px;
  padding:16px;
  min-height:260px;
  background:#fafafa;
  line-height:1.6;
}
@media(max-width:650px){
  .ql-editor{
    font-size:.75rem;
  }
}
</style>
