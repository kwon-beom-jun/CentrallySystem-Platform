<template>
  <!-- 좌측 이미지 + 우측 회원가입 레이아웃 -->
  <div class="signup-layout">
    <!-- 왼쪽 : 이미지 -->
    <div class="left-section">
      <v-img src="/img/common/login/003.png" alt="join image" cover class="side-image" />
    </div>

    <!-- 오른쪽 : 폼 -->
    <div class="right-section">
      <div class="form-container">
        <!-- 로그인 페이지와 동일한 헤더  -->
        <h1 class="title-login">JOIN</h1>
        <h2 class="title">Centrally System</h2>
        <div class="system-header">
          <p class="system-subtitle">CENTRALLY SYSTEM은 회사 관련 시스템입니다</p>
        </div>

        <!-- ===== 회원가입 폼 ===== -->
        <form ref="formRef" @submit.prevent="handleSubmit">
          <!-- 이름 / 휴대폰 -->
          <DefaultFormRow 
            align="betweenEqual" 
            gap="12px" 
            marginBottom="10px" 
            marginTop="8px"
          >
            <div class="field-half">
              <DefaultLabel
                text="이름" 
                forId="userName" 
                size="small" 
                alignment="left" 
              />
              <DefaultTextfield 
                id="userName" 
                v-model="userName" 
                size="full"
                required 
                customHeight="40px"
              />
            </div>
            <div class="field-half">
              <DefaultLabel 
                text="핸드폰 번호" 
                forId="phone" 
                size="small" 
                alignment="left" 
              />
              <DefaultTextfield
                id="phone"
                v-model="phone"
                size="full"
                placeholder="'-' 없이 입력하세요"
                required
                customHeight="40px"
              />
            </div>
          </DefaultFormRow>

          <!-- 비밀번호 / 확인 -->
          <DefaultFormRow gap="12px" marginBottom="10px" align="betweenEqual">
            <div class="field-half">
              <DefaultLabel text="비밀번호" forId="password" size="small" alignment="left" />
              <DefaultTextfield
                type="password"
                id="password"
                v-model="password"
                size="full"
                required
                customHeight="40px"
              />
            </div>
            <div class="field-half">
              <DefaultLabel
                text="비밀번호 확인"
                forId="confirmPassword"
                size="small"
                alignment="left"
              />
              <DefaultTextfield
                type="password"
                id="confirmPassword"
                v-model="confirmPassword"
                size="full"
                required
                customHeight="40px"
              />
            </div>
          </DefaultFormRow>

          <!-- 이메일 / 인증 메일 -->
          <DefaultLabel text="이메일" forId="email" size="small" alignment="left" />
          <DefaultFormRow growFirst>
            <DefaultTextfield
              id="email"
              v-model="email"
              validationType="email"
              reserveErrorSpace
              required
              size="full"
              customHeight="40px"
            />
            <DefaultButton
              color="gray"
              class="btn-sm no-pad"
              customWidth="110"
              marginBottom="21px"
              @click="sendEmailVerification"
              customHeight="40px"
            >
              인증 메일
            </DefaultButton>
          </DefaultFormRow>

          <!-- 인증코드 / 타이머 -->
          <DefaultLabel text="인증 코드" forId="email" size="small" alignment="left" />
          <DefaultFormRow marginBottom="35px">
            <DefaultTextfield
              id="verificationCode"
              v-model="verificationCode"
              size="small"
              :disabled="verificationCodeDisable"
              placeholder="인증코드"
              customHeight="40px"
            />
            <DefaultButton 
              color="yellow" 
              size="small" 
              @click="sameVerification"
              customHeight="40px"
            >
              확인
            </DefaultButton>
            <span v-if="!verificationCodeDisable && countdown > 0" class="timer-caption">
              {{ countdown }}s
            </span>
          </DefaultFormRow>

          <button class="action-btn join-btn" type="submit">가입하기</button>
          <button class="action-btn back-btn" @click="onGoBack">돌아가기</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import DefaultButton from "@/components/common/button/DefaultButton.vue";
import DefaultTextfield from "@/components/common/textfield/DefaultTextfield.vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import KakaoAddressModal from "@/components/common/kakao/address/KakaoAddressModal.vue";
import EmailApi from "@/api/auth/EmailApi";
import UsersApi from "@/api/auth/UsersApi";
import { toast } from "vue3-toastify";

// 라우터 사용 설정
const router = useRouter();

const userName = ref("");
const email = ref("");
const phone = ref("");
const dob = ref("");
const joinDate = ref("");
const department = ref("");
const team = ref(""); // 팀을 위한 상태 추가
const position = ref("");
const password = ref("");
const confirmPassword = ref("");

// 인증 코드 입력값
const verificationCode = ref("");
const verificationCodeDisable = ref(false);

// 타이머 관련 상태
const countdown = ref(0);
let timerInterval = null;

/**
 * 카카오 주소 API
 */
const zipCode = ref("");
const address = ref("");
const detailAddress = ref("");
const isModalOpen = ref(false);

function openModal() {
  isModalOpen.value = true;
}
function closeModal() {
  isModalOpen.value = false;
}
function handleSelectAddress(payload) {
  // payload = { address: ..., zipCode: ... }
  address.value = payload.address;
  zipCode.value = payload.zipCode;
}

/**
 * 타이머 시작 함수
 * 5분(300초)부터 1초마다 감소
 */
function startTimer() {
  countdown.value = 300; // 300초 = 5분
  verificationCode.value = "";
  verificationCodeDisable.value = false;
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    if (countdown.value > 0) {
      countdown.value--;
    } else {
      clearInterval(timerInterval);
    }
  }, 1000);
}

/**
 * 인증 메일 발송 버튼 클릭 시
 *  - 백엔드에 email 보내서 인증코드 생성 & 메일 발송 요청
 */
async function sendEmailVerification() {
  if (!email.value) {
    toast.error("이메일을 입력하세요");
    return;
  }

  const response = await EmailApi.mailSend({
    email: email.value,
  });

  if (response.status === 200) {
    // 인증 메일 발송 후 타이머 시작(약간의 오차가 있을 수 있음)
    // 인증 실패시 백엔드 호출하는동안에도 멈춰있어서 오차가 있을 수 있음
    startTimer();
    toast.info(response.data.message);
  } else {
    toast.error(response.data.message);
  }
}

/**
 * 인증 확인 버튼 클릭 시
 *  - 백엔드에 인증코드 보내서 검증
 */
async function sameVerification() {
  /**
   *
   *
   *
   *  verificationCode는 백엔드에서 암호화 된 값으로 해줘야하나?
   *  이후 암호화 된 값을 백엔드에서 검증해야하나?
   *
   *
   *
   */
  const response = await EmailApi.mailVerify({
    email: email.value,
    code: verificationCode.value,
  });

  if (response.status === 200) {
    verificationCodeDisable.value = true;
    toast.info(response.data.message);
    if (timerInterval) clearInterval(timerInterval); // 타이머 중지
  } else {
    toast.error(response.data.message);
  }
}

/**
 * 회원 가입 벡엔드 호출
 *  - 폼 제출 시 호출되는 함수
 *  - 폼은 주로 클라이언트에서 데이터의 유효성을 확인하거나 기본적인 입력값이 있는지 체크하는 용도
 */
const formRef = ref(null);
async function handleSubmit() {
  // formRef를 통해 폼 요소의 유효성을 검사합니다.
  if (!formRef.value.checkValidity()) {
    formRef.value.reportValidity();
    return;
  }

  if (password.value !== confirmPassword.value) {
    toast.warning("비밀번호가 일치하지 않습니다");
    return;
  }

  if (!verificationCode.value) {
    toast.warning("인증코드를 입력하세요");
    return;
  }

  console.log(formRef);

  const response = await UsersApi.createUser({
    userName: userName.value,
    email: email.value,
    phone: phone.value,
    // dob: dob.value,
    // joinDate: joinDate.value,
    // department: department.value,
    // team: team.value,
    // position: position.value,
    // zipCode: zipCode.value,
    // address: address.value,
    // detailAddress: detailAddress.value,
    password: password.value,
    verificationCode: verificationCode.value,
  });

  if (response.status === 200) {
    toast.info(response.data.message);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    onGoBack();
  } else {
    toast.error(response.data.message);
  }

  // 서버로 데이터를 전송하는 로직을 추가하세요
  console.log("회원가입 완료:", {
    userName: userName.value,
    email: email.value,
    phone: phone.value,
    dob: dob.value,
    joinDate: joinDate.value,
    // department: department.value,
    // team: team.value,
    // position: position.value,
    zipCode: zipCode.value,
    address: address.value,
    detailAddress: detailAddress.value,
    password: password.value,
    verificationCode: verificationCode.value,
  });
}

const onGoBack = () => {
  router.push("login");
};
</script>

<style scoped>
/* ───────── 레이아웃 ───────── */
.signup-layout {
  display: flex;
  min-height: 100vh;
}

.left-section {
  flex: 5;
}
.side-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.right-section {
  flex: 2;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background: #fff;
}

.form-container {
  width: 100%;
  max-width: 420px;
  transform: scale(0.86);
  transform-origin: center;
}

/* ───────── 헤더 타이포 ───────── */
.title-login {
  text-align: left;
  font-weight: 900;
  margin-bottom: 40px;
}
.title {
  text-align: left;
  font-size: 1.5rem;
  font-weight: 800;
  margin-bottom: 10px;
}
.system-header {
  text-align: left;
  margin-bottom: 30px;
}
.system-subtitle {
  font-size: 0.9rem;
  color: #6c757d;
}

/* 타이머 */
.timer-caption {
  font-size: 0.74rem;
  color: #e03131;
  margin-left: 6px;
}

/* 필드 내부 폰트/패딩 */
::v-deep .v-field__input {
  font-size: 0.92rem;
  padding: 12px 14px 12px 26px !important;
}

/* 기본 버튼 색상 */
.primary-btn {
  background: #3d6ef7;
  color: #fff;
  transition: 0.2s;
}
.primary-btn:hover {
  background: #335eea;
}

/* ───────── 기본 버튼 스타일 ───────── */
.action-btn {
  width: 100%;
  height: 45px;
  margin-bottom: 10px;
  border: none;
  border-radius: 4px;
  font-size: 0.8rem;
  cursor: pointer;
  font-weight: 100;
  display: flex;
  align-items: center;
  justify-content: center;
}

.join-btn,
.back-btn {
  font-size: 0.875rem;
  background: #f8f8f8;
  border: 1px solid #dadce0;
  color: #555;
}

.join-btn:hover,
.back-btn:hover {
  /* background: #f7f7f7; */
  background: #ececec;
}

.back-btn {
  /* background: #a6c2ff; */
  margin-bottom: 30px;
}

/* ─── 모바일(≤768px) ─── */
@media (max-width: 768px) {
  .left-section {
    display: none;
  }
  .signup-layout {
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
  .right-section {
    width: 100%;
    padding: 1.5rem 2rem;
  }
  .form-container {
    transform: scale(0.875);
  }

  .action-btn {
    height: 38px;
    font-size: 0.7rem;
  }

  .join-btn,
  .back-btn {
    font-size: 0.7rem;
    border: 1px solid #dadce0;
    color: #555;
  }

  .title-login {
    font-size: 1.8rem;
    margin-bottom: 28px;
  }
  .title {
    font-size: 1.3rem;
  }
  .system-subtitle {
    font-size: 0.8rem;
    margin-bottom: 24px;
  }

  ::v-deep .v-field__input {
    font-size: 0.85rem;
    padding: 10px 12px 10px 22px !important;
  }
}
</style>
