<template>
  <div class="container">
    <div class="system-header">
      <h1 class="system-title">CENTRALLY SYSTEM</h1>
      <p class="system-subtitle">CENTRALLY SYSTEM은 회사 관련 시스템입니다</p>
    </div>
    <form ref="formRef" @submit.prevent="handleSubmit">

      <!-- 이름과 핸드폰 번호 -->
      <DefaultFormRow align="betweenEqual" gap="10px" marginBottom="20px" marginTop="20px">
        <div>
          <DefaultLabel text="이름" forId="userName" size="small" />
          <DefaultTextfield
            id="userName"
            v-model="userName"
            size="full"
            required
          />
        </div>
        <div>
          <DefaultLabel text="핸드폰 번호" forId="phone" size="small" />
          <DefaultTextfield
            id="phone"
            v-model="phone"
            size="full"
            placeholder="'-' 없이 입력하세요"
            required
          />
        </div>
      </DefaultFormRow>

      <!-- 이메일 + 인증코드 / 인증 메일 발송 -->
      <DefaultLabel text="이메일" forId="email" size="small" />
      <DefaultFormRow growFirst marginBottom="5px">
        <DefaultTextfield
          id="email"
          v-model="email"
          validationType="email"
          reserveErrorSpace="true"
          required
          size="full"
        />
        <DefaultButton
          color="gray"
          @click="sendEmailVerification"
          margin-bottom="21px"
        >
          인증 메일 발송
        </DefaultButton>
      </DefaultFormRow>

      <!-- 인증코드 입력 + 버튼 (한 줄 배치) -->
      <DefaultFormRow marginBottom="20px">
        <DefaultTextfield
          id="verificationCode"
          v-model="verificationCode"
          size="small"
          :disabled="verificationCodeDisable"
          placeholder="인증코드 입력"
        />
        <DefaultButton
          color="yellow"
          @click="sameVerification"
          size="small"
        >
          인증 확인
        </DefaultButton>
        <!-- 타이머 표시 (인증확인 버튼 옆) -->
        <div v-if="!verificationCodeDisable && countdown > 0" 
          style="margin-left: 10px; 
          font-size: 0.7rem; 
          color: #d9534f;">
          남은 시간: {{ countdown }}초
        </div>
      </DefaultFormRow>

      <!-- 비밀번호와 비밀번호 확인 -->
      <DefaultFormRow marginBottom="20px" gap="10px" align="betweenEqual">
        <div>
          <DefaultLabel text="비밀번호" forId="password" size="small" />
          <DefaultTextfield
            type="password"
            id="password"
            v-model="password"
            size="full"
            required
          />
        </div>
        <div>
          <DefaultLabel text="비밀번호 확인" forId="confirmPassword" size="small" />
          <DefaultTextfield
            type="password"
            id="confirmPassword"
            v-model="confirmPassword"
            size="full"
            required
          />
        </div>
      </DefaultFormRow>

      <!-- 생년월일과 입사일 -->
      <DefaultFormRow marginBottom="20px" gap="10px" align="betweenEqual">
        <div>
          <DefaultLabel text="생년월일" forId="dob" size="small" />
          <DefaultTextfield
            type="date"
            id="dob"
            v-model="dob"
            size="full"
            required
          />
        </div>
        <div>
          <DefaultLabel text="입사일" forId="joinDate" size="small" />
          <DefaultTextfield
            type="date"
            id="joinDate"
            v-model="joinDate"
            size="full"
            required
          />
        </div>
      </DefaultFormRow>

      <!-- 우편번호와 주소 -->
      <DefaultLabel text="우편번호" forId="zipCode" size="small"/>
      <DefaultFormRow marginBottom="20px">
        <DefaultTextfield
          id="zipCode"
          v-model="zipCode"
          size="small"
          placeholder="우편번호"
          :disabled="true"
          required
        />
        <DefaultButton
          color="gray"
          @click="openModal"
          size="large"
        >
          주소 검색
        </DefaultButton>
      </DefaultFormRow>

      <DefaultLabel text="주소" forId="address" size="small" />
      <DefaultTextfield
        id="address"
        v-model="address"
        size="full"
        placeholder="주소를 입력하세요"
        :disabled="true"
        required
        marginBottom="20px"
      />

      <!-- 상세주소 입력 -->
      <DefaultLabel text="상세 주소" forId="detailAddress" size="small" />
      <DefaultTextfield
        id="detailAddress"
        v-model="detailAddress"
        size="full"
        placeholder="상세 주소를 입력하세요"
      />

      <!-- 저장 버튼 -->
      <DefaultFormRow align="center" marginTop="20px">
        <DefaultButton
          marginRight="5px"
          @click="handleSubmit">
          가입하기
        </DefaultButton>
        <DefaultButton
          color="gray"
          @click="onGoBack">
          돌아가기
        </DefaultButton>
      </DefaultFormRow>

    </form>
  </div>
  <KakaoAddressModal
    :visible="isModalOpen"
    @close="closeModal"
    @selectAddress="handleSelectAddress"
  />
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import KakaoAddressModal from '@/components/common/kakao/address/KakaoAddressModal.vue';
import EmailApi from '@/api/auth/EmailApi';
import UsersApi from '@/api/auth/UsersApi';
import { toast } from 'vue3-toastify';

// 라우터 사용 설정
const router = useRouter();

const userName = ref('');
const email = ref('');
const phone = ref('');
const dob = ref('');
const joinDate = ref('');
const department = ref('');
const team = ref('');  // 팀을 위한 상태 추가
const position = ref('');
const password = ref('');
const confirmPassword = ref('');

// 인증 코드 입력값
const verificationCode = ref('');
const verificationCodeDisable = ref(false);

// 타이머 관련 상태
const countdown = ref(0);
let timerInterval = null;

/**
 * 카카오 주소 API
 */
const zipCode = ref('');
const address = ref('');
const detailAddress = ref('');
const isModalOpen = ref(false);

function openModal() {
  isModalOpen.value = true;
}
function closeModal() {
  isModalOpen.value = false;
}
function handleSelectAddress(payload) {
  // payload = { address: ..., zipCode: ... }
  address.value = payload.address;
  zipCode.value = payload.zipCode;
}

/**
 * 타이머 시작 함수
 * 5분(300초)부터 1초마다 감소
 */
 function startTimer() {
  countdown.value = 300; // 300초 = 5분
  verificationCode.value = '';
  verificationCodeDisable.value = false;
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    if (countdown.value > 0) {
      countdown.value--;
    } else {
      clearInterval(timerInterval);
    }
  }, 1000);
}

/**
 * 인증 메일 발송 버튼 클릭 시
 *  - 백엔드에 email 보내서 인증코드 생성 & 메일 발송 요청
 */
async function sendEmailVerification() {
  if (!email.value) {
    toast.error("이메일을 입력하세요");
    return;
  }

  const response = await EmailApi.mailSend({ 
    email: email.value 
  });

  if (response.status === 200) {
    // 인증 메일 발송 후 타이머 시작(약간의 오차가 있을 수 있음)
    // 인증 실패시 백엔드 호출하는동안에도 멈춰있어서 오차가 있을 수 있음
    startTimer();
    toast.info(response.data.message);
  } else {
    toast.error(response.data.message);
  }
}

/**
 * 인증 확인 버튼 클릭 시
 *  - 백엔드에 인증코드 보내서 검증
 */
async function sameVerification() {
  /**
   * 
   * 
   * 
   *  verificationCode는 백엔드에서 암호화 된 값으로 해줘야하나?
   *  이후 암호화 된 값을 백엔드에서 검증해야하나?
   * 
   * 
   * 
   */
  const response = await EmailApi.mailVerify({ 
    email: email.value,
    code: verificationCode.value
  });

  if (response.status === 200) {
    verificationCodeDisable.value = true;
    toast.info(response.data.message);
    if (timerInterval) clearInterval(timerInterval); // 타이머 중지
  } else {
    toast.error(response.data.message);
  }
}

/**
 * 회원 가입 벡엔드 호출
 *  - 폼 제출 시 호출되는 함수
 *  - 폼은 주로 클라이언트에서 데이터의 유효성을 확인하거나 기본적인 입력값이 있는지 체크하는 용도
 */
const formRef = ref(null);
async function handleSubmit() {
  // formRef를 통해 폼 요소의 유효성을 검사합니다.
  if (!formRef.value.checkValidity()) {
    formRef.value.reportValidity();
    return;
  }

  if (password.value !== confirmPassword.value) {
    toast.warning('비밀번호가 일치하지 않습니다');
    return;
  }

  if (!verificationCode.value) {
    toast.warning('인증코드를 입력하세요');
    return;
  }

  console.log(formRef);

  const response = await UsersApi.createUser({
    userName: userName.value,
    email: email.value,
    phone: phone.value,
    dob: dob.value,
    joinDate: joinDate.value,
    department: department.value,
    team: team.value,
    position: position.value,
    zipCode: zipCode.value,
    address: address.value,
    detailAddress: detailAddress.value,
    password: password.value,
    verificationCode: verificationCode.value
  });

  if (response.status === 200) {
    toast.info(response.data.message);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    onGoBack();
  } else {
    toast.error(response.data.message);
  }

  // 서버로 데이터를 전송하는 로직을 추가하세요
  console.log('회원가입 완료:', {
    userName: userName.value,
    email : email.value,
    phone: phone.value,
    dob: dob.value,
    joinDate: joinDate.value,
    // department: department.value,
    // team: team.value,
    // position: position.value,
    zipCode: zipCode.value,
    address: address.value,
    detailAddress: detailAddress.value,
    password: password.value,
    verificationCode: verificationCode.value
  });
}

const onGoBack = () => {
  router.push('login');
};
</script>

<style scoped>
.container {
  margin-top: 80px;
  max-width: 600px;
}
.card {
  border: 1px solid #a3a3a3;
}
.system-header {
  text-align: center;
  margin-bottom: 40px;
}
.system-title {
  font-size: 2rem;
  font-weight: 900;
}
.system-subtitle {
  font-size: 0.9rem;
  color:#6c757d;
  margin-top:8px;
}
#zipCode {
  max-width: 30%; /* 우편번호 필드의 너비를 50%로 설정 */
}
/* 모바일에서는 두 개의 필드가 한 줄에 나타나도록 강제 */
@media (max-width: 650px) {
  .container {
    margin-top: 60px;
    margin-bottom: 30px;
    padding: 0px 40px 0px 40px;
  }
  .system-title {
    font-size: 1.8rem;
  }
  .system-subtitle {
    font-size: 0.8rem;
  }
}
@media (max-width: 500px) {
  .system-title {
    font-size: 1.3rem;
  }
  .system-subtitle {
    font-size: 0.7rem;
  }
}
</style>
