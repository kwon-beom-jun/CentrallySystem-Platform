<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': !isMobile }">
      <h2 class="content-title">영수증 신청 내역 조회</h2>
      <p class="content-sub-title">월별 영수증 신청 내역 확인 페이지</p>

      <!-- 월 선택 셀렉트 -->
      <DefaultFormRow marginBottom="10px" align="right">
        <DefaultLabel text="날짜(월) 선택 :" forId="monthSearch" size="small" />
        <DefaultTextfield
          type="month"
          id="monthSearch"
          v-model="selectedMonth"
          size="small"
          @change="filterByMonth"
        />
      </DefaultFormRow>

      <!-- ─── 조회 결과 없는 경우 ─── -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        />
      </div>

      <div v-if="data.length">
        <!-- ─── 테이블 보기 ─── -->
        <DefaultTable
          class="receipt-table"
          :columns="columns"
          :data="data"
          :showTable="!isMobile"
          :rowClick="openEditModal"
        />

        <!-- ─── 카드 레이아웃 (모바일) ─── -->
        <div class="card-layout" v-if="isMobile">
          <div class="card" v-for="(item, idx) in data" :key="idx">
            <!-- 카드 헤더 (발행일 + 수정 버튼) -->
            <div class="card-header">
              <p class="card-title">{{ item.date }}</p>

              <div class="card-actions">
                <DefaultButton
                  size="small"
                  color="gray"
                  customHeight="24px"
                  @click.stop="openEditModal(item)"
                >
                  보기
                </DefaultButton>
              </div>
            </div>

            <!-- 카드 바디 -->
            <div class="card-body">
              <p class="card-text">
                <strong>총 인원(당사자 포함) : </strong>
                <span @click="togglePeopleList(item)" style="cursor: pointer">
                  {{ item.peopleCount  }}명
                </span>
              </p>
              <div v-if="showPeopleList(item)">
                <div class="people-list">
                  <p
                    v-for="person in item.people"
                    :key="person.name"
                    class="people-list-item"
                  >
                    [ 일행 ] {{ person.name }} ({{ person.department }} -
                    {{ person.team }})
                  </p>
                </div>
              </div>

              <p class="card-text">
                <strong>결재 상태 : </strong>
                <span :class="statusColor(item.statusText)">
                  {{ item.statusText }}
                </span>
              </p>

              <p
                v-if="item.statusText === '반려' && item.rejectedReason"
                class="card-text text-danger ms-1"
              >
                • {{ item.rejectedReason }}
              </p>

              <!-- 결재자 목록 -->
              <p class="card-text">
                <strong>결재자 : </strong>
                <span @click="toggleApproverList(idx)" style="cursor: pointer">
                  {{ item.approvers.length }}명
                </span>
              </p>
              <div v-if="showApproverList(idx)">
                <div class="people-list">
                  <p
                    v-for="ap in item.approvers"
                    :key="ap.userId"
                    class="people-list-item"
                  >
                    [{{ ap.stateText }}] {{ ap.name }} ({{ ap.department }}-{{ ap.team }})
                  </p>
                </div>
              </div>

              <p class="card-text">
                <strong>구분/사유 : </strong> {{ item.type }} /
                {{ item.reason }}
              </p>
              <p class="card-text">
                <strong>금액 : </strong> {{ item.amount }}
              </p>
              <p class="card-text">
                <strong>금액/인원수 : </strong>
                {{ calculateAmountPerPerson(item) }}
              </p>
              <p>
                <strong class="card-text">영수증 사진 : </strong>
                <a
                  class="card-text"
                  @click.prevent="openPreviewModal(item.receipt)"
                  style="cursor: pointer; color: blue"
                >
                  {{ item.receiptName }}
                </a>
              </p>
            </div>
          </div>
        </div>

        <!-- 페이지네이션 -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>

    <!-- 이미지 미리보기 모달 -->
    <div
      v-if="isPreviewVisible"
      class="modal preview-modal"
      @click="closePreviewModalOnOutsideClick"
    >
      <div
        class="preview-modal-content"
        @mousedown="startDrag"
        @mousemove="onDrag"
        @mouseup="endDrag"
        @mouseleave="endDrag"
        @touchstart="startDrag"
        @touchmove="onDrag"
        @touchend="endDrag"
      >
        <img
          :src="previewImage"
          :class="{ zoomed: isZoomed }"
          class="preview-modal-image"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`,
          }"
          @dblclick="toggleZoom"
          @touchstart="toggleZoom"
        />
      </div>
    </div>

    <!-- 개인 영수증 히스토리 모달 -->
    <ReceiptDetailViewModal
      :isVisible="historyModalVisible"
      :receipt="editingReceipt"
      @close="historyModalVisible = false"
      @updated="fetchMetadata(currentPage)"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import DefaultTable from "@/components/common/table/DefaultTable.vue";
import DefaultButton from "@/components/common/button/DefaultButton.vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultTextfield from "@/components/common/textfield/DefaultTextfield.vue";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import ReceiptDetailViewModal from "@/components/receipt/ReceiptDetailViewModal.vue";
import DefaultPagination from "@/components/common/pagination/DefaultPagination.vue";
import ReceiptsApi from "@/api/receipt/ReceiptsApi";
import { useAuthStore } from "@/store/auth";
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";
import { usePreviewModal } from "@/utils/preview-modal";
import { toast } from "vue3-toastify";

/* ────── 스토어 ────── */
const authStore = useAuthStore();
const store = useUserDirectoryStore();

/* ────── 반응형 여부 ────── */
const isMobile = ref(window.innerWidth <= 650);
const updateIsMobile = () => (isMobile.value = window.innerWidth <= 650);

/* ────── 페이지네이션 ────── */
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);

/* ────── 수정 모달 ────── */
// const editModalVisible  = ref(false);
const editingReceipt = ref(null);
const historyModalVisible = ref(false);

/* ────── 미리보기 모달 ────── */
const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  openPreviewModal,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag,
} = usePreviewModal();
function closePreviewModalOnOutsideClick(e) {
  if (!e.target.classList.contains("preview-modal-image")) {
    isPreviewVisible.value = false;
  }
}

/* ────── 테이블/카드 데이터 ────── */
const data = ref([]);
const noData = ref(false);
const columns = [
  { key: "date", label: "발행일", width: 120 },
  { key: "type", label: "구분", width: 100 },
  { key: "peopleCount", label: "총 인원", width: 80 },
  { key: "reason", label: "사유", width: 150 },
  { key: "amount", label: "금액", width: 80 },
  { key: "amountPerPerson", label: "금액/인원", width: 80 },
  {
    key: "statusText",
    label: "결제 상황",
    width: 80,
    customClass: (value) => {
      if (value === "신청") return "text-blue";
      if (value === "승인") return "text-green";
      if (value === "반려") return "text-red";
      return "";
    },
  },
];

/* ────── 페이지 변경 ────── */
function onPageChange(page) {
  currentPage.value = page;
  fetchMetadata(page);
}

/* ────── 금액/인원 계산 ────── */
function calculateAmountPerPerson(item) {
  const amount = parseInt(item.amount.replace(/[^0-9]/g, ""), 10);
  const total = item.peopleCount ?? (item.people.length + 1);  // 안전망
  return Math.floor(amount / total).toLocaleString();
}

/* ────── 카드 토글(참여자/결재자) ────── */
const openedIndex = ref(null); // 참여자
const openedApproverIdx = ref(null); // 결재자
const togglePeopleList = (i) =>
  (openedIndex.value = openedIndex.value === i ? null : i);
const showPeopleList = (i) => openedIndex.value === i;
const toggleApproverList = (i) =>
  (openedApproverIdx.value = openedApproverIdx.value === i ? null : i);
const showApproverList = (i) => openedApproverIdx.value === i;

/* ────── 월 선택 ────── */
const selectedMonth = ref(getCurrentYearMonth());
function getCurrentYearMonth() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  return `${yyyy}-${mm}`; // 예: "2025-04"
}

/* ────── 월 선택 시 ────── */
function filterByMonth() {
  currentPage.value = 1;
  fetchMetadata(1);
}

/* ────── 데이터 조회 ────── */
async function fetchMetadata(page = 1) {
  const pageSize = isMobile.value ? 4 : 10;
  const params = {
    page: page - 1,
    size: pageSize,
    yearMonth: selectedMonth.value, // 예: "2025-04"
  };
  try {
    const res = await ReceiptsApi.getReceiptsByUserIdWithStatus(
      authStore.getUserId,
      params
    );
    const receiptPage = res.data; // { content, totalPages, ... }

    /* 변환 */
    const transformedList = receiptPage.content.map((r) => {
      /* 참가자 */
      const peopleArr = (r.participantsList || []).map((p) => ({
        name: p.participantName || `User${p.participantUserId}`,
        department: p.department ?? "",
        team: p.team ?? "",
      }));

      /* 결재선 → 화면용 */
      const approverArr = (r.approvalLines || []).map((al) => ({
        userId: al.approverUserId,
        name: al.approverName,
        department: al.department,
        team: al.team,
        approvalRole: al.approvalRole, // 1=결재, 2=합의
        approvalStatus: al.approvalStatus,
        stateText: al.rejectedAt ? "반려" : al.approvalStatus ? "승인" : "대기",
        approvalType: al.approvalRole === 1 ? "결재" : "합의",
        rejectedReason: al.rejectedReason,
      }));

      /* 🟢 추가 : 영수증 전체의 반려 사유(첫 반려자 기준) */
      const rejectedReason =
        approverArr.find(ap => ap.rejectedReason)?.rejectedReason || "";

      const statusText = (() => {
        if (!r.status) return "";
        switch (r.status) {
          case "REQUEST":   return "신청";
          case "APPROVED":  return "승인";
          case "REJECTED":  return "반려";
          case "WAITING":   return "대기";
          case "CLOSED":    return "마감";
          default:          return "";
        }
      })();

      return {
        date: r.submissionDate,
        type: r.category?.categoryName || "",
        categoryId: r.category?.categoryId ?? null,
        reason: r.reason,
        amount: Number(r.amount ?? 0).toLocaleString(),
        receiptName: r.attachment ? r.attachment.fileName : "영수증 미등록",
        receipt: r.attachment ? r.attachment.fileUrl : "",
        people: peopleArr,
        approvers: approverArr,
        peopleCount: peopleArr.length + 1,
        amountPerPerson: 0, // 잠시 0으로, 아래에서 재계산
        receiptId: r.receiptId,
        amountRaw: r.amount ?? 0,
        statusText,
        rejectedReason,
      };
    });

    /* 금액/인원 재계산 */
    data.value = transformedList.map((item) => ({
      ...item,
      amountPerPerson: calculateAmountPerPerson(item),
    }));

    noData.value = !data.value.length;
    totalPages.value = receiptPage.totalPages;

    /* 모바일이면 스크롤 맨 위로 */
    if (isMobile.value) window.scrollTo(0, 0);
  } catch (err) {
    toast.error("영수증 조회 중 오류가 발생했습니다");
    console.error(err);
  }
}

/* ────── 상세 모달 오픈 ────── */
function openEditModal(row) {
  editingReceipt.value = {
    id: row.receiptId,
    date: row.date,
    type: row.type,
    categoryId: row.categoryId,
    amount: row.amountRaw?.toString() ?? "",
    reason: row.reason,
    receiptName: row.receiptName,
    receipt: row.receipt,
    participants: [...row.people],
    approvers: row.approvers.map((a) => ({
      ...a,
      approvalType: a.approvalType ?? (a.approvalRole === 1 ? "결재" : "합의"),
      rejectedReason: a.rejectedReason,
    })),
    statusText: row.statusText,
    rejectedReason: row.rejectedReason,
  };
  historyModalVisible.value = true;
}

function statusColor(txt) {
  if (txt === '승인') return 'text-success';
  if (txt === '반려') return 'text-danger';
  if (txt === '신청') return 'text-primary';
  return 'text-secondary';
}

/* ────── 마운트 ────── */
onMounted(async () => {
  window.addEventListener("resize", updateIsMobile);
  await fetchMetadata(currentPage.value);
  await store.refresh();
});
</script>

<style scoped>
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}

.reason {
  margin-top: 10px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 10px;
}

.list-group-item,
.list-group {
  font-size: 0.875em !important;
}

.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

.now-label {
  cursor: pointer;
  color: #0d6efd;
}

.now-label:hover {
  text-decoration: underline;
}

.drag-handle {
  cursor: grab;
  user-select: none;
}

.drag-handle:active {
  cursor: grabbing;
}

.align-items-center {
  margin-bottom: 0px !important;
}

/* 선택 토글용 글자 버튼 */
.approval-option {
  cursor: pointer;
  padding: 2px 6px;
  /* border-radius: 4px; */
  color: #39393a; /* 기본 회색 */
  border: 1px solid #8e8e8f; /* 기본 얇은 회색 테두리 */
  user-select: none;
  margin: 0;
}

.approval-option + .approval-option {
  margin-left: -1px; /* 경계선 겹침 처리 */
}

.approval-option-right {
  margin-right: 7px;
}
.approval-option.active {
  color: #0d6efd; /* 선택 시 파란색 */
  font-weight: 900;
  background: #0d6dfd25;
}
/* ── 미리보기 모달 ───────────────────────────── */
.preview-modal {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}

/* ─── 카드 헤더 버튼 일렬 배치 ─────────────────── */
.card-actions {
  display: flex; /* 가로 한 줄 */
  flex-wrap: nowrap; /* 줄바꿈 방지 */
  gap: 4px; /* 버튼 간격 */
  margin-left: auto;
}

/* DefaultButton 내부 <button> 폭 덮어쓰기 */
.card-actions :deep(button) {
  width: auto !important; /* 100% → auto */
  min-width: 50px; /* 필요 시 최소 너비 지정 */
  padding: 2px 6px; /* XS 버튼 느낌 */
  line-height: 1.3;
}
.card-header {
  display: flex;
  align-items: center;
}
@media (max-width: 650px) {
  .list-group-item,
  .list-group {
    font-size: 0.8em !important;
  }

  .form-group {
    margin-bottom: 10px;
  }
}
</style>
