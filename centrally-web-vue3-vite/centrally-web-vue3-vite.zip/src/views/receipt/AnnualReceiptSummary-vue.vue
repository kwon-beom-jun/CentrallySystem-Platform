<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 년도별 요약</h2>
      <p class="content-sub-title">년도별 영수증 현황 요약 페이지</p>

      <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="d-flex align-items-center">
          <DefaultTextfield
            type="year"
            id="yearInput"
            v-model="selectedYear"
            size="small"
            @change="fetchData"
            validationType="number"
          />
          <label class="me-2">&nbsp; 년도</label>
        </div>
      </div>

      <!-- DefaultTable 컴포넌트 사용 -->
      <DefaultTable
        :columns="columns"
        :data="data"
        :footerData="footerData"
        :showTable="!isMobile"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';

// 상태 정의
const selectedYear = ref('2024');
const data = ref([]);
const totalRequested = ref(0);
const totalApproved = ref(0);
const totalRejected = ref(0);
const totalPending = ref(0);
const isMobile = ref(false);  // 모바일 여부에 따른 테이블 렌더링

// 테이블의 컬럼 정의
const columns = ref([
  { key: 'month', label: '월', width: 50 },
  { key: 'requested', label: '총', width: 80 },
  { key: 'approved', label: '승인', width: 80 },
  { key: 'rejected', label: '반려', width: 80 },
  { key: 'pending', label: '대기', width: 80 }
]);

// 더미 데이터
const dummyData = [
  { month: '1월', requested: 1000000, approved: 800000, rejected: 100000, pending: 100000 },
  { month: '2월', requested: 1200000, approved: 900000, rejected: 200000, pending: 100000  },
  { month: '3월', requested: 800000, approved: 500000, rejected: 100000, pending: 200000  },
  { month: '4월', requested: 1500000, approved: 1300000, rejected: 100000, pending: 100000   },
  { month: '5월', requested: 1200000, approved: 1100000, rejected: 100000, pending: 200000   },
  // 추가 데이터...
];

// 데이터 가져오기 함수
const fetchData = () => {
  // 더미 데이터로 시뮬레이션
  data.value = dummyData.filter(() => {
    // 모든 연도를 표시하므로 필터링 필요 없음
    return true;
  });

  // 총 합계 계산
  totalRequested.value = data.value.reduce((sum, item) => sum + item.requested, 0);
  totalApproved.value = data.value.reduce((sum, item) => sum + item.approved, 0);
  totalRejected.value = data.value.reduce((sum, item) => sum + item.rejected, 0);
  totalPending.value = data.value.reduce((sum, item) => sum + item.pending, 0);

  // 푸터 데이터 계산
  footerData.value = [
    '총 합계',
    totalRequested.value.toLocaleString() + '원',
    totalApproved.value.toLocaleString() + '원',
    totalRejected.value.toLocaleString() + '원',
    totalPending.value.toLocaleString() + '원'
  ];
};

// 푸터 데이터 (빈 배열로 초기화)
const footerData = ref([]);

// 컴포넌트가 마운트되면 데이터 가져오기
onMounted(fetchData);
</script>

<style scoped>
.mb-3 {
  margin-bottom: 20px !important;
}
</style>
