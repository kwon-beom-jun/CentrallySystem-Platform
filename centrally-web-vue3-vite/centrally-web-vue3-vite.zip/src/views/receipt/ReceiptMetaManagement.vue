<template>
  <div class="content content-wrapper">
    <h2 class="content-title">영수증 설정 관리</h2>
    <p class="content-sub-title">Receipt Meta Management</p>

    <!-- ───────── 기본 합의자(고정) 관리 구역 헤더 ───────── -->
    <div class="hr-label"><span>기본 합의자(고정) 관리</span></div>

    <!-- 🔹 기본-합의자(고정) 관리 패널 -->
    <section v-if="isAdmin" class="soft-box">
      <DefaultFormRow align="between" marginBottom="5px">
        <DefaultLabel
          text="기본 합의자(고정) 관리"
        />
        <!-- +고정 버튼 → 사용자 검색 드롭다운 열기 -->
        <DefaultButton
          class="btn-xs square me-2"
          @click="showSearch = !showSearch"
        >
          + 고정 등록
        </DefaultButton>
      </DefaultFormRow>

      <!-- 검색 드롭다운 (toggle) -->
      <UserSearchDropdown
        v-if="showSearch"
        class="mt-2"
        :keepSearchValue="false"
        placeholder="이름(이메일) 검색"
        inputSize="full"
        :includeCurrentUser="true"
        @userSelected="addFixedUser"
      />

      <!-- draggable 리스트 -->
      <draggable
        v-model="fixedApprovers"
        item-key="userId"
        tag="ul"
        class="list-group mt-2"
        handle=".drag-handle"
        @end="saveOrder"
      >
        <template #item="{ element, index }">
          <li
            class="list-group-item d-flex align-items-center justify-content-between"
          >
            <DefaultFormRow>
              <span class="drag-handle me-2">≡</span>
              <DefaultLabel
                :text="`${index + 1}. ${element.userName} [${element.email}] ${element.department} - ${element.team}`"
                size="small"
                marginLeft="10px"
              />
            </DefaultFormRow>

            <button
              type="button"
              class="btn btn-sm btn-outline-danger square-btn"
              @click.stop="removeFixedUser(index)"
            >
              ×
            </button>
          </li>
        </template>
      </draggable>
    </section>


    <!-- ───────── 카테고리 관리 구역 헤더 ───────── -->
    <div class="hr-label"><span>카테고리 관리</span></div>

    <section class="soft-box">
      <DefaultFormRow align="between" marginBottom="5px">
        <DefaultLabel
          text="카테고리 관리"
        />
        <DefaultButton
          v-if="isAdmin"
          @click="showModal"
        >
          카테고리 등록
        </DefaultButton>
      </DefaultFormRow>

      <!-- 카테고리 테이블 -->
      <DefaultTable
        :columns="columns"
        :data="categoryData"
        @delete-row="handleDelete"
        :fixedHeader="true"
        :scroll="true"
        :scrollHeight="400"
        :rowClick="handleRowClick"
        :selectHeight="'28px'"
        :buttonHeight="'28px'"
        :minRows="8"
      />
    </section>

    <!-- 등록/수정 모달 -->
    <ReceiptsCategoryCreateModal
      v-model:isVisible="isModalVisible"
      :isCreate="isCreate"
      :form="form"
      @save="handleSave"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import draggable from 'vuedraggable'
import UserSearchDropdown from '@/components/auth/UserSearchDropdown.vue'
import DefaultApproverApi from '@/api/receipt/ReceiptsDefaultApproverApi'
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultTable  from '@/components/common/table/DefaultTable.vue';
import ReceiptsCategoryCreateModal from '@/components/receipt/ReceiptsCategoryCreateModal.vue';
import ReceiptsCategoryApi from '@/api/receipt/ReceiptsCategoryApi';
import { useHrmStore } from '@/store/hrm';
import { toast } from 'vue3-toastify';

/* ───── 상태 ───── */
const hrmStore         = useHrmStore();
const isAdmin          = ref(false);
const isModalVisible   = ref(false);
const isCreate         = ref(true);
const categoryData     = ref([]);
const form             = ref({ id:null, category:'', maxAmount:0 });

/* ───── 테이블 컬럼 ───── */
const columns = [
  { key:'category',   label:'유형',          width:120,  align: 'center' },
  { key:'maxAmount',  label:'최대 금액(원)',  width:100,  align: 'center' },
  {
    key:'delete',     label:'', width:70, type:'button',
    buttonText:'삭제', buttonColor:'red', buttonSize:'full-small',
    emit:'delete-row', vIf: () => isAdmin.value               // ← 관리자인 경우만 렌더
  }
];

/* ───── 데이터 로딩 ───── */
async function fetchCategories() {
  const { data } = await ReceiptsCategoryApi.getCategories();
  categoryData.value = data.map(c => ({
    id:         c.categoryId,
    category:   c.categoryName,
    maxAmount:  c.limitPrice
  }));
}

/* ───── 버튼 & 콜백 ───── */
function showModal() {
  isCreate.value = true;
  form.value = { id:null, category:'', maxAmount:0 };
  isModalVisible.value = true;
}

/* 행 클릭 → 수정 모달 */
function handleRowClick(row) {
  if (!isAdmin.value) return;               // (선택) 관리자만 수정
  isCreate.value = false;                   // 수정 모드
  form.value = {                            // 선택 행 데이터 주입
    id        : row.id,
    category  : row.category,
    maxAmount : row.maxAmount
  };
  isModalVisible.value = true;              // 모달 열기
}

/* 모달 저장 완료 */
async function handleSave() {
  /* 실제 환경에서는 POST/PUT 이후 fetchCategories() 호출 */
  await fetchCategories();          // 백엔드 데이터 재동기화
  isModalVisible.value = false;
}

/* 테이블 삭제 버튼 */
async function handleDelete(row) {
  try {
    await ReceiptsCategoryApi.disableCategory(row.id);
    toast.success('카테고리를 비활성화했습니다');
    await fetchCategories();
  } catch(e) {
    toast.error('비활성화 실패');
  }
}

/* ───────────────────────── 고정 합의자(Pinned Approver) 상태 ───────────────────────── */
const fixedApprovers = ref([])          // [{userId, name, …, order}, …]
const showSearch     = ref(false)       // ‘+고정’ 드롭다운 토글

/* 최초로드 */
async function fetchFixedApprovers () {
  const { data } = await DefaultApproverApi.getDefaultApprovers({size:1000})
  fixedApprovers.value = (data.content ?? data)
    .sort((a,b)=>a.stepNo-b.stepNo) // 서버에서 이미 정렬돼 오더라도 한 번 더 안전하게
}

/* +고정 버튼으로 선택 */
async function addFixedUser (user) {
  const exists = fixedApprovers.value.some(u=>u.userId===user.userId)
  if (exists) return toast.warning('이미 고정돼 있습니다')

  // ① 서버 저장
  await DefaultApproverApi.createDefaultApprovers({
    userId: user.userId,
    userName: user.name,
    email: user.email,
    department: user.department,
    team: user.team,
    stepNo: fixedApprovers.value.length + 1
  })

  // ② 화면 추가
  fixedApprovers.value.push({
    userId: user.userId,
    userName: user.name,
    email: user.email,
    department: user.department,
    team: user.team,
    stepNo: fixedApprovers.value.length + 1
  })
  showSearch.value = false
  toast.success('고정 목록에 추가되었습니다')
}

/* 삭제 */
async function removeFixedUser (idx) {
  const target = fixedApprovers.value[idx]
  await DefaultApproverApi.deleteDefaultApprovers(target.userId)
  fixedApprovers.value.splice(idx,1)
  toast.success('고정 목록에 삭제되었습니다')
  saveOrder()                                 // order 다시 정렬
}

/* 드래그 후 순서 저장 */
async function saveOrder () {
  // 화면 배열 순서대로 order 재계산
  fixedApprovers.value.forEach((u,i)=>u.stepNo=i+1)

  // PATCH → [{userId, order}, …] 형태로 전송한다고 가정
  await DefaultApproverApi.reorderDefaultApprovers(
    fixedApprovers.value.map(({userId,stepNo})=>({userId,stepNo}))
  )
  toast.success('순서가 저장되었습니다')
}


/* 페이지 진입 시 불러오기 */
onMounted(async ()=>{
  isAdmin.value = hrmStore.isHrmAdmin
  await Promise.all([ fetchCategories(), fetchFixedApprovers() ])
})

/* ───── 초기화 ───── */
onMounted(async () => {
  isAdmin.value = hrmStore.isHrmAdmin;
  await fetchCategories();
});
</script>

<style scoped>
.hr-label{
  display:flex;
  align-items:center;
  margin:28px 0 14px;          /* 위·아래 간격 */
  font-weight:600;
  font-size:1rem;
  color:#333;
}
.hr-label::before,
.hr-label::after{
  content:"";
  flex:1;
  border-top:1px solid #d7d7d7;/* 가로줄 */
}
.hr-label span{                /* 가운데 글자 */
  white-space:nowrap;
  margin:0 12px;
}
.soft-box{
  background:#f9f9f9;     /* 흐린 회색 (원하면 더 흐리게 #fcfcfc) */
  border:1px solid #ededed;
  border-radius:6px;
  padding:14px 16px;
  margin-bottom: 70px;     /* 뒤 구역과 간격 */
}
.section-title {
  margin: 0;
  font-size: 1rem;
}
.drag-handle {
  cursor: grab;
  user-select: none;
}
.drag-handle:active {
  cursor: grabbing;
}
.square-btn {
  width: 15px;
  height: 15px;
  font-size: 0.6rem;
  padding: 0;
  border-radius: 3px;
}
.btn-xs.square {
  border-radius: 3px;
  padding: 1px 6px;
  font-size: 0.7rem;
}
</style>
