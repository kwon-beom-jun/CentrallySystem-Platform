<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 내역 관리</h2>
      <p class="content-sub-title">사용자들의 영수증 내역을 관리하는 페이지</p>

      <!-- 검색 영역 -->
      <div class="search-controls">
        <!-- 시작, 종료일 그룹 -->
        <DefaultFormRow align="right">
          <DefaultLabel text="시작 :" forId="startDate" size="small" />
          <DefaultTextfield
            type="date"
            id="startDate"
            v-model="startDate"
            size="xsmall"
          />
          <DefaultLabel text="종료 :" forId="endDate" size="small" marginLeft="10px" />
          <DefaultTextfield
            type="date"
            id="endDate"
            v-model="endDate"
            size="xsmall"
          />
        </DefaultFormRow>
        <!-- 이름 검색 그룹 -->
        <DefaultFormRow align="right" marginTop="7px">
          <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
          <UserSearchDropdown
            labelText="사용자 검색"
            inputId="nameSearch"
            inputSize="large"
            placeholder="사용자(이메일)을 검색해주세요"
            :includeCurrentUser="true"
            @userSelected="onUserSelected"
          />
          <DefaultButton 
            @click="search"
            size="small">
            조회
          </DefaultButton>
        </DefaultFormRow>
      </div>

      
      <!-- 조회 결과 없는 경우 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="data.length">
        <!-- 테이블: 사용자 ID/이메일 컬럼 추가됨 -->
        <DefaultTable
          :columns="columns"
          :data="data"
          @delete-row="deleteReceipt"
          @row-updated="handleRowUpdated"
          :rowClick="onRowClick"
          :selectHeight="'28px'"
          :buttonHeight="'28px'"
          :minRows="8"
        />

        <!-- 페이지네이션 -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>
    <ReceiptDetailViewModal
      :isVisible="detailVisible"
      :receipt ="selectedReceipt"
      @close="detailVisible = false"
      @updated="fetchDataFromServer(currentPage)"
    />

    <!-- 삭제 확인 AlertModal -->
    <AlertModal
      :isVisible="deleteConfirmVisible"
      :disableBackgroundClose="false"
      confirmText="확인"
      cancelText="취소"
      @close="deleteConfirmVisible = false"
      @confirm="deleteNotice"
    >
      <template #body>
        <!-- <p style="color: red;">※ 삭제 ※</p>
        <p style="color: red;">  -->
        <p>※ 삭제 ※</p>
        <p> 
          영수증을 삭제하면 복구되지 않습니다 <br/>
          영수증 삭제를 진행하겠습니까? <br/>
        </p>
        <p style="color: red;">
          영수증 삭제 [ R-ID : #{{ receiptToDelete.receiptId }} ]
        </p>
      </template>
    </AlertModal>
  </div>
  <!-- ─── 이미지 미리보기 모달 ─── -->
  <div
    v-if="isPreviewVisible"
    class="modal preview-modal"
    @click="closePreviewModalOnOutsideClick"
  >
    <div
      class="preview-modal-content"
      @mousedown="startDrag"
      @mousemove="onDrag"
      @mouseup="endDrag"
      @mouseleave="endDrag"
      @touchstart="startDrag"
      @touchmove="onDrag"
      @touchend="endDrag"
    >
      <img
        :src="previewImage"
        class="preview-modal-image"
        :class="{ zoomed: isZoomed }"
        :style="{
          transform: isZoomed
            ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
            : 'none',
          transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`,
        }"
        @dblclick="toggleZoom"
        @touchstart="toggleZoom"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import AlertModal from '@/components/common/modal/AlertModal.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import UserSearchDropdown from '@/components/auth/UserSearchDropdown.vue';
import ReceiptDetailViewModal from '@/components/receipt/ReceiptDetailViewModal.vue';
import { usePreviewModal } from '@/utils/preview-modal';

import ReceiptsApi from '@/api/receipt/ReceiptsApi';
import ReceiptsRequestApi from '@/api/receipt/ReceiptsRequestApi';
import HrmUserApi from '@/api/hrm/UsersApi'; // 🔥 [추가] 사용자 정보 불러오기
import { toast } from 'vue3-toastify';
// import { useAuthStore } from '@/store/auth'
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";

const noData = ref(false);
// const authStore = useAuthStore()

// =========== 메인 데이터 / 컬럼 정의 ===========

// 🔥 [수정] 사용자 ID/이메일 컬럼을 추가
const data = ref([]);
const columns = [
  { key: 'receiptId',     label: 'R-ID',        width: 40 },
  { key: 'userName',      label: '이름',         width: 50 },
  { key: 'userEmail',     label: '이메일',       width: 120 },
  { key: 'date',          label: '발행일',       width: 70 },
  { key: 'type',          label: '구분',         width: 80 },
  { key: 'peopleCount',   label: '총 인원',       width: 60 },
  { key: 'reason',        label: '사유',         width: 100 },
  { key: 'amount',        label: '금액',         width: 60 },
  { key: 'amountPerPerson', label: '금액/인원수', width: 80 },
  {
    key: 'status',
    label: '상태',
    width: 85,
    type: 'select',
    getOptions: () => {
    return [
      { value: 'REQUEST',  label: '신청' },
      { value: 'APPROVED', label: '승인' },
      { value: 'REJECTED',  label: '반려' },
      { value: 'WAITING', label: '대기' },
      { value: 'CLOSED',   label: '마감' },
    ];
    },
  },
  {
    key: "delete",
    label: "",
    width: 80,
    type: "button",
    buttonText: "삭제",
    buttonColor: "red",
    buttonSize: "full-small",
    emit: 'delete-row' 
  }
];

// ─────────────── 이미지 미리보기 ───────────────
const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag,
} = usePreviewModal();

function closePreviewModalOnOutsideClick(e) {
  if (!e.target.classList.contains('preview-modal-image')) {
    isPreviewVisible.value = false;
  }
}

// 검색 조건
const startDate = ref('');
const endDate = ref('');
const searchUserId = ref('');
// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

// 페이지네이션
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);
const tableViewSize = ref(8);

// 사용자 정보 캐싱
const userMap = ref({}); // { [userId]: { userId, email, ... }}

// 조회된 날짜 범위 (출력용)
const computedStartDate = ref('');
const computedEndDate = ref('');

// 상세 모달 표시 여부 + 선택된 행 데이터
const detailVisible = ref(false);
const selectedReceipt = ref({});

// 테이블 행 클릭 시 → 상세 모달 열기
function onRowClick(item) {
  selectedReceipt.value = item;   // 클릭된 행(영수증) 데이터
  detailVisible.value = true;     // 모달 열기
}

// =========== 서버 연동: 데이터 가져오기 ===========

// (1) 전체 사용자 목록 불러오기 → userMap 생성
async function fetchUserList() {
  const userRes = await HrmUserApi.getUsers();
  const users = userRes.data || [];
  const tempMap = {};
  users.forEach(u => {
    tempMap[u.userId] = {
      userId: u.userId,
      email: u.email,
      name: u.name
    };
  });
  userMap.value = tempMap;
}

// (2) 영수증 데이터 가져오기
async function fetchDataFromServer(page = 1) {
  const params = {
    startDate: startDate.value,
    endDate: endDate.value,
    userId: searchUserId.value,
    page: page - 1,
    size: tableViewSize.value,
  };

  const response = await ReceiptsApi.getReceiptsWithStatus(params);

  const receiptPage = response.data;
  const content = receiptPage.content || [];

  const transformed = content.map(r => {

    /* ── 결재선(approvers) ─────────────────────────── */
    const approverArr = (r.approvalLines || []).map(al => ({
      userId        : al.approverUserId,
      name          : al.approverName,
      department    : al.department,
      team          : al.team,
      approvalRole  : al.approvalRole,           // 1=결재, 2=합의
      approvalType  : al.approvalRole === 1 ? '결재' : '합의',
      approvalStatus: al.approvalStatus,         // true/false
      stateText     : al.rejectedAt
                      ? '반려'
                      : al.approvalStatus ? '승인' : '대기',
      rejectedReason: al.rejectedReason
    }));

    // ───── 카테고리 정보 ─────
    const categoryId   = r.category?.categoryId    ?? null;
    const categoryName = r.category?.categoryName  ?? '미지정';
    const limitPrice   = r.category?.limitPrice    ?? null;

    // userId, userEmail 가져오기 (userMap)
    const userInfo = userMap.value[r.userId] || { userId: r.userId, email: '알수없음' };

    const peopleArr = r.participantsList?.map(p => ({
      name: p.participantName,
      department: p.department,
      team: p.team
    })) || [];
    const peopleCount = peopleArr.length + 1

    const attachment = r.attachment;
    const receiptName = attachment ? attachment.fileName : '영수증 미등록';
    const receiptUrl = attachment ? attachment.fileUrl : '';

    const amountVal = r.amount ? parseInt(r.amount, 10) : 0;
    const amountStr = amountVal.toLocaleString() + '원';
    // 백엔드 예시:  "APPROVED" | "REJECTED" | "REQUEST" | ...
    const codeStr = typeof r.status === 'string'
        ? r.status.toUpperCase()
        : (r.status?.statusCode ?? 'REQUEST');  // 모두 대문자 통일
    const codeLabel = getStatusLabel(codeStr);

    const approverId = r.approverId ? r.approverId : ''; // 결재자 아이디
    const approverName = r.approverName ? r.approverName : ''; // 결재자 이름

    /* 반려 사유 */
    const rejectedReason =
      approverArr.find(ap => ap.rejectedReason)?.rejectedReason || '';

    return {
      // 🔥 사용자
      userId: userInfo.userId,
      userEmail: userInfo.email,
      userName: userInfo.name,
      // 영수증
      receiptId: r.receiptId,
      date: r.submissionDate,         // 예: '2025-04-03'
      type      : categoryName,               // ✅ “야근저녁”, “회식비” 등
      categoryId: categoryId,                 // 필요하면 화면/모달에서 사용
      limitPrice: limitPrice,                 // (예: 12 000 원 한도)
      reason: r.reason,               // 예: '야근'
      amount: amountStr,              // '80,000원'
      approvers: approverArr,
      rejectedReason: rejectedReason,
      peopleCount,
      participants : peopleArr,
      amountPerPerson: calculateAmountPerPerson(amountVal, peopleCount),
      status : codeStr,
      statusLabel: codeLabel, // 디테일 모달 표시용 (문자)
      receiptName,
      approverId,
      approverName,
      receipt: receiptUrl
    };
  });

  data.value = transformed;
  noData.value = data.value.length ? false : true;
  totalPages.value = receiptPage.totalPages;
  computedStartDate.value = startDate.value;
  computedEndDate.value = endDate.value;
}

// (3) 검색 버튼 클릭
function search() {
  currentPage.value = 1;
  fetchDataFromServer(currentPage.value);
}

// 영수증 상태 값 -> 라벨 치환
function getStatusLabel(code) {
  const map = {
    REQUEST  : '신청',
    APPROVED : '승인',
    REJECTED : '반려',
    WAITING  : '대기',
    CLOSED   : '마감',
  };
  return map[String(code).toUpperCase()] ?? '알수없음';
}

/** 금액/인원 계산 */
function calculateAmountPerPerson(amountVal, peopleCount) {
  if (!peopleCount) return '0';
  const per = Math.floor(amountVal / peopleCount);
  return per.toLocaleString() + '원';
}

// 페이지 변경 시 실행 (페이지네이션 클릭)
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
}

// UserSearchDropdown에서 선택 시 호출되는 이벤트 핸들러
function onUserSelected(selectedUser) {
  searchUserId.value = selectedUser.userId;
}

// 영수증 상태 수정
async function handleRowUpdated(updatedRow) {
  
    // 사용자 ID를 path param으로 보냄
    // const userId = updatedRow.userId;
    // API 호출
    // await ReceiptsRequestApi.forceChangeStatus(userId, decisionList);

    /*   forceChangeStatus( receiptId , newStatus )   */
    await ReceiptsRequestApi.forceChangeStatus(
          updatedRow.receiptId,      // path ①
          updatedRow.status          // path ② : 'REQUEST' | 'WAITING' | …
    );
    toast.success('상태가 수정되었습니다.');
    fetchDataFromServer(currentPage.value);
}


// 삭제할 영수증을 임시로 저장
const receiptToDelete = ref(null);
// AlertModal 표시 여부
const deleteConfirmVisible = ref(false);

// 사용자가 [삭제] 버튼 클릭 시
function deleteReceipt(row) {
  // 삭제할 데이터 저장
  receiptToDelete.value = row;
  // 모달 표시
  deleteConfirmVisible.value = true;
}

// 모달에서 [확인] 누르면 → 실제 삭제 실행
async function deleteNotice() {
  if (!receiptToDelete.value) return;

  const deleteData = receiptToDelete.value;

  // 모달 닫기 & 대상 초기화
  deleteConfirmVisible.value = false;
  receiptToDelete.value = null;

  // 백엔드 DELETE 호출
  await ReceiptsApi.deleteReceipt(deleteData.receiptId);
  // toast.success(`영수증 #${deleteData.receiptId}이(가) 삭제되었습니다.`);
  toast.success(`영수증이 삭제되었습니다.`);

  // 테이블 재조회
  fetchDataFromServer(currentPage.value);
}

// startDate/endDate 자동 보정
watch(startDate, (newStart) => {
  if (newStart > endDate.value) {
    endDate.value = newStart;
  }
});
watch(endDate, (newEnd) => {
  if (newEnd < startDate.value) {
    startDate.value = newEnd;
  }
});

// 날짜 자동 설정: YYYY-MM-DD 형태
function getTodayString() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// =========== onMounted: 초기 로드 ===========
// 1) 사용자 목록 → userMap
// 2) 영수증 목록
onMounted(async () => {
  await fetchUserList();
  userDirStore.refresh();
  
  startDate.value = getTodayString();
  endDate.value = getTodayString();

  fetchDataFromServer(currentPage.value);
});
</script>

<style scoped>
.content {
  transition: margin-right 0.3s ease;
}
.search-controls {
  margin-bottom: 10px;
}

/* 반응형 테이블/카드 (원본 그대로 유지) */
@media (min-width: 851px) {
  #nameSearch {
    font-size: 1rem;
  }
}

@media (max-width: 850px) {
  .btn-primary {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
    margin-bottom: 10px;
  }
}

@media (min-width: 1920px) {
  .navbar-text {
    font-size: 1.5rem; /* 더 큰 텍스트 크기 */
  }
}
</style>
