<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': sidebarVisible && !isMobile }">
      <h2 class="content-title">영수증 신청 내역 조회</h2>
      <p class="content-sub-title">월별 영수증 신청 내역 확인 페이지</p>

      <div class="d-flex justify-content-end align-items-center mb-3">
        <label for="monthSearch" class="mr-2">월 선택 :</label>
        <DefaultSelect
          id="monthSearch"
          v-model="selectedMonth"
          :options="monthOptions"
          @change="filterByMonth"
          size="xsmall"
        />
      </div>

      <!-- 테이블 보기 (큰 화면에서만 보임) -->
      <DefaultTable
        class="receipt-table"
        :columns="columns"
        :data="data"
        :openSidebar="openSidebar"
        :showTable="!isMobile"
      />

      <!-- 카드 레이아웃 (작은 화면에서만 보임) -->
      <div class="card-layout" v-if="isMobile">
        <div class="card" v-for="(item, index) in data" :key="index">
          <div class="card-header">
            <p class="card-title">{{ item.date }}</p>
          </div>
          <div class="card-body">
            <p class="card-text">
              <strong>인원 : </strong>
              <span @click="togglePeopleList(item)" style="cursor: pointer;">
                {{ item.people.length }}명
              </span>
            </p>
            <div v-if="showPeopleList(item)">
              <div class="people-list">
                <div class="people-list-header">명단</div>
                <p 
                  v-for="person in item.people" 
                  :key="person.name" 
                  class="people-list-item"
                >
                  {{ person.name }} ({{ person.department }} - {{ person.team }})
                </p>
              </div>
            </div>
            <p class="card-text"><strong>구분/사유 : </strong> {{ item.type }} / {{ item.reason }}</p>
            <p class="card-text"><strong>금액 : </strong> {{ item.amount }}</p>
            <p class="card-text"><strong>금액/인원수 : </strong> {{ item.amountPerPerson }}</p>
            <p>
              <strong class="card-text">영수증 사진 : </strong>
              <a class="card-text"
                @click.prevent="openPreviewModal(item.receipt)"
                style="cursor: pointer; color: blue;"
              >
                {{ item.receiptName }}
              </a>
            </p>
            <p class="card-text">
              <strong>반려 사유: </strong> {{ item.rejectionReason || 'X' }}
            </p>
            <p class="card-text">
              <strong>결제 상황: </strong>
              <span :class="getStatusClass(item.status)">{{ item.status }}</span>
            </p>
          </div>
        </div>
      </div>

      <!-- 페이지네이션 (공통 컴포넌트) -->
      <DefaultPagination
        :currentPage="currentPage"
        :totalPages="totalPages"
        :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange"
      />
    </div>

    <!-- 사이드바 추가 -->
    <div 
      :class="['sidebar-wrapper', { 'sidebar-visible': sidebarVisible }]"
      v-click-away="{ handler: closeSidebar, exclude: ['.receipt-table'] }"
    >
      <ReceiptSidebar 
        v-if="!isMobile" 
        :item="selectedItem" 
        :visible="sidebarVisible" 
        @close="closeSidebar"
        @preview-image="openPreviewModal"
      />
    </div>

    <!-- 이미지 미리보기 모달 -->
    <div v-if="isPreviewVisible" class="modal preview-modal" @click="closePreviewModalOnOutsideClick">
      <div
        class="preview-modal-content"
        @mousedown="startDrag"
        @mousemove="onDrag"
        @mouseup="endDrag"
        @mouseleave="endDrag"
        @touchstart="startDrag"
        @touchmove="onDrag"
        @touchend="endDrag"
      >
        <img
          :src="previewImage"
          :class="{ zoomed: isZoomed }"
          class="preview-modal-image"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
          }"
          @dblclick="toggleZoom"
          @touchstart="toggleZoom"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import ReceiptSidebar from './ReceiptSidebar.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultSelect from '@/components/common/select/DefaultSelect.vue';
import { usePreviewModal } from '@/utils/preview-modal';
// import axios from 'axios'; // 실제 서버 연동 시

// ==============================
// 미리보기 모달 관련 로직
// ==============================
const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  openPreviewModal,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag
} = usePreviewModal();

function closePreviewModalOnOutsideClick(event) {
  if (!event.target.classList.contains('preview-modal-image')) {
    isPreviewVisible.value = false;
  }
}

// ==============================
// 메인 데이터 / 테이블 관련
// ==============================
const data = ref([]); // 실제 서버에서 받아온 데이터 저장

/**
 * columns 정의
 * - key: 실제 데이터 속성명
 * - label: 테이블 헤더 표시 이름
 * - customClass: (선택) 셀에 적용할 동적 클래스 로직
 */
const columns = [
  { key: 'date', label: '발행일', width: 100  },
  { key: 'type', label: '구분', width: 50  },
  { key: 'peopleCount', label: '인원수', width: 60  },
  { key: 'reason', label: '사유', width: 200  },
  { key: 'amount', label: '금액', width: 60  },
  { key: 'amountPerPerson', label: '금액/인원수', width: 100  },
  {
    key: 'status',
    label: '결제 상황',
    width: 80,
    customClass: (value) => {
      if (value === '신청') return 'text-blue';
      if (value === '승인') return 'text-green';
      if (value === '반려') return 'text-red';
      return '';
    },
  },
];

const monthOptions = [
  { value: '01', label: '1월' },
  { value: '02', label: '2월' },
  { value: '03', label: '3월' },
  { value: '04', label: '4월' },
  { value: '05', label: '5월' },
  { value: '06', label: '6월' },
  { value: '07', label: '7월' },
  { value: '08', label: '8월' },
  { value: '09', label: '9월' },
  { value: '10', label: '10월' },
  { value: '11', label: '11월' },
  { value: '12', label: '12월' },
];

// ==============================
// 페이지네이션 관련
// ==============================
const currentPage = ref(1);       // 현재 페이지
const totalPages = ref(1);        // 서버에서 받아올 총 페이지 수
const visiblePageCount = ref(5);  // 페이지네이션에서 보여줄 최대 페이지 버튼 수

/**
 * 페이지가 바뀔 때마다 서버에 해당 페이지 데이터 요청
 */
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
}

// 예시: 금액/인원수 계산
function calculateAmountPerPerson(item) {
  const amountNum = parseInt(item.amount.replace(/[^0-9]/g, ''), 10);
  const peopleCount = item.people?.length || 0;
  return peopleCount > -1
    ? Math.floor(amountNum / (peopleCount+1)).toLocaleString() + '원'
    : 'N/A';
}

/**
 * 서버에서 데이터 가져오는 함수 (백엔드 연동)
 * - 실제로는 axios.get(...) 등을 사용하여 
 *   백엔드에 { page, selectedMonth } 등 필요 파라미터를 보내고,
 *   응답으로 data, totalPages 등을 받아온 뒤 세팅.
 */
// async function fetchDataFromServer(page = 1) {
async function fetchDataFromServer() {
  // const response = await axios.get('/api/receipts', {
  //   params: { page, month: selectedMonth.value },
  // });
  // data.value = response.data.items;
  // totalPages.value = response.data.totalPages;

  // --------------------------
  //      예시: mockData
  // --------------------------
  const mockData = [
    {
      date: '2024-08-01',
      type: '식비',
      reason: '야근',
      amount: '100,000원',
      receiptName: '영수증 예시',
      receipt: '/receipt/receipt_sample/receipt_example.jpg',
      status: '반려',
      rejectionReason: '미지원 항목으로 인한 반려',
      people: [
        { department: 'SI사업본부', team: '프레임워크', name: '권범준', position: '책임' },
        { department: 'SI사업본부', team: '프레임워크', name: '홍길동', position: '선임' },
      ],
    },
    {
      date: '2024-08-02',
      type: '식비',
      reason: '야근',
      amount: '110,000원',
      receiptName: '영수증 예시',
      receipt: '/receipt/receipt_sample/receipt_example.jpg',
      status: '신청',
      rejectionReason: '',
      people: [
        { department: 'SI사업본부', team: '프레임워크', name: '권범준', position: '책임' },
        { department: 'SI사업본부', team: '프레임워크', name: '홍길동', position: '선임' },
        { department: 'SI사업본부', team: '프레임워크', name: '심청이', position: '선임' },
      ],
    },
    // page=2,3일때는 다른 mockData를 준다고 가정할 수도 있음
  ];

  // 서버 응답처럼 가정
  data.value = mockData.map(item => ({
    ...item,
    peopleCount: item.people.length,
    amountPerPerson: calculateAmountPerPerson(item),
  }));

  totalPages.value = 3; // 예: 서버에서 받은 총 페이지 수
}

// ==============================
// 반응형 / 사이드바 로직
// ==============================
const isMobile = ref(window.innerWidth <= 650);
function updateIsMobile() {
  isMobile.value = window.innerWidth <= 650;
}
window.addEventListener('resize', updateIsMobile);

const selectedItem = ref(null);
const sidebarVisible = ref(false);
function openSidebar(item) {
  if (!isMobile.value) {
    selectedItem.value = item;
    sidebarVisible.value = true;
  }
}
function closeSidebar() {
  sidebarVisible.value = false;
}

// ==============================
// 상태값 -> CSS 클래스 변환 (모바일용)
// ==============================
function getStatusClass(status) {
  if (status === '신청') return 'status-pending';
  if (status === '승인') return 'status-approved';
  if (status === '반려') return 'status-rejected';
  return '';
}

// ==============================
// 모바일 인원 목록 토글
// ==============================
const openedIndex = ref(null);
function togglePeopleList(index) {
  openedIndex.value = openedIndex.value === index ? null : index;
}
function showPeopleList(index) {
  return openedIndex.value === index;
}

// ==============================
// 월별 필터
// ==============================
const selectedMonth = ref(getCurrentMonth());
function getCurrentMonth() {
  const now = new Date();
  const month = now.getMonth() + 1;
  return month < 10 ? `0${month}` : `${month}`;
}
function filterByMonth() {
  // 바뀐 월( selectedMonth.value )을 이용해 
  // fetchDataFromServer(1) 다시 호출하거나, 서버 파라미터로 보내면 됨
  currentPage.value = 1;
  fetchDataFromServer(1);
}

// 컴포넌트 초기 로드시 1페이지 데이터 호출
onMounted(() => {
  fetchDataFromServer(currentPage.value);
});
</script>

<style scoped>
.content {
  transition: margin-right 0.3s ease;
}
.content-expanded {
  margin-right: 300px;
}

/* 사이드바 */
.sidebar-wrapper {
  position: fixed;
  right: 0;
  top: 0;
  width: 300px;
  height: 100%;
  transform: translateX(100%);
  transition: transform 0.3s ease;
  z-index: 1000;
}
.sidebar-visible {
  transform: translateX(0);
}
.sidebar {
  width: 100%;
  height: 100%;
  background-color: #f9f9f9;
  border-left: 1px solid #ddd;
  padding: 20px;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
}

.mb-3 {
  margin-bottom: 20px !important;
}

/* 상태별 텍스트 스타일 */
.status-approved {
  color: green;
  font-weight: bold;
}
.status-pending {
  color: blue;
  font-weight: bold;
}
.status-rejected {
  color: red;
  font-weight: bold;
}

/* columns의 customClass에서 사용하는 예시 */
.text-red {
  color: red;
  font-weight: bold;
}
.text-blue {
  color: blue;
  font-weight: bold;
}
.text-green {
  color: green;
  font-weight: bold;
}

/* 인원 목록 스타일 */
.people-list {
  font-size: 0.7rem;
  max-height: 150px;
  overflow-y: auto;
  margin-top: 10px;
  border-top: 1px solid #ddd;
  padding-top: 10px;
}
.people-list-header {
  font-weight: bold;
  margin-bottom: 5px;
}
.people-list-item {
  padding: 1px 0;
  margin: 0;
  margin-left: 10px;
}

/* 이미지 미리보기 모달 */
.preview-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}
</style>
