<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 년도별 요약</h2>
      <p class="content-sub-title">연도별 영수증 현황 요약 페이지</p>

      <DefaultFormRow marginBottom="10px" align="right">
        <DefaultLabel text="년도 :" forId="yearInput" size="small" />
        <!-- 연도 입력: type="year" (실제로 내부에서 number 처리) -->
        <DefaultTextfield
          type="number"
          id="yearInput"
          v-model="selectedYear"
          size="small"
          @change="onYearChange"
        />
      </DefaultFormRow>

      <!-- DefaultTable 컴포넌트 사용 -->
      <DefaultTable
        :columns="columns"
        :data="tableData"
        :footerData="footerData"
        :showTable="!isMobile"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import { useAuthStore } from '@/store/auth'
import { toast } from 'vue3-toastify';
import ReceiptsApi from '@/api/receipt/ReceiptsApi'; 

// Pinia store
const authStore = useAuthStore();

// 연도 선택 상태
const now = new Date();
const currentYear = now.getFullYear(); // 예: 2025

// 연도 선택 상태 (기본값: 현재 연도)
const selectedYear = ref(String(currentYear));

// 테이블에 표시할 데이터
const tableData = ref([]);
const footerData = ref([]);

// 컬럼 정의
const columns = [
  { key: 'monthLabel',  label: '월',   width: 50 },
  { key: 'waitingStr',  label: '대기', width: 80 },
  { key: 'requestStr',  label: '신청', width: 80 },
  { key: 'approvedStr', label: '승인', width: 80 },
  { key: 'rejectedStr', label: '반려', width: 80 },
  { key: 'closedStr',   label: '마감', width: 80 },
  { key: 'totalSumStr', label: '합계', width: 90 }
];

// 반응형 여부 (예시)
const isMobile = ref(false);

// 데이터 가져오기 함수
async function fetchYearlySummary() {
  const userId = authStore.getUserId;
  const params = { year: selectedYear.value }; // ex) year=2025
  
  // GET /receipts/user/{userId}/year-summary?year=XXXX
  const response = await ReceiptsApi.getReceiptByUserYearlySummary(userId, params);
  // 응답 구조: { year, monthlyList, totalRequested, totalApproved, totalRejected, totalSum }
  const data = response.data;

  // monthlyList: [{ month:1, requested:..., approved:..., rejected:..., totalSum:...}, ...]
  // 테이블에 맞게 변환
  tableData.value = data.monthlyList.map(m => ({
    monthLabel : `${m.month}월`,
    waitingStr : `${m.waiting.toLocaleString()}원`,
    requestStr : `${m.request.toLocaleString()}원`,
    approvedStr: `${m.approved.toLocaleString()}원`,
    rejectedStr: `${m.rejected.toLocaleString()}원`,
    closedStr  : `${m.closed.toLocaleString()}원`,
    totalSumStr: `${m.sum.toLocaleString()}원`,
  }));

  footerData.value = [
    '합계',
    `${data.totalWaiting.toLocaleString()}원`,
    `${data.totalRequest.toLocaleString()}원`,
    `${data.totalApproved.toLocaleString()}원`,
    `${data.totalRejected.toLocaleString()}원`,
    `${data.totalClosed.toLocaleString()}원`,
    `${data.totalSum.toLocaleString()}원`,
  ];
}


/**
 * 연도 입력이 변경되었을 때
 * - 4자리 숫자 형식인지 확인
 * - 아니면 경고 띄우고 현재 연도로 되돌림
 */
 function onYearChange() {
  const regex = /^\d{4}$/;
  if (!regex.test(selectedYear.value)) {
    toast.warning('년도를 4자리 숫자로 입력해주세요\n현재 연도로 대체합니다');
    selectedYear.value = String(currentYear);
  }
  // 유효하다면 API 호출
  fetchYearlySummary();
}

onMounted(() => {
  fetchYearlySummary();
});
</script>

<style scoped>
.mb-3 {
  margin-bottom: 20px !important;
}
</style>
