<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 년도별 요약</h2>
      <p class="content-sub-title">연도별 영수증 현황 요약 페이지</p>

      <DefaultFormRow marginBottom="10px" align="right">
        <DefaultLabel text="년도 :" forId="yearInput" size="small" />
        <!-- 연도 입력: type="year" (실제로 내부에서 number 처리) -->
        <DefaultTextfield
          type="number"
          id="yearInput"
          v-model="selectedYear"
          size="small"
          @change="onYearChange"
        />
      </DefaultFormRow>

      <!-- DefaultTable 컴포넌트 사용 -->
      <DefaultTable
        :columns="columns"
        :data="tableData"
        :footerData="footerData"
        :showTable="!isMobile"
      />
    </div>
  </div>
</template>

<script setup>
/* ───────────────────────────── imports ───────────────────────────── */
import { ref, onMounted }           from 'vue'
import { toast }                    from 'vue3-toastify'

import DefaultTable                 from '@/components/common/table/DefaultTable.vue'
import DefaultTextfield             from '@/components/common/textfield/DefaultTextfield.vue'
import DefaultLabel                 from '@/components/common/label/DefaultLabel.vue'
import DefaultFormRow               from '@/components/common/DefaultFormRow.vue'

import ReceiptsApi                  from '@/api/receipt/ReceiptsApi'
import { useAuthStore }             from '@/store/auth'

/* ─────────────────────────── reactive state ─────────────────────── */
const auth           = useAuthStore()
const isMobile       = ref(false)                       // 필요하면 resize 로직 추가
const now            = new Date()
const currentYear    = now.getFullYear()
const selectedYear   = ref(String(currentYear))

const tableData      = ref([])                          // 본문
const footerData     = ref([])                          // 푸터 합계 행

/* ──────────────────────── table column schema ───────────────────── */
const columns = [
  { key:'monthLabel',  label:'월',    width: 50, align: 'center' },
  { key:'waitingStr',  label:'대기',  width: 80, align: 'right' },
  { key:'requestStr',  label:'신청',  width: 80, align: 'right' },
  { key:'approvedStr', label:'승인',  width: 80, align: 'right' },
  { key:'rejectedStr', label:'반려',  width: 80, align: 'right' },
  { key:'closedStr',   label:'마감',  width: 80, align: 'right' },
  { key:'totalSumStr', label:'합계',  width: 90, align: 'right' }
]

/* ─────────────────────── helpers & formatters ───────────────────── */
const won = n => `${Number(n||0).toLocaleString()}원`

/* ─────────────────────── data fetch from API ───────────────────── */
async function fetchYearlySummary () {
  try {
    const { data } =
      await ReceiptsApi.getReceiptByUserYearlySummary(auth.getUserId, {
        year: selectedYear.value          // query param ?year=YYYY
      })

    /* ① 본문 행 */
    tableData.value = (data.monthlyList || []).map(m => ({
      monthLabel : `${m.month}월`,
      waitingStr : won(m.waiting),
      requestStr : won(m.request),
      approvedStr: won(m.approved),
      rejectedStr: won(m.rejected),
      closedStr  : won(m.closed),
      totalSumStr: won(m.sum)
    }))

    /* ② 푸터 합계 */
    footerData.value = [
      '합계',
      won(data.totalWaiting),
      won(data.totalRequest),
      won(data.totalApproved),
      won(data.totalRejected),
      won(data.totalClosed),
      won(data.totalSum)
    ]
  } catch (err) {
    console.error(err)
    toast.error('연도별 영수증 요약 조회 중 오류가 발생했습니다')
  }
}

/**
 * 연도 입력 변경 시 유효성 검사
 * - 4자리 숫자가 아니면 현재 연도로 되돌리고 경고
 */
function onYearChange () {
  if (!/^\d{4}$/.test(selectedYear.value)) {
    toast.warning('년도를 4자리 숫자로 입력해주세요\n현재 연도로 변경합니다')
    selectedYear.value = String(currentYear)
  }
  fetchYearlySummary()
}

/* ─────────────────────────── lifecycle ─────────────────────────── */
onMounted(fetchYearlySummary)
</script>

<style scoped>
.mb-3 {
  margin-bottom: 20px !important;
}
</style>
