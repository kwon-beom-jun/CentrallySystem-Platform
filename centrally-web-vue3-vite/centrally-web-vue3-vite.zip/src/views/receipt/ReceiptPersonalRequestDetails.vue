<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': sidebarVisible && !isMobile }">
      <h2 class="content-title">{{ userName }}님 영수증 신청 내역 조회</h2>
      <p class="content-sub-title">
        날짜: [{{ filteredStartDate }} ~ {{ filteredEndDate }}]
      </p>
      
      <!-- 뒤로가기 버튼 -->
      <DefaultButton 
        size="small" 
        align="left"
        color="gray"
        customHeight="30px"
        @click="goBack">
        뒤로가기
      </DefaultButton>

      <!-- 조회 결과 없을 때 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="!noData">
        <div class="d-flex align-items-center justify-content-end content-body-header">
          <span class="mr-2 all-click">전체 승인</span>
          <DefaultTextfield
            type="radio"
            name="approveAll" 
            class="approveAll" 
            id="approveAll"
            @change="toggleApproveAll" 
            v-model="selectAllDecision"
            value="2" 
            size="small"
          />
          <span class="mr-2 all-click">전체 반려</span>
          <DefaultTextfield
            type="radio"
            name="rejectAll" 
            class="rejectAll" 
            id="rejectAll"
            @change="toggleRejectAll" 
            v-model="selectAllDecision"
            value="3" 
            size="small"
          />
        </div>
        <hr />

        <!-- 테이블 보기 (큰 화면에서만 보임) -->
        <table class="table mt-3 receipt-table" id="dataTable" v-if="!isMobile">
          <thead>
            <tr>
              <th>식별 번호</th>
              <th>발행일</th>
              <th>총 인원</th>
              <th>구분</th>
              <th>사유</th>
              <th>금액</th>
              <th>영수증 사진</th>
              <th>승인</th>
              <th>반려</th>
              <th>반려사유</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in data"
              :key="index"
              @click="(e) => {
                const t=e.target.tagName;
                if(t!=='A' && t!=='INPUT') openEditModal(item);
              }"
            >
              <td class="text-ellipsis align-center">{{ item.receiptCode }}</td>
              <td class="date-cell align-center">{{ item.date }}</td>
              <td class="align-center">{{ item.peopleCount }}</td>
              <td class="text-ellipsis">{{ item.type }}</td>
              <td class="text-ellipsis">{{ item.reason }}</td>
              <td class="text-ellipsis align-right">{{ formatAmount(item.amount) }}원</td>
              <td class="text-ellipsis-picture" @click.stop>
                <a
                  href="#"
                  @click.stop.prevent="openPreviewModal(item.receipt)"
                  class="text-primary"
                >
                  {{ item.receiptName }}
                </a>
              </td>
              <td @click.stop>
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="approveRadio"
                  v-model="item.decision"
                  value="2"
                  @change="updateDecision()"
                />
              </td>
              <td @click.stop>
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="rejectRadio"
                  v-model="item.decision"
                  value="3"
                  @change="updateDecision()"
                />
              </td>
              <td @click.stop>
                <DefaultTextfield
                  size="full"
                  v-model="item.rejectReason"
                  :disabled="item.decision !== '3' && item.decision !== 3"
                />
              </td>
            </tr>
            <!-- 데이터 행이 8 개보다 적을 때 채워줄 Placeholder -->
            <tr
              v-for="n in fillerRows"
              :key="`ph-${n}`"
              class="placeholder-row"
              aria-hidden="true"
              :style="{ height: rowH + 'px' }"
            >
              <td v-for="i in 10" :key="i">&nbsp;</td>
            </tr>
          </tbody>
        </table>

        <!-- 카드 레이아웃 보기 (작은 화면에서만 보임) -->
        <div class="card-layout" v-if="isMobile">
          <div
            class="card"
            v-for="(item, index) in data"
            :key="index"
          >
            <div class="card-header">
              <p class="card-title">
                {{ item.date }} <br />
                [ 식별 번호 : {{ item.receiptCode }} ]
              </p>
              <div class="card-actions">
                <DefaultButton
                  size="small"
                  color="gray"
                  customHeight="24px"
                  @click.stop="openEditModal(item)"
                >
                  보기
                </DefaultButton>
              </div>
            </div>
            <div class="card-body">
              <p class="card-text">
                <strong>총 인원 : </strong>
                <span @click="togglePeopleList(item)" style="cursor: pointer;">
                  {{ item.peopleCount }}명
                </span>
              </p>
              <div v-if="showPeopleList(item)">
                <div class="people-list">
                  <!-- <div class="people-list-header">명단</div> -->
                  <p
                    v-for="person in item.people"
                    :key="person.name"
                    class="people-list-item"
                  >
                    {{ person.name }} ({{ person.department }} - {{ person.team }})
                  </p>
                </div>
              </div>
              <p class="card-text">
                <strong>구분/사유 : </strong>
                {{ item.type }} / {{ item.reason }}
              </p>
              <p class="card-text">
                <strong>금액 : </strong>
                {{ formatAmount(item.amount) }}
              </p>
              <p class="card-text">
                <strong>금액/인원수 : </strong>
                {{ calculateAmountPerPerson(item) }}
              </p>
              <p>
                <strong class="card-text">영수증 사진 : </strong>
                <a class="card-text"
                  @click.prevent="openPreviewModal(item.receipt)"
                  style="cursor: pointer; color: blue;"
                >
                  {{ item.receiptName }}
                </a>
              </p>
              <p class="card-text">
                <strong>결정: </strong>
                승인
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="approveRadio"
                  v-model="item.decision"
                  value="2"
                  @change="updateDecision()"
                />
                | 반려
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="rejectRadio"
                  v-model="item.decision"
                  value="3"
                  @change="updateDecision()"
                />
                <br>
              </p>
              <p class="card-text d-flex align-items-center">
                <strong>반려사유: </strong>
                <DefaultTextfield
                  v-model="item.rejectReason"
                  marginLeft="10px"
                  customHeight="32px"
                  size="full"
                  class="rejectReason ml-2"
                  :disabled="item.decision !== '3' && item.decision !== 3"
                  placeholder="사유 입력"
                  style="flex:1;"
                />
                <!-- <input
                  type="text"
                  class="form-control rejectReason ml-2"
                  v-model="item.rejectReason"
                  style="flex: 1;"
                  :disabled="item.decision !== '3' && item.decision !== 3"
                /> -->
              </p>
            </div>
          </div>
        </div>

        <!-- 저장 버튼 -->
        <DefaultButton align="right" @click="save">
          저장
        </DefaultButton>

        <!-- 페이지네이션 (공통 컴포넌트) -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />

        <!-- 사이드바 추가 -->
        <div 
          :class="['sidebar-wrapper', { 'sidebar-visible': sidebarVisible }]"
          v-click-away="{ handler: closeSidebar, exclude: ['.receipt-table'] }"
        >
          <ReceiptSidebar 
            v-if="!isMobile" 
            :item="selectedItem" 
            :visible="sidebarVisible" 
            @close="closeSidebar"
            @preview-image="openPreviewModal"
          />
        </div>
      </div>
      
      <!-- 이미지 미리보기 모달 -->
      <div
        v-if="isPreviewVisible"
        class="modal preview-modal"
        @click="closePreviewModalOnOutsideClick"
      >
        <div
          class="preview-modal-content"
          @mousedown="startDrag"
          @mousemove="onDrag"
          @mouseup="endDrag"
          @mouseleave="endDrag"
          @touchstart="startDrag"
          @touchmove="onDrag"
          @touchend="endDrag"
        >
          <img
            :src="previewImage"
            :class="{ zoomed: isZoomed }"
            class="preview-modal-image"
            :style="{
              transform: isZoomed
                ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
                : 'none',
              transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
            }"
            @dblclick="toggleZoom"
            @touchstart="toggleZoom"
          />
        </div>
      </div>
    </div>
  </div>

  <!-- 🆕 영수증 상세 모달 -->
  <ReceiptDetailViewModal
    :isVisible="historyModalVisible"
    :receipt="editingReceipt"
    @close="historyModalVisible = false"
    @updated="fetchDataFromServer(currentPage)" />

</template>

<script setup>
/* ──────────────────────────────── import ──────────────────────────────── */
import { ref, computed, onMounted, watch, nextTick } from 'vue'
import { useRouter, useRoute }             from 'vue-router'
import { toast }                           from 'vue3-toastify'

import DefaultTextfield       from '@/components/common/textfield/DefaultTextfield.vue'
import DefaultButton          from '@/components/common/button/DefaultButton.vue'
import DefaultPagination      from '@/components/common/pagination/DefaultPagination.vue'
import ReceiptSidebar         from './ReceiptSidebar.vue'
import ReceiptDetailViewModal from '@/components/receipt/ReceiptDetailViewModal.vue'

import { usePreviewModal }    from '@/utils/preview-modal'
import ReceiptsSearchApi      from '@/api/receipt/ReceiptsSearchApi'
import ReceiptsRequestApi     from '@/api/receipt/ReceiptsRequestApi'
import { useAuthStore }       from '@/store/auth'

/* ──────────────────────────────── 상수 ──────────────────────────────── */
const MOBILE_BP         = 1000          /* 화면폭 기준(px)                */
const MOBILE_PAGE_SIZE  = 4
const DESKTOP_PAGE_SIZE = 6

/* ──────────────────────────────── 반응형 상태 ──────────────────────────────── */
const isMobile = ref(window.innerWidth <= MOBILE_BP)
const pageSize = computed(() => (isMobile.value ? MOBILE_PAGE_SIZE : DESKTOP_PAGE_SIZE))
window.addEventListener('resize', () => { isMobile.value = window.innerWidth <= MOBILE_BP })

/* ──────────────────────────────── 라우터 & 스토어 ──────────────────────────────── */
const router = useRouter()
const route  = useRoute()
const auth   = useAuthStore()

/* ──────────────────────────────── 파라미터 ──────────────────────────────── */
const filteredStartDate = ref('')
const filteredEndDate   = ref('')
const userId   = ref('')
const userName = ref('')

/* ──────────────────────────────── 화면 상태 ──────────────────────────────── */
const data             = ref([])
const noData           = ref(false)
const currentPage      = ref(1)
const totalPages       = ref(1)
const visiblePageCount = ref(5)

/* ──────────────────────────────── 모달/사이드바 ──────────────────────────────── */
const sidebarVisible      = ref(false)
const selectedItem        = ref(null)
const editingReceipt      = ref(null)
const historyModalVisible = ref(false)

/* ──────────────────────────────── 전체 승인/반려 ──────────────────────────────── */
const selectAllDecision = ref('')

/* ──────────────────────────────── 프리뷰 모달 util ──────────────────────────────── */
const {
  isPreviewVisible, previewImage,
  isZoomed, zoomedPosition, zoomOrigin,
  openPreviewModal, toggleZoom,
  startDrag, onDrag, endDrag
} = usePreviewModal()

/* ──────────────────────────────── 포매터 & 헬퍼 ──────────────────────────────── */
const formatAmount = n => (+n || 0).toLocaleString()
const calculateAmountPerPerson = item =>
  item.peopleCount
    ? `${Math.floor(item.amountRaw / item.peopleCount).toLocaleString()} 원`
    : 'N/A'

/* ──────────────────────────────── watch (날짜 검증) ──────────────────────────────── */
watch(filteredStartDate, v => { if (v > filteredEndDate.value) filteredEndDate.value = v })
watch(filteredEndDate,   v => { if (v < filteredStartDate.value) filteredStartDate.value = v })

/* ──────────────────────────────── 데이터 매핑 ──────────────────────────────── */
function mapRow(raw) {
  const peopleArr = raw.participantsList || []
  const peopleCnt = peopleArr.length + 1
  const amountRaw = +(`${raw.amount}`.replace(/[^0-9]/g, '')) || 0

  return {
    /* 표 본문 */
    receiptId : raw.receiptId,
    receiptCode : raw.receiptCode,
    date      : raw.submissionDate,
    type      : raw.category?.categoryName ?? '',
    categoryId: raw.category?.categoryId ?? null,
    reason    : raw.reason,
    amount    : amountRaw.toString(),
    amountRaw,
    receiptName: raw.attachment?.fileName || '영수증',
    receipt     : raw.attachment?.fileUrl  || '',
    people      : peopleArr.map(p => ({
      name: p.participantName,
      department: p.department,
      team: p.team
    })),
    peopleCount     : peopleCnt,
    amountPerPerson : peopleCnt ? Math.floor(amountRaw / peopleCnt) : 0,
    /* 결재라인 */
    approvers: (raw.approvalLines || []).map(a => ({
      userId   : a.approverUserId,
      name     : a.approverName,
      department:a.department,
      team     : a.team,
      approvalRole : a.approvalRole,          // ← 추가
      isDefault    : a.approvalRole === 3,    // ← 추가(선택)  
      approvalType : a.approvalRole === 1 ? '결재' : '합의',   // 1=결재, 2·3=합의
      stateText    : a.rejectedAt      ? '반려'
                   : a.approvalStatus  ? '승인'
                                       : '대기',
      rejectedReason: a.rejectedReason
    })),
    statusText    : raw.status ?? '',
    rejectedReason: '',
    /* 결재(저장용) */
    decision     : '',
    rejectReason : ''
  }
}

/* ──────────────────────────────── 서버 통신 ──────────────────────────────── */
async function fetchDataFromServer(page = 1) {
  sidebarVisible.value = false

  const { data: dto } =
    await ReceiptsSearchApi.getMyPendingByDate(auth.getUserId, {
      userId     : userId.value,
      startDate  : filteredStartDate.value,
      endDate    : filteredEndDate.value,
      statusCodes: ['REQUEST'],
      page       : page - 1,
      size       : pageSize.value
    })

  data.value       = (dto.content || []).map(mapRow)
  totalPages.value = dto.totalPages || 1
  noData.value     = data.value.length === 0

  if (isMobile.value) window.scrollTo(0, 0)
}

/* ──────────────────────────────── 페이지 이동 ──────────────────────────────── */
function onPageChange(page) {
  currentPage.value = page
  fetchDataFromServer(page)
}

/* ──────────────────────────────── 승인/반려 제어 ──────────────────────────────── */
function toggleApproveAll() {
  data.value.forEach(r => {
    r.decision = selectAllDecision.value === '2' ? '2' : ''
    if (r.decision !== '3') r.rejectReason = ''     // 사유 초기화
  })
}
function toggleRejectAll() {
  data.value.forEach(r => {
    r.decision = selectAllDecision.value === '3' ? '3' : ''
    /* 반려 ALL 선택일 때는 그대로 두고, 해제되면 사유도 제거 */
    if (r.decision !== '3') r.rejectReason = ''
  })
}
function updateDecision() {
  /* 선택이 ‘승인’(2) 으로 바뀌면 반려 사유 제거 */
  data.value.forEach(r => {
    if (r.decision === '2' || r.decision == 2) r.rejectReason = ''
  })
  const allA = data.value.length && data.value.every(r => r.decision === '2')
  const allR = data.value.length && data.value.every(r => r.decision === '3')
  selectAllDecision.value = allA ? '2' : allR ? '3' : ''
}

/* ──────────────────────────────── 저장 ──────────────────────────────── */
async function save() {
  /* ── ‘반려’ 사유 입력 여부 검사 ───────────────── */
  const missing = data.value.find(r =>
      (r.decision === '3' || r.decision == 3) &&
      !(r.rejectReason?.trim())
  )
  if (missing) {
    toast.warning('반려 사유를 입력해주세요.')
    return
  }

  const payload = data.value
    .filter(r => r.decision == 2 || r.decision == 3   // 🔸 느슨비교(==)
         || r.decision === '2' || r.decision === '3')
    .map(r => ({
      receiptId   : r.receiptId,
      statusCode  : r.decision,
      rejectReason: r.rejectReason,
      approverId  : auth.getUserId,
      approverName: auth.getUser
    }))

  if (!payload.length) return toast.warning('승인 또는 반려된 항목이 없습니다.')

  await ReceiptsRequestApi.saveReceiptDecisions(userId.value, payload)
  toast.success('저장되었습니다.');
  selectAllDecision.value = '';
  fetchDataFromServer(currentPage.value)
}

/* ──────────────────────────────── 상세 모달 ──────────────────────────────── */
function openEditModal(row) {
  editingReceipt.value    = { ...row } // 그대로 전달
  historyModalVisible.value = true
}

/* ──────────────────────────────── 카드 인원 토글 ──────────────────────────────── */
const openedIndex = ref(null)
function togglePeopleList(row) { openedIndex.value = openedIndex.value === row ? null : row }
function showPeopleList(row)   { return openedIndex.value === row }

/* ──────────────────────────────── 사이드바 ──────────────────────────────── */
function closeSidebar() { sidebarVisible.value = false }

/* ──────────────────────────────── 이미지 미리보기 ──────────────────────────────── */
function closePreviewModalOnOutsideClick(e) {
  if (!e.target.classList.contains('preview-modal-image')) isPreviewVisible.value = false
}

/* ──────────────────────────────── 네비게이션 ──────────────────────────────── */
function goBack() {
  /* 뒤로가기 전에 모달/사이드바 확실히 닫기 */
  historyModalVisible.value = false
  sidebarVisible.value      = false
  isPreviewVisible.value    = false
  router.back()
}

/* ──────────────────────── 8개 이하 테이블 더미데이터 ──────────────────────── */
const rowH = ref(0)

/* 데스크톱 테이블이 8 행보다 적으면 빈 행을 채우기 위한 계산 */
const fillerRows = computed(() => {
  /* 모바일 카드 레이아웃일 때는 필요 없음 */
  if (isMobile.value) return 0
  const diff = DESKTOP_PAGE_SIZE - data.value.length
  return diff > 0 ? diff : 0
})
async function syncRowHeight () {
  await nextTick()                        // DOM 렌더 완료 후
  const tr = document.querySelector('#dataTable tbody tr:not(.placeholder-row)')
  rowH.value = tr ? tr.offsetHeight : 0
}
/* 데이터·창크기 변화마다 재계산 */
watch(data,    syncRowHeight, { deep:true })
watch(isMobile,syncRowHeight)
onMounted(     syncRowHeight)
window.addEventListener('resize', syncRowHeight)

/* ──────────────────────────────── 초기화 ──────────────────────────────── */
onMounted(() => {
  filteredStartDate.value = route.query.startDate || ''
  filteredEndDate.value   = route.query.endDate   || ''
  userId.value            = route.query.userId    || ''
  userName.value          = route.query.userName  || ''

  if (!userId.value) return goBack()              // 파라미터 이상 → 이전 페이지

  fetchDataFromServer()
})
</script>


<style scoped>
/* .mt-3 {
  margin-top: 0px !important;
} */
#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}
#dataTable td {
  vertical-align: middle;
  text-align: left;
}

hr {
  margin: 10px 0px 10px 0px;
}

/* 테이블 본문 폰트 사이즈 */
tbody {
  font-size: var(--table-body-font-size, 0.75rem);
}

.content {
  transition: margin-right 0.3s ease;
}

.content-sub-title {
  margin-bottom: 10px !important;
}

.content-expanded {
  margin-right: 300px;
}

.content-body-header {
  margin-top: 30px;
}

.text-primary {
  color: #c7573e;
  /* 원하는 하이퍼링크 색상으로 변경 */
  text-decoration: none;
  /* 하이퍼링크 밑줄 제거 */
}

/* 사이드바 */
.sidebar-wrapper {
  position: fixed;
  right: 0;
  top: 0;
  width: 300px;
  height: 100%;
  transform: translateX(100%);
  transition: transform 0.3s ease;
  z-index: 1000;
}

/* 사이드바가 보일 때 적용되는 클래스 */
.sidebar-visible {
  transform: translateX(0);
  /* 화면 안으로 슬라이드 */
}

/* 사이드바 내용물 스타일 유지 */
.sidebar {
  width: 100%;
  height: 100%;
  background-color: #f9f9f9;
  border-left: 1px solid #ddd;
  padding: 20px;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
}

/* 전체 승인/반려 */
.all-click {
  font-weight: bold;
  margin-left: 10px;
}

/* 카드 레이아웃 인원 목록 스타일 추가 */
.people-list {
  font-size: 0.7rem;
  max-height: 150px;
  overflow-y: auto;
  margin-top: 10px;
  border-top: 1px solid #ddd;
  padding-top: 10px;
}
.people-list-header {
  font-weight: bold;
  margin-bottom: 5px;
}
.people-list-item {
  padding: 1px 0;
  margin: 0;
  margin-left: 10px;
}

/* 이미지 미리보기 모달 */
.preview-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}

.approveRadio,
.rejectRadio {
  /* 축소 기준점을 중앙으로 설정 */
  transform-origin: center center;
  /* 수직 정렬 (inline 요소가 text-baseline이 아니라 middle에 맞춰지도록 함) */
  vertical-align: middle;
}

.mx-width-700 {
  margin-top: 50px;
}

.text-ellipsis {
  max-width: 60px;        /* 원하는 최대 폭 – 상황에 맞게 조절 */
  white-space: nowrap;     /* 줄바꿈 금지 */
  overflow: hidden;        /* 넘치는 글자 숨김  */
  text-overflow: ellipsis; /* ‘…’ 표시       */
}
.text-ellipsis-picture {
  max-width: 100px;        /* 원하는 최대 폭 – 상황에 맞게 조절 */
  white-space: nowrap;     /* 줄바꿈 금지 */
  overflow: hidden;        /* 넘치는 글자 숨김  */
  text-overflow: ellipsis; /* ‘…’ 표시       */
}

.date-cell {
  min-width: 80px;      /* 80px 확보 */
  white-space: nowrap;  /* 줄바꿈 방지 */
}

#dataTable th {
  text-align: center;          /* 헤더 전체 중앙정렬 */
}

#dataTable th:nth-child(1),
#dataTable td.align-center {
  text-align: center;
}

#dataTable td input.approveRadio,
#dataTable td input.rejectRadio {
  display: block;
  margin: 0 auto;           /* 좌우 중앙 */
}

/* 우측 정렬 보조 클래스 ─ 금액 열에 사용 */
#dataTable td.align-right {
  text-align: right;
}

/* 금액 헤더도 우측 정렬 (6번째 컬럼) */
/* #dataTable th:nth-child(6) {
  text-align: right;
} */

/* 실제 데이터 행만 hover (placeholder-row 제외) */
#dataTable tbody tr:not(.placeholder-row):hover td {
  background-color: #e7f1ff !important;
}

/* ─── 카드 헤더 버튼 일렬 배치 ─────────────────── */
.card-actions {
  display: flex; /* 가로 한 줄 */
  flex-wrap: nowrap; /* 줄바꿈 방지 */
  gap: 4px; /* 버튼 간격 */
  margin-left: auto;
}

/* DefaultButton 내부 <button> 폭 덮어쓰기 */
.card-actions :deep(button) {
  width: auto !important; /* 100% → auto */
  min-width: 50px; /* 필요 시 최소 너비 지정 */
  padding: 2px 6px; /* XS 버튼 느낌 */
  line-height: 1.3;
}
.card-header {
  display: flex;
  align-items: center;
}

/* ───────── style scoped – 더미 행 모양만 살짝 ───────── */
.placeholder-row td{
  background:#fafafa;
  /* border-left:1px solid #e0e0e0; */
  padding:8px;
}
.placeholder-row td:first-child{border-left:none;}
@media (max-width: 1000px) {
  .page-link {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
  }

  .page-item {
    font-size: 0.75rem;
  }

  .pagination {
    margin: 3px 0 60px 0;
  }
}

@media (max-width: 650px) {
  .content-body-header {
    margin-top: 40px;
  }
  .rejectReason {
    width: 100%;
  }
}

@media (max-width: 700px) {
  .approveRadio,
  .rejectRadio {
    /* 라디오 크기 축소 */
    transform: scale(0.7);
    /* 라디오가 작아지는 만큼 위치 조정이 필요하다면 여기에 마진 설정 가능 */
    margin: 0 2px;
  }
}
</style>
