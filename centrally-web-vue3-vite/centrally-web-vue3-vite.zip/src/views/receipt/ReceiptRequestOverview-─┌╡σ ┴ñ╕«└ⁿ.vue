<template>
  <div class="content content-wrapper">
    <h2 class="content-title">영수증 신청 내역 조회 현황</h2>
    <p class="content-sub-title">
      검색 날짜: [{{ startDate }} ~ {{ endDate }}]
    </p>

    <!-- ───── 검색 영역 ───── -->
    <div class="search-controls">
      <!-- 시작/종료일 + 조회버튼 -->
      <DefaultFormRow align="right">
        <DefaultLabel text="시작 :" forId="startDate" size="small" />
        <DefaultTextfield
          id="startDate"
          type="date"
          v-model="startDate"
          size="xsmall"
        />

        <DefaultLabel
          text="종료 :"
          forId="endDate"
          size="small"
          marginLeft="10px"
        />
        <DefaultTextfield
          id="endDate"
          type="date"
          v-model="endDate"
          size="xsmall"
        />

        <DefaultButton size="small" marginLeft="10px" @click="search">
          조회
        </DefaultButton>
      </DefaultFormRow>
    </div>

    <!-- KPI 카드 (행이 3개 이하일 때만 노출) -->
    <!-- <div v-if="tableData.length && tableData.length <= 20" class="kpi-wrap"> -->
    <div v-if="tableData.length" class="kpi-wrap">
      <div class="kpi-card">
        <div class="kpi-title">총 영수증 건수</div>
        <div class="kpi-value">{{ summary.cnt }}건</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-title">총 금액</div>
        <div class="kpi-value">{{ formatNumber(summary.total) }}원</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-title">건당 평균 금액</div>
        <div class="kpi-value">{{ formatNumber(summary.avg) }}원</div>
      </div>
    </div>

    <!-- ───── 결과 없을 때 ───── -->
    <div v-if="noData">
      <v-img
        class="mx-width-700 no-results-found"
        src="/img/common/state/001.png"
      />
    </div>

    <!-- ───── 결과 테이블 / 카드 ───── -->
    <div v-if="tableData.length">
      <DefaultTable
        :columns="columns"
        :data="tableData"
        :rowClick="goToDetail"
        :showTable="!isMobile"
      />

      <div class="card-layout" v-if="isMobile">
        <div
          class="card"
          v-for="(item, idx) in tableData"
          :key="idx"
          @click="goToDetail(item)"
        >
          <div class="card-header d-flex justify-content-between mb-2">
            <p class="card-title">{{ item.userName }}</p>
            <p class="card-title">{{ item.submissionDate }}</p>
          </div>
          <div class="card-body">

            <!-- 총 인원·금액/인원수 -->
            <p class="card-text">
              <strong>총 인원(당사자 포함) : </strong>
              {{ item.peopleCount }}명
            </p>

            <p class="card-text">
              <strong>금액/인원수 : </strong>
              {{ formatNumber(item.amountPerPerson) }}원
            </p>

            <!-- ✅ 결재자 표시 / 토글 -->
            <p class="card-text">
              <strong>결재자: </strong>
              <span @click.stop="toggleApproverList(idx)" style="cursor:pointer">
                {{ item.approvers.length }}명
              </span>
            </p>
            <div v-if="showApproverList(idx)">
              <div class="people-list">
                <p v-for="ap in item.approvers"
                  :key="ap.userId"
                  class="people-list-item">
                  [{{ ap.stateText }}] {{ ap.name }} ({{ ap.department }}-{{ ap.team }})
                </p>
              </div>
            </div>
            
            <p class="card-text"><strong>구분: </strong>{{ item.category }}</p>
            <p class="card-text"><strong>금액: </strong>{{ formatNumber(item.amount) }}원</p>
            <p class="card-text"><strong>사유: </strong>{{ item.reason }}</p>
          </div>
        </div>
      </div>

      <DefaultPagination
        :currentPage="currentPage"
        :totalPages="totalPages"
        :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from "vue";
import { useRouter } from "vue-router";
import ReceiptsSearchApi from "@/api/receipt/ReceiptsSearchApi";
import HrmUserApi from "@/api/hrm/UsersApi";
import DefaultTable from "@/components/common/table/DefaultTable.vue";
import DefaultButton from "@/components/common/button/DefaultButton.vue";
import DefaultPagination from "@/components/common/pagination/DefaultPagination.vue";
import DefaultTextfield from "@/components/common/textfield/DefaultTextfield.vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import DefaultLabel from "@/components/common/label/DefaultLabel.vue";
import { useAuthStore } from "@/store/auth";

/* ---------- 상태 ---------- */
const router = useRouter();
const auth = useAuthStore();
const myId = auth.getUserId; // 로그인 사용자

const startDate = ref("");
const endDate = ref("");
const noData = ref(false);

const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);

const tableData = ref([]);
const isMobile = ref(window.innerWidth < 850);

/* ---------- 컬럼 ---------- */
const columns = [
  { key: "userName", label: "유저", width: 50 },
  { key: "submissionDate", label: "일자", width: 100 },
  { key: "peopleCount",      label: "총 인원",  width: 80  },
  { key: "category", label: "구분", width: 80 },
  { key: "reason", label: "사유", width: 150 },
  { key: "amount", label: "금액", width: 80 },
  { key: "amountPerPerson",  label: "금액/인원",width: 90  }, 
];

/* ---------- 헬퍼 ---------- */
const formatNumber = (n) => (!n ? 0 : n.toLocaleString());

/* ---------- 데이터 로드 ---------- */
async function fetchData(page = 1) {
  const pageSize = isMobile.value ? 4 : 10;
  const params = {
    startDate: startDate.value,
    endDate: endDate.value,
    statusCode: 1, // 대기
    page: page - 1,
    size: pageSize,
  };

  const { data } = await ReceiptsSearchApi.getMyPendingByDate(
    myId,
    params
  );

  tableData.value = (data.content || []).map(r => {
    /* ── 총 인원(참가자 + 본인) 계산 ── */
    const peopleArr    = r.participantsList || [];
    const peopleCount  = peopleArr.length + 1;
    const amount       = Number(r.amount ?? 0);
    const amountPerPerson = peopleCount
      ? Math.floor(amount / peopleCount)
      : 0;

    return {
      ...r,                                         // 원본 필드
      category  : r.category?.categoryName ?? '',
      peopleCount,
      amountPerPerson,

      approvers : (r.approvalLines || []).map(al => ({
        userId    : al.approverUserId,
        name      : al.approverName,
        department: al.department,
        team      : al.team,
        stateText : al.rejectedAt      ? '반려'
                  :  al.approvalStatus ? '승인'
                                        : '대기',
      })),
    };
  });
  
  totalPages.value = data.totalPages || 1;
  noData.value = tableData.value.length === 0;

  if (isMobile.value) window.scrollTo(0, 0);

  await mapUserIdsToNames();
}

/* ID→이름 매핑 */
async function mapUserIdsToNames() {
  const ids = [...new Set(tableData.value.map((r) => r.userId))];
  if (!ids.length) return;

  const users = await HrmUserApi.getUsersByIds(ids);
  const userMap = Object.fromEntries(users.map((u) => [u.userId, u.name]));

  tableData.value = tableData.value.map((r) => ({
    ...r,
    userName: userMap[r.userId] || "알 수 없음",
  }));
}

/* ---------- 상태 ---------- */
const openedApproverIdx = ref(null);         // ⬅ 추가

/* ---------- 이벤트 / 헬퍼 ---------- */
function toggleApproverList(i) {             // ⬅ 추가
  openedApproverIdx.value =
    openedApproverIdx.value === i ? null : i;
}
function showApproverList(i) {               // ⬅ 추가
  return openedApproverIdx.value === i;
}

/* ---------- 이벤트 ---------- */
function search() {
  currentPage.value = 1;
  fetchData(1);
}
function onPageChange(p) {
  currentPage.value = p;
  fetchData(p);
}
function updateIsMobile() {
  const next = window.innerWidth < 850;
  if (isMobile.value !== next) {      // 값이 변한 경우에만
    isMobile.value = next;
    currentPage.value = 1;            // 현재 page 리셋
    fetchData(1);                     // pageSize 재적용
  }
}
function goToDetail(item) {
  router.push({
    name: "ReceiptPersonalRequestDetails",
    query: {
      startDate: startDate.value,
      endDate: endDate.value,
      userId: item.userId,
      userName: item.userName,
    },
  });
}

const summary = computed(() => {
  const cnt   = tableData.value.length;
  const total = tableData.value.reduce((sum, r) => sum + r.amount, 0);
  const avg   = cnt ? Math.floor(total / cnt) : 0;
  return { cnt, total, avg };
});

/* ---------- 날짜 유효성 ---------- */
watch(startDate, (s) => {
  if (s > endDate.value) endDate.value = s;
});
watch(endDate, (e) => {
  if (e < startDate.value) startDate.value = e;
});

/* ---------- 마운트 ---------- */
onMounted(() => {
  const today = new Date().toISOString().slice(0, 10);
  startDate.value = today;
  endDate.value = today;

  updateIsMobile();
  fetchData(1);
  window.addEventListener("resize", updateIsMobile);
});
</script>

<style scoped>
#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}

/* 상태별 색상 설정 */
.status-complete {
  color: blue; /* 완료 상태는 파란색 */
}
.status-in-progress {
  color: red; /* 진행중 상태는 빨간색 */
}
.align-items-center {
  margin-bottom: 0px !important;
}
.bnt-search {
  margin: 0 !important;
}
.search-controls {
  margin-bottom: 10px;
}
.kpi-wrap{display:flex;gap:12px;margin-bottom:14px;}
.kpi-card{flex:1;background:#fafafa;border:1px solid #e0e0e0;border-radius:8px;
          padding:12px 16px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.04);}
.kpi-title{font-size:.8rem;color:#606060;margin-bottom:4px;}
.kpi-value{font-size:1.1rem;font-weight:700;color:#333;}

@media (min-width: 851px) {
  #nameSearch {
    font-size: 1rem;
  }
  .card {
    display: none; /* 카드 숨기기 */
  }
  .table {
    display: table; /* 테이블 표시 */
  }
}

@media (max-width: 850px) {
  .btn-primary {
    font-size: 0.75rem; /* 모바일 버튼 글자 크기 줄이기 */
    padding: 0.3rem 0.6rem; /* 모바일 버튼 패딩 줄이기 */
    margin-bottom: 10px;
  }
  /* ---------------------------------- */
  .table {
    display: none; /* 테이블 숨기기 */
  }
  .bnt-print {
    margin-bottom: 40px;
  }
  .kpi-wrap{gap:8px;}
  .kpi-card{padding:8px 10px;}
  .kpi-title{font-size:.6rem;}
  .kpi-value{font-size:.8rem;}
}
</style>
