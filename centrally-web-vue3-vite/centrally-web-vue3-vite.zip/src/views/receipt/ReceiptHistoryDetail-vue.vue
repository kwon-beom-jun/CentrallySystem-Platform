<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': sidebarVisible && !isMobile }">
      <h2 class="content-title">권범준님 영수증 내역 상세 조회</h2>
      <!-- 검색된 날짜 범위 표시 -->
      <div class="content-sub-title">
        <p>날짜: [{{ filteredStartDate }} ~ {{ filteredEndDate }}]</p>
      </div>
      <div class="btn-back">
        <!-- 뒤로가기 버튼 -->
        <DefaultButton
          size="small"
          align="left"
          color="gray"
          customHeight="30px"
          @click="goBack">
          뒤로가기
        </DefaultButton>
      </div>

      <!-- 테이블 보기 (큰 화면) -->
      <DefaultTable
        class="receipt-table"
        :showTable="!isMobile"
        :columns="columns"
        :data="data"
        :rowClick="openSidebar"
      />

      <!-- 카드 레이아웃 보기 (작은 화면에서만 보임) -->
      <div class="card-layout" v-if="isMobile">
        <div
          class="card"
          v-for="(item, index) in data"
          :key="index"
        >
          <div class="card-header">
            <p class="card-title">{{ item.date }}</p>
          </div>
          <div class="card-body">
            <p class="card-text">
              <strong>인원 : </strong>
              <span @click="togglePeopleList(item)" style="cursor: pointer;">
                {{ item.people.length }}명
              </span>
            </p>
            <div v-if="showPeopleList(item)">
              <div class="people-list">
                <div class="people-list-header">명단</div>
                <p
                  v-for="person in item.people"
                  :key="person.name"
                  class="people-list-item"
                >
                  {{ person.name }} ({{ person.department }} - {{ person.team }})
                </p>
              </div>
            </div>
            <p class="card-text">
              <strong>구분/사유 : </strong> 
              {{ item.type }} / {{ item.reason }}
            </p>
            <p class="card-text">
              <strong>금액 : </strong>
              {{ item.amount }}
            </p>
            <p class="card-text">
              <strong>금액/인원수 : </strong>
              {{ calculateAmountPerPerson(item) }}
            </p>
            <p>
              <strong class="card-text">영수증 사진 : </strong>
              <a
                class="card-text"
                @click.prevent="openPreviewModal(item.receipt)"
                style="cursor: pointer; color: blue;"
              >
                {{ item.receiptName }}
              </a>
            </p>
            <p class="card-text">
              <strong>반려 사유: </strong> {{ item.rejectionReason || 'X' }}
            </p>
            <p class="card-text">
              <strong>결제 상황:</strong>
              <span :class="getStatusClass(item.status)">{{ item.status }}</span>
            </p>
          </div>
        </div>
      </div>

      <!-- 페이지네이션 (공통 컴포넌트) -->
      <DefaultPagination
        :currentPage="currentPage"
        :totalPages="totalPages"
        :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange"
      />
    </div>

    <!-- 사이드바 추가 -->
    <div 
      :class="['sidebar-wrapper', { 'sidebar-visible': sidebarVisible }]"
      v-click-away="{ handler: closeSidebar, exclude: ['.receipt-table'] }"
    >
      <ReceiptSidebar 
        v-if="!isMobile" 
        :item="selectedItem" 
        :visible="sidebarVisible" 
        @close="closeSidebar"
        @preview-image="openPreviewModal"
      />
    </div>

    <!-- 이미지 미리보기 모달 -->
    <div
      v-if="isPreviewVisible"
      class="modal preview-modal"
      @click="closePreviewModalOnOutsideClick"
    >
      <div
        class="preview-modal-content"
        @mousedown="startDrag"
        @mousemove="onDrag"
        @mouseup="endDrag"
        @mouseleave="endDrag"
        @touchstart="startDrag"
        @touchmove="onDrag"
        @touchend="endDrag"
      >
        <img
          :src="previewImage"
          :class="{ zoomed: isZoomed }"
          class="preview-modal-image"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
          }"
          @dblclick="toggleZoom"
          @touchstart="toggleZoom"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router';
import ReceiptSidebar from './ReceiptSidebar.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue'; 
import { usePreviewModal } from '@/utils/preview-modal';
// import axios from 'axios'; // 실제 백엔드 연동 시

// =====================
// 1) 날짜 표시 
// =====================
const filteredStartDate = ref('2024-08');
const filteredEndDate = ref('2024-09');

// =====================
// 2) 사이드바 / 모바일
// =====================
const selectedItem = ref(null);
const sidebarVisible = ref(false);
const isMobile = ref(window.innerWidth <= 650);
function updateIsMobile() {
  isMobile.value = window.innerWidth <= 650;
}
watch(isMobile, (newVal) => {
  if (newVal) closeSidebar();
});

// =====================
// 3) 미리보기 모달
// =====================
const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  openPreviewModal,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag
} = usePreviewModal();
function closePreviewModalOnOutsideClick(event) {
  if (!event.target.classList.contains('preview-modal-image')) {
    isPreviewVisible.value = false;
  }
}

// =====================
// 4) 데이터 / 페이지네이션
// =====================
const data = ref([]);
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);  // 페이지네이션에서 보여줄 최대 페이지 버튼 수

// **테이블 컬럼** 정의
// 각각의 'key'가 item[key]에 대응
// 필요 시 customClass, customValue 등 추가 가능
const columns = [
  { key: 'date', label: '발행일', width: 100 },
  {
    key: 'peopleCount',
    label: '인원수',
    width: 60,
    // 만약 item.peopleCount에 값이 없다면 직접 계산 가능
    // customValue: (item) => item.people.length,
    customValue: (item) => item.people ? item.people.length : 0,
  },
  { key: 'type', label: '구분', width: 100 },
  { key: 'reason', label: '사유', width: 130 },
  { key: 'amount', label: '금액', width: 100 },
  {
    key: 'amountPerPerson',
    label: '금액/인원수',
    width: 100,
    // customValue: (item) => calculateAmountPerPerson(item),
    customValue: (item) => calculateAmountPerPerson(item),
  },
  {
    key: 'status',
    label: '결제 상황',
    width: 80,
    // 동적 클래스 지정 (DefaultTable.vue에서 customClass 사용)
    customClass: (value) => {
      if (value === '신청중') return 'text-blue';
      if (value === '승인') return 'text-green';
      if (value === '반려') return 'text-red';
      return '';
    }
  },
];

// =====================
// 서버(또는 mock) 연동
// =====================
// 실제로는 axios로 서버에 { page } 등 파라미터를 보내어
// 해당 페이지 데이터와 totalPages 응답을 받아 세팅
// async function fetchDataFromServer(page = 1) {
async function fetchDataFromServer() {
  // const response = await axios.get('/api/receipts', { params: { page } });
  // data.value = response.data.items;
  // totalPages.value = response.data.totalPages;

  // 여기서는 예시(mock) 데이터
  const mockData = [
    {
      date: '2024-08-01',
      type: '식비',
      reason: '야근',
      amount: '100,000원',
      receiptName: '영수증 예시',
      receipt: '/receipt/receipt_sample/receipt_example.jpg',
      status: '반려',
      rejectionReason: '미지원 항목으로 인한 반려',
      people: [
        { department: 'SI사업본부', team: '프레임워크', name: '권범준', position: '책임' },
        { department: 'SI사업본부', team: '프레임워크', name: '홍길동', position: '선임' },
      ],
    },
    {
      date: '2024-08-02',
      type: '식비',
      reason: '야근',
      amount: '110,000원',
      receiptName: '영수증 예시',
      receipt: '/receipt/receipt_sample/receipt_example.jpg',
      status: '신청중',
      rejectionReason: '',
      people: [
        { department: 'SI사업본부', team: '프레임워크', name: '권범준', position: '책임' },
        { department: 'SI사업본부', team: '프레임워크', name: '홍길동', position: '선임' },
        { department: 'SI사업본부', team: '프레임워크', name: '심청이', position: '선임' },
      ],
    },
    // 필요 시 더미 데이터 더 추가...
  ];

  data.value = mockData;
  totalPages.value = 3; // 예시로 총 3페이지
}

// 페이지 전환 (DefaultPagination → @pageChange)
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
}

// =====================
// 5) 기타 로직
// =====================
// 금액/인원수 계산
function calculateAmountPerPerson(item) {
  const amount = parseInt(item.amount.replace(/[^0-9]/g, ''), 10) || 0;
  const peopleCount = item.people?.length || 0;
  return peopleCount > -1
    ? Math.floor(amount / (peopleCount+1)).toLocaleString() + ' 원'
    : 'N/A';
}

// 결제 상황별 CSS 클래스
function getStatusClass(status) {
  if (status === '신청중') return 'status-pending';
  if (status === '승인')   return 'status-approved';
  if (status === '반려')   return 'status-rejected';
  return '';
}

// 모바일 인원 목록 토글
const openedIndex = ref(null);
function togglePeopleList(index) {
  openedIndex.value = openedIndex.value === index ? null : index;
}
function showPeopleList(index) {
  return openedIndex.value === index;
}

// 사이드바
function openSidebar(item) {
  if (!isMobile.value) {
    selectedItem.value = item;
    sidebarVisible.value = true;
  }
}
function closeSidebar() {
  sidebarVisible.value = false;
}

// 뒤로가기
const router = useRouter();
function goBack() {
  router.back();
}

// =====================
// 6) onMounted
// =====================
onMounted(() => {
  fetchDataFromServer(currentPage.value);
  window.addEventListener('resize', updateIsMobile);
  updateIsMobile();
});
</script>

<style scoped>
.content {
  transition: margin-right 0.3s ease;
}
.content-expanded {
  margin-right: 300px;
}
.content-sub-title {
  margin-bottom: 0px !important;
}
.btn-back {
  margin-bottom: 74px !important;
}

/* 반응형 카드 레이아웃 */
.card-layout {
  margin-top: 40px;
}

/* 사이드바 */
.sidebar-wrapper {
  position: fixed;
  right: 0;
  top: 0;
  width: 300px;
  height: 100%;
  transform: translateX(100%);
  transition: transform 0.3s ease;
  z-index: 1000;
}
.sidebar-visible {
  transform: translateX(0);
}
.sidebar {
  width: 100%;
  height: 100%;
  background-color: #f9f9f9;
  border-left: 1px solid #ddd;
  padding: 20px;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
}

/* 상태별 색상 */
.status-approved {
  color: green;
  font-weight: bold;
}
.status-pending {
  color: blue;
  font-weight: bold;
}
.status-rejected {
  color: red;
  font-weight: bold;
}

/* 인원 목록 */
.people-list {
  font-size: 0.7rem;
  max-height: 150px;
  overflow-y: auto;
  margin-top: 10px;
  border-top: 1px solid #ddd;
  padding-top: 10px;
}
.people-list-header {
  font-weight: bold;
  margin-bottom: 5px;
}
.people-list-item {
  padding: 1px 0;
  margin: 0;
  margin-left: 10px;
}

/* 이미지 미리보기 모달 */
.preview-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}
.zoomed {
  cursor: move; /* 확대된 상태에서는 드래그 가능 */
}
</style>
