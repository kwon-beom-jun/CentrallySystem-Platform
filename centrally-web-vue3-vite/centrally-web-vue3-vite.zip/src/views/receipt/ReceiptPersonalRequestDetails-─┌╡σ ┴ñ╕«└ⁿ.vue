<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': sidebarVisible && !isMobile }">
      <h2 class="content-title">{{ userName }}님 영수증 신청 내역 조회</h2>
      <p class="content-sub-title">
        날짜: [{{ filteredStartDate }} ~ {{ filteredEndDate }}]
      </p>
      
      <!-- 뒤로가기 버튼 -->
      <DefaultButton 
        size="small" 
        align="left"
        color="gray"
        customHeight="30px"
        @click="goBack">
        뒤로가기
      </DefaultButton>

      <!-- 조회 결과 없을 때 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="!noData">
        <div class="d-flex align-items-center justify-content-end content-body-header">
          <span class="mr-2 all-click">전체 승인</span>
          <DefaultTextfield
            type="radio"
            name="approveAll" 
            class="approveAll" 
            id="approveAll"
            @change="toggleApproveAll" 
            v-model="selectAllDecision"
            value="2" 
            size="small"
          />
          <span class="mr-2 all-click">전체 반려</span>
          <DefaultTextfield
            type="radio"
            name="rejectAll" 
            class="rejectAll" 
            id="rejectAll"
            @change="toggleRejectAll" 
            v-model="selectAllDecision"
            value="3" 
            size="small"
          />
        </div>
        <hr />

        <!-- 테이블 보기 (큰 화면에서만 보임) -->
        <table class="table mt-3 receipt-table" id="dataTable" v-if="!isMobile">
          <thead>
            <tr>
              <th>발행일</th>
              <th>총 인원</th>
              <th>구분</th>
              <th>사유</th>
              <th>금액</th>
              <th>영수증 사진</th>
              <th>승인</th>
              <th>반려</th>
              <th>반려사유</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in data"
              :key="index"
              @click="(e) => {
                const t=e.target.tagName;
                if(t!=='A' && t!=='INPUT') openEditModal(item);
              }"
            >
              <td class="text-ellipsis">{{ item.date }}</td>
              <td>{{ item.peopleCount }}</td>
              <td class="text-ellipsis">{{ item.type }}</td>
              <td class="text-ellipsis">{{ item.reason }}</td>
              <td class="text-ellipsis">{{ formatAmount(item.amount) }}원</td>
              <td class="text-ellipsis-picture" @click.stop>
                <a
                  href="#"
                  @click.stop.prevent="openPreviewModal(item.receipt)"
                  class="text-primary"
                >
                  {{ item.receiptName }}
                </a>
              </td>
              <td @click.stop>
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="approveRadio"
                  v-model="item.decision"
                  value="2"
                  @change="updateDecision()"
                />
              </td>
              <td @click.stop>
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="rejectRadio"
                  v-model="item.decision"
                  value="3"
                  @change="updateDecision()"
                />
              </td>
              <td @click.stop>
                <DefaultTextfield
                  size="full"
                  v-model="item.rejectReason"
                />
              </td>
            </tr>
          </tbody>
        </table>

        <!-- 카드 레이아웃 보기 (작은 화면에서만 보임) -->
        <div class="card-layout" v-if="isMobile">
          <div
            class="card"
            v-for="(item, index) in data"
            :key="index"
          >
            <div class="card-header">
              <p class="card-title">{{ item.date }}</p>
              <div class="card-actions">
                <DefaultButton
                  size="small"
                  color="gray"
                  customHeight="24px"
                  @click.stop="openEditModal(item)"
                >
                  보기
                </DefaultButton>
              </div>
            </div>
            <div class="card-body">
              <p class="card-text">
                <strong>총 인원 : </strong>
                <span @click="togglePeopleList(item)" style="cursor: pointer;">
                  {{ item.peopleCount }}명
                </span>
              </p>
              <div v-if="showPeopleList(item)">
                <div class="people-list">
                  <!-- <div class="people-list-header">명단</div> -->
                  <p
                    v-for="person in item.people"
                    :key="person.name"
                    class="people-list-item"
                  >
                    {{ person.name }} ({{ person.department }} - {{ person.team }})
                  </p>
                </div>
              </div>
              <p class="card-text">
                <strong>구분/사유 : </strong>
                {{ item.type }} / {{ item.reason }}
              </p>
              <p class="card-text">
                <strong>금액 : </strong>
                {{ formatAmount(item.amount) }}
              </p>
              <p class="card-text">
                <strong>금액/인원수 : </strong>
                {{ calculateAmountPerPerson(item) }}
              </p>
              <p>
                <strong class="card-text">영수증 사진 : </strong>
                <a class="card-text"
                  @click.prevent="openPreviewModal(item.receipt)"
                  style="cursor: pointer; color: blue;"
                >
                  {{ item.receiptName }}
                </a>
              </p>
              <p class="card-text">
                <strong>결정: </strong>
                승인
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="approveRadio"
                  v-model="item.decision"
                  :value="2" 
                  @change="updateDecision()"
                />
                | 반려
                <input
                  type="radio"
                  :name="'decision' + index"
                  class="rejectRadio"
                  v-model="item.decision"
                  :value="3"
                  @change="updateDecision()"
                />
                <br>
              </p>
              <p class="card-text d-flex align-items-center">
                <strong>반려사유: </strong>
                <input
                  type="text"
                  class="form-control rejectReason ml-2"
                  v-model="item.rejectReason"
                  style="flex: 1;"
                />
              </p>
            </div>
          </div>
        </div>

        <!-- 저장 버튼 -->
        <DefaultButton align="right" @click="save">
          저장
        </DefaultButton>

        <!-- 페이지네이션 (공통 컴포넌트) -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />

        <!-- 사이드바 추가 -->
        <div 
          :class="['sidebar-wrapper', { 'sidebar-visible': sidebarVisible }]"
          v-click-away="{ handler: closeSidebar, exclude: ['.receipt-table'] }"
        >
          <ReceiptSidebar 
            v-if="!isMobile" 
            :item="selectedItem" 
            :visible="sidebarVisible" 
            @close="closeSidebar"
            @preview-image="openPreviewModal"
          />
        </div>
      </div>
      
      <!-- 이미지 미리보기 모달 -->
      <div
        v-if="isPreviewVisible"
        class="modal preview-modal"
        @click="closePreviewModalOnOutsideClick"
      >
        <div
          class="preview-modal-content"
          @mousedown="startDrag"
          @mousemove="onDrag"
          @mouseup="endDrag"
          @mouseleave="endDrag"
          @touchstart="startDrag"
          @touchmove="onDrag"
          @touchend="endDrag"
        >
          <img
            :src="previewImage"
            :class="{ zoomed: isZoomed }"
            class="preview-modal-image"
            :style="{
              transform: isZoomed
                ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
                : 'none',
              transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
            }"
            @dblclick="toggleZoom"
            @touchstart="toggleZoom"
          />
        </div>
      </div>
    </div>
  </div>

  <!-- 🆕 영수증 상세 모달 -->
  <ReceiptDetailViewModal
    :isVisible="historyModalVisible"
    :receipt="editingReceipt"
    @close="historyModalVisible = false"
    @updated="fetchDataFromServer(currentPage)" />

</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import ReceiptSidebar from './ReceiptSidebar.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import ReceiptsSearchApi from '@/api/receipt/ReceiptsSearchApi';
import ReceiptsRequestApi from '@/api/receipt/ReceiptsRequestApi';
import { usePreviewModal } from '@/utils/preview-modal';
import { toast } from 'vue3-toastify';
import { useAuthStore } from '@/store/auth'
import ReceiptDetailViewModal from '@/components/receipt/ReceiptDetailViewModal.vue';

const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  openPreviewModal,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag
} = usePreviewModal();

const router = useRouter();
const route = useRoute();
const authStore = useAuthStore()

const selectedItem = ref(null);
const sidebarVisible = ref(false);
const isMobile = ref(window.innerWidth <= 1000);
const updateIsMobile = () => {
  isMobile.value = window.innerWidth <= 1000;
};

const filteredStartDate = ref('');
const filteredEndDate = ref('');
const userId = ref('');
const userName = ref('');

const noData = ref(false);
const data = ref([]);
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);

const editingReceipt      = ref(null);   // 모달이 볼 데이터
const historyModalVisible = ref(false);  // 모달 on/off

const fetchDataFromServer = async (page = 1) => {
  closeSidebar();
  const pageSize = isMobile.value ? 4 : 6;
  const params = {
    userId: userId.value,
    startDate: filteredStartDate.value,
    endDate: filteredEndDate.value,
    statusCode: 1,
    page: page - 1,
    size: pageSize
  };

  const response = await ReceiptsSearchApi.getMyPendingByDate(authStore.getUserId, params);
  const receiptPage = response.data;

  data.value = receiptPage.content.map(item => {
    /* ── 총 인원 계산 ── */
    const peopleArr   = item.participantsList || [];
    const peopleCount = peopleArr.length + 1; 

    const amountNumber = typeof item.amount === 'string'
      ? parseInt(item.amount.replace(/[^0-9]/g, ''), 10)
      : item.amount || 0;

    const approvers = (item.approvalLines || []).map(al => ({
      userId       : al.approverUserId,
      name         : al.approverName,
      department   : al.department,
      team         : al.team,
      approvalType : al.approvalRole === 2 ? '합의' : '결재',
      stateText    : al.rejectedAt      ? '반려'
                    : al.approvalStatus ? '승인'
                                      : '대기',
      rejectedReason: al.rejectedReason
    }));

    const rejectedReason =
      approvers.find(a => a.rejectedReason)?.rejectedReason || '';

    return {
      receiptId: item.receiptId,
      date: item.submissionDate,
      type: item.category?.categoryName ?? '',
      categoryId : item.category?.categoryId ?? null,
      reason: item.reason,
      amount: amountNumber.toString(),
      amountRaw  : amountNumber,
      receiptName: item.attachment?.fileName || '영수증',
      receipt: item.attachment?.fileUrl || '',
      people: peopleArr.map(p => ({
        name: p.participantName,
        department: p.department,
        team: p.team
      })),
      peopleCount,
      amountPerPerson: peopleCount
        ? Math.floor(amountNumber / peopleCount)
        : 0,   
      approvers,
      statusText   : item.status ?? '',
      rejectedReason,
      decision: '',
      rejectReason: ''
    };
  });

  totalPages.value = receiptPage.totalPages || 1;

  noData.value = data.value.length ? false : true;
  
  // 스크롤 맨 위로 이동(모바일 카드형식일때)
  if (isMobile.value) {
    window.scrollTo(0, 0)
  }
};

const onPageChange = newPage => {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
};

// 영수증 신청 저장
// 기존: decision이 "approve"/"reject"였다면
// → 이제는 정수 2|3
const save = async () => {
  const decisionList = data.value
    .filter(item => item.decision === '2' || item.decision === '3')
    .map(item => ({
      receiptId: item.receiptId,
      // 🔥 백엔드가 statusCode 로 받으므로 여기서 statusCode: item.decision
      statusCode: item.decision,
      rejectReason: item.rejectReason || '',
      approverId: authStore.getUserId, // 결재자 아이디
      approverName: authStore.getUser, // 결재자 이름
    }));

  if (decisionList.length === 0) {
    toast.warning('승인 또는 반려된 항목이 없습니다.');
    return;
  }

  await ReceiptsRequestApi.saveReceiptDecisions(userId.value, decisionList);
  toast.success('저장이 완료되었습니다.');
  fetchDataFromServer(currentPage.value); // 새로고침
};

const selectAllDecision = ref('');
const toggleApproveAll = () => {
  if (selectAllDecision.value === '2') {
    data.value.forEach(item => (item.decision = '2'));
  } else {
    data.value.forEach(item => (item.decision = ''));
  }
};
const toggleRejectAll = () => {
  if (selectAllDecision.value === '3') {
    data.value.forEach(item => (item.decision = '3'));
  } else {
    data.value.forEach(item => (item.decision = ''));
  }
};
const updateDecision = () => {
  const allApproved = data.value.length > 0 && data.value.every(i => i.decision === '2');
  const allRejected = data.value.length > 0 && data.value.every(i => i.decision === '3');

  if (allApproved) selectAllDecision.value = '2';
  else if (allRejected) selectAllDecision.value = '3';
  else selectAllDecision.value = '';
};

const closeSidebar = () => {
  sidebarVisible.value = false;
};
const closePreviewModalOnOutsideClick = event => {
  if (!event.target.classList.contains('preview-modal-image')) {
    isPreviewVisible.value = false;
  }
};

const formatAmount = amount => {
  const amt = typeof amount === 'string' ? parseInt(amount.replace(/[^0-9]/g, ''), 10) : amount;
  return (amt || 0).toLocaleString();
};

const calculateAmountPerPerson = item => {
  const amountNum = typeof item.amount === 'string'
    ? parseInt(item.amount.replace(/[^0-9]/g, ''), 10)
    : item.amount;
  const peopleCount = item.peopleCount ?? (item.people.length + 1);
  return peopleCount
    ? `${Math.floor(amountNum / peopleCount).toLocaleString()} 원`
    : 'N/A';
};

const openedIndex = ref(null);
function togglePeopleList(index) {
  openedIndex.value = openedIndex.value === index ? null : index;
}
function showPeopleList(index) {
  return openedIndex.value === index;
}

/* ────── 상세 모달 오픈 ────── */
function openEditModal(row) {
  editingReceipt.value = {
    id: row.receiptId,
    date: row.date,
    type: row.type,
    categoryId: row.categoryId,
    amount    : (row.amountRaw ?? 0).toString(),
    amountRaw : row.amountRaw ?? 0,   
    reason: row.reason,
    receiptName: row.receiptName,
    receipt: row.receipt,
    participants: [...row.people],
    approvers: row.approvers.map((a) => ({
      ...a,
      approvalType: a.approvalType ?? (a.approvalRole === 1 ? "결재" : "합의"),
      rejectedReason: a.rejectedReason,
    })),
    statusText: row.statusText,
    rejectedReason: row.rejectedReason,
  };
  historyModalVisible.value = true;
}

const goBack = () => router.back();

onMounted(() => {
  filteredStartDate.value = route.query.startDate || '';
  filteredEndDate.value = route.query.endDate || '';
  userId.value = route.query.userId || '';
  userName.value = route.query.userName || '';

  if (!filteredStartDate.value || !filteredEndDate.value || !userId.value || !userName.value) {
    goBack();
  }

  fetchDataFromServer();
  window.addEventListener('resize', updateIsMobile);
});
</script>

<style scoped>
/* .mt-3 {
  margin-top: 0px !important;
} */
#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}
#dataTable td {
  vertical-align: middle;
  text-align: left;
}

hr {
  margin: 10px 0px 10px 0px;
}

/* 테이블 본문 폰트 사이즈 */
tbody {
  font-size: var(--table-body-font-size, 0.75rem);
}

.content {
  transition: margin-right 0.3s ease;
}

.content-sub-title {
  margin-bottom: 10px !important;
}

.content-expanded {
  margin-right: 300px;
}

.content-body-header {
  margin-top: 30px;
}

.text-primary {
  color: #c7573e;
  /* 원하는 하이퍼링크 색상으로 변경 */
  text-decoration: none;
  /* 하이퍼링크 밑줄 제거 */
}

/* 사이드바 */
.sidebar-wrapper {
  position: fixed;
  right: 0;
  top: 0;
  width: 300px;
  height: 100%;
  transform: translateX(100%);
  transition: transform 0.3s ease;
  z-index: 1000;
}

/* 사이드바가 보일 때 적용되는 클래스 */
.sidebar-visible {
  transform: translateX(0);
  /* 화면 안으로 슬라이드 */
}

/* 사이드바 내용물 스타일 유지 */
.sidebar {
  width: 100%;
  height: 100%;
  background-color: #f9f9f9;
  border-left: 1px solid #ddd;
  padding: 20px;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
}

/* 전체 승인/반려 */
.all-click {
  font-weight: bold;
  margin-left: 10px;
}

/* 카드 레이아웃 인원 목록 스타일 추가 */
.people-list {
  font-size: 0.7rem;
  max-height: 150px;
  overflow-y: auto;
  margin-top: 10px;
  border-top: 1px solid #ddd;
  padding-top: 10px;
}
.people-list-header {
  font-weight: bold;
  margin-bottom: 5px;
}
.people-list-item {
  padding: 1px 0;
  margin: 0;
  margin-left: 10px;
}

/* 이미지 미리보기 모달 */
.preview-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}

.approveRadio,
.rejectRadio {
  /* 축소 기준점을 중앙으로 설정 */
  transform-origin: center center;
  /* 수직 정렬 (inline 요소가 text-baseline이 아니라 middle에 맞춰지도록 함) */
  vertical-align: middle;
}

.mx-width-700 {
  margin-top: 50px;
}

.text-ellipsis {
  max-width: 60px;        /* 원하는 최대 폭 – 상황에 맞게 조절 */
  white-space: nowrap;     /* 줄바꿈 금지 */
  overflow: hidden;        /* 넘치는 글자 숨김  */
  text-overflow: ellipsis; /* ‘…’ 표시       */
}
.text-ellipsis-picture {
  max-width: 100px;        /* 원하는 최대 폭 – 상황에 맞게 조절 */
  white-space: nowrap;     /* 줄바꿈 금지 */
  overflow: hidden;        /* 넘치는 글자 숨김  */
  text-overflow: ellipsis; /* ‘…’ 표시       */
}

/* ─── 카드 헤더 버튼 일렬 배치 ─────────────────── */
.card-actions {
  display: flex; /* 가로 한 줄 */
  flex-wrap: nowrap; /* 줄바꿈 방지 */
  gap: 4px; /* 버튼 간격 */
  margin-left: auto;
}

/* DefaultButton 내부 <button> 폭 덮어쓰기 */
.card-actions :deep(button) {
  width: auto !important; /* 100% → auto */
  min-width: 50px; /* 필요 시 최소 너비 지정 */
  padding: 2px 6px; /* XS 버튼 느낌 */
  line-height: 1.3;
}
.card-header {
  display: flex;
  align-items: center;
}
@media (max-width: 1000px) {
  .page-link {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
  }

  .page-item {
    font-size: 0.75rem;
  }

  .pagination {
    margin: 3px 0 60px 0;
  }
}

@media (max-width: 650px) {
  .content-body-header {
    margin-top: 40px;
  }
  .rejectReason {
    width: 100%;
  }
}

@media (max-width: 700px) {
  .approveRadio,
  .rejectRadio {
    /* 라디오 크기 축소 */
    transform: scale(0.7);
    /* 라디오가 작아지는 만큼 위치 조정이 필요하다면 여기에 마진 설정 가능 */
    margin: 0 2px;
  }
}
</style>
