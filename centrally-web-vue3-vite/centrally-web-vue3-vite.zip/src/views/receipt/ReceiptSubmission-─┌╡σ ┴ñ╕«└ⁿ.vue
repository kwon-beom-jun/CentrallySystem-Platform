<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': !isMobile }">
      <h2 class="content-title">영수증 등록(상태 : 대기 & 반려)</h2>
      <p class="content-sub-title">
        [반려 → 신청] 영수증은 상태 및 결재선은 승인은 초기화
      </p>

      <DefaultFormRow marginBottom="10px" align="right">
        <DefaultButton align="right" style="" @click="openModal">
          영수증 등록
        </DefaultButton>
      </DefaultFormRow>

      <!-- 영수증 등록 모달 -->
      <ReceiptSubmissionCreateModal
        :isVisible="modalVisible"
        @close="modalVisible = false"
        @confirm="() => receiptConfirm()"
      />

      <!-- 영수증 수정 모달 (신규) -->
      <ReceiptSubmissionEditModal
        :isVisible="editModalVisible"
        :receipt="editingReceipt"
        @close="editModalVisible = false"
        @confirm="() => fetchMetadata(currentPage)"
      />

      <!-- 조회 결과 없는 경우 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="data.length">
        <!-- 테이블 보기 -->
        <DefaultTable
          class="receipt-table"
          :columns="columns"
          :data="data"
          :showTable="!isMobile"
          :rowClick="openEditModal"
          :buttonHeight="'30px'"
          @apply-row="handleApply"
          @delete-row="handleDelete"
          :minRows="8"
        />

        <!-- 카드 레이아웃 (모바일에서만) -->
        <div class="card-layout" v-if="isMobile">
          <div class="card" v-for="(item, idx) in data" :key="idx">
            <div class="card-header">
              <p class="card-title">{{ item.date }}</p>

              <!-- 오른쪽 액션 버튼 -->
              <div class="card-actions">
                <DefaultButton
                  size="small"
                  color="gray"
                  customHeight="25px"
                  @click.stop="openEditModal(item)"
                >
                  수정
                </DefaultButton>
                <DefaultButton
                  size="small"
                  color="blue"
                  customHeight="25px"
                  @click.stop="handleApply(item)"
                >
                  신청
                </DefaultButton>
                <DefaultButton
                  size="small"
                  color="red"
                  customHeight="25px"
                  @click.stop="handleDelete(item)"
                >
                  삭제
                </DefaultButton>
              </div>
            </div>
            <div class="card-body">
              <p class="card-text">
                <strong>총 인원(당사자 포함) : </strong>
                <span @click="togglePeopleList(item)" style="cursor: pointer"
                  >{{ item.peopleCount }}명</span
                >
              </p>
              <div v-if="showPeopleList(item)">
                <div class="people-list">
                  <!-- <div class="people-list-header">명단</div> -->
                  <p
                    v-for="person in item.people"
                    :key="person.name"
                    class="people-list-item"
                  >
                    [ 일행 ] {{ person.name }} ({{ person.department }} -
                    {{ person.team }})
                  </p>
                </div>
              </div>

              <p class="card-text">
                <strong>결재 상태 : </strong>
                <span :class="statusColor(item.statusText)">
                  {{ item.statusText }}
                </span>
              </p>
              <!-- 반려 사유(있을 때) -->
              <p v-if="item.statusText==='반려' && item.rejectedReason"
                class="card-text text-danger ms-1">
                • {{ item.rejectedReason }}
              </p>

              <!-- ─── 결재자 목록 ─── -->
              <p class="card-text">
                <strong>결재자 : </strong>
                <span @click="toggleApproverList(idx)" style="cursor: pointer">
                  {{ item.approvers.length }}명
                </span>
              </p>
              <div v-if="showApproverList(idx)">
                <div class="people-list">
                  <!-- <div class="people-list-header">결재자</div> -->
                  <p
                    v-for="ap in item.approvers"
                    :key="ap.userId"
                    class="people-list-item"
                  >
                    [{{ ap.stateText }}] {{ ap.name }} ({{ ap.department }}-{{ ap.team }})
                  </p>
                </div>
              </div>

              <p class="card-text">
                <strong>구분/사유 : </strong> {{ item.type }} /
                {{ item.reason }}
              </p>
              <p class="card-text">
                <strong>금액 : </strong> {{ item.amount }}
              </p>
              <p class="card-text">
                <strong>금액/인원수 : </strong>
                {{ calculateAmountPerPerson(item) }}
              </p>
              <p>
                <strong class="card-text">영수증 사진 : </strong>
                <a
                  class="card-text"
                  @click.prevent="openPreviewModal(item.receipt)"
                  style="cursor: pointer; color: blue"
                >
                  {{ item.receiptName }}
                </a>
              </p>
            </div>
          </div>
        </div>

        <!-- 페이지네이션 (공통 컴포넌트) -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>

    <!-- 이미지 미리보기 -->
    <div
      v-if="isPreviewVisible"
      class="modal preview-modal"
      @click="closePreviewModalOnOutsideClick"
    >
      <div
        class="preview-modal-content"
        @mousedown="startDrag"
        @mousemove="onDrag"
        @mouseup="endDrag"
        @mouseleave="endDrag"
        @touchstart="startDrag"
        @touchmove="onDrag"
        @touchend="endDrag"
      >
        <img
          :src="previewImage"
          :class="{ zoomed: isZoomed }"
          class="preview-modal-image"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`,
          }"
          @dblclick="toggleZoom"
          @touchstart="toggleZoom"
        />
      </div>
    </div>
  </div>

  <!-- 신청 확인 모달 -->
  <AlertModal
    :isVisible="applyModalVisible"
    title="신청 확인"
    confirmText="신청"
    cancelText="취소"
    @close="applyModalVisible = false"
    @confirm="confirmApply"
  >
    <template #body>
      <p>선택한 영수증을 신청하시겠습니까?</p>
    </template>
  </AlertModal>

  <!-- 삭제 확인 모달 -->
  <AlertModal
    :isVisible="deleteModalVisible"
    confirmText="삭제"
    cancelText="취소"
    @close="deleteModalVisible = false"
    @confirm="confirmDelete"
  >
    <template #body>
        <div style="color: red;">
          ※ 삭제 ※ <br/><br/>
          영수증을 삭제하면 복구되지 않습니다 <br/>
          영수증 삭제를 진행하겠습니까? <br/>
        </div>
    </template>
  </AlertModal>
</template>

<script setup>
import { ref, onMounted } from "vue";
import DefaultTable from "@/components/common/table/DefaultTable.vue";
import DefaultButton from "@/components/common/button/DefaultButton.vue";
import ReceiptSubmissionCreateModal from "@/components/receipt/ReceiptSubmissionCreateModal.vue";
import ReceiptSubmissionEditModal from "@/components/receipt/ReceiptSubmissionEditModal.vue";
import DefaultPagination from "@/components/common/pagination/DefaultPagination.vue";
import DefaultFormRow from "@/components/common/DefaultFormRow.vue";
import AlertModal from "@/components/common/modal/AlertModal.vue";
import ReceiptsApi from "@/api/receipt/ReceiptsApi";
import ReceiptsRequestApi from '@/api/receipt/ReceiptsRequestApi';
import { toast } from "vue3-toastify";
import { useAuthStore } from "@/store/auth";
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";
import { usePreviewModal } from "@/utils/preview-modal";

// Vue Router, Pinia 스토어
const authStore = useAuthStore();
const store = useUserDirectoryStore();
const noData = ref(false);

// 반응형 여부
const isMobile = ref(window.innerWidth <= 650);
const updateIsMobile = () => {
  isMobile.value = window.innerWidth <= 650;
};

// 페이지네이션 관련 상태
const currentPage = ref(1);
const totalPages = ref(1); // 백엔드로부터 받아오는 총 페이지 수
const visiblePageCount = ref(5); // 페이지네이션에서 보여질 페이지 수

// 수정 모달 관련 상태
const editModalVisible = ref(false);
const editingReceipt = ref(null);

/* ───── 삭제 확인 모달 ───── */
const deleteModalVisible = ref(false);
const deleteTarget       = ref(null);   // { receiptId, … }

/* ───── 신청 확인 모달 ───── */
const applyModalVisible  = ref(false);
const applyTarget        = ref(null);

/* ────────── 미리보기 모달 상태/메서드 ────────── */
const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  openPreviewModal,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag,
} = usePreviewModal();

function closePreviewModalOnOutsideClick(e) {
  if (!e.target.classList.contains("preview-modal-image")) {
    isPreviewVisible.value = false;
  }
}

// 실제 데이터
const data = ref([]); // 화면에 뿌릴 데이터 (백엔드에서 받아올 것)
const columns = [
  { key: "date", label: "발행일", width: 120 },
  { key: "type", label: "구분", width: 100 },
  { key: "peopleCount", label: "총 인원", width: 80 },
  { key: "reason", label: "사유", width: 150 },
  { key: "amount", label: "금액", width: 80 },
  { key: "amountPerPerson", label: "금액/인원", width: 80 },
  {
    key: "statusText",
    label: "결제 상황",
    width: 80,
    customClass: (value) => {
      if (value === "반려") return "text-red";
      return "";
    },
  },
  {
    key: "apply",
    label: "",
    width: 80,
    type: "button",
    buttonText: "신청",
    buttonColor: "blue",
    buttonSize: "full-small",
    emit: "apply-row",
  },
  {
    key: "delete",
    label: "",
    width: 80,
    type: "button",
    buttonText: "삭제",
    buttonColor: "red",
    buttonSize: "full-small",
    emit: "delete-row",
  },
];

/**
 * 페이지 변경 시 호출될 함수
 * - 백엔드에 page(또는 offset 등)를 보내서 해당 페이지 데이터를 받는다.
 * - 응답으로 현재 페이지 데이터와 totalPages(또는 totalItems)를 받으면 state 갱신
 */
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchMetadata(newPage);
}

// 금액/인원수 계산 예시
function calculateAmountPerPerson(item) {
  const amount = parseInt(item.amount.replace(/[^0-9]/g, ""), 10);
  const totalPeople = item.peopleCount ?? item.people.length + 1;  // 안전망
  return Math.floor(amount / totalPeople).toLocaleString();
}

// 카드 레이아웃 명단 리스트 참여자
const openedIndex = ref(null);
function togglePeopleList(index) {
  openedIndex.value = openedIndex.value === index ? null : index;
}
function showPeopleList(index) {
  return openedIndex.value === index;
}
// 카드 레이아웃 명단 리스트 결재자
const openedApproverIdx = ref(null); // 결재자
function toggleApproverList(i) {
  openedApproverIdx.value = openedApproverIdx.value === i ? null : i;
}
function showApproverList(i) {
  return openedApproverIdx.value === i;
}

// 영수증 등록 완료 후
function receiptConfirm() {
  toast.success("영수증 등록 성공");
  fetchMetadata();
}

// 모달 등 나머지 로직
const modalVisible = ref(false);
function openModal() {
  modalVisible.value = true;
}

/**
 * 백엔드에서 데이터 가져오기
 * - 실제로는 axios를 사용해서 서버에 page, itemsPerPage 등을 넘겨주고
 *   응답으로 받은 데이터/totalPages 등을 세팅.
 */
// Auth에서 검색하지않고 receipt_participants 테이블 사용 이유는
// 사용자가 서비스를 탈퇴 이후에도 데이터를 조회해야 할 수 있어야 하기 때문
async function fetchMetadata(page = 1) {
  const pageSize = isMobile.value ? 4 : 8;
  // (1) 서버에서 영수증 목록 조회
  /**
   * stateCode 3 = 반려, 4 = 대기
   * 백엔드 컨트롤러가 List<Integer> statusCodes 를 받도록 변경됐으므로
   *  - statusCodes=3&statusCodes=4   ← 배열 전송
   *  - 또는  statusCodes=3,4         ← 문자열 전송
   */
  const receiptRes = await ReceiptsApi.getReceiptsByUserIdAndStatuses(
    authStore.getUserId,
    {
      statusCodes: [3, 4], // ⇒  ?statusCodes=3&statusCodes=4
      page: page - 1,
      size: pageSize,
    }
  );
  const receiptPage = receiptRes.data; // { content: [...], totalPages, ... }

  // (2) 참여자 정보를 있는 그대로 사용 (추가 Auth 호출 X)
  const transformedList = receiptPage.content.map((r) => {
    /* 영수증 전체 상태 텍스트 ─ 백엔드가 enum 이름(문자열)만 넘겨줌 */
    const statusText = (() => {
      if (!r.status) return "";
      switch (r.status) {
        case "WAITING":   return "대기";
        case "REJECTED":  return "반려";
        default:          return "";
      }
    })();
    /* 참가자 배열 */
    const peopleArr = (r.participantsList || []).map((p) => ({
      name: p.participantName || `User${p.participantUserId}`,
      department: p.department ?? "",
      team: p.team ?? "",
    }));

    // 첨부파일
    const receiptName = r.attachment ? r.attachment.fileName : "영수증 미등록";
    const receiptUrl = r.attachment ? r.attachment.fileUrl : "";

    // 금액 표기(문자열 변환 등)
    // const amountStr = r.amount ? r.amount.toLocaleString() : '0원';

    // 스크롤 맨 위로 이동(모바일 카드형식일때)
    if (isMobile.value) {
      window.scrollTo(0, 0);
    }

    /* approvalLines → 화면용 배열 */
    const approverArr = (r.approvalLines || []).map((al) => {
      // 상태 텍스트 계산
      let stateTxt = "대기";
      if (al.rejectedAt) stateTxt = "반려";
      else if (al.approvalStatus) stateTxt = "승인";

      const reason = al.rejectedReason ?? "";

      return {
        userId: al.approverUserId,
        name: al.approverName,
        department: al.department,
        team: al.team,
        /** 1=결재, 2=합의 ─ 숫자 보존 */
        approvalRole: al.approvalRole,
        /** true 승인, false(미승인) */
        approvalStatus: al.approvalStatus,
        approvalType: al.approvalRole === 1 ? "결재" : "합의",
        /** 반려 여부를 쉽게 쓰도록 */
        rejected: !!al.rejectedAt,
        stateText: stateTxt,
        rejectedReason: reason,
      };
    });

    const rejectedReason =
          approverArr.find(ap => ap.rejectedReason)?.rejectedReason || "";

    // 변환된 데이터 구조
    return {
      date: r.submissionDate, // 예: "2025-04-01"
      type: r.category?.categoryName || "", // 예: "테스트"
      reason: r.reason, // 예: "테스트 입니다"
      amount: Number(r.amount ?? 0).toLocaleString(),
      receiptName: receiptName,
      receipt: receiptUrl,
      people: peopleArr,
      // approvers: approverArr.map((a) => ({
      //   ...a,
      //   stateText:
      //     a.state === 1
      //       ? "대기"
      //       : a.state === 2
      //       ? "승인"
      //       : a.state === 3
      //       ? "반려"
      //       : "",
      // })),
      approvers: approverArr,
      id: r.receiptId,
      amountRaw: r.amount ?? 0, // 필요하면 숫자 그대로
      receiptId: r.receiptId,
      categoryId : r.category?.categoryId ?? null,
      statusText: statusText,
      rejectedReason,
    };
  });

  // (3) peopleCount, amountPer 등 계산
  const finalData = transformedList.map((item) => {
    const peopleCount = item.people.length + 1;
    const amountNum =
      parseInt((item.amount || "0").replace(/[^0-9]/g, ""), 10) || 0;
    const amountPer = Math.floor(amountNum / peopleCount).toLocaleString();

    return {
      ...item,
      peopleCount,
      amountPerPerson: amountPer,
    };
  });

  // (4) table/card UI에 사용할 data.value에 대입
  data.value = finalData;
  noData.value = data.value.length ? false : true;
  totalPages.value = receiptPage.totalPages;
}

// 영수증 신청 처리
async function handleApply(row) {
  applyTarget.value      = row;        // 대상 저장
  applyModalVisible.value = true;      // 모달 오픈
}

async function confirmApply () {
  if (!applyTarget.value) return;
  try {
    await ReceiptsRequestApi.requestReceipt(applyTarget.value.receiptId);
    toast.success("신청 완료되었습니다.");
    fetchMetadata(currentPage.value);   // 목록 갱신
  } catch (e) {
    console.error(e);
    toast.error("신청 중 오류가 발생했습니다.");
  } finally {
    applyModalVisible.value = false;
    applyTarget.value       = null;
  }
}

function handleDelete(row) {
  deleteTarget.value       = row;
  deleteModalVisible.value = true;      // AlertModal 열기
}

async function confirmDelete () {
  if (!deleteTarget.value) return;
  try {
    await ReceiptsApi.deleteReceipt(deleteTarget.value.receiptId);
    toast.success("삭제되었습니다.");
    fetchMetadata(currentPage.value);   // 목록 갱신
  } catch (e) {
    console.error(e);
    toast.error("삭제 중 오류가 발생했습니다.");
  } finally {
    deleteModalVisible.value = false;
    deleteTarget.value       = null;
  }
}

function statusColor(txt) {
  if (txt === '승인') return 'text-success';   // 초록
  if (txt === '반려') return 'text-danger';    // 빨강
  if (txt === '대기') return 'text-primary';   // 파랑(원하면 변경)
  return 'text-secondary';
}

// 모바일 화면 판단
onMounted(async () => {
  window.addEventListener("resize", updateIsMobile);
  // 컴포넌트 초기 로드시 1페이지 데이터를 불러온다
  await fetchMetadata(currentPage.value);
  await store.refresh();
});

function openEditModal(row) {
  const src = data.value.find(d => d.receiptId === row.receiptId) || row;
  // 2️⃣ 모달에 전달
  editingReceipt.value = {
    id: src.receiptId,
    date: src.date,
    type: src.type,
    categoryId: src.categoryId,
    amount: src.amountRaw?.toString() ?? "",
    reason: src.reason,
    receiptName: src.receiptName,
    receipt: src.receipt,
    participants: [...src.people],
    approvers: [...src.approvers],
    status:     src.status    ?? "",     // ← enum 그대로도 같이 주면 편함
    statusText: src.statusText ?? "",
    rejectedReason: src.rejectedReason,
  };

  editModalVisible.value = true;
}
</script>

<style scoped>
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}

.reason {
  margin-top: 10px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 10px;
}

.list-group-item,
.list-group {
  font-size: 0.875em !important;
}

.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

.now-label {
  cursor: pointer;
  color: #0d6efd;
}

.now-label:hover {
  text-decoration: underline;
}

.drag-handle {
  cursor: grab;
  user-select: none;
}

.drag-handle:active {
  cursor: grabbing;
}

.align-items-center {
  margin-bottom: 0px !important;
}

/* 선택 토글용 글자 버튼 */
.approval-option {
  cursor: pointer;
  padding: 2px 6px;
  /* border-radius: 4px; */
  color: #39393a; /* 기본 회색 */
  border: 1px solid #8e8e8f; /* 기본 얇은 회색 테두리 */
  user-select: none;
  margin: 0;
}

.approval-option + .approval-option {
  margin-left: -1px; /* 경계선 겹침 처리 */
}

.approval-option-right {
  margin-right: 7px;
}
.approval-option.active {
  color: #0d6efd; /* 선택 시 파란색 */
  font-weight: 900;
  background: #0d6dfd25;
}
/* ── 미리보기 모달 ───────────────────────────── */
.preview-modal {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}

/* ─── 카드 헤더 버튼 일렬 배치 ─────────────────── */
.card-actions {
  display: flex;          /* 가로 한 줄 */
  flex-wrap: nowrap;      /* 줄바꿈 방지 */
  gap: 4px;               /* 버튼 간격 */
  margin-left: auto;
}

/* DefaultButton 내부 <button> 폭 덮어쓰기 */
.card-actions :deep(button) {
  width: auto !important; /* 100% → auto */
  min-width: 50px;        /* 필요 시 최소 너비 지정 */
  padding: 2px 6px;       /* XS 버튼 느낌 */
  line-height: 1.3;
}
.card-header {
  display: flex;
  align-items: center;
}
@media (max-width: 650px) {
  .list-group-item,
  .list-group {
    font-size: 0.8em !important;
  }

  .form-group {
    margin-bottom: 10px;
  }
}
</style>
