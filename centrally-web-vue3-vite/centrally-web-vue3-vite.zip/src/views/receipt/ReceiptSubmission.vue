<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': !isMobile }">
      <h2 class="content-title">영수증 등록(상태 : 대기 & 반려)</h2>
      <p class="content-sub-title">
        [반려 → 신청] 영수증은 상태 및 결재선은 승인은 초기화
      </p>

      <DefaultFormRow gap="10px" marginBottom="10px" align="between">
        <!-- 필터 -->
        <DefaultSelect
          id="serviceSearch"
          v-model="selectedService"
          :options="serviceOptions"
          @change="onStatusChange"
          size="small"
        />
        <!-- <select
          v-model="filterStatus"
          class="form-select form-select-sm"
          style="width:110px; height: 38px;"
        >
          <option value="">전체</option>
          <option value="WAITING">대기</option>
          <option value="REJECTED">반려</option>
        </select> -->
        <DefaultButton 
          align="right" 
          style="" 
          @click="openModal"
        >
          영수증 등록
        </DefaultButton>
      </DefaultFormRow>

      <!-- 영수증 등록 모달 -->
      <ReceiptSubmissionCreateModal
        :isVisible="modalVisible"
        @close="modalVisible = false"
        @confirm="() => receiptConfirm()"
      />

      <!-- 영수증 수정 모달 (신규) -->
      <ReceiptSubmissionEditModal
        :isVisible="editModalVisible"
        :receipt="editingReceipt"
        @close="editModalVisible = false"
        @confirm="() => fetchMetadata(currentPage)"
      />

      <!-- 조회 결과 없는 경우 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="data.length">
        <!-- 테이블 보기 -->
        <DefaultTable
          class="receipt-table"
          :columns="columns"
          :data="data"
          :showTable="!isMobile"
          :rowClick="openEditModal"
          :buttonHeight="'30px'"
          @apply-row="handleApply"
          @delete-row="handleDelete"
          :minRows="8"
        />

        <!-- 카드 레이아웃 (모바일에서만) -->
        <div class="card-layout" v-if="isMobile">
          <div class="card" v-for="(item, idx) in data" :key="idx">
            <div class="card-header">
              <p class="card-title">
                {{ item.date }} <br />
                [ 식별 번호 : {{ item.receiptCode }} ]
              </p>

              <!-- 오른쪽 액션 버튼 -->
              <div class="card-actions">
                <DefaultButton
                  size="small"
                  color="gray"
                  customHeight="25px"
                  @click.stop="openEditModal(item)"
                >
                  수정
                </DefaultButton>
                <DefaultButton
                  size="small"
                  color="blue"
                  customHeight="25px"
                  @click.stop="handleApply(item)"
                >
                  신청
                </DefaultButton>
                <DefaultButton
                  size="small"
                  color="red"
                  customHeight="25px"
                  @click.stop="handleDelete(item)"
                >
                  삭제
                </DefaultButton>
              </div>
            </div>
            <div class="card-body">
              <p class="card-text">
                <strong>총 인원(당사자 포함) : </strong>
                <span @click="togglePeopleList(item)" style="cursor: pointer"
                  >{{ item.peopleCount }}명</span
                >
              </p>
              <div v-if="showPeopleList(item)">
                <div class="people-list">
                  <!-- <div class="people-list-header">명단</div> -->
                  <p
                    v-for="person in item.people"
                    :key="person.name"
                    class="people-list-item"
                  >
                    [ 일행 ] {{ person.name }} ({{ person.department }} -
                    {{ person.team }})
                  </p>
                </div>
              </div>

              <p class="card-text">
                <strong>결재 상태 : </strong>
                <span :class="statusColor(item.statusText)">
                  {{ item.statusText }}
                </span>
              </p>
              <!-- 반려 사유(있을 때) -->
              <p v-if="item.statusText==='반려' && item.rejectedReason"
                class="card-text text-danger ms-1">
                • {{ item.rejectedReason }}
              </p>

              <!-- ─── 결재자 목록 ─── -->
              <p class="card-text">
                <strong>결재자 : </strong>
                <span @click="toggleApproverList(idx)" style="cursor: pointer">
                  {{ item.approvers.length }}명
                </span>
              </p>
              <div v-if="showApproverList(idx)">
                <div class="people-list">
                  <!-- <div class="people-list-header">결재자</div> -->
                  <p
                    v-for="ap in item.approvers"
                    :key="ap.userId"
                    class="people-list-item"
                  >
                    [{{ ap.stateText }}] {{ ap.name }} ({{ ap.department }}-{{ ap.team }})
                  </p>
                </div>
              </div>

              <p class="card-text">
                <strong>구분/사유 : </strong> {{ item.type }} /
                {{ item.reason }}
              </p>
              <p class="card-text">
                <strong>금액 : </strong> {{ item.amount }}
              </p>
              <p class="card-text">
                <strong>금액/인원수 : </strong>
                {{ calculateAmountPerPerson(item) }}
              </p>
              <p>
                <strong class="card-text">영수증 사진 : </strong>
                <a
                  class="card-text"
                  @click.prevent="openPreviewModal(item.receipt)"
                  style="cursor: pointer; color: blue"
                >
                  {{ item.receiptName }}
                </a>
              </p>
            </div>
          </div>
        </div>

        <!-- 페이지네이션 (공통 컴포넌트) -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>

    <!-- 이미지 미리보기 -->
    <div
      v-if="isPreviewVisible"
      class="modal preview-modal"
      @click="closePreviewModalOnOutsideClick"
    >
      <div
        class="preview-modal-content"
        @mousedown="startDrag"
        @mousemove="onDrag"
        @mouseup="endDrag"
        @mouseleave="endDrag"
        @touchstart="startDrag"
        @touchmove="onDrag"
        @touchend="endDrag"
      >
        <img
          :src="previewImage"
          :class="{ zoomed: isZoomed }"
          class="preview-modal-image"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`,
          }"
          @dblclick="toggleZoom"
          @touchstart="toggleZoom"
        />
      </div>
    </div>
  </div>

  <!-- 신청 확인 모달 -->
  <AlertModal
    :isVisible="applyModalVisible"
    title="신청 확인"
    confirmText="신청"
    cancelText="취소"
    @close="applyModalVisible = false"
    @confirm="confirmApply"
  >
    <template #body>
      <p>선택한 영수증을 신청하시겠습니까?</p>
    </template>
  </AlertModal>

  <!-- 삭제 확인 모달 -->
  <AlertModal
    :isVisible="deleteModalVisible"
    confirmText="삭제"
    cancelText="취소"
    @close="deleteModalVisible = false"
    @confirm="confirmDelete"
  >
    <template #body>
        <div style="color: red;">
          ※ 삭제 ※ <br/><br/>
          영수증을 삭제하면 복구되지 않습니다 <br/>
          영수증 삭제를 진행하겠습니까? <br/>
        </div>
    </template>
  </AlertModal>
</template>

<script setup>
/* ───────────────────────── IMPORTS ───────────────────────── */
import { ref, computed, onMounted, watch } from 'vue'
import { toast }                    from 'vue3-toastify'

import DefaultTable                 from '@/components/common/table/DefaultTable.vue'
import DefaultButton                from '@/components/common/button/DefaultButton.vue'
import DefaultPagination            from '@/components/common/pagination/DefaultPagination.vue'
import DefaultFormRow               from '@/components/common/DefaultFormRow.vue'
import DefaultSelect                from "@/components/common/select/DefaultSelect.vue";
import AlertModal                   from '@/components/common/modal/AlertModal.vue'
import ReceiptSubmissionCreateModal from '@/components/receipt/ReceiptSubmissionCreateModal.vue'
import ReceiptSubmissionEditModal   from '@/components/receipt/ReceiptSubmissionEditModal.vue'

import ReceiptsApi          from '@/api/receipt/ReceiptsApi'
import ReceiptsRequestApi   from '@/api/receipt/ReceiptsRequestApi'
import { useAuthStore }     from '@/store/auth'
import { usePreviewModal }  from '@/utils/preview-modal'

/* ───────────────────────── CONSTANTS ─────────────────────── */
const MOBILE_BP         = 650
const MOBILE_PAGE_SIZE  = 4
const DESKTOP_PAGE_SIZE = 8

/* ───────────────────────── RESPONSIVE ────────────────────── */
const isMobile = ref(window.innerWidth <= MOBILE_BP)
const pageSize = computed(() => isMobile.value ? MOBILE_PAGE_SIZE : DESKTOP_PAGE_SIZE)
function updateIsMobile () { isMobile.value = window.innerWidth <= MOBILE_BP }
window.addEventListener('resize', updateIsMobile)

/* ───────────────────────── STORES ────────────────────────── */
const authStore = useAuthStore()

/* ───────────────────────── DATA / TABLE ──────────────────── */
const data            = ref([])
const noData          = ref(false)
const currentPage     = ref(1)
const totalPages      = ref(1)
const visiblePageCount= ref(5)
const serviceOptions = [
  { value: '',          label: '전체'  },
  { value: 'WAITING',   label: '대기'  },
  { value: 'REJECTED',  label: '반려' }
]
const selectedService = ref('')        // v-model 값
const filterStatus    = ref('')        // 실제 API 파라미터

/* ─────── columns: 템플릿에서 그대로 쓰므로 변경 ❌ ─────── */
const columns = [
  { key:'receiptCode',     label:'식별 번호',  width:75,  align: 'center' },
  { key:'date',            label:'발행일',  width:100,    align: 'center' },
  { key:'type',            label:'구분',    width:100,    align: 'center' },
  { key:'peopleCount',     label:'총 인원', width:60,     align: 'center'  },
  { key:'reason',          label:'사유',    width:150,    align: 'left'},
  { key:'amount',          label:'금액',    width:80,     align: 'right' },
  { key:'amountPerPerson', label:'금액/인원',width:80,    align: 'right' },
  { key:'statusText',      label:'결제 상황',width:75,    align: 'center',
    customClass:v=>v==='반려'?'text-red':'' },
  { key:'apply',  type:'button', label:'', width:80,
    buttonText:'신청',  buttonColor:'blue', buttonSize:'full-small', emit:'apply-row' },
  { key:'delete', type:'button', label:'', width:80,
    buttonText:'삭제', buttonColor:'red',  buttonSize:'full-small', emit:'delete-row' }
]

/* ───────────────────────── PREVIEW MODAL ─────────────────── */
const { isPreviewVisible, previewImage,
        isZoomed, zoomedPosition, zoomOrigin,
        openPreviewModal, toggleZoom,
        startDrag, onDrag, endDrag } = usePreviewModal()

function closePreviewModalOnOutsideClick (e) {
  if (!e.target.classList.contains('preview-modal-image'))
    isPreviewVisible.value = false
}

/* ───────────────────────── CARD TOGGLES ──────────────────── */
const openedIndex       = ref(null)  // 참여자
const openedApproverIdx = ref(null)  // 결재자
function togglePeopleList    (row){ openedIndex.value       = openedIndex.value===row ? null : row }
function showPeopleList      (row){ return openedIndex.value       === row }
function toggleApproverList  (i)  { openedApproverIdx.value = openedApproverIdx.value===i ? null : i }
function showApproverList    (i)  { return openedApproverIdx.value === i }

/* ───────────────────────── SUPPORT FNS ──────────────────── */
const calculateAmountPerPerson = item => {
  const total = parseInt((item.amount||'0').replace(/[^0-9]/g,''),10)||0
  return item.peopleCount
    ? Math.floor(total/item.peopleCount).toLocaleString()
    : '0'
}
const statusColor = txt =>
  txt==='승인' ? 'text-success'
: txt==='반려'  ? 'text-danger'
: txt==='대기'  ? 'text-primary'
:                 'text-secondary'

/* ───────────────────────── MODAL FLAGS ───────────────────── */
const modalVisible       = ref(false)
const editModalVisible   = ref(false)
const editingReceipt     = ref(null)

const applyModalVisible  = ref(false)
const deleteModalVisible = ref(false)
const applyTarget        = ref(null)
const deleteTarget       = ref(null)

/* ───────────────────────── FETCH LIST ────────────────────── */
async function fetchMetadata (page=1){
  const { data: pageDto } =
    await ReceiptsApi.searchUserReceipts(authStore.getUserId,{
      statusCodes:
        filterStatus.value==='WAITING' ? [4] :
        filterStatus.value==='REJECTED'? [3] : [3,4],
      page:page-1,
      size:pageSize.value
    })

  data.value = (pageDto.content||[]).map(mapRow)
  totalPages.value = pageDto.totalPages || 1
  noData.value     = data.value.length===0
  if(isMobile.value) window.scrollTo(0,0)
}

function mapRow(r){
  const people     = (r.participantsList||[]).map(p=>({
    userId    : p.participantUserId ?? null,
    name:p.participantName, 
    department:p.department, 
    team:p.team
  }))
  const amountRaw  = +r.amount || 0
  const approvers  = (r.approvalLines||[]).map(al=>({
    userId:al.approverUserId,
    name:al.approverName,
    department:al.department,
    team:al.team,
    approvalRole:al.approvalRole,
    approvalType:al.approvalRole===1?'결재':'합의',
    approvalStatus:al.approvalStatus,
    rejected:!!al.rejectedAt,
    stateText: al.rejectedAt ? '반려' : al.approvalStatus ? '승인':'대기',
    rejectedReason:al.rejectedReason??''
  }))
  const rejectedReason = approvers.find(a=>a.rejectedReason)?.rejectedReason || ''

  return {
    /* table/card 필드 */
    receiptId:r.receiptId,
    receiptCode:r.receiptCode,
    date:r.submissionDate,
    type:r.category?.categoryName ?? '',
    categoryId:r.category?.categoryId ?? null,
    reason:r.reason,
    amount:amountRaw.toLocaleString(),
    amountRaw,
    receiptName:r.attachment?.fileName || '영수증 미등록',
    receipt:r.attachment?.fileUrl || '',
    people,
    peopleCount:people.length+1,
    amountPerPerson: Math.floor(amountRaw/(people.length+1)).toLocaleString(),
    approvers,
    status:r.status,
    statusText: r.status==='WAITING' ? '대기' : r.status==='REJECTED' ? '반려' : '',
    rejectedReason
  }
}

/* ───────────────────────── PAGINATION ───────────────────── */
function onPageChange(p){ currentPage.value=p; fetchMetadata(p) }


/* ───────────────────────── 필터 ───────────────────── */
function onStatusChange(val){
  filterStatus.value = val
  currentPage.value  = 1
  fetchMetadata(1)
}

/* ───────────────────────── APPLY / DELETE ───────────────── */
function handleApply (row){ applyTarget.value=row;   applyModalVisible.value=true }
function handleDelete(row){ deleteTarget.value=row; deleteModalVisible.value=true }

async function confirmApply(){
  if(!applyTarget.value) return
  try{
    await ReceiptsRequestApi.requestReceipt(applyTarget.value.receiptId)
    toast.success('신청 완료되었습니다.')
    fetchMetadata(currentPage.value)
  }catch(e){
    console.error(e); toast.error('신청 중 오류가 발생했습니다.')
  }finally{
    applyModalVisible.value=false; applyTarget.value=null
  }
}
async function confirmDelete(){
  if(!deleteTarget.value) return
  try{
    await ReceiptsApi.deleteReceipt(deleteTarget.value.receiptId)
    toast.success('삭제되었습니다.')
    fetchMetadata(currentPage.value)
  }catch(e){
    console.error(e); toast.error('삭제 중 오류가 발생했습니다.')
  }finally{
    deleteModalVisible.value=false; deleteTarget.value=null
  }
}

/* ───────────────────────── REG / EDIT ───────────────────── */
function receiptConfirm(){ toast.success('영수증 등록 성공'); fetchMetadata(currentPage.value) }
function openModal(){ modalVisible.value=true }
function openEditModal(row){
  const src = data.value.find(d=>d.receiptId===row.receiptId) || row
  editingReceipt.value = {
    id:src.receiptId,
    date:src.date,
    type:src.type,
    categoryId:src.categoryId,
    amount:src.amountRaw.toString(),
    reason:src.reason,
    receiptName:src.receiptName,
    receipt:src.receipt,
    participants:[...src.people],
    approvers:[...(src.approvers||[])],
    status:src.status ?? '',
    statusText:src.statusText ?? '',
    rejectedReason:src.rejectedReason
  }
  editModalVisible.value = true
}

/* ───────────────────────── LIFECYCLE ────────────────────── */
onMounted(() => fetchMetadata())
</script>

<style scoped>
.modal-header {
  display: flex;
  justify-content: space-between;
  font-size: 1.5rem;
}

.reason {
  margin-top: 10px;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 10px;
}

.list-group-item,
.list-group {
  font-size: 0.875em !important;
}

.square-btn {
  width: 15px;
  height: 15px;
  padding: 0;
  text-align: center;
  border-radius: 4px;
  font-size: 0.55rem;
}

.now-label {
  cursor: pointer;
  color: #0d6efd;
}

.now-label:hover {
  text-decoration: underline;
}

.drag-handle {
  cursor: grab;
  user-select: none;
}

.drag-handle:active {
  cursor: grabbing;
}

.align-items-center {
  margin-bottom: 0px !important;
}

/* 선택 토글용 글자 버튼 */
.approval-option {
  cursor: pointer;
  padding: 2px 6px;
  /* border-radius: 4px; */
  color: #39393a; /* 기본 회색 */
  border: 1px solid #8e8e8f; /* 기본 얇은 회색 테두리 */
  user-select: none;
  margin: 0;
}

.approval-option + .approval-option {
  margin-left: -1px; /* 경계선 겹침 처리 */
}

.approval-option-right {
  margin-right: 7px;
}
.approval-option.active {
  color: #0d6efd; /* 선택 시 파란색 */
  font-weight: 900;
  background: #0d6dfd25;
}
/* ── 미리보기 모달 ───────────────────────────── */
.preview-modal {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}

/* ─── 카드 헤더 버튼 일렬 배치 ─────────────────── */
.card-actions {
  display: flex;          /* 가로 한 줄 */
  flex-wrap: nowrap;      /* 줄바꿈 방지 */
  gap: 4px;               /* 버튼 간격 */
  margin-left: auto;
}

/* DefaultButton 내부 <button> 폭 덮어쓰기 */
.card-actions :deep(button) {
  width: auto !important; /* 100% → auto */
  min-width: 50px;        /* 필요 시 최소 너비 지정 */
  padding: 2px 6px;       /* XS 버튼 느낌 */
  line-height: 1.3;
}
.card-header {
  display: flex;
  align-items: center;
}
@media (max-width: 650px) {
  .list-group-item,
  .list-group {
    font-size: 0.8em !important;
  }

  .form-group {
    margin-bottom: 10px;
  }
}
</style>
