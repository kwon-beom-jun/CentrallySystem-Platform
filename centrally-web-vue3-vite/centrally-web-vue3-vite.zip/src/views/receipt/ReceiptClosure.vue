<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 결제 마감 확인</h2>
      <p class="content-sub-title">결제 마감 후 정상적 처리 확인 페이지</p>



    </div>
  </div>
</template>

<script setup>
</script>

<style scoped>
</style>
