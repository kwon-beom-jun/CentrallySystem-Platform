<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 전체 취합</h2>
      <p class="content-sub-title">Receipt Category Management</p>

      

      <!-- ───── 검색 영역 ───── -->
      <div class="search-controls">
        <!-- 시작/종료일 -->
        <DefaultFormRow align="right">
          <DefaultLabel text="시작 :" forId="startDate" size="small" />
          <DefaultTextfield
            type="date"
            id="startDate"
            v-model="startDate"
            size="xsmall"
          />
          <DefaultLabel text="종료 :" forId="endDate" size="small" marginLeft="10px" />
          <DefaultTextfield
            type="date"
            id="endDate"
            v-model="endDate"
            size="xsmall"
          />
        </DefaultFormRow>

        <!-- 이름 검색 -->
        <DefaultFormRow align="right" marginTop="7px">
          <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
          <UserSearchDropdown
            labelText="사용자 검색"
            inputId="nameSearch"
            inputSize="large"
            placeholder="사용자(이메일)을 검색해주세요"
            :includeCurrentUser="true"
            @userSelected="onUserSelected"
          />
          <DefaultButton
            size="small"
            @click="search"
            color="gray"
          >
            조회
          </DefaultButton>
        </DefaultFormRow>
      </div>

      <!-- 조회 결과 없을 때 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-else-if="data.length">
        <!-- DefaultTable 컴포넌트 (큰 화면) -->
        <DefaultTable
          :columns="columns"
          :data="data"
          :showTable="!isMobile"
          :bodyFontSize="'0.7rem'"
          :rowClick="goToDetail"
        />

        <!-- 카드 형식(작은 화면) -->
        <div v-if="isMobile">
          <div
            class="card"
            v-for="(item, index) in data"
            :key="index"
            @click="goToDetail(item)"
          >
            <div class="card-header">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <p class="card-title">{{ item.name }}</p>
                <p class="card-title">{{ item.email }}</p>
              </div>
            </div>
            <div class="card-body">
              <p class="card-text"><strong>건수: </strong>{{ item.count }}</p>
              <p class="card-text"><strong>부서: </strong>{{ item.department }}</p>
              <p class="card-text"><strong>팀: </strong>{{ item.team }}</p>
              <p class="card-text"><strong>총 건수: </strong>{{ formatCurrency(item.requested) }}원</p>
              <p class="card-text"><strong>승인 건수: </strong>{{ formatCurrency(item.approved) }}원</p>
              <p class="card-text"><strong>마감 건수: </strong>{{ formatCurrency(item.rejected) }}원</p>
            </div>
          </div>
        </div>

        <!-- 페이지네이션 -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router';

/* ─── 공용 컴포넌트 ─── */
import DefaultTable       from '@/components/common/table/DefaultTable.vue';
import DefaultPagination  from '@/components/common/pagination/DefaultPagination.vue';
import DefaultFormRow     from '@/components/common/DefaultFormRow.vue';
import DefaultLabel       from '@/components/common/label/DefaultLabel.vue';
import DefaultTextfield   from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultButton      from '@/components/common/button/DefaultButton.vue';
import UserSearchDropdown from '@/components/auth/UserSearchDropdown.vue';
import { useAuthStore } from '@/store/auth'
import { useUserDirectoryStore } from "@/store/hrm/userDirectory";

// API
import ReceiptsSearchApi from '@/api/receipt/ReceiptsSearchApi'; 
import HrmUserApi from '@/api/hrm/UsersApi.js'; // 🔥 HrmUserApi로만 사용자 정보 획득

// Vue Router
const router = useRouter();
const authStore = useAuthStore();

// 상태 변수
const noData = ref(false);
const data = ref([]);  // 최종 테이블/카드에 표시할 목록
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);
const isMobile = ref(false);

// 검색 조건
const startDate = ref('');
const endDate = ref('');
const searchUserId = ref(''); // UserSearchDropdown에서 선택된 유저ID
// 사용자 및 권한 조회
const userDirStore = useUserDirectoryStore();

// 조회된 날짜 범위(출력용)
const computedStartDate = ref('');
const computedEndDate = ref('');

// 모든 사용자 목록
const userList = ref([]);

// 테이블 컬럼 정의
const columns = ref([
  { key: 'name',      label: '이름',      width: 60  },
  { key: 'department',label: '부서',      width: 100 },
  { key: 'team',      label: '팀',        width: 100 },
  { key: 'email',     label: '이메일',    width: 130 },
  { key: 'count',     label: '총 건수',   width: 80,    align: 'center' },
  { key: 'approved',  label: '승인 건수',  width: 100,  align: 'right' },
  { key: 'closed',    label: '마감 건수',  width: 100,  align: 'right' },
]);

// ========== 서버에서 요약 데이터 가져오기 ==========
async function fetchDataFromServer(page = 1) {
  const pageSize = isMobile.value ? 4 : 10;
  const response = await ReceiptsSearchApi.getApprClosedSummaryAll({
    startDate: startDate.value,
    endDate:   endDate.value,
    userId:    searchUserId.value || undefined,
    page:      currentPage.value - 1,
    size:      pageSize
  });

  data.value       = enrichSummaryData(response.data.content);
  totalPages.value = response.data.totalPages; 

  // response.data.content를 기반으로 userList 정보와 매핑
  data.value = enrichSummaryData(response.data.content);
  noData.value = data.value.length ? false : true;
  totalPages.value = response.data.totalPages;
  
  computedStartDate.value = startDate.value;
  computedEndDate.value = endDate.value;

  // 스크롤 맨 위로 이동(모바일 카드형식일때)
  if (isMobile.value) {
    window.scrollTo(0, 0)
  }
}

// ========== 사용자 목록 불러오기(HrmUserApi) & 부서/팀/직급 정보 포함 ==========
async function fetchUserList() {
  const userRes = await HrmUserApi.getUsers();
  const rawUsers = userRes.data || [];
  // 필요한 필드만 매핑
  userList.value = rawUsers.map(u => ({
    userId: u.userId,
    email: u.email,
    name: u.name,
    // HrmUser.team?.teamName, team.department?.departmentName
    department: u.team?.department?.departmentName || '미지정',
    team: u.team?.teamName || '미지정'
  }));
}

// 요약 데이터에 사용자 정보(이름, 이메일, 부서, 팀) 매핑
function enrichSummaryData(summaryList) {
  return summaryList.map(item => {
    const matchedUser = userList.value.find(u => u.userId === item.userId);
    return {
      ...item,
      name: matchedUser?.name || '알 수 없음',
      email: matchedUser?.email || '알 수 없음',
      department: matchedUser?.department || '미지정',
      team: matchedUser?.team || '미지정'
    };
  });
}

// 페이지네이션
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
}

// 반응형
function updateViewMode() {
  isMobile.value = window.innerWidth <= 850;
}

// 금액 표시
function formatCurrency(amount) {
  if (!amount) return '0';
  return amount.toLocaleString();
}

// 날짜 제한 로직
watch(startDate, (newVal) => {
  if (newVal > endDate.value) {
    endDate.value = newVal;
  }
});
watch(endDate, (newVal) => {
  if (newVal < startDate.value) {
    startDate.value = newVal;
  }
});

// 상세 페이지 이동
function goToDetail(item) {
  router.push({
    name: 'ReceiptAllMergeDetail',
    query: {
      userId: item.userId,
      userName: item.name,
      startDate: startDate.value,
      endDate: endDate.value
    }
  });
}

// 날짜 자동 설정: YYYY-MM-DD 형태
function getTodayString() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// UserSearchDropdown 선택 이벤트
function onUserSelected(user) {
  // user = { userId, email, name, … }
  searchUserId.value = user?.userId ?? '';
}

// 조회 버튼 메서드
function search() {
  currentPage.value = 1;          // 항상 1페이지부터
  fetchDataFromServer(1);
}

// 날짜 제한 로직(자동 조회 X)
watch(startDate, newVal => {
  if (newVal > endDate.value) endDate.value = newVal;
});
watch(endDate, newVal => {
  if (newVal < startDate.value) startDate.value = newVal;
});

// onMounted
onMounted(async () => {
  // 1) 사용자 목록 불러오기 (team/department 포함)
  await fetchUserList();
  userDirStore.refresh();

  // 2) 기본 날짜(오늘)
  startDate.value = getTodayString();
  endDate.value = getTodayString();

  // 3) 첫 조회
  fetchDataFromServer(currentPage.value);

  // 4) 반응형 모드 설정
  updateViewMode();
  window.addEventListener('resize', updateViewMode);
});
</script>

<style scoped>
.search-controls {
  margin-top: 30px;
  margin-bottom: 10px;
}
.align-items-center {
  margin-bottom: 0px !important;
}

/* 반응형 테이블/카드 */
@media (min-width: 851px) {
  #nameSearch {
    font-size: 1rem;
  }
  .card {
    display: none; /* 카드 숨기기 (PC에서는 테이블만) */
  }
  .table {
    display: table;
  }
}

@media (max-width: 850px) {
  .content-sub-title {
    margin-bottom: 88px !important;
  }
  .btn-primary {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
    margin-bottom: 10px;
  }
  .table {
    display: none; /* 모바일에서는 카드 형식만 보여줌 */
  }
}
</style>
