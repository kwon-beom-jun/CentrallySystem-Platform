<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 결재 내역 조회(내가 포함된 결재선)</h2>
      <!-- 검색된 날짜 범위 표시 -->
      <p class="content-sub-title">
        날짜: [{{ computedStartDate }} ~ {{ computedEndDate }}]
      </p>

      <!-- 검색 영역 -->
      <div class="search-controls">
        <!-- 시작, 종료일 그룹 -->
        <DefaultFormRow align="right">
          <DefaultLabel text="시작 :" forId="startDate" size="small" />
          <DefaultTextfield
            type="date"
            id="startDate"
            v-model="startDate"
            size="xsmall"
          />
          <DefaultLabel text="종료 :" forId="endDate" size="small" marginLeft="10px" />
          <DefaultTextfield
            type="date"
            id="endDate"
            v-model="endDate"
            size="xsmall"
          />
        </DefaultFormRow>
        <!-- 이름 검색 그룹 -->
        <DefaultFormRow align="right" marginTop="7px">
          <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
          <UserSearchDropdown
            labelText="사용자 검색"
            inputId="nameSearch"
            inputSize="large"
            placeholder="사용자(이메일)을 검색해주세요"
            :includeCurrentUser="true"
            @userSelected="onUserSelected"
          />
          <DefaultButton 
            @click="search"
            size="small">
            조회
          </DefaultButton>
        </DefaultFormRow>
      </div>

      <!-- 조회 결과 없을 때 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-else-if="data.length">
        <!-- DefaultTable 컴포넌트 (큰 화면) -->
        <DefaultTable
          :columns="columns"
          :data="data"
          :showTable="!isMobile"
          :bodyFontSize="'0.7rem'"
          :rowClick="goToDetail"
        />

        <!-- 카드 형식(작은 화면) -->
        <div v-if="isMobile">
          <div
            class="card"
            v-for="(item, index) in data"
            :key="index"
            @click="goToDetail(item)"
          >
            <div class="card-header">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <p class="card-title">{{ item.name }}</p>
                <p class="card-title">{{ item.email }}</p>
              </div>
            </div>
            <div class="card-body">
              <p class="card-text"><strong>건수: </strong>{{ item.count }}</p>
              <p class="card-text"><strong>부서: </strong>{{ item.department }}</p>
              <p class="card-text"><strong>팀: </strong>{{ item.team }}</p>
              <p class="card-text"><strong>대기: </strong>{{ formatCurrency(item.waiting) }}원</p>
              <p class="card-text"><strong>신청: </strong>{{ formatCurrency(item.requested) }}원</p>
              <p class="card-text"><strong>승인: </strong>{{ formatCurrency(item.approved) }}원</p>
              <p class="card-text"><strong>반려: </strong>{{ formatCurrency(item.rejected) }}원</p>
              <p class="card-text"><strong>마감: </strong>{{ formatCurrency(item.closed) }}원</p>
            </div>
          </div>
        </div>

        <!-- 페이지네이션 -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
/* ───────────────────────────── imports ───────────────────────────── */
import { ref, watch, onMounted }        from 'vue'
import { useRouter }                    from 'vue-router'

import DefaultTable                     from '@/components/common/table/DefaultTable.vue'
import DefaultButton                    from '@/components/common/button/DefaultButton.vue'
import DefaultPagination                from '@/components/common/pagination/DefaultPagination.vue'
import DefaultTextfield                 from '@/components/common/textfield/DefaultTextfield.vue'
import DefaultLabel                     from '@/components/common/label/DefaultLabel.vue'
import DefaultFormRow                   from '@/components/common/DefaultFormRow.vue'
import UserSearchDropdown               from '@/components/auth/UserSearchDropdown.vue'

import { useAuthStore }                 from '@/store/auth'
import { useUserDirectoryStore }        from '@/store/hrm/userDirectory'

import ReceiptsSearchApi                from '@/api/receipt/ReceiptsSearchApi'
import HrmUserApi                       from '@/api/hrm/UsersApi'

/* ──────────────────────────── stores & router ────────────────────── */
const auth        = useAuthStore()
const directory   = useUserDirectoryStore()
const router      = useRouter()

/* ─────────────────────────── reactive states ─────────────────────── */
const isMobile           = ref(false)
const startDate          = ref('')
const endDate            = ref('')
const searchUserId       = ref('')
const computedStartDate  = ref('')
const computedEndDate    = ref('')

const data               = ref([])
const noData             = ref(false)

const currentPage        = ref(1)
const totalPages         = ref(1)
const visiblePageCount   = ref(5)

/* ───────────────────────────── table meta ───────────────────────── */
const columns = [
  { key:'name',      label:'이름',     width: 60  },
  { key:'department',label:'부서',     width: 100 },
  { key:'team',      label:'팀',       width: 100 },
  { key:'email',     label:'이메일',   width: 130 },
  { key:'count',     label:'건수',     width: 50,   align: 'center' },
  { key:'waiting',   label:'대기',     width: 100,  align: 'right' },
  { key:'requested', label:'신청',     width: 100,  align: 'right' },
  { key:'approved',  label:'승인',     width: 100,  align: 'right' },
  { key:'rejected',  label:'반려',     width: 100,  align: 'right' },
  { key:'closed',    label:'마감',     width: 100,  align: 'right' }
]

/* ─────────────────────────── helper utils ───────────────────────── */
const won = n => (Number(n||0)).toLocaleString()

function formatCurrency(n){ return won(n) }

/* ──────────────────────── user list mapping  ────────────────────── */
const userList = ref([])                      // [{userId, name, email, dept, team}]
async function fetchUserList () {
  const { data } = await HrmUserApi.getUsers()
  userList.value = (data || []).map(u => ({
    userId     : u.userId,
    email      : u.email,
    name       : u.name,
    department : u.team?.department?.departmentName ?? '미지정',
    team       : u.team?.teamName ?? '미지정'
  }))
}

/* ───────────────────────── data enrichment ───────────────────────── */
function enrichSummaryData (rows){
  return rows.map(r=>{
    const u = userList.value.find(x=>x.userId===r.userId) || {}
    return {
      ...r,
      name      : u.name       ?? '알 수 없음',
      email     : u.email      ?? '알 수 없음',
      department: u.department ?? '미지정',
      team      : u.team       ?? '미지정'
    }
  })
}

/* ──────────────────────── server interaction ────────────────────── */
async function fetchData (page=1){
  const pageSize = isMobile.value ? 4 : 10
  const { data: res } = await ReceiptsSearchApi.getReceiptSummaryByNameAndDate({
    startDate : startDate.value,
    endDate   : endDate.value,
    userId    : searchUserId.value,
    approverId: auth.getUserId,
    page      : page-1,
    size      : pageSize
  })
  data.value          = enrichSummaryData(res.content || [])
  noData.value        = data.value.length === 0
  totalPages.value    = res.totalPages || 1
  computedStartDate.value = startDate.value
  computedEndDate.value   = endDate.value
  if (isMobile.value) window.scrollTo(0,0)
}

/* ─────────────────────────── search / nav ───────────────────────── */
function search () {
  currentPage.value = 1
  fetchData(1)
}
function onPageChange (p){ currentPage.value = p; fetchData(p) }
function onUserSelected (u){ searchUserId.value = u.userId }
function goToDetail (row){
  router.push({
    name : 'ReceiptHistoryDetail',
    query: {
      userId   : row.userId,
      userName : row.name,
      startDate: startDate.value,
      endDate  : endDate.value
    }
  })
}

/* ───────────────────────────── watchers ─────────────────────────── */
watch(startDate,v=>{ if(v> endDate.value) endDate.value=v })
watch(endDate  ,v=>{ if(v< startDate.value) startDate.value=v })

/* ───────────────────────────── resize  ──────────────────────────── */
function updateViewMode (){ isMobile.value = window.innerWidth <= 850 }

/* ──────────────────────────── init helpers ───────────────────────── */
function todayString (){
  const d=new Date()
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

/* ───────────────────────────── mounted ──────────────────────────── */
onMounted(async ()=>{
  await fetchUserList()
  await directory.refresh()

  startDate.value = endDate.value = todayString()

  updateViewMode()
  window.addEventListener('resize', updateViewMode)

  // fetchData(currentPage.value)
  search()
})
</script>

<style scoped>
.search-controls {
  margin-top: 30px;
  margin-bottom: 10px;
}
.align-items-center {
  margin-bottom: 0px !important;
}

/* 반응형 테이블/카드 */
@media (min-width: 851px) {
  #nameSearch {
    font-size: 1rem;
  }
  .card {
    display: none; /* 카드 숨기기 (PC에서는 테이블만) */
  }
  .table {
    display: table;
  }
}

@media (max-width: 850px) {
  .btn-primary {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
    margin-bottom: 10px;
  }
  .table {
    display: none; /* 모바일에서는 카드 형식만 보여줌 */
  }
}
</style>
