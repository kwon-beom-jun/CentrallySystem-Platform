<template>
  <div class="content content-wrapper">
    <h2 class="content-title">영수증 신청 내역 조회 현황</h2>
    <p class="content-sub-title date-toggle-line">
      <span>검색 날짜: [{{ startDate }} ~ {{ endDate }}]</span>
      <DefaultButton
        v-if="tableData.length"
        @click="toggleKpi"
        type="text"
        class="kpi-toggle-btn"
      >
        {{ showKpi ? '통계 숨기기 ▲' : '통계 보기 ▼' }}
      </DefaultButton>
    </p>

    <!-- ───── 검색 영역 ───── -->
    <div class="search-controls">
      <!-- ① 날짜 범위만 -->
      <DefaultFormRow align="right">
        <DefaultLabel text="시작 :" forId="startDate" size="small" />
        <DefaultTextfield id="startDate" type="date" v-model="startDate" size="xsmall" />

        <DefaultLabel text="종료 :" forId="endDate" size="small" marginLeft="10px" />
        <DefaultTextfield id="endDate" type="date" v-model="endDate" size="xsmall" />
      </DefaultFormRow>

      <!-- ② 이름 + 조회 버튼 (추가) -->
      <DefaultFormRow align="right" marginTop="7px">
        <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
        <UserSearchDropdown
          labelText="사용자 검색"
          inputId="nameSearch"
          inputSize="large"
          placeholder="사용자(이메일)을 검색해주세요"
          :includeCurrentUser="true"
          @userSelected="onUserSelected"
        />
        <DefaultButton size="small" @click="search" color="gray">조회</DefaultButton>
      </DefaultFormRow>
    </div>

    <!-- KPI 카드 (행이 3개 이하일 때만 노출) -->
    <div v-if="tableData.length && showKpi" class="kpi-wrap">
      <div class="kpi-card">
        <div class="kpi-title">총 영수증 건수</div>
        <div class="kpi-value">{{ summary.cnt }}건</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-title">총 금액</div>
        <div class="kpi-value">{{ formatNumber(summary.total) }}원</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-title">건당 평균 금액</div>
        <div class="kpi-value">{{ formatNumber(summary.avg) }}원</div>
      </div>
    </div>

    <!-- ───── 결과 없을 때 ───── -->
    <div v-if="noData">
      <v-img class="mx-width-700 no-results-found" src="/img/common/state/001.png" />
    </div>

    <!-- ───── 결과 테이블 / 카드 ───── -->
    <div v-if="tableData.length">
      <DefaultTable 
        :columns="columns" 
        :data="tableData" 
        :rowClick="goToDetail" 
        :showTable="!isMobile" 
        :minRows="10"
      />

      <div class="card-layout" v-if="isMobile">
        <div class="card" v-for="(item, idx) in tableData" :key="idx" @click="goToDetail(item)">
          <div class="card-header d-flex justify-content-between mb-2">
            <p class="card-title">{{ item.userName }} [ 식별 번호 : {{ item.receiptCode }} ]</p>
            <p class="card-title">{{ item.submissionDate }}</p>
          </div>
          <div class="card-body">

            <!-- 총 인원·금액/인원수 -->
            <p class="card-text">
              <strong>총 인원(당사자 포함) : </strong>
              {{ item.peopleCount }}명
            </p>

            <p class="card-text">
              <strong>금액/인원수 : </strong>
              {{ formatNumber(item.amountPerPerson) }}원
            </p>

            <!-- ✅ 결재자 표시 / 토글 -->
            <p class="card-text">
              <strong>결재자: </strong>
              <span @click.stop="toggleApproverList(idx)" style="cursor:pointer">
                {{ item.approvers.length }}명
              </span>
            </p>
            <div v-if="showApproverList(idx)">
              <div class="people-list">
                <p v-for="ap in item.approvers" :key="ap.userId" class="people-list-item">
                  [{{ ap.stateText }}] {{ ap.name }} ({{ ap.department }}-{{ ap.team }})
                </p>
              </div>
            </div>

            <p class="card-text"><strong>구분: </strong>{{ item.category }}</p>
            <p class="card-text"><strong>금액: </strong>{{ formatNumber(item.amount) }}원</p>
            <p class="card-text"><strong>사유: </strong>{{ item.reason }}</p>
          </div>
        </div>
      </div>

      <DefaultPagination :currentPage="currentPage" :totalPages="totalPages" :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange" />
    </div>
  </div>
</template>

<script setup>
/* ────────────────────────────────
 *  공통 import
 * ──────────────────────────────── */
import { ref, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth'
import ReceiptsSearchApi from '@/api/receipt/ReceiptsSearchApi'
import HrmUserApi from '@/api/hrm/UsersApi'

/* 로컬 컴포넌트 (템플릿에서 쓰이므로 import 필요) */
import DefaultFormRow from '@/components/common/DefaultFormRow.vue'
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue'
import DefaultLabel from '@/components/common/label/DefaultLabel.vue'
import DefaultButton from '@/components/common/button/DefaultButton.vue'
import DefaultTable from '@/components/common/table/DefaultTable.vue'
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue'
import UserSearchDropdown               from '@/components/auth/UserSearchDropdown.vue'

/* ────────────────────────────────
 *  상수·헬퍼
 * ──────────────────────────────── */
const MOBILE_BP = 850
const MOBILE_PAGE_SIZE = 4
const DESKTOP_PAGE_SIZE = 10
const fmt = n => (+n || 0).toLocaleString()

/* ───────── 반응형 상태 ───────── */
const isMobile = ref(window.innerWidth < MOBILE_BP)
const pageSize = computed(() => isMobile.value ? MOBILE_PAGE_SIZE : DESKTOP_PAGE_SIZE)

/* ───────── 조회·뷰 상태 ───────── */
const router = useRouter()
const myId = useAuthStore().getUserId
const startDate = ref('')
const endDate = ref('')
const currentPage = ref(1)
const totalPages = ref(1)
const visiblePageCount = ref(5)
const tableData = ref([])
const noData = ref(false)

/* ───────── 컬럼 정의 ───────── */
const columns = [
  { key: 'receiptCode',     label:'식별 번호',   width:75,    align: 'center' },
  { key: 'userName',        label: '유저',      width: 50  },
  { key: 'submissionDate',  label: '발행일',    width: 100,   align: 'center' },
  { key: 'peopleCount',     label: '총 인원',   width: 60,    align: 'center' },
  { key: 'category',        label: '구분',      width: 80  },
  { key: 'reason',          label: '사유',      width: 150 },
  { key: 'amount',          label: '금액',      width: 80,    align: 'right' },
  { key: 'amountPerPerson', label: '금액/인원',  width: 90,   align: 'right' }
]
/* ─── KPI 토글 상태 ─── */
const showKpi = ref(false)
function toggleKpi () { showKpi.value = !showKpi.value }

/* ───────── KPI 요약 ───────── */
const summary = ref({ cnt: 0, total: 0, avg: 0 });
const selectedUserId = ref(null);
async function fetchSummary() {
  const { data } = await ReceiptsSearchApi.getMyPendingSummary(myId, {
    userId: selectedUserId.value ?? null,
    startDate: startDate.value,
    endDate: endDate.value,
    statusCode: 'REQUEST',      // 같은 조건
  });
  summary.value = data;
}

/* ───────── 데이터 로드 ───────── */
async function fetchData(page = 1) {
  const { data } =
    await ReceiptsSearchApi.getMyPendingByDate(myId, {
      userId: selectedUserId.value ?? null,
      startDate: startDate.value,
      endDate: endDate.value,
      statusCodes: ['REQUEST'],
      page: page - 1,
      size: pageSize.value
    })

  /* 이름 맵핑 */
  const ids = [...new Set((data.content || []).map(r => r.userId))]
  const users = ids.length ? await HrmUserApi.getUsersByIds(ids) : []
  const nameMap = Object.fromEntries(users.map(u => [u.userId, u.name]))

  /* 행 가공 */
  tableData.value = (data.content || []).map(r => {
    const peopleCnt = (r.participantsList?.length || 0) + 1
    const amount = +r.amount || 0
    return {
      ...r,
      userName: nameMap[r.userId] || '알 수 없음',
      category: r.category?.categoryName || '',
      peopleCount: peopleCnt,
      amountPerPerson: peopleCnt ? Math.floor(amount / peopleCnt) : 0,
      approvers: (r.approvalLines || []).map(a => ({
        userId: a.approverUserId,
        name: a.approverName,
        department: a.department,
        team: a.team,
        stateText: a.rejectedAt ? '반려' : a.approvalStatus ? '승인' : '대기'
      }))
    }
  })

  totalPages.value = data.totalPages || 1
  noData.value = tableData.value.length === 0
  await fetchSummary();
  if (isMobile.value) window.scrollTo(0, 0)
}

/* ───────── 이벤트 ───────── */
function search() { currentPage.value = 1; fetchData(1) }
function onPageChange(p) { currentPage.value = p; fetchData(p) }
function goToDetail(row) {
  router.push({
    name: 'ReceiptPersonalRequestDetails',
    query: {
      startDate: startDate.value,
      endDate: endDate.value,
      userId: row.userId,
      userName: row.userName
    }
  })
}

/* 모바일 카드 토글(원본 유지) */
const openedApproverIdx = ref(null)
function toggleApproverList(i) {
  openedApproverIdx.value =
  openedApproverIdx.value === i ? null : i
}
function showApproverList(i) { return openedApproverIdx.value === i }

/* ───────── 이름 선택 이벤트 ───────── */
function onUserSelected(user) {
  selectedUserId.value = user?.userId ?? null   // dropdown → API 파라미터
}

/* 화면 폭 변경 → pageSize 재적용 */
function handleResize() {
  // const prev = isMobile.value
  // isMobile.value = window.innerWidth < MOBILE_BP
  // if (prev !== isMobile.value) {
  //   currentPage.value = 1
  //   fetchData(1)
  // }
  isMobile.value = window.innerWidth < MOBILE_BP
}

/* 날짜 상호 제약 */
watch(startDate, v => { if (v > endDate.value) endDate.value = v })
watch(endDate, v => { if (v < startDate.value) startDate.value = v })


/** 오늘(로컬 타임존 기준) YYYY-MM-DD */
function todayLocal () {
  const d = new Date()
  // UTC ↔ 로컬 오프셋 보정
  const tzOffsetMs = d.getTimezoneOffset() * 60000
  return new Date(d - tzOffsetMs).toISOString().slice(0, 10)
}

// 📌 PC ↔ 모바일 모드가 실제로 변한 순간에만 1회 재조회
watch(isMobile, () => {
  currentPage.value = 1
  fetchData(1)
})

/* ───────── 최초 실행 ───────── */
onMounted(() => {
  const today = todayLocal()
  startDate.value = endDate.value = today
  window.addEventListener('resize', handleResize)
  fetchData(1)
})

/* 템플릿 헬퍼 */
function formatNumber(n) { return fmt(n) }
</script>


<style scoped>
.content-sub-title {
  margin-bottom: 56px;
}
/* 날짜 + 토글 한 줄 배치 */
.date-toggle-line {
  display: flex;
  align-items: center;
  gap: 8px;          /* 날짜 ↔ 버튼 간격 */
  flex-wrap: wrap;   /* 폭이 좁으면 자동 줄바꿈 */
}

#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}

/* 상태별 색상 설정 */
.status-complete {
  color: blue;
  /* 완료 상태는 파란색 */
}

.status-in-progress {
  color: red;
  /* 진행중 상태는 빨간색 */
}

.align-items-center {
  margin-bottom: 0px !important;
}

.bnt-search {
  margin: 0 !important;
}

.search-controls {
  margin-bottom: 10px;
}

.kpi-wrap {
  display: flex;
  gap: 12px;
  margin-bottom: 14px;
}

.kpi-card {
  flex: 1;
  background: #fafafa;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 8px 14px;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0, 0, 0, .04);
}

.kpi-title {
  font-size: .8rem;
  color: #606060;
  margin-bottom: 4px;
}

.kpi-value {
  font-size: 0.875rem;
  font-weight: 700;
  color: #333;
}

/* 토글 버튼 최소화 */
.kpi-toggle-btn {
  padding: 0;
  font-size: 0.8rem;
  color: #007aff;
  min-width: 0;      /* DefaultButton의 기본 min-width 제거용 */
}
@media (min-width: 851px) {
  #nameSearch {
    font-size: 1rem;
  }

  .card {
    display: none;
    /* 카드 숨기기 */
  }

  .table {
    display: table;
    /* 테이블 표시 */
  }
}

@media (max-width: 850px) {
  .btn-primary {
    font-size: 0.75rem;
    /* 모바일 버튼 글자 크기 줄이기 */
    padding: 0.3rem 0.6rem;
    /* 모바일 버튼 패딩 줄이기 */
    margin-bottom: 10px;
  }

  /* ---------------------------------- */
  .table {
    display: none;
    /* 테이블 숨기기 */
  }

  .bnt-print {
    margin-bottom: 40px;
  }

  .kpi-wrap {
    gap: 8px;
  }

  .kpi-card {
    padding: 8px 10px;
  }

  .kpi-title {
    font-size: .6rem;
  }

  .kpi-value {
    font-size: .8rem;
  }
}
</style>
