<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': sidebarVisible && !isMobile }">
      <h2 class="content-title">영수증 신청 내역 조회</h2>
      <p class="content-sub-title">월별 영수증 신청 내역 확인 페이지</p>

      <!-- 월 선택 셀렉트 -->
      <DefaultFormRow marginBottom="10px" align="right">
        <DefaultLabel text="날짜(월) 선택 :" forId="monthSearch" size="small" />
        <DefaultTextfield
          type="month"
          id="monthSearch"
          v-model="selectedMonth"
          size="small"
          @change="filterByMonth"
        />
      </DefaultFormRow>

      
      <!-- 조회 결과 없는 경우 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="data.length">
        <!-- 테이블 (PC) -->
        <DefaultTable
          class="receipt-table"
          :columns="columns"
          :data="data"
          :openSidebar="openSidebar"
          :showTable="!isMobile"
        />

        <!-- 카드 레이아웃 (모바일) -->
        <div class="card-layout" v-if="isMobile">
          <div class="card" v-for="(item, index) in data" :key="index">
            <div class="card-header">
              <p class="card-title">{{ item.date }}</p>
            </div>
            <div class="card-body">
              <p class="card-text">
                <strong>인원 : </strong>
                <span @click="togglePeopleList(item)" style="cursor: pointer;">
                  {{ item.people.length }}명
                </span>
              </p>
              <div v-if="showPeopleList(item)">
                <div class="people-list">
                  <div class="people-list-header">명단</div>
                  <p v-for="person in item.people" :key="person.name" class="people-list-item">
                    {{ person.name }} ({{ person.department }} - {{ person.team }})
                  </p>
                </div>
              </div>
              <p class="card-text">
                <strong>구분/사유 : </strong> {{ item.type }} / {{ item.reason }}
              </p>
              <p class="card-text"><strong>금액 : </strong> {{ item.amount }}</p>
              <p class="card-text"><strong>금액/인원수 : </strong> {{ item.amountPerPerson }}</p>
              <p>
                <strong class="card-text">영수증 사진 : </strong>
                <a class="card-text"
                  @click.prevent="openPreviewModal(item.receipt)"
                  style="cursor: pointer; color: blue;"
                >
                  {{ item.receiptName }}
                </a>
              </p>
              <p class="card-text">
                <strong>반려 사유 : </strong> {{ item.rejectionReason || 'X' }}
              </p>
              <p class="card-text">
                <strong>결제 상황 : </strong>
                <span :class="getStatusClass(item.status)">{{ item.status }}</span>
              </p>
              <p class="card-text" v-if="item.approverName">
                <strong>결제자 : </strong>
                {{ item.approverName }}
              </p>
            </div>
          </div>
        </div>

        <!-- 페이지네이션 -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>

    <!-- 사이드바 -->
    <div 
      :class="['sidebar-wrapper', { 'sidebar-visible': sidebarVisible }]"
      v-click-away="{ handler: closeSidebar, exclude: ['.receipt-table'] }"
    >
      <ReceiptSidebar 
        v-if="!isMobile" 
        :item="selectedItem" 
        :visible="sidebarVisible" 
        @close="closeSidebar"
        @preview-image="openPreviewModal"
      />
    </div>

    <!-- 이미지 미리보기 모달 -->
    <div v-if="isPreviewVisible" class="modal preview-modal" @click="closePreviewModalOnOutsideClick">
      <div
        class="preview-modal-content"
        @mousedown="startDrag"
        @mousemove="onDrag"
        @mouseup="endDrag"
        @mouseleave="endDrag"
        @touchstart="startDrag"
        @touchmove="onDrag"
        @touchend="endDrag"
      >
        <img
          :src="previewImage"
          :class="{ zoomed: isZoomed }"
          class="preview-modal-image"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
          }"
          @dblclick="toggleZoom"
          @touchstart="toggleZoom"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useAuthStore } from '@/store/auth';
import ReceiptSidebar from './ReceiptSidebar.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultFormRow from '@/components/common/DefaultFormRow.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
import ReceiptsApi from '@/api/receipt/ReceiptsApi';
import { usePreviewModal } from '@/utils/preview-modal';

const noData = ref(false);

// =========== 미리보기 모달 관련 ===========
const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  openPreviewModal,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag
} = usePreviewModal();

function closePreviewModalOnOutsideClick(event) {
  if (!event.target.classList.contains('preview-modal-image')) {
    isPreviewVisible.value = false;
  }
}

// =========== Vuex/Pinia (사용자 정보) ===========
const authStore = useAuthStore();

// =========== 메인 데이터 / 컬럼 정의 ===========
const data = ref([]);
const columns = [
  { key: 'date', label: '발행일', width: 100 },
  { key: 'type', label: '구분', width: 50 },
  { key: 'peopleCount', label: '참여인원', width: 80 },
  { key: 'reason', label: '사유', width: 200 },
  { key: 'amount', label: '금액', width: 60 },
  { key: 'amountPerPerson', label: '금액/인원수', width: 100 },
  {
    key: 'status',
    label: '결제 상황',
    width: 80,
    customClass: (value) => {
      if (value === '신청') return 'text-blue';
      if (value === '승인') return 'text-green';
      if (value === '반려') return 'text-red';
      return '';
    },
  },
  { key: 'approverName', label: '결재자', width: 60 },
];

// =========== 달(月) 선택 셀렉트 옵션 ===========
// const monthOptions = [
//   { value: '01', label: '1월' },
//   { value: '02', label: '2월' },
//   { value: '03', label: '3월' },
//   { value: '04', label: '4월' },
//   { value: '05', label: '5월' },
//   { value: '06', label: '6월' },
//   { value: '07', label: '7월' },
//   { value: '08', label: '8월' },
//   { value: '09', label: '9월' },
//   { value: '10', label: '10월' },
//   { value: '11', label: '11월' },
//   { value: '12', label: '12월' },
// ];


// =========== 페이지네이션 ===========
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);

function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
}

// =========== 반응형 / 사이드바 ===========
const isMobile = ref(window.innerWidth <= 650);
function updateIsMobile() {
  isMobile.value = window.innerWidth <= 650;
}
window.addEventListener('resize', updateIsMobile);

const selectedItem = ref(null);
const sidebarVisible = ref(false);
function openSidebar(item) {
  if (!isMobile.value) {
    selectedItem.value = item;
    sidebarVisible.value = true;
  }
}
function closeSidebar() {
  sidebarVisible.value = false;
}

// =========== 상태 -> CSS 클래스 (모바일) ===========
function getStatusClass(status) {
  if (status === '신청') return 'status-pending';
  if (status === '승인') return 'status-approved';
  if (status === '반려') return 'status-rejected';
  return '';
}

// =========== 인원 목록 토글 (모바일) ===========
const openedIndex = ref(null);
function togglePeopleList(index) {
  openedIndex.value = openedIndex.value === index ? null : index;
}
function showPeopleList(index) {
  return openedIndex.value === index;
}

// =========== 월 선택 (기본값: 현재 월) ===========
const selectedMonth = ref(getCurrentYearMonth());
function getCurrentYearMonth() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  return `${yyyy}-${mm}`; // 예: "2025-04"
}

/**
 * 월 선택 시 동작
 * - 첫 페이지로 돌아가서 새로 데이터를 불러온다.
 */
function filterByMonth() {
  currentPage.value = 1;
  fetchDataFromServer(1);
}

// =========== 서버 연동: 데이터 가져오기 ===========
// [변경] 실제 백엔드 호출로직
async function fetchDataFromServer(page = 1) {
  // 사이드바 닫음
  closeSidebar();
  
  const pageSize = isMobile.value ? 4 : 10;
  // (1) 백엔드에 전달할 파라미터 준비
  const params = {
    page: page - 1,
    size: pageSize,
    yearMonth: selectedMonth.value // 예: "2025-04"
  };

  // (2) 특정 사용자 + 상태목록(endPoint)
  const userId = authStore.getUserId; 
  // 백엔드: GET /receipts/user/{userId}/with-status?yearMonth=2025-04&page=...
  const response = await ReceiptsApi.getReceiptsByUserIdWithStatus(userId, params);

  // (3) 응답 데이터 구조 
  // { receiptPage: {...}, statusList: [...] }
  const receiptPage = response.data;
  // const statusList = response.data.statusList; 
  // statusList를 별도로 활용할 수도 있음 (ex. 드롭다운, 상태 변경 등)

  // receiptPage.content -> 영수증 배열
  const content = receiptPage.content;

  // (4) 각 영수증 데이터를 프론트에서 쓰기 편한 형태로 가공
  const transformed = content.map(r => {
    const peopleArr = r.participantsList?.map(p => ({
      name: p.participantName,
      department: p.department,
      team: p.team
    })) || [];

    // 영수증 첨부파일
    const attachment = r.attachment;
    const receiptName = attachment ? attachment.fileName : '영수증 미등록';
    const receiptUrl = attachment ? attachment.fileUrl : '';

    // 금액 변환
    const amountVal = r.amount ? parseInt(r.amount, 10) : 0;
    const amountStr = amountVal.toLocaleString() + '원';

    // 상태 (신청, 승인, 반려, etc.)
    const statusDesc = r.status?.description || '신청';  
    // 반려 사유는 예시로 reason이나 별도 필드를 사용
    const rejectionReason = r.reason ? r.reason : '';

    const approverId = r.approverId ? r.approverId : ''; // 결재자 아이디
    const approverName = r.approverName ? r.approverName : ''; // 결재자 이름

    // 스크롤 맨 위로 이동(모바일 카드형식일때)
    if (isMobile.value) {
      window.scrollTo(0, 0)
    }
    
    return {
      date: r.submissionDate,          // 예: '2025-04-03'
      type: r.category,                // 예: '식비'
      reason: r.reason,                // 예: '야근'
      amount: amountStr,               // '80,000원'
      people: peopleArr,               // [{ name, dept, team }]
      peopleCount: peopleArr.length,
      amountPerPerson: calculateAmountPerPerson(amountVal, peopleArr.length),
      status: statusDesc,              // '신청'|'승인'|'반려'...
      rejectionReason,
      receiptName,
      approverId,
      approverName,
      receipt: receiptUrl
    };
  });

  // (5) 결과 할당
  data.value = transformed;
  noData.value = data.value.length ? false : true;
  totalPages.value = receiptPage.totalPages;
}

/**
 * 금액/인원 계산
 */
function calculateAmountPerPerson(amountVal, peopleCount) {
  const divisor = (peopleCount ?? 0) + 1;        // 최소 1
  const per = Math.floor(amountVal / (divisor));
  return per.toLocaleString() + '원';
}

// =========== onMounted: 초기 로드 ===========
onMounted(() => {
  fetchDataFromServer(currentPage.value);
});
</script>

<style scoped>
.content {
  transition: margin-right 0.3s ease;
}
.content-expanded {
  margin-right: 300px;
}
/* 사이드바 */
.sidebar-wrapper {
  position: fixed;
  right: 0;
  top: 0;
  width: 300px;
  height: 100%;
  transform: translateX(100%);
  transition: transform 0.3s ease;
  z-index: 1000;
}
.sidebar-visible {
  transform: translateX(0);
}
.sidebar {
  width: 100%;
  height: 100%;
  background-color: #f9f9f9;
  border-left: 1px solid #ddd;
  padding: 20px;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
}

/* 상태별 텍스트 컬러 */
.status-approved {
  color: green;
  font-weight: bold;
}
.status-pending {
  color: blue;
  font-weight: bold;
}
.status-rejected {
  color: red;
  font-weight: bold;
}

/* 사람 목록 */
.people-list {
  font-size: 0.7rem;
  max-height: 150px;
  overflow-y: auto;
  margin-top: 10px;
  border-top: 1px solid #ddd;
  padding-top: 10px;
}
.people-list-header {
  font-weight: bold;
  margin-bottom: 5px;
}
.people-list-item {
  padding: 1px 0;
  margin: 0;
  margin-left: 10px;
}

/* 미리보기 모달 */
.preview-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}
</style>
