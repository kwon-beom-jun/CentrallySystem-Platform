<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper" :class="{ 'content-expanded': sidebarVisible && !isMobile }">
      <h2 class="content-title">{{ userName }}님 영수증 내역 상세 조회</h2>
      <!-- 검색된 날짜 범위 표시 -->
      <p class="content-sub-title">
        날짜: [{{ filteredStartDate }} ~ {{ filteredEndDate }}]
      </p>
      <div class="btn-back">
        <!-- 뒤로가기 버튼 -->
        <DefaultButton
          size="small"
          align="left"
          color="gray"
          customHeight="30px"
          @click="goBack">
          뒤로가기
        </DefaultButton>
      </div>

      <!-- 테이블 보기 (큰 화면) -->
      <DefaultTable
        class="receipt-table"
        :showTable="!isMobile"
        :columns="columns"
        :data="data"
        :rowClick="openSidebar"
      />

      <!-- 카드 레이아웃 보기 (작은 화면에서만 보임) -->
      <div class="card-layout" v-if="isMobile">
        <div
          class="card"
          v-for="(item, index) in data"
          :key="index"
        >
          <div class="card-header">
            <p class="card-title">{{ item.date }}</p>
          </div>
          <div class="card-body">
            <p class="card-text">
              <strong>인원 : </strong>
              <span @click="togglePeopleList(index)" style="cursor: pointer;">
                {{ item.people.length }}명
              </span>
            </p>
            <div v-if="showPeopleList(item)">
              <div class="people-list">
                <div class="people-list-header">명단</div>
                <p
                  v-for="person in item.people"
                  :key="person.name"
                  class="people-list-item"
                >
                  {{ person.name }} ({{ person.department }} - {{ person.team }})
                </p>
              </div>
            </div>
            <p class="card-text">
              <strong>구분/사유 : </strong> 
              {{ item.type }} / {{ item.reason }}
            </p>
            <p class="card-text">
              <strong>금액 : </strong>
              {{ item.amount }}
            </p>
            <p class="card-text">
              <strong>금액/인원수 : </strong>
              {{ item.amountPerPerson }}
            </p>
            <p>
              <strong class="card-text">영수증 사진 : </strong>
              <a
                class="card-text"
                @click.prevent="openPreviewModal(item.receipt)"
                style="cursor: pointer; color: blue;"
              >
                {{ item.receiptName }}
              </a>
            </p>
            <p class="card-text">
              <strong>반려 사유: </strong> {{ item.rejectionReason || 'X' }}
            </p>
            <p class="card-text">
              <strong>결제 상황:</strong>
              <span :class="getStatusClass(item.status)">{{ item.status }}</span>
            </p>
          </div>
        </div>
      </div>

      <!-- 페이지네이션 (공통 컴포넌트) -->
      <DefaultPagination
        :currentPage="currentPage"
        :totalPages="totalPages"
        :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange"
      />
    </div>

    <!-- 사이드바 추가 -->
    <div 
      :class="['sidebar-wrapper', { 'sidebar-visible': sidebarVisible }]"
      v-click-away="{ handler: closeSidebar, exclude: ['.receipt-table'] }"
    >
      <ReceiptSidebar 
        v-if="!isMobile" 
        :item="selectedItem" 
        :visible="sidebarVisible" 
        @close="closeSidebar"
        @preview-image="openPreviewModal"
      />
    </div>

    <!-- 이미지 미리보기 모달 -->
    <div
      v-if="isPreviewVisible"
      class="modal preview-modal"
      @click="closePreviewModalOnOutsideClick"
    >
      <div
        class="preview-modal-content"
        @mousedown="startDrag"
        @mousemove="onDrag"
        @mouseup="endDrag"
        @mouseleave="endDrag"
        @touchstart="startDrag"
        @touchmove="onDrag"
        @touchend="endDrag"
      >
        <img
          :src="previewImage"
          :class="{ zoomed: isZoomed }"
          class="preview-modal-image"
          :style="{
            transform: isZoomed
              ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
              : 'none',
            transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`
          }"
          @dblclick="toggleZoom"
          @touchstart="toggleZoom"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router';
import ReceiptSidebar from './ReceiptSidebar.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue'; 
import ReceiptsSearchApi from '@/api/receipt/ReceiptsSearchApi';
import { usePreviewModal } from '@/utils/preview-modal';
import { useRoute } from 'vue-router';
import { useAuthStore } from '@/store/auth'

const route = useRoute();
const authStore = useAuthStore();
const approverId = ref(authStore.getUserId);

// =====================
// 1) 날짜 표시 
// =====================
const filteredStartDate = ref('');
const filteredEndDate = ref('');
const userId = ref('');
const userName = ref('');

// =====================
// 2) 사이드바 / 모바일
// =====================
const selectedItem = ref(null);
const sidebarVisible = ref(false);
const isMobile = ref(window.innerWidth <= 650);
function updateIsMobile() {
  isMobile.value = window.innerWidth <= 650;
}
watch(isMobile, (newVal) => {
  if (newVal) closeSidebar();
});

// =====================
// 3) 미리보기 모달
// =====================
const {
  isPreviewVisible,
  previewImage,
  isZoomed,
  zoomedPosition,
  zoomOrigin,
  openPreviewModal,
  toggleZoom,
  startDrag,
  onDrag,
  endDrag
} = usePreviewModal();
function closePreviewModalOnOutsideClick(event) {
  if (!event.target.classList.contains('preview-modal-image')) {
    isPreviewVisible.value = false;
  }
}

// =====================
// 4) 데이터 / 페이지네이션
// =====================
const data = ref([]);
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);  // 페이지네이션에서 보여줄 최대 페이지 버튼 수

// **테이블 컬럼** 정의
// 각각의 'key'가 item[key]에 대응
// 필요 시 customClass, customValue 등 추가 가능
const columns = [
  { key: 'date', label: '발행일', width: 100 },
  {
    key: 'peopleCount',
    label: '인원수',
    width: 60,
    // 만약 item.peopleCount에 값이 없다면 직접 계산 가능
    // customValue: (item) => item.people.length,
    customValue: (item) => item.people ? item.people.length : 0,
  },
  { key: 'type', label: '구분', width: 100 },
  { key: 'reason', label: '사유', width: 130 },
  { key: 'amount', label: '금액', width: 100 },
  {
    key: 'amountPerPerson',
    label: '금액/인원수',
    width: 100,
    // customValue: (item) => calculateAmountPerPerson(item),
    customValue: (item) => {
      const amount = parseInt(item.amount.replace(/[^0-9]/g, ''), 10);
      const peopleCount = item.people ? item.people.length : 0;
      return calculateAmountPerPerson(amount, peopleCount);
    }
  },
  {
    key: 'status',
    label: '결제 상황',
    width: 80,
    // 동적 클래스 지정 (DefaultTable.vue에서 customClass 사용)
    customClass: (value) => {
      if (value === '신청') return 'text-blue';
      if (value === '승인') return 'text-green';
      if (value === '반려') return 'text-red';
      return '';
    }
  },
];

// =========== 서버 연동: 데이터 가져오기 ===========
// [변경] 실제 백엔드 호출로직
async function fetchDataFromServer(page = 1) {
  // 사이드바 닫음
  closeSidebar();
  const pageSize = isMobile.value ? 4 : 10;

  // 백엔드: GET /receipts/user/{userId}/with-status?yearMonth=2025-04&page=...
  const response = await ReceiptsSearchApi.getPendingReceiptsByApprover(
    approverId.value,   // ← 새 파라미터
    {
      page: page - 1,
      size: pageSize,
      userId: userId.value,          // (선택) 특정 신청자
      startDate: filteredStartDate.value,
      endDate:   filteredEndDate.value,
    }
  );

  // (3) 응답 데이터 구조 
  // { receiptPage: {...}, statusList: [...] }
  const receiptPage = response.data;
  // const statusList = response.data.statusList; 
  // statusList를 별도로 활용할 수도 있음 (ex. 드롭다운, 상태 변경 등)

  // receiptPage.content -> 영수증 배열
  const content = receiptPage.content;

  // (4) 각 영수증 데이터를 프론트에서 쓰기 편한 형태로 가공
  const transformed = content.map(r => {
    const peopleArr = r.participantsList?.map(p => ({
      name: p.participantName,
      department: p.department,
      team: p.team
    })) || [];

    // 영수증 첨부파일
    const attachment = r.attachment;
    const receiptName = attachment ? attachment.fileName : '영수증 미등록';
    const receiptUrl = attachment ? attachment.fileUrl : '';

    // 금액 변환
    const amountVal = r.amount ? parseInt(r.amount, 10) : 0;
    const amountStr = amountVal.toLocaleString() + '원';

    // 상태 (신청, 승인, 반려, etc.)
    const statusDesc = r.status?.description || '신청';  
    // 반려 사유는 예시로 reason이나 별도 필드를 사용
    const rejectionReason = r.reason ? r.reason : ''; // 예시

    // 스크롤 맨 위로 이동(모바일 카드형식일때)
    if (isMobile.value) {
      window.scrollTo(0, 0)
    }

    return {
      date: r.submissionDate,          // 예: '2025-04-03'
      type: r.category,                // 예: '식비'
      reason: r.reason,                // 예: '야근'
      amount: amountStr,               // '80,000원'
      people: peopleArr,               // [{ name, dept, team }]
      peopleCount: peopleArr.length,
      amountPerPerson: calculateAmountPerPerson(amountVal, peopleArr.length),
      status: statusDesc,              // '신청'|'승인'|'반려'...
      rejectionReason,
      receiptName,
      receipt: receiptUrl
    };
  });

  // (5) 결과 할당
  data.value = transformed;
  totalPages.value = receiptPage.totalPages;
}

// 페이지 전환 (DefaultPagination → @pageChange)
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
}

// =====================
// 5) 기타 로직
// =====================
// 금액/인원수 계산
/** amount(number)·peopleCount(number) → '8,000원' */
function calculateAmountPerPerson(amountVal, peopleCount) {
  if (!peopleCount) return '0원';
  return Math.floor(amountVal / (peopleCount + 1)).toLocaleString() + '원';
}

// 결제 상황별 CSS 클래스
function getStatusClass(status) {
  if (status === '신청') return 'status-pending';
  if (status === '승인')   return 'status-approved';
  if (status === '반려')   return 'status-rejected';
  return '';
}

// 모바일 인원 목록 토글
const openedIndex = ref(null);
function togglePeopleList(idx) {
  openedIndex.value = openedIndex.value === idx ? null : idx;
}
function showPeopleList(index) {
  return openedIndex.value === index;
}

// 사이드바
function openSidebar(item) {
  if (!isMobile.value) {
    selectedItem.value = item;
    sidebarVisible.value = true;
  }
}
function closeSidebar() {
  sidebarVisible.value = false;
}

// 뒤로가기
const router = useRouter();
function goBack() {
  router.back();
}

// =====================
// 6) onMounted
// =====================
onMounted(() => {
  filteredStartDate.value = route.query.startDate || '';
  filteredEndDate.value = route.query.endDate || '';
  userId.value = route.query.userId || '';
  userName.value = route.query.userName || '';

  if (!userId.value || !filteredStartDate.value || !filteredEndDate.value) {
    router.back();
    return;
  }

  fetchDataFromServer();
  window.addEventListener('resize', updateIsMobile);
  updateIsMobile();
});
</script>

<style scoped>
.content {
  transition: margin-right 0.3s ease;
}
.content-expanded {
  margin-right: 300px;
}
.content-sub-title {
  margin-bottom: 10px !important;
}
.btn-back {
  margin-bottom: 78px !important;
}

/* 반응형 카드 레이아웃 */
.card-layout {
  margin-top: 40px;
}

/* 사이드바 */
.sidebar-wrapper {
  position: fixed;
  right: 0;
  top: 0;
  width: 300px;
  height: 100%;
  transform: translateX(100%);
  transition: transform 0.3s ease;
  z-index: 1000;
}
.sidebar-visible {
  transform: translateX(0);
}
.sidebar {
  width: 100%;
  height: 100%;
  background-color: #f9f9f9;
  border-left: 1px solid #ddd;
  padding: 20px;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
}

/* 상태별 색상 */
.status-approved {
  color: green;
  font-weight: bold;
}
.status-pending {
  color: blue;
  font-weight: bold;
}
.status-rejected {
  color: red;
  font-weight: bold;
}

/* 인원 목록 */
.people-list {
  font-size: 0.7rem;
  max-height: 150px;
  overflow-y: auto;
  margin-top: 10px;
  border-top: 1px solid #ddd;
  padding-top: 10px;
}
.people-list-header {
  font-weight: bold;
  margin-bottom: 5px;
}
.people-list-item {
  padding: 1px 0;
  margin: 0;
  margin-left: 10px;
}

/* 이미지 미리보기 모달 */
.preview-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.preview-modal-content {
  position: relative;
}
.preview-modal-image {
  max-width: 80vw;
  max-height: 80vh;
  transition: transform 0.2s ease;
}
.zoomed {
  cursor: move; /* 확대된 상태에서는 드래그 가능 */
}

@media (max-width: 650px) {
  .btn-back {
    margin-bottom: 0px !important;
  }
}
</style>
