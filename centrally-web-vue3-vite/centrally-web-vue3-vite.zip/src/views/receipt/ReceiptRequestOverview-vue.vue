<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 신청 내역 조회 현황</h2>
      <!-- 검색된 날짜 범위 표시 -->
      <p class="content-sub-title" v-if="data.length">
        날짜: [{{ startDate }} ~ {{ endDate }}]
      </p>

      <div class="search-controls">
        <!-- 시작, 종료일 그룹 -->
        <div class="d-flex align-items-center end-date-group mt-2 start-end-date-group">
          <DefaultLabel text="시작 :" forId="startDate" size="small" />
          <DefaultTextfield
            type="date"
            id="startDate"
            v-model="startDate"
            size="small"
          />
          <DefaultLabel text="종료 :" forId="endDate" size="small" />
          <DefaultTextfield
            type="date"
            id="endDate"
            v-model="endDate"
            size="small"
          />
        </div>
        <!-- 이름 검색 그룹 -->
        <div class="d-flex align-items-center name-group mt-2">
          <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
          <!-- 예시... 
          <DefaultTextfield
            type="text"
            v-model="korNumInput"
            size="medium"
            validationType="korean|number"
            placeholder="한글과 숫자만 입력하세요"
            errorMessage="한글과 숫자만 입력 가능합니다."
            :reserveErrorSpace="true"
          />
          -->
          <DefaultTextfield
            type="text"
            id="nameSearch"
            v-model="nameSearch"
            size="small"
            placeholder="이름 입력"
          />
          <DefaultButton 
            @click="search"
            size="small">
            조회
          </DefaultButton>
        </div>
      </div>

      <!-- DefaultTable 컴포넌트 (큰 화면) -->
      <DefaultTable
        :columns="columns"
        :data="data"
        :showTable="viewMode"
      />

      <!-- 카드 형식 보기 (작은 화면) -->
      <div class="card" v-for="(item, index) in data" :key="index">
        <div class="card-header">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <p class="card-title">{{ item.name }}</p>
            <p class="card-title">{{ item.email }}</p>
          </div>
        </div>
        <div class="card-body">
          <p class="card-text">
            <Strong>부서: </Strong>{{ item.department }}
          </p>
          <p class="card-text">
            <Strong>팀: </Strong>{{ item.team }}
          </p>
          <p class="card-text">
            <Strong>건수: </Strong>{{ item.count }}
          </p>
          <p class="card-text">
            <Strong>신청금액: </Strong>{{ item.requested.toLocaleString() }}원
          </p>
        </div>
      </div>
      
      <!-- 페이지네이션 (공통 컴포넌트) -->
      <DefaultPagination
        :currentPage="currentPage"
        :totalPages="totalPages"
        :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';

// import axios from 'axios'; // 실제 백엔드 호출 시 사용

// ================ 상태 정의 ================
const startDate = ref('');
const endDate = ref('');
const nameSearch = ref('');

// 실제 서버에서 받아온 데이터
const data = ref([]);

// 테이블 / 카드 전환
// (true면 테이블, false면 카드)
const viewMode = ref(true);

// 페이지네이션
const currentPage = ref(1);
const totalPages = ref(1);
const visiblePageCount = ref(5);  // 페이지네이션에서 보여줄 최대 페이지 버튼 수

// 컬럼 정의
const columns = ref([
  { key: 'name', label: '이름', width: 60 },
  { key: 'department', label: '부서', width: 100 },
  { key: 'team', label: '직책', width: 100 },
  { key: 'email', label: '이메일', width: 150 },
  { key: 'count', label: '건수', width: 50 },
  { key: 'requested', label: '신청금액', width: 100 },
]);

/**
 * 서버에서 데이터 가져오기
 * 실제로는 axios 등을 사용하여 파라미터(startDate, endDate, nameSearch, currentPage 등)를 전송 후,
 * 응답에서 data, totalPages 등을 받아 세팅하시면 됩니다.
 */
// async function fetchDataFromServer(page = 1) {
async function fetchDataFromServer() {
  // const response = await axios.get('/api/searchReceipts', {
  //   params: {
  //     startDate: startDate.value,
  //     endDate: endDate.value,
  //     name: nameSearch.value,
  //     page: page,
  //   },
  // });
  // data.value = response.data.items;
  // totalPages.value = response.data.totalPages;

  // 여기서는 mockData로 예시 구현
  const mockData = [
    {
      name: '홍길동',
      department: 'SI사업본부',
      team: '프레임워크',
      email: 'hong@example.com',
      count: 3,
      requested: 1000000,
    },
    {
      name: '김철수',
      department: 'SI사업본부',
      team: '프레임워크',
      email: 'kim@example.com',
      count: 5,
      requested: 1200000,
    },
    {
      name: '이영희',
      department: 'SI사업본부',
      team: '프레임워크',
      email: 'lee@example.com',
      count: 2,
      requested: 800000,
    },
    // 추가 더미 데이터 ...
  ];
  
  data.value = mockData;
  totalPages.value = 2; // 예시로 총 2페이지 있다고 가정
}

/**
 * 검색 버튼 클릭 시 실행
 * - 검색 파라미터를 포함하여 페이지 1번으로 재조회
 */
function search() {
  currentPage.value = 1;
  fetchDataFromServer(currentPage.value);
}

/**
 * 페이지 변경 시 (DefaultPagination에서 방출)
 * - 새 페이지를 받아서 currentPage를 갱신
 * - 백엔드 재조회
 */
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(currentPage.value);
}

/**
 * 화면 크기에 따라 테이블 / 카드 전환
 */
function updateViewMode() {
  if (window.innerWidth <= 650) {
    viewMode.value = false; // 모바일 → 카드
  } else {
    viewMode.value = true;  // PC → 테이블
  }
}

onMounted(() => {
  // 컴포넌트 초기 로드시 첫 페이지 조회
  fetchDataFromServer(currentPage.value);

  // 화면 너비에 따라 viewMode 결정
  updateViewMode();
  window.addEventListener('resize', updateViewMode);
});
</script>

<style scoped>
#dataTable tbody tr:hover td {
  background-color: #e7f1ff !important;
}

/* 상태별 색상 설정 */
.status-complete {
  color: blue; /* 완료 상태는 파란색 */
}
.status-in-progress {
  color: red; /* 진행중 상태는 빨간색 */
}
.align-items-center {
  margin-bottom: 0px !important;
}
.start-end-date-group label {
  margin-left: 10px !important;
}
.bnt-search {
  margin: 0 !important;
}

@media (min-width: 1201px) {
  .search-controls {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
    margin-bottom: 12px;
  }
  .search-controls > div {
    margin-right: 1rem;
  }
  #nameSearch {
    font-size: 1rem;
  }
  .card {
    display: none; /* 카드 숨기기 */
  }
  .table {
    display: table; /* 테이블 표시 */
  }
}

@media (min-width: 1920px) {
  .navbar-text {
    font-size: 1.5rem; /* 더 큰 텍스트 크기 */
  }
}

@media (max-width: 650px) {
  .btn-primary {
    font-size: 0.75rem; /* 모바일 버튼 글자 크기 줄이기 */
    padding: 0.3rem 0.6rem; /* 모바일 버튼 패딩 줄이기 */
    margin-bottom: 10px;
  }
  .search-controls {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
  }
  .search-controls > div {
    width: 100%;
    display: flex;
    justify-content: flex-end;
  }
  /* 이름 그룹을 위쪽에 배치 */
  /* ---------------------------------- */
  .name-group {
    order: -1;
    margin: 0 !important;
  }
  .start-end-date-group {
    order: 1;
    margin-bottom: 10px !important;
  }
  /* ---------------------------------- */
  .table {
    display: none; /* 테이블 숨기기 */
  }
  .bnt-print {
    margin-bottom: 40px;
  }
  .start-end-date-group input {
    width: 110px !important;
  }
}
</style>
