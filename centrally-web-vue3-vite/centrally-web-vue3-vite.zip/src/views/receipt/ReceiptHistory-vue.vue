<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 결재 내역 조회</h2>

      <!-- 검색된 날짜 범위 표시 -->
      <!-- 서버 조회 결과로 받아온 startDate/endDate 등을 표시하는 예시 -->
      <div class="content-sub-title" v-if="data.length">
        <p>날짜: [{{ computedStartDate }} ~ {{ computedEndDate }}]</p>
      </div>

      <!-- PDF 출력 버튼 -->
      <DefaultButton 
        size="small"
        align="left"
        color="gray"
        @click="printPDF"
      >
        PDF 출력하기
      </DefaultButton>

      <!-- 검색 영역 -->
      <div class="search-controls">
        <!-- 시작일, 종료일 그룹 -->
        <div class="d-flex align-items-center start-end-date-group mt-2">
          <DefaultLabel text="시작 :" forId="startDate" size="small" />
          <DefaultTextfield
            type="date"
            id="startDate"
            v-model="startDate"
            size="small"
          />
          <DefaultLabel text="종료 :" forId="endDate" size="small" />
          <DefaultTextfield
            type="date"
            id="endDate"
            v-model="endDate"
            size="small"
          />
        </div>
        <!-- 이름 검색 그룹 -->
        <div class="d-flex align-items-center name-group mt-2">
          <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
          <DefaultTextfield
            type="text"
            id="nameSearch"
            v-model="nameSearch"
            size="small"
            placeholder="이름 입력"
          />
          <DefaultButton 
            @click="search"
            size="small">
            조회
          </DefaultButton>
        </div>
      </div>

      <!-- DefaultTable 컴포넌트 사용 (큰 화면일 때만 보이도록) -->
      <DefaultTable
        :columns="columns"
        :data="data"
        :showTable="!isMobile"
      />

      <!-- 카드 형식 보기 (작은 화면일 때만 보이도록) -->
      <div v-if="isMobile">
        <div
          class="card"
          v-for="(item, index) in data"
          :key="index"
        >
          <div class="card-header">
            <div class="d-flex justify-content-between align-items-center mb-2">
              <p class="card-title">{{ item.name }}</p>
              <p class="card-title">{{ item.email }}</p>
            </div>
          </div>
          <div class="card-body">
            <p class="card-text"><Strong>건수: </Strong>{{ item.count }}</p>
            <p class="card-text"><Strong>부서: </Strong>{{ item.department }}</p>
            <p class="card-text"><Strong>팀: </Strong>{{ item.team }}</p>
            <p class="card-text"><Strong>신청금액: </Strong>{{ formatCurrency(item.requested) }}원</p>
            <p class="card-text"><Strong>승인금액: </Strong>{{ formatCurrency(item.approved) }}원</p>
            <p class="card-text"><Strong>반려금액: </Strong>{{ formatCurrency(item.rejected) }}원</p>
          </div>
        </div>
      </div>

      <!-- 페이지네이션 (공통 컴포넌트) -->
      <DefaultPagination
        :currentPage="currentPage"
        :totalPages="totalPages"
        :visiblePageCount="visiblePageCount"
        @pageChange="onPageChange"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import DefaultTable from '@/components/common/table/DefaultTable.vue';
import DefaultButton from '@/components/common/button/DefaultButton.vue';
import DefaultPagination from '@/components/common/pagination/DefaultPagination.vue';
import DefaultTextfield from '@/components/common/textfield/DefaultTextfield.vue';
import DefaultLabel from '@/components/common/label/DefaultLabel.vue';
// import axios from 'axios'; // 실제 서버 연동 시 사용

/** 
 * 1) 상태 정의 
 */
const data = ref([]);             // 실제 서버에서 받아온 데이터
const currentPage = ref(1);       // 현재 페이지
const totalPages = ref(1);        // 총 페이지 수(서버 응답)
const isMobile = ref(false);      // 뷰포트 너비에 따른 반응형 여부
const visiblePageCount = ref(5);  // 페이지네이션에서 보여줄 최대 페이지 버튼 수

// 검색용
const startDate = ref('');
const endDate = ref('');
const nameSearch = ref('');

// (출력용) 서버에서 조회된 기간
const computedStartDate = ref('');
const computedEndDate = ref('');

/**
 * 2) 컬럼 정의
 */
const columns = ref([
  { key: 'name',      label: '이름',      width: 60 },
  { key: 'department',label: '부서',      width: 100 },
  { key: 'team',      label: '팀',        width: 100 },
  { key: 'email',     label: '이메일',      width: 130 },
  { key: 'count',     label: '건수',      width: 50 },
  { key: 'requested', label: '신청금액',  width: 100 },
  { key: 'approved',  label: '승인금액',  width: 100 },
  { key: 'rejected',  label: '반려금액',  width: 100 },
]);

/**
 * 3) 서버에서 데이터 가져오기
 * - page, startDate, endDate, nameSearch 등의 파라미터로 백엔드 호출
 * - 응답으로 data, totalPages, 조회된 날짜 범위 등을 받아 세팅
 */
// async function fetchDataFromServer(page = 1) {
async function fetchDataFromServer() {
  // 실제 API 예시:
  // const response = await axios.get('/api/receipts', {
  //   params: {
  //     page,
  //     startDate: startDate.value,
  //     endDate: endDate.value,
  //     name: nameSearch.value,
  //   },
  // });
  // data.value = response.data.items;
  // totalPages.value = response.data.totalPages;
  // computedStartDate.value = response.data.startDate; 
  // computedEndDate.value = response.data.endDate;

  // 여기서는 예시 mockData
  const mockData = [
    {
      month: '2024-01',
      name: '홍길동',
      department: 'SI사업본부',
      team: '프레임워크',
      email: 'hong@example.com',
      count: 3,
      requested: 1000000,
      approved: 800000,
      rejected: 200000,
      status: '승인',
    },
    {
      month: '2024-02',
      name: '김철수',
      department: 'SI사업본부',
      team: '프레임워크',
      email: 'kim@example.com',
      count: 5,
      requested: 1200000,
      approved: 1000000,
      rejected: 200000,
      status: '신청 중',
    },
    {
      month: '2024-03',
      name: '이영희',
      department: 'SI사업본부',
      team: '프레임워크',
      email: 'lee@example.com',
      count: 2,
      requested: 800000,
      approved: 500000,
      rejected: 300000,
      status: '반려',
    },
    // ...
  ];
  // 서버 응답처럼 가정
  data.value = mockData;
  totalPages.value = 3; // 예: 총 3페이지
  
  // 예: 응답 데이터에 조회된 startDate, endDate가 있다면 세팅
  computedStartDate.value = startDate.value || '2024-01';
  computedEndDate.value   = endDate.value   || '2024-03';
}

/**
 * 4) 검색 함수
 * - 검색 버튼 클릭 시 1페이지부터 다시 조회
 */
function search() {
  currentPage.value = 1;
  fetchDataFromServer(currentPage.value);
}

/**
 * 5) 페이지 변경 시 (DefaultPagination)
 * - 새 페이지를 받아서 백엔드 재호출
 */
function onPageChange(newPage) {
  currentPage.value = newPage;
  fetchDataFromServer(newPage);
}

/**
 * 6) 반응형 / 뷰 모드 전환
 */
function updateViewMode() {
  isMobile.value = window.innerWidth <= 650;
}

/**
 * 7) PDF 출력 예시 (실제 구현은 필요에 따라 추가)
 */
function printPDF() {
  console.log('PDF 출력 로직 실행');
  // window.print() or 기타 PDF 라이브러리 활용 가능
}

/**
 * 8) 통화(금액) 형식 함수
 */
function formatCurrency(amount) {
  if (!amount) return '0';
  return amount.toLocaleString();
}

/**
 * 9) onMounted
 * - 초기 1페이지 조회
 * - 화면 너비 체크
 */
onMounted(() => {
  const today = new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"
  startDate.value = today;
  endDate.value = today;
  fetchDataFromServer(currentPage.value);
  updateViewMode();
  window.addEventListener('resize', updateViewMode);
});
</script>

<style scoped>
.content-sub-title {
  margin-bottom: 0px !important;
}
.search-controls {
  margin-top: 60px;
  margin-bottom: 20px;
}
.start-end-date-group label {
  margin-left: 10px !important;
}
.align-items-center {
  margin-bottom: 0px !important;
}
/* (기존) 상태별 색상 설정 예시 
.status-approved   { color: green;  font-weight: bold; }
.status-pending   { color: blue;   font-weight: bold; }
.status-rejected  { color: red;    font-weight: bold; }
.status-closed    { color: black;  font-weight: bold; }
*/

/* 반응형 테이블/카드 */
@media (min-width: 1201px) {
  .search-controls {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
    margin-bottom: 20px;
  }
  .search-controls > div {
    margin-right: 1rem;
  }
  #nameSearch {
    font-size: 1rem;
  }
  .card {
    display: none; /* 카드 숨기기 */
  }
  .table {
    display: table; /* 테이블 표시 */
  }
}

@media (max-width: 650px) {
  .btn-primary {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
    margin-bottom: 10px;
  }
  .search-controls {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    margin-top: 30px;
  }
  .search-controls > div {
    width: 100%;
    display: flex;
    justify-content: flex-end;
  }
  /* 이름 그룹을 위쪽에 배치 */
  .name-group {
    order: -1;
    margin: 0 !important;
  }
  .start-end-date-group {
    order: 1;
    margin-bottom: 10px;
  }
  .table {
    display: none; /* 테이블 숨기기 */
  }
}

@media (min-width: 1920px) {
  .navbar-text {
    font-size: 1.5rem; /* 더 큰 텍스트 크기 */
  }
}

@media (max-width: 650px) {
  .start-end-date-group input {
    width: 110px !important;
  }
}
</style>
