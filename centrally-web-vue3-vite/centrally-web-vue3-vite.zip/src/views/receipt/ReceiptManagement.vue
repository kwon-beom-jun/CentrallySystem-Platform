<template>
  <div>
    <!-- 메인 콘텐츠 영역 -->
    <div class="content content-wrapper">
      <h2 class="content-title">영수증 내역 관리</h2>
      <p class="content-sub-title">사용자들의 영수증 내역을 관리하는 페이지</p>

      <!-- 검색 영역 -->
      <div class="search-controls">
        <!-- 시작, 종료일 그룹 -->
        <DefaultFormRow align="right">
          <DefaultLabel text="시작 :" forId="startDate" size="small" />
          <DefaultTextfield
            type="date"
            id="startDate"
            v-model="startDate"
            size="xsmall"
          />
          <DefaultLabel text="종료 :" forId="endDate" size="small" marginLeft="10px" />
          <DefaultTextfield
            type="date"
            id="endDate"
            v-model="endDate"
            size="xsmall"
          />
        </DefaultFormRow>
        <!-- 이름 검색 그룹 -->
        <DefaultFormRow align="right" marginTop="7px">
          <DefaultLabel text="이름 :" forId="nameSearch" size="small" />
          <UserSearchDropdown
            labelText="사용자 검색"
            inputId="nameSearch"
            inputSize="large"
            placeholder="사용자(이메일)을 검색해주세요"
            :includeCurrentUser="true"
            @userSelected="onUserSelected"
          />
          <DefaultButton 
            @click="search"
            color="gray"
            size="small">
            조회
          </DefaultButton>
        </DefaultFormRow>
      </div>

      
      <!-- 조회 결과 없는 경우 -->
      <div v-if="noData">
        <v-img
          class="mx-width-700 no-results-found"
          src="/img/common/state/001.png"
        ></v-img>
      </div>

      <div v-if="data.length">
        <!-- 테이블: 사용자 ID/이메일 컬럼 추가됨 -->
        <DefaultTable
          :columns="columns"
          :data="data"
          @delete-row="deleteReceipt"
          @row-updated="handleRowUpdated"
          :rowClick="onRowClick"
          :selectHeight="'28px'"
          :buttonHeight="'28px'"
          :minRows="8"
        />

        <!-- 페이지네이션 -->
        <DefaultPagination
          :currentPage="currentPage"
          :totalPages="totalPages"
          :visiblePageCount="visiblePageCount"
          @pageChange="onPageChange"
        />
      </div>
    </div>
    <ReceiptDetailViewModal
      :isVisible="detailVisible"
      :receipt ="selectedReceipt"
      @close="detailVisible = false"
      @updated="fetchDataFromServer(currentPage)"
    />

    <!-- 삭제 확인 AlertModal -->
    <AlertModal
      :isVisible="deleteConfirmVisible"
      :disableBackgroundClose="false"
      confirmText="확인"
      cancelText="취소"
      @close="deleteConfirmVisible = false"
      @confirm="deleteNotice"
    >
      <template #body>
        <!-- <p style="color: red;">※ 삭제 ※</p>
        <p style="color: red;">  -->
        <p>※ 삭제 ※</p>
        <p> 
          영수증을 삭제하면 복구되지 않습니다 <br/>
          영수증 삭제를 진행하겠습니까? <br/>
        </p>
        <p style="color: red;">
          영수증 삭제 [ 식별 번호 : #{{ receiptToDelete.receiptCode }} ]
        </p>
      </template>
    </AlertModal>
  </div>
  <!-- ─── 이미지 미리보기 모달 ─── -->
  <div
    v-if="isPreviewVisible"
    class="modal preview-modal"
    @click="closePreviewModalOnOutsideClick"
  >
    <div
      class="preview-modal-content"
      @mousedown="startDrag"
      @mousemove="onDrag"
      @mouseup="endDrag"
      @mouseleave="endDrag"
      @touchstart="startDrag"
      @touchmove="onDrag"
      @touchend="endDrag"
    >
      <img
        :src="previewImage"
        class="preview-modal-image"
        :class="{ zoomed: isZoomed }"
        :style="{
          transform: isZoomed
            ? `translate(${zoomedPosition.x}px, ${zoomedPosition.y}px) scale(1.5)`
            : 'none',
          transformOrigin: `${zoomOrigin.x}px ${zoomOrigin.y}px`,
        }"
        @dblclick="toggleZoom"
        @touchstart="toggleZoom"
      />
    </div>
  </div>
</template>

<script setup>
/* ──────────────── imports ──────────────── */
import { ref, watch, onMounted }       from 'vue'
import AlertModal                      from '@/components/common/modal/AlertModal.vue'
import DefaultPagination               from '@/components/common/pagination/DefaultPagination.vue'
import DefaultTable                    from '@/components/common/table/DefaultTable.vue'
import DefaultButton                   from '@/components/common/button/DefaultButton.vue'
import DefaultTextfield                from '@/components/common/textfield/DefaultTextfield.vue'
import DefaultLabel                    from '@/components/common/label/DefaultLabel.vue'
import DefaultFormRow                  from '@/components/common/DefaultFormRow.vue'
import UserSearchDropdown              from '@/components/auth/UserSearchDropdown.vue'
import ReceiptDetailViewModal          from '@/components/receipt/ReceiptDetailViewModal.vue'
import { usePreviewModal }             from '@/utils/preview-modal'

import ReceiptsApi                     from '@/api/receipt/ReceiptsApi'
import ReceiptsRequestApi              from '@/api/receipt/ReceiptsRequestApi'
import HrmUserApi                      from '@/api/hrm/UsersApi'
import { toast }                       from 'vue3-toastify'
import { useUserDirectoryStore }       from '@/store/hrm/userDirectory'

/* ──────────────── reactive state ──────────────── */
const startDate      = ref('')
const endDate        = ref('')
const searchUserId   = ref('')

const data           = ref([])
const noData         = ref(false)

const currentPage    = ref(1)
const totalPages     = ref(1)
const visiblePageCount = ref(5)
const pageSize       = ref(8)

/* 사용자 캐시 : { [userId]: { userName, userEmail, department, team } } */
const userMap        = ref({})

/* 상세/삭제 모달 */
const detailVisible        = ref(false)
const selectedReceipt      = ref({})
const deleteConfirmVisible = ref(false)
const receiptToDelete      = ref(null)

/* preview-modal */
const {
  isPreviewVisible, previewImage, isZoomed,
  zoomedPosition, zoomOrigin,
  toggleZoom, startDrag, onDrag, endDrag
} = usePreviewModal()
const closePreviewModalOnOutsideClick = e => {
  if (!e.target.classList.contains('preview-modal-image'))
    isPreviewVisible.value = false
}

/* ──────────────── helpers ──────────────── */
const LABEL        = { REQUEST:'신청', APPROVED:'승인', REJECTED:'반려', WAITING:'대기', CLOSED:'마감' }
const statusLabel  = c => LABEL[c] ?? '알수없음'
const perPerson    = (amt,cnt)=>`${Math.floor(amt/cnt).toLocaleString()}원`
const today        = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

/* ──────────────── table schema ──────────────── */
const columns = [
  { key:'receiptCode',label:'식별 번호',  width:75,     align: 'center' },
  { key:'userName',   label:'이름',      width:60,     align: 'center' },
  { key:'userEmail',  label:'이메일',     width:140 },
  { key:'date',       label:'발행일',     width:100  },
  { key:'type',       label:'구분',       width:90  },
  { key:'peopleCount',label:'총 인원',    width:70,     align: 'center' },
  { key:'reason',     label:'사유',       width:120 },
  { key:'amount',     label:'금액',       width:75,    align: 'right' },
  { key:'amountPerPerson', label:'금액/인원', width:90, align: 'right' },
  {
    key:'status',
    label:'상태',
    width:85,
    type:'select',
    getOptions:() => Object.entries(LABEL).map(([v,l])=>({ value:v, label:l }))
  },
  { key:'delete',
    label:'',
    width:80,
    type:'button',
    buttonText:'삭제',
    buttonColor:'red',
    buttonSize:'full-small',
    emit:'delete-row'
  }
]

/* ──────────────── API helpers ──────────────── */
async function loadUsers () {
  const { data: users = [] } = await HrmUserApi.getUsers()
  userMap.value = Object.fromEntries(
    users.map(u => [
      u.userId,
      {
        userName  : u.name,
        userEmail : u.email,
        department: u.team?.department?.departmentName || '',
        team      : u.team?.teamName || ''
      }
    ])
  )
}

async function fetchReceipts (page = 1) {
  const { data: pageDto } = await ReceiptsApi.getReceiptsWithStatus({
    startDate: startDate.value,
    endDate  : endDate.value,
    userId   : searchUserId.value,
    page     : page - 1,
    size     : pageSize.value
  })

  data.value = (pageDto.content || []).map(r => {
    const uInfo = userMap.value[r.userId] ?? { userName:'알수없음', userEmail:'알수없음' }

    /* participants: 이름 누락 시 보완 */
    const participants = (r.participantsList || []).map(p => {
      const fallback = userMap.value[p.participantUserId] ?? {}
      return {
        name      : p.participantName || fallback.userName || '알수없음',
        department: p.department      || fallback.department || '',
        team      : p.team            || fallback.team       || ''
      }
    })
    const peopleCount = participants.length + 1

    /* approvers */
    const approvers = (r.approvalLines || []).map(al => ({
      userId        : al.approverUserId,
      name          : al.approverName,
      department    : al.department,
      team          : al.team,
      approvalRole  : al.approvalRole,
      approvalType  : al.approvalRole === 1 ? '결재' : '합의',
      approvalStatus: al.approvalStatus,
      stateText     : al.rejectedAt ? '반려' : al.approvalStatus ? '승인' : '대기',
      rejectedReason: al.rejectedReason
    }))

    const amountNum = +r.amount || 0

    return {
      /* 사용자 */
      userId   : r.userId,
      userName : uInfo.userName,
      userEmail: uInfo.userEmail,

      /* 영수증 */
      receiptId  : r.receiptId,
      receiptCode: r.receiptCode,
      date       : r.submissionDate,
      type       : r.category?.categoryName ?? '미지정',
      categoryId : r.category?.categoryId   ?? null,
      limitPrice : r.category?.limitPrice   ?? null,
      reason     : r.reason,
      amount     : `${amountNum.toLocaleString()}원`,
      amountRaw  : amountNum,
      amountPerPerson: perPerson(amountNum, peopleCount),
      peopleCount,
      participants,
      approvers,
      rejectedReason: approvers.find(a => a.rejectedReason)?.rejectedReason || '',

      status    : (r.status || 'REQUEST').toUpperCase(),
      statusText: statusLabel((r.status || 'REQUEST').toUpperCase()),

      receiptName : r.attachment?.fileName || '영수증 미등록',
      receipt     : r.attachment?.fileUrl  || '',
      approverId  : r.approverId   ?? '',
      approverName: r.approverName ?? ''
    }
  })

  noData.value   = data.value.length === 0
  totalPages.value = pageDto.totalPages || 1
}

/* ──────────────── UI handlers ──────────────── */
function search () {
  currentPage.value = 1
  fetchReceipts(1)
}
function onPageChange (p) {
  currentPage.value = p
  fetchReceipts(p)
}
function onUserSelected (u) { searchUserId.value = u.userId }
function onRowClick (row)  { selectedReceipt.value = row; detailVisible.value = true }

async function handleRowUpdated (row) {
  await ReceiptsRequestApi.forceChangeStatus(row.receiptId, row.status)
  toast.success('상태가 수정되었습니다.')
  fetchReceipts(currentPage.value)
}

/* 삭제 플로우 */
function deleteReceipt (row) {
  receiptToDelete.value      = row
  deleteConfirmVisible.value = true
}
async function deleteNotice () {
  if (!receiptToDelete.value) return
  await ReceiptsApi.deleteReceipt(receiptToDelete.value.receiptId)
  toast.success('영수증이 삭제되었습니다.')
  deleteConfirmVisible.value = false
  receiptToDelete.value      = null
  fetchReceipts(currentPage.value)
}

/* 날짜 보정 */
watch(startDate, v => { if (v > endDate.value) endDate.value = v })
watch(endDate  , v => { if (v < startDate.value) startDate.value = v })

/* ──────────────── mounted ──────────────── */
const userDirStore = useUserDirectoryStore()

onMounted(async () => {
  await loadUsers()
  userDirStore.refresh()

  startDate.value = endDate.value = today()
  fetchReceipts(currentPage.value)
})
</script>

<style scoped>
.content {
  transition: margin-right 0.3s ease;
}
.search-controls {
  margin-bottom: 10px;
}

/* 반응형 테이블/카드 (원본 그대로 유지) */
@media (min-width: 851px) {
  #nameSearch {
    font-size: 1rem;
  }
}

@media (max-width: 850px) {
  .btn-primary {
    font-size: 0.75rem;
    padding: 0.3rem 0.6rem;
    margin-bottom: 10px;
  }
}

@media (min-width: 1920px) {
  .navbar-text {
    font-size: 1.5rem; /* 더 큰 텍스트 크기 */
  }
}
</style>
